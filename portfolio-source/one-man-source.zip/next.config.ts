import type { NextConfig } from "next";
const exporting = process.env.NEXT_STATIC_EXPORT === "1";
const config: NextConfig = {
  ...(exporting ? { output: "export" } : {}),
  assetPrefix: process.env.NEXT_PUBLIC_ASSET_BASE || undefined,
  poweredByHeader: false,
};
export default config;
