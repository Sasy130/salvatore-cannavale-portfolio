import VicePortfolio from '@/components/vice/VicePortfolio';
export default function Page(){return <VicePortfolio/>;}
