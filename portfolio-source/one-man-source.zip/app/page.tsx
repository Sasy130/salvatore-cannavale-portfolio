import CinemaPortfolio from '@/components/cinema/CinemaPortfolio';
export default function Page(){return <CinemaPortfolio/>;}
