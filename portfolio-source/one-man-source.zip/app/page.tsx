import ManifestExperience from "@/components/manifest/ManifestExperience";
export default function Page(){return <ManifestExperience/>;}
