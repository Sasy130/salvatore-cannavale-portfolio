import type { Metadata, Viewport } from "next";
import Runtime from "@/components/reality/Runtime";
import { jsonLd, siteConfig } from "@/lib/site-data";
import "./globals.css";
export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: `${siteConfig.name} — La realtà si riscrive.`,
    template: "%s — ONE MAN",
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    locale: siteConfig.locale,
    url: "/",
    siteName: siteConfig.name,
    title: "ONE MAN — La realtà si riscrive.",
    description: siteConfig.description,
    images: [
      {
        url: `${process.env.NEXT_PUBLIC_ASSET_BASE??""}/og.png`,
        width: 1200,
        height: 630,
        alt: "ONE MAN — La realtà si riscrive.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "ONE MAN — La realtà si riscrive.",
    description: siteConfig.description,
    images: [`${process.env.NEXT_PUBLIC_ASSET_BASE??""}/og.png`],
  },
  robots: { index: true, follow: true },
  icons: { apple: `${process.env.NEXT_PUBLIC_ASSET_BASE??""}/apple-touch-icon.png` },
};
export const viewport: Viewport = {
  themeColor: "#eeede6",
  colorScheme: "light",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="it">
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: jsonLd({
              "@context": "https://schema.org",
              "@type": "WebSite",
              "@id": `${siteConfig.url}/#website`,
              name: siteConfig.name,
              url: siteConfig.url,
              description: siteConfig.description,
              inLanguage: siteConfig.language,
            }),
          }}
        />
        {children}
        <Runtime />
      </body>
    </html>
  );
}
