import GalleryExperience from "@/components/gallery/GalleryExperience";
export default function Page(){return <GalleryExperience/>;}
