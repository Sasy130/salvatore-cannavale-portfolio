import { siteConfig, jsonLd } from "@/lib/site-data";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { projects } from "@/lib/portfolio-data";
import CaseStudy from "@/components/portfolio/CaseStudy";
export const dynamicParams = false;
export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const p = projects.find((p) => p.slug === slug);
  return {
    title: p ? p.title : "Universo non trovato — ONE MAN",
    description: p?.summary,
    alternates: { canonical: `/progetti/${slug}` },
    openGraph: {
      type: "article",
      locale: "it_IT",
      url: `/progetti/${slug}`,
      title: p?.title,
      description: p?.summary,
      images: [{ url: "/og.png", width: 1200, height: 630, alt: p?.title }],
    },
  };
}
export default async function ProjectPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const index = projects.findIndex((p) => p.slug === slug);
  if (index < 0) notFound();
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: jsonLd({
            "@context": "https://schema.org",
            "@type": "CreativeWork",
            name: projects[index].title,
            description: projects[index].description,
            url: `${siteConfig.url}/progetti/${slug}`,
            inLanguage: "it-IT",
            genre: projects[index].category,
            image: siteConfig.url + projects[index].images[0].src,
            isPartOf: { "@id": `${siteConfig.url}/#website` },
          }),
        }}
      />
      <CaseStudy
        key={slug}
        project={projects[index]}
        next={projects[(index + 1) % projects.length]}
      />
    </>
  );
}
