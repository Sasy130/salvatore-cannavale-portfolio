import Link from "next/link";
export default function NotFound() {
  return (
    <main className="contact-section" style={{ minHeight: "100svh" }}>
      <span className="eyebrow">ONE MAN / 404</span>
      <h1
        style={{
          fontSize: "clamp(45px,10vw,140px)",
          lineHeight: 1,
          margin: "60px 0",
        }}
      >
        QUESTA REALTÀ
        <br />
        NON ESISTE.
      </h1>
      <p>La pagina che cerchi non è stata trovata.</p>
      <Link className="action-button" href="/">
        Torna all’inizio ↗
      </Link>
    </main>
  );
}
