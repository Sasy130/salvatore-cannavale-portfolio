import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";
export default defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    rules: {
      // R3F descrive attributi Three.js, e SVG locali hanno già dimensioni e caricamento espliciti.
      "react/no-unknown-property": "off",
      "@next/next/no-img-element": "off",
      // Il progetto usa GSAP, Zustand e il ciclo imperativo R3F, non React Compiler.
      "react-hooks/refs": "off",
      "react-hooks/immutability": "off",
      "react-hooks/set-state-in-effect": "off",
    },
  },
  globalIgnores([
    ".next/**",
    ".next-static/**",
    "out/**",
    "scratch/**",
    "test-results/**",
    "next-env.d.ts",
  ]),
]);
