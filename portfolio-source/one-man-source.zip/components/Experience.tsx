"use client";
import { useVisualMemory } from "@/lib/visual-memory";
import SceneSlot from "./universe/SceneSlot";
import { Component, useEffect, useRef, useState, type ReactNode } from "react";
import gsap from "gsap";
import { useReality } from "@/lib/reality-store";
import { phases, useIntro } from "@/lib/intro-store";
import Portfolio from "./portfolio/Portfolio";

class SceneBoundary extends Component<
  { children: ReactNode; onError: () => void },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}
const copy = {
  IDLE: ["NON DOVEVI", "ARRIVARE FIN QUI.", "Tocca l’impossibile."],
  CONTACT: ["LA MATERIA", "TI SENTE.", "Continua a tenere premuto."],
  FRACTURE: ["OGNI REALTÀ", "HA UNA CREPA.", "Attraversamento in corso."],
  ROOM: ["ORA SEI TU", "A CONTROLLARE.", "Trascina per esplorare."],
  CREATION: [
    "DA UN SOLO UOMO.",
    "INFINITE POSSIBILITÀ.",
    "Trascina il nucleo verso il punto luminoso.",
  ],
  REVEAL: ["ONE MAN", "LA REALTÀ SI RISCRIVE.", "Un nuovo punto di vista."],
  COMPLETE: ["", "", ""],
};
export default function Experience() {
  const phase = useIntro((s) => s.phase),
    energy = useIntro((s) => s.energy),
    reduced = useIntro((s) => s.reduced),
    fallback = useIntro((s) => s.fallback),
    run = useIntro((s) => s.run);
  const [ready, setReady] = useState(false);
  const title = useRef<HTMLDivElement>(null);
  const veil = useRef<HTMLDivElement>(null);
  const skipButton = useRef<HTMLButtonElement>(null);
  const homeTitle = useRef<HTMLHeadingElement>(null);
  const previous = useRef(phase);
  useEffect(() => {
    useVisualMemory.getState().hydrate();
    if (useVisualMemory.getState().memory.introSeen && new URLSearchParams(location.search).get("intro") !== "1") useIntro.getState().skip();
    if (
      [
        "#contenuto",
        "#chi-sono",
        "#progetti",
        "#competenze",
        "#contatti",
        "#universo",
      ].includes(location.hash)
    )
      useIntro.getState().skip();
    if (new URLSearchParams(location.search).get("intro") === "1")
      useIntro.getState().replay();
    const media = matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => useIntro.setState({ reduced: media.matches });
    update();
    media.addEventListener("change", update);
    let supported = false;
    try {
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("webgl2");
      supported = !!context;
      context?.getExtension("WEBGL_lose_context")?.loseContext();
    } catch {}
    useIntro.setState({ fallback: !supported });
    setReady(true);
    let raf = 0,
      last = performance.now();
    const frame = (now: number) => {
      if (!document.hidden) useIntro.getState().tick((now - last) / 1000);
      last = now;
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    const release = () => useIntro.getState().hold(false);
    const visibility = () => {
      last = performance.now();
      if (document.hidden) release();
    };
    window.addEventListener("pointerup", release);
    window.addEventListener("pointercancel", release);
    window.addEventListener("blur", release);
    document.addEventListener("visibilitychange", visibility);
    return () => {
      cancelAnimationFrame(raf);
      media.removeEventListener("change", update);
      window.removeEventListener("pointerup", release);
      window.removeEventListener("pointercancel", release);
      window.removeEventListener("blur", release);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, []);
  useEffect(() => {
    const from = previous.current;
    if (phase === "COMPLETE" && previous.current !== "COMPLETE")
      homeTitle.current?.focus({ preventScroll: true });
    if (phase === "IDLE" && previous.current === "COMPLETE")
      skipButton.current?.focus();
    previous.current = phase;
    const ctx = gsap.context(() => {
      if (veil.current) {
        if (phase === "REVEAL" && !reduced)
          gsap.fromTo(
            veil.current,
            { opacity: 0 },
            { opacity: 1, delay: 3.5, duration: 0.7, ease: "power2.in" },
          );
        else if (phase === "COMPLETE" && from === "REVEAL" && !reduced)
          gsap.fromTo(
            veil.current,
            { opacity: 1 },
            { opacity: 0, duration: 1, ease: "power2.out" },
          );
        else gsap.set(veil.current, { opacity: 0 });
      }
      if (title.current)
        gsap.fromTo(
          title.current,
          { opacity: 0, y: reduced ? 0 : 22 },
          {
            opacity: 1,
            y: 0,
            duration: reduced ? 0.01 : 0.8,
            ease: "power3.out",
          },
        );
    });
    return () => ctx.revert();
  }, [phase, reduced]);
  const keyboard = (event: React.KeyboardEvent) => {
    if (event.target !== event.currentTarget) return;
    const s = useIntro.getState();
    if (["Space", "Enter"].includes(event.code)) {
      event.preventDefault();
      if (s.phase === "IDLE" || s.phase === "CONTACT") s.hold(true);
      else if (s.phase === "CREATION") s.transition("REVEAL");
    }
    if (event.code.startsWith("Arrow") && s.phase === "ROOM") {
      event.preventDefault();
      s.explore(0.23);
    }
  };
  const replay = () => {
    useReality.getState().deactivate();
    history.replaceState(history.state, "", location.pathname);
    useIntro.getState().replay();
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  return (
    <>
      <a
        className="skip-link"
        href={phase === "COMPLETE" ? "#contenuto" : "#comandi"}
      >
        Vai ai comandi
      </a>
      {phase !== "COMPLETE" ? (
        <main
          className="intro"
          data-phase={phase}
          aria-label="La stanza impossibile"
          onKeyDown={keyboard}
          onKeyUp={(e) => {
            if (e.code === "Space" || e.code === "Enter")
              useIntro.getState().hold(false);
          }}
          tabIndex={0}
        >
          <header className="topbar">
            <a
              className="brand"
              href="#contenuto"
              onClick={() => useIntro.getState().skip()}
            >
              ONE MAN
              <span className="brand-dot" />
            </a>
            <span className="top-caption">
              STUDIO INDIPENDENTE
              <br />
              DESIGN · CODICE · VISIONE
            </span>
            <button
              ref={skipButton}
              className="text-button"
              onClick={() => useIntro.getState().skip()}
            >
              Salta introduzione <span>↗</span>
            </button>
          </header>
          <div className="scene">
            {ready && !fallback && !reduced ? (
              <SceneBoundary
                key={run}
                onError={() => useIntro.setState({ fallback: true })}
              >
                <SceneSlot kind="intro" run={run} />
              </SceneBoundary>
            ) : (
              <div className="essential-art" aria-hidden="true">
                <div className="essential-monolith" />
                <i />
                <i />
              </div>
            )}
          </div>
          <div className="cross cross-one" aria-hidden="true">
            +
          </div>
          <div className="cross cross-two" aria-hidden="true">
            +
          </div>
          <div className="scene-meta">
            <span className="status-light" /> ESPERIMENTO 001 <span>/</span> LA
            STANZA IMPOSSIBILE
          </div>
          <div className="intro-copy" ref={title} aria-live="polite">
            <span className="eyebrow">
              {String(phases.indexOf(phase) + 1).padStart(2, "0")} / 06 —{" "}
              {phase === "IDLE"
                ? "IL VUOTO"
                : phase === "CONTACT"
                  ? "IL CONTATTO"
                  : phase === "FRACTURE"
                    ? "LA FRATTURA"
                    : phase === "ROOM"
                      ? "LA STANZA IMPOSSIBILE"
                      : phase === "CREATION"
                        ? "LA CREAZIONE"
                        : "LA RIVELAZIONE"}
            </span>
            <h1>
              {copy[phase][0]}
              <br />
              <span>{copy[phase][1]}</span>
            </h1>
            <p>{copy[phase][2]}</p>
          </div>
          <aside className="side-note">
            LA REALTÀ È SOLO
            <br />
            IL PUNTO DI PARTENZA.
          </aside>
          <div id="comandi" className="interaction-panel">
            {(phase === "IDLE" || phase === "CONTACT") && (
              <>
                <button
                  className="hold-button"
                  aria-label="Tieni premuto per 1,5 secondi per aprire il monolite"
                  onPointerDown={(e) => {
                    e.currentTarget.setPointerCapture(e.pointerId);
                    useIntro.getState().hold(true);
                  }}
                  onPointerUp={() => useIntro.getState().hold(false)}
                  onPointerCancel={() => useIntro.getState().hold(false)}
                  onLostPointerCapture={() => useIntro.getState().hold(false)}
                  onKeyDown={(e) => {
                    if (e.code === "Space" || e.code === "Enter") {
                      e.preventDefault();
                      useIntro.getState().hold(true);
                    }
                  }}
                  onKeyUp={() => useIntro.getState().hold(false)}
                  onBlur={() => useIntro.getState().hold(false)}
                >
                  <span className="contact-icon" aria-hidden="true" />
                  <span>
                    TIENI PREMUTO
                    <span className="button-sub">PER RISCRIVERE LA REALTÀ</span>
                  </span>
                  <span className="hold-time">
                    {Math.round(energy * 100)
                      .toString()
                      .padStart(2, "0")}
                    %
                  </span>
                  <i style={{ width: `${energy * 100}%` }} />
                </button>
                <span className="control-hint">
                  Monolite o pulsante · mouse, dito o barra spaziatrice
                </span>
              </>
            )}
            {phase === "ROOM" && (
              <>
                <button
                  className="action-button"
                  onClick={() => useIntro.getState().explore(0.34)}
                >
                  Ruota la stanza ↔
                </button>
                <span className="control-hint">
                  Trascina la scena o premi tre volte una freccia
                </span>
              </>
            )}
            {phase === "CREATION" && (
              <>
                <button
                  className="action-button"
                  onClick={() => useIntro.getState().transition("REVEAL")}
                >
                  Connetti il nucleo ↗
                </button>
                <span className="control-hint">
                  Trascina nella scena oppure attiva questo comando
                </span>
              </>
            )}
            {(phase === "FRACTURE" || phase === "REVEAL") && (
              <span className="transition-label">
                LO SPAZIO SI STA RISCRIVENDO <span>•••</span>
              </span>
            )}
          </div>
          <footer className="intro-footer">
            <span>
              UN SOLO UOMO.
              <br />
              <strong>INFINITE POSSIBILITÀ.</strong>
            </span>
            <div
              className="phase-track"
              aria-label={`Fase ${phases.indexOf(phase) + 1} di 6`}
            >
              {phases.slice(0, 6).map((p, i) => (
                <span
                  key={p}
                  className={i <= phases.indexOf(phase) ? "active" : ""}
                />
              ))}
            </div>
            <span className="mode-label">
              {fallback
                ? "MODALITÀ ESSENZIALE · WEBGL NON DISPONIBILE"
                : reduced
                  ? "MODALITÀ ESSENZIALE · MOVIMENTO RIDOTTO"
                  : "ESPERIENZA INTERATTIVA 3D"}
              <br />© ONE MAN {new Date().getFullYear()}
            </span>
          </footer>
        </main>
      ) : (
        <Portfolio titleRef={homeTitle} onReplay={replay} />
      )}
      <div ref={veil} className="transition-veil" aria-hidden="true" />
    </>
  );
}
