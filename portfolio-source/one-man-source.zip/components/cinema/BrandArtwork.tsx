export default function BrandArtwork({id,variant=0}:{id:string;variant?:number}){
 return <div id={id} className={`cp-brand-art cp-stage-art cp-stage-art-${variant}`} role="img" aria-label="Composizione tipografica ONE MAN con tagli di luce rosa e turchese"><div className="cp-stage-depth" aria-hidden="true"><i/><i/><i/></div><div className="cp-stage-beam" aria-hidden="true"/><div className="cp-stage-type" aria-hidden="true"><span>CREA.</span><span>OSA.</span></div><div className="cp-stage-credit" aria-hidden="true"><span>VISIONE INDIPENDENTE</span><span>DESIGN + CODICE</span></div></div>;
}
