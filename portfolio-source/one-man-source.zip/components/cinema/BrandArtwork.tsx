"use client";
import {useLayoutEffect,useRef,useState} from 'react';
import gsap from 'gsap';
const rows=64;
function line(row:number,phase:number){
 const t=row/(rows-1)*2-1;let d='';
 for(let j=0;j<=40;j++){const u=j/40*2-1;const x=400+u*350+Math.sin(t*3+phase*.5)*(1-u*u)*phase*22;const y=300+t*230*Math.cos(u*1.25+phase*.25)+Math.sin(u*3.8+t*2.1+phase*.9)*86*(1-t*t);d+=(j?'L':'M')+x.toFixed(2)+','+y.toFixed(2);}
 return d;
}
export default function BrandArtwork({id,variant=0}:{id:string;variant?:number}){
 const root=useRef<HTMLDivElement>(null);const [form,setForm]=useState(variant%2);const interactive=id==='hero-brand';
 useLayoutEffect(()=>{const paths=root.current?.querySelectorAll('path');if(!paths)return;const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;const tween=gsap.to(paths,{attr:{d:(i:number)=>line(i,form)},duration:reduced?0:1.15,stagger:reduced?0:.003,ease:'power2.inOut'});return()=>{tween.kill();};},[form]);
 return <div id={id} ref={root} className="cp-brand-art cp-tension" data-form={form} onPointerMove={e=>{const r=e.currentTarget.getBoundingClientRect();e.currentTarget.style.setProperty('--art-x',String((e.clientX-r.left)/r.width-.5));e.currentTarget.style.setProperty('--art-y',String((e.clientY-r.top)/r.height-.5));}} onPointerLeave={e=>{e.currentTarget.style.setProperty('--art-x','0');e.currentTarget.style.setProperty('--art-y','0');}}><svg id={`${id}-surface`} viewBox="0 0 800 600" role="img" aria-label="Tensione: opera grafica generativa composta da sessantaquattro linee che si trasformano"><g>{Array.from({length:rows},(_,i)=><path key={i} d={line(i,variant%2)} fill="none" stroke={i%8===0?'#f0eee7':'#171715'} strokeWidth={i%8===0?1.8:1.15}/>)}</g></svg><span className="cp-art-coordinate" aria-hidden="true">FIG. 01 — TENSIONE</span>{interactive&&<button className="cp-art-control" aria-controls={`${id}-surface`} aria-pressed={form===1} onClick={()=>setForm(f=>1-f)}>Riscrivi la forma <span aria-hidden="true">↗</span></button>}</div>;
}
