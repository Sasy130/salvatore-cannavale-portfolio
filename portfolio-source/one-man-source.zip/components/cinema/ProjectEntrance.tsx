"use client";
import {useLayoutEffect,useRef} from 'react';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {projects} from '@/lib/restored-projects';
import CoastArt from './CoastArt';
export default function ProjectEntrance(){
 const root=useRef<HTMLElement>(null);
 useLayoutEffect(()=>{
  gsap.registerPlugin(ScrollTrigger);const media=gsap.matchMedia();
  media.add('(prefers-reduced-motion: no-preference)',()=>{const el=root.current;if(!el)return;el.dataset.animated='true';const ctx=gsap.context(()=>{
   const tl=gsap.timeline({scrollTrigger:{trigger:el,start:'top top',end:'bottom bottom',scrub:.45}});
   tl.fromTo('.cp-entry-screen',{clipPath:'circle(0% at 50% 50%)'},{clipPath:'circle(76% at 50% 50%)',duration:1,ease:'power2.inOut'},0)
    .to('.cp-entry-sun',{scale:2.5,rotation:12,opacity:0,duration:.75,ease:'power2.in'},0)
    .fromTo('.cp-entry-screen img',{scale:1.3},{scale:1,duration:1,ease:'power2.out'},0)
    .fromTo('.cp-entry-title em',{xPercent:-8},{xPercent:0,duration:1,ease:'power2.inOut'},0);
  },el);return()=>{ctx.revert();delete el.dataset.animated;};});return()=>media.revert();
 },[]);
 return <section id="universi" ref={root} className="cp-entry" aria-labelledby="cp-entry-title"><div className="cp-entry-stage"><p className="cp-entry-kicker">DALL’IMMAGINAZIONE ALLO SCHERMO</p><h2 className="cp-entry-title" id="cp-entry-title">LE IDEE<br/><em>PRENDONO VITA.</em></h2><div className="cp-entry-window"><div className="cp-entry-sun" aria-hidden="true"><CoastArt sunId="entry-sun"/></div><figure className="cp-entry-screen"><img src={projects[0].image} alt={projects[0].alt} loading="lazy"/></figure></div><div className="cp-entry-footer"><p>{projects.length} progetti da attraversare.<br/>Il prossimo movimento è tuo.</p><a href="#progetti">Entra nei progetti <span aria-hidden="true">↓</span></a></div></div></section>;
}
