"use client";
import {Suspense,useEffect,useMemo,useRef,type RefObject} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import {useTexture} from '@react-three/drei';
import * as THREE from 'three';
import {projects} from '@/lib/restored-projects';
export interface PreviewMotion{cursor:number;x:number;y:number}
const vertex=`
uniform float uBend;uniform vec2 uPointer;varying vec2 vUv;varying vec3 vView;
void main(){vUv=uv;vec3 p=position;
p.z+=sin(uv.x*3.14159265)*uBend*.12;
p.y+=sin(uv.x*6.2831853)*uPointer.y*.015;
p.x+=sin(uv.y*3.14159265)*uPointer.x*.015;
vec4 view=modelViewMatrix*vec4(p,1.);vView=view.xyz;gl_Position=projectionMatrix*view;}`;
const fragment=`
uniform sampler2D uMap;uniform vec2 uCrop;uniform float uReveal;varying vec2 vUv;varying vec3 vView;
void main(){float front=vUv.y-(1.-uReveal+sin(vUv.x*3.14159265)*sin(uReveal*3.14159265)*.055);if(front<0.)discard;
vec2 uv=(vUv-.5)/uCrop+.5;vec3 c=vec3(.969,.937,.898);if(uv.x>=0.&&uv.x<=1.&&uv.y>=0.&&uv.y<=1.)c=texture2D(uMap,uv).rgb;
vec3 n=normalize(cross(dFdx(vView),dFdy(vView)));
float light=.92+.08*abs(dot(n,normalize(vec3(-.25,.4,1.))));
gl_FragColor=vec4(c*light,1.);
#include <colorspace_fragment>
}`;
function Reel({motion,onReady}:{motion:RefObject<PreviewMotion>;onReady:()=>void}){
 const originals=useTexture(projects.map(p=>p.image));const {viewport,size,gl}=useThree();
 const textures=useMemo(()=>originals.map(t=>{t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;}),[originals]);
 const geometry=useMemo(()=>new THREE.PlaneGeometry(1,1,size.width<700?24:40,12),[size.width]);
 const crops=useMemo(()=>textures.map(t=>{const image=t.image as {width:number;height:number};const a=image.width/image.height,plane=viewport.width/viewport.height;return new THREE.Vector2(a<plane?a/plane:1,a>plane?plane/a:1);}),[textures,viewport.width,viewport.height]);
 const materials=useMemo(()=>[0,1].map(()=>new THREE.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,side:THREE.DoubleSide,toneMapped:false,uniforms:{uMap:{value:textures[0]},uCrop:{value:new THREE.Vector2(1,1)},uBend:{value:0},uReveal:{value:1},uPointer:{value:new THREE.Vector2()}}})),[textures]);
 const outgoing=useRef<THREE.Mesh>(null),incoming=useRef<THREE.Mesh>(null),announced=useRef(false);
 useEffect(()=>()=>geometry.dispose(),[geometry]);useEffect(()=>()=>materials.forEach(m=>m.dispose()),[materials]);
 useFrame(()=>{const s=motion.current;const cursor=THREE.MathUtils.clamp(s.cursor,0,textures.length-1);const index=Math.floor(cursor),phase=THREE.MathUtils.smoothstep(cursor-index,.22,.78);const width=viewport.width,height=viewport.height;
  const update=(mesh:THREE.Mesh|null,slot:number,i:number)=>{if(!mesh)return;const pulse=Math.sin(phase*Math.PI),reveal=slot===0?1:phase;mesh.visible=slot===0?phase<1:phase>0;mesh.position.set(0,0,slot===1?pulse*.12:-pulse*.1);mesh.rotation.set(-s.y*.045,s.x*.055,slot===0?-pulse*.018:0);const scale=slot===0?1+pulse*.045:1;mesh.scale.set(width*scale,height*scale,Math.min(width,height));const u=materials[slot].uniforms;u.uMap.value=textures[i];u.uCrop.value.copy(crops[i]);u.uReveal.value=reveal;u.uBend.value=slot===0?0:pulse*.035;u.uPointer.value.set(s.x,s.y);};
  update(outgoing.current,0,index);update(incoming.current,1,Math.min(index+1,textures.length-1));
  gl.domElement.dataset.warpCursor=cursor.toFixed(2);gl.domElement.dataset.reelPhase=phase.toFixed(2);gl.domElement.dataset.reelPanels='2';gl.domElement.dataset.previewMode='studio';
  if(!announced.current){announced.current=true;queueMicrotask(onReady);}
 });
 return <><mesh ref={outgoing} geometry={geometry} material={materials[0]} frustumCulled={false}/><mesh ref={incoming} geometry={geometry} material={materials[1]} frustumCulled={false}/></>;
}
export default function WarpPreview({motion,playing,onReady,onFailure}:{motion:RefObject<PreviewMotion>;playing:boolean;onReady:()=>void;onFailure:()=>void}){
 const cleanup=useRef<(()=>void)|null>(null);useEffect(()=>()=>{cleanup.current?.();},[]);
 return <Canvas camera={{position:[0,0,8],fov:40,near:.1,far:40}} dpr={[1,1.5]} frameloop={playing?'always':'demand'} gl={{alpha:true,antialias:false,powerPreference:'low-power'}} onCreated={({gl})=>{const lost=(e:Event)=>{e.preventDefault();onFailure();};gl.domElement.addEventListener('webglcontextlost',lost);cleanup.current=()=>gl.domElement.removeEventListener('webglcontextlost',lost);gl.setClearColor('#f7efe5',0);gl.debug.onShaderError=()=>queueMicrotask(onFailure);}}><Suspense fallback={null}><Reel motion={motion} onReady={onReady}/></Suspense></Canvas>;
}
