"use client";
import {Suspense,useEffect,useMemo,useRef,type RefObject} from 'react';
import {Canvas,useFrame,useThree} from '@react-three/fiber';
import {useTexture} from '@react-three/drei';
import * as THREE from 'three';
import {projects} from '@/lib/restored-projects';
export interface PreviewMotion{cursor:number;x:number;y:number}
const vertex=`
uniform float uBend;uniform vec2 uPointer;varying vec2 vUv;varying vec3 vView;
void main(){vUv=uv;vec3 p=position;
float curl=sin(uv.x*3.14159265)*uBend;
p.z+=curl*.38;
p.y+=curl*.09+sin(uv.x*6.2831853)*uPointer.y*.025;
p.x+=sin(uv.y*3.14159265)*uPointer.x*.035;
vec4 view=modelViewMatrix*vec4(p,1.);vView=view.xyz;gl_Position=projectionMatrix*view;}`;
const fragment=`
uniform sampler2D uMapA;uniform sampler2D uMapB;uniform vec2 uCropA;uniform vec2 uCropB;uniform float uBlend;uniform float uBend;
varying vec2 vUv;varying vec3 vView;
void main(){
vec2 a=(vUv-.5)*uCropA+.5;vec2 b=(vUv-.5)*uCropB+.5;
float edge=uBlend*1.24-.12;
float wave=sin(vUv.y*6.2831853+uBlend*3.14159265)*sin(uBlend*3.14159265)*.045;
float mask=1.-smoothstep(edge-.018,edge+.018,vUv.x+wave);
vec3 c=mix(texture2D(uMapA,a).rgb,texture2D(uMapB,b).rgb,mask);
vec3 n=normalize(cross(dFdx(vView),dFdy(vView)));
float lighting=.88+.12*max(dot(n,normalize(vec3(-.25,.4,1.))),0.);
float ridge=exp(-abs(vUv.x+wave-edge)*85.)*sin(uBlend*3.14159265)*.025;
gl_FragColor=vec4(c*lighting+ridge*vec3(.8,.35,.55),1.);
#include <colorspace_fragment>
}`;
function Surface({motion,onReady}:{motion:RefObject<PreviewMotion>;onReady:()=>void}){
 const originals=useTexture(projects.map(p=>p.image));const {viewport,size,gl}=useThree();
 // Le tredici texture appartengono alla cache del loader; nessuna copia GPU aggiuntiva.
 const textures=useMemo(()=>originals.map(t=>{t.colorSpace=THREE.SRGBColorSpace;t.needsUpdate=true;return t;}),[originals]);
 const geometry=useMemo(()=>new THREE.PlaneGeometry(1,1,size.width<700?32:56,24),[size.width]);
 const crops=useMemo(()=>textures.map(t=>{const image=t.image as {width:number;height:number};const a=image.width/image.height,plane=viewport.width/viewport.height;return new THREE.Vector2(a>plane?plane/a:1,a<plane?a/plane:1);}),[textures,viewport.width,viewport.height]);
 const uniforms=useMemo(()=>({uMapA:{value:textures[0]},uMapB:{value:textures[1]},uCropA:{value:new THREE.Vector2(1,1)},uCropB:{value:new THREE.Vector2(1,1)},uBlend:{value:0},uBend:{value:0},uPointer:{value:new THREE.Vector2()}}),[textures]);
 const material=useMemo(()=>new THREE.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,uniforms,side:THREE.DoubleSide,toneMapped:false}),[uniforms]);
 const mesh=useRef<THREE.Mesh>(null),announced=useRef(false);
 useEffect(()=>()=>geometry.dispose(),[geometry]);useEffect(()=>()=>material.dispose(),[material]);
 useFrame(()=>{const s=motion.current;const cursor=THREE.MathUtils.clamp(s.cursor,0,textures.length-1);const i=Math.floor(cursor),next=Math.min(i+1,textures.length-1),blend=THREE.MathUtils.smoothstep(cursor-i,.12,.88);
 uniforms.uMapA.value=textures[i];uniforms.uMapB.value=textures[next];uniforms.uCropA.value.copy(crops[i]);uniforms.uCropB.value.copy(crops[next]);uniforms.uBlend.value=blend;uniforms.uBend.value=Math.sin(blend*Math.PI)*1.15+Math.hypot(s.x,s.y)*.25;uniforms.uPointer.value.set(s.x,s.y);
 if(mesh.current){mesh.current.scale.set(viewport.width*.97,viewport.height*.94,Math.min(viewport.width,viewport.height));mesh.current.rotation.set(-s.y*.13,s.x*.18,0);}
 gl.domElement.dataset.warpCursor=cursor.toFixed(2);gl.domElement.dataset.warpBend=uniforms.uBend.value.toFixed(2);
 if(!announced.current){announced.current=true;queueMicrotask(onReady);}
 });
 return <mesh ref={mesh} geometry={geometry} material={material} frustumCulled={false}/>;
}
export default function WarpPreview({motion,playing,onReady,onFailure}:{motion:RefObject<PreviewMotion>;playing:boolean;onReady:()=>void;onFailure:()=>void}){
 const cleanup=useRef<(()=>void)|null>(null);
 useEffect(()=>()=>{cleanup.current?.();},[]);
 return <Canvas orthographic camera={{position:[0,0,8],zoom:100,near:.1,far:30}} dpr={[1,1.5]} frameloop={playing?'always':'demand'} gl={{alpha:true,antialias:false,powerPreference:'low-power'}} onCreated={({gl})=>{const lost=(e:Event)=>{e.preventDefault();onFailure();};gl.domElement.addEventListener('webglcontextlost',lost);cleanup.current=()=>gl.domElement.removeEventListener('webglcontextlost',lost);gl.setClearColor('#080808',0);gl.debug.onShaderError=()=>queueMicrotask(onFailure);}}><Suspense fallback={null}><Surface motion={motion} onReady={onReady}/></Suspense></Canvas>;
}
