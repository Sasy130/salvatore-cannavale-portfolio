"use client";
import SceneSlot from "@/components/universe/SceneSlot";
import { useEffect, useRef, useState } from "react";
import { useReality } from "@/lib/reality-store";
import { usePerformance } from "@/lib/performance-store";
import SceneBoundary from "./SceneBoundary";
import { usePortfolioScene, type EnvironmentName } from "@/lib/portfolio-store";

export default function SceneLayer({
  environment,
  detail = false,
  paused = false,
  amplitude = 0.6,
  onModeChange,
}: {
  environment?: EnvironmentName;
  detail?: boolean;
  paused?: boolean;
  amplitude?: number;
  onModeChange?: (live: boolean) => void;
}) {
  const secret = useReality((s) => s.secret);
  const capability = usePerformance((s) => s.webgl);
  const section = usePortfolioScene((s) => s.section);
  const sceneEnvironment = usePortfolioScene((s) => s.environment);
  const [near, setNear] = useState(!detail);
  const fallbackName =
    environment ??
    (section === "contatti"
      ? "portal"
      : section === "competenze"
        ? "orbit"
        : section === "progetti"
          ? sceneEnvironment
          : "room");
  const [enabled, setEnabled] = useState(false),
    [failed, setFailed] = useState(false),
    [visible, setVisible] = useState(true);
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    onModeChange?.(enabled && capability && !failed && near);
  }, [enabled, capability, failed, near, onModeChange]);
  useEffect(() => {
    const media = matchMedia("(prefers-reduced-motion: reduce)");
    const check = () => {
      if (media.matches) {
        setEnabled(false);
        return;
      }
      try {
        const canvas = document.createElement("canvas");
        const gl = canvas.getContext("webgl2");
        setEnabled(!!gl);
        gl?.getExtension("WEBGL_lose_context")?.loseContext();
      } catch {
        setFailed(true);
      }
    };
    check();
    media.addEventListener("change", check);
    const visibility = () => setVisible(!document.hidden);
    document.addEventListener("visibilitychange", visibility);
    const observer = new IntersectionObserver(
      (entries) => {
        setVisible(entries[0].isIntersecting && !document.hidden);
        if (entries[0].isIntersecting) setNear(true);
      },
      { rootMargin: "150px" },
    );
    if (host.current) observer.observe(host.current);
    return () => {
      media.removeEventListener("change", check);
      document.removeEventListener("visibilitychange", visibility);
      observer.disconnect();
    };
  }, []);
  return (
    <div
      ref={host}
      className={detail ? "world-layer world-detail" : "world-layer"}
      aria-hidden="true"
    >
      {enabled && capability && !failed && near ? (
        <SceneBoundary
          onError={() => {
            setFailed(true);
            usePerformance.setState({ webgl: false });
          }}
        >
          <SceneSlot
            kind="world"
            environment={environment}
            detail={detail}
            paused={paused}
            amplitude={amplitude}
            visible={visible && !secret}
          />
        </SceneBoundary>
      ) : (
        <div className={`world-fallback fallback-${fallbackName}`}>
          <i />
          <i />
          <i />
        </div>
      )}
    </div>
  );
}
