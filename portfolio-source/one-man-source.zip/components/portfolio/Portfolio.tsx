"use client";
import { useLayoutEffect, useRef, type RefObject } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { identity, projects } from "@/lib/portfolio-data";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useReality } from "@/lib/reality-store";
import RealityControl from "@/components/reality/RealityControl";
import UniverseOverlay from "@/components/universe/UniverseOverlay";
import LivingControls from "@/components/universe/LivingControls";
import Navigation from "./Navigation";
import SceneLayer from "./SceneLayer";
import PortalLink from "./PortalLink";
import SkillSystem from "./SkillSystem";
import ContactPanel from "./ContactPanel";
import "./portfolio.css";
function SectionLabel({
  number,
  children,
}: {
  number: string;
  children: React.ReactNode;
}) {
  return (
    <div className="section-label">
      <span>{number}</span>
      <span>{children}</span>
      <i />
    </div>
  );
}
export default function Portfolio({
  titleRef,
  onReplay,
}: {
  titleRef: RefObject<HTMLHeadingElement | null>;
  onReplay: () => void;
}) {
  const root = useRef<HTMLElement>(null);
  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    usePortfolioScene.setState({
      progress: 0,
      section: "contenuto",
      environment: "room",
      opening: false,
    });
    const mm = gsap.matchMedia();
    const ctx = gsap.context(() => {
      const ids = [
        "contenuto",
        "chi-sono",
        "progetti",
        "competenze",
        "contatti",
        "universo",
      ];
      ids.forEach((id) =>
        ScrollTrigger.create({
          trigger: id === "contenuto" ? ".portfolio-hero" : `#${id}`,
          start: "top 60%",
          end: "bottom 40%",
          onEnter: () => usePortfolioScene.setState({ section: id }),
          onEnterBack: () => usePortfolioScene.setState({ section: id }),
        }),
      );
      ScrollTrigger.create({
        trigger: root.current,
        start: "top top",
        end: "bottom bottom",
        onUpdate: (s) => usePortfolioScene.setState({ progress: s.progress }),
      });
      projects.forEach((p) =>
        ScrollTrigger.create({
          trigger: `#portale-${p.slug}`,
          start: "top 65%",
          end: "bottom 35%",
          onEnter: () =>
            usePortfolioScene.setState({ environment: p.environment }),
          onEnterBack: () =>
            usePortfolioScene.setState({ environment: p.environment }),
        }),
      );
      mm.add("(prefers-reduced-motion: no-preference)", () => {
        const mobile = innerWidth < 768;
        gsap.fromTo(
          ".hero-glyph",
          { yPercent: 115, rotateX: -65, opacity: 0 },
          {
            yPercent: 0,
            rotateX: 0,
            opacity: 1,
            duration: 1.1,
            stagger: 0.055,
            ease: "power4.out",
          },
        );
        gsap.to(".hero-line:first-child .hero-glyph", {
          y: (i: number) => (i % 2 ? 50 : -30),
          rotation: (i: number) => (i % 2 ? 9 : -8),
          x: (i: number) => (i - 2) * 15,
          stagger: 0.025,
          scrollTrigger: {
            trigger: ".portfolio-hero",
            start: "top top",
            end: "bottom 15%",
            scrub: 1,
          },
        });
        gsap.to(".hero-coordinate", {
          y: mobile ? -30 : -120,
          scrollTrigger: {
            trigger: ".portfolio-hero",
            scrub: 1,
            start: "top top",
            end: "bottom top",
          },
        });
        gsap.from(".about-line span", {
          yPercent: 100,
          rotate: 4,
          stagger: 0.08,
          duration: 1,
          scrollTrigger: { trigger: "#chi-sono", start: "top 75%" },
        });
        gsap.to(".about-orbit", {
          rotation: 120,
          scale: 1.15,
          scrollTrigger: {
            trigger: "#chi-sono",
            start: "top bottom",
            end: "bottom top",
            scrub: 1,
          },
        });
        gsap.utils
          .toArray<HTMLElement>(".universe-project")
          .forEach((panel, i) => {
            gsap.fromTo(
              panel,
              { rotationY: mobile ? 0 : i % 2 ? 8 : -8, z: mobile ? 0 : -100 },
              {
                rotationY: 0,
                z: 0,
                scrollTrigger: {
                  trigger: panel,
                  start: "top 90%",
                  end: "top 25%",
                  scrub: 1,
                },
              },
            );
            gsap.fromTo(
              panel.querySelector(".portal-image"),
              { yPercent: mobile ? -3 : -9, scale: 1.13 },
              {
                yPercent: mobile ? 3 : 9,
                scale: 1.06,
                scrollTrigger: {
                  trigger: panel,
                  start: "top bottom",
                  end: "bottom top",
                  scrub: 1,
                },
              },
            );
          });
        gsap.fromTo(
          ".environment-divider span",
          { xPercent: mobile ? 10 : 35 },
          {
            xPercent: mobile ? -10 : -35,
            scrollTrigger: {
              trigger: ".environment-divider",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          },
        );
        gsap.fromTo(
          ".contact-heading .kinetic-word",
          { y: 80, opacity: 0.25 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.1,
            scrollTrigger: {
              trigger: "#contatti",
              start: "top 80%",
              end: "top 15%",
              scrub: 1,
            },
          },
        );
      });
    }, root);
    let disposed = false;
    const refresh = () => {
      if (!disposed) ScrollTrigger.refresh();
    };
    refresh();
    if (location.hash)
      document
        .getElementById(location.hash.slice(1))
        ?.scrollIntoView({ behavior: "instant" });
    const frame = requestAnimationFrame(refresh);
    document.fonts.ready.then(refresh);
    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      mm.revert();
      ctx.revert();
      usePortfolioScene.setState({ opening: false });
    };
  }, []);
  const pointer = (e: React.PointerEvent<HTMLElement>) => {
    if (
      e.pointerType !== "mouse" ||
      matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const rect = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty(
      "--px",
      `${((e.clientX - rect.left) / rect.width - 0.5) * 2}`,
    );
    e.currentTarget.style.setProperty(
      "--py",
      `${((e.clientY - rect.top) / rect.height - 0.5) * 2}`,
    );
  };
  return (
    <main id="contenuto" className="portfolio" ref={root}>
      <Navigation />
      <RealityControl />
      <SceneLayer />
      <section className="portfolio-hero" aria-labelledby="portfolio-title">
        <div className="hero-topline">
          <span className="eyebrow">IDENTITÀ CREATIVA INDIPENDENTE</span>
          <span className="tiny-label">
            NATO NELL’IMMAGINAZIONE
            <br />
            DISPONIBILE NELLA REALTÀ
          </span>
        </div>
        <h1
          id="portfolio-title"
          ref={titleRef}
          tabIndex={-1}
          aria-label="ONE MAN"
          onPointerDown={() => {
            if (useReality.getState().active) useReality.getState().fragment();
          }}
        >
          <span className="hero-line" aria-hidden="true">
            {"ONE".split("").map((l, i) => (
              <span className="hero-glyph" key={i}>
                {l}
              </span>
            ))}
          </span>
          <span className="hero-line" aria-hidden="true">
            {"MAN".split("").map((l, i) => (
              <span className="hero-glyph" key={i}>
                {l}
              </span>
            ))}
          </span>
          <span className="hero-asterisk" aria-hidden="true">
            ✳︎
          </span>
        </h1>
        <button
          className="type-trigger"
          onClick={() => useReality.getState().fragment()}
          aria-controls="portfolio-title"
        >
          Tocca la tipografia · frammenta ONE MAN ↗
        </button>
        <div className="hero-coordinate" aria-hidden="true">
          <span>OGGETTO 001</span>
          <i />
          MATERIA IN CONTINUA RISCRITTURA
        </div>
        <div className="portfolio-hero-bottom">
          <p>
            LA REALTÀ
            <br />
            SI RISCRIVE.
          </p>
          <div>
            <span>
              Un solo creatore. Design, codice
              <br />e mondi ancora da immaginare.
            </span>
            <a className="explore-button" href="#progetti">
              Esplora i progetti <b aria-hidden="true">↗</b>
            </a>
          </div>
          <a
            className="scroll-cue"
            href="#chi-sono"
            aria-label="Scorri alla sezione Chi sono"
          >
            <i />
            <span>SCOPRI</span>
          </a>
        </div>
        <div className="hero-baseline">
          <span>NON UN SITO. UN UNIVERSO.</span>
          <span>SCORRI PER CAMBIARE PROSPETTIVA ↓</span>
        </div>
      </section>
      <section
        id="chi-sono"
        className="about-universe section-space"
        onPointerMove={pointer}
        onPointerLeave={(e) => {
          e.currentTarget.style.setProperty("--px", "0");
          e.currentTarget.style.setProperty("--py", "0");
        }}
      >
        <SectionLabel number="01">DIETRO ONE MAN</SectionLabel>
        <div className="about-orbit" aria-hidden="true">
          <i />
          <i />
          <span>1</span>
        </div>
        <h2 className="about-heading">
          <span className="about-line">
            <span>UN SOLO</span>
          </span>
          <span className="about-line">
            <span>CREATORE.</span>
          </span>
          <span className="about-line quiet-line">
            <span>NESSUN LIMITE</span>
          </span>
          <span className="about-line quiet-line">
            <span>ALL’IMMAGINAZIONE.</span>
          </span>
        </h2>
        <div className="about-editorial">
          <span className="tiny-label">
            UNA PERSONA.
            <br />
            MOLTEPLICI DIMENSIONI.
          </span>
          <div>
            <p>{identity.bio}</p>
            <p>{identity.approach}</p>
          </div>
          <span className="about-signature reality-body">
            ONE
            <br />
            MAN<span>↗</span>
          </span>
        </div>
      </section>
      <div className="environment-divider" aria-hidden="true">
        <span>ALTRE FORME DI REALTÀ / ALTRE FORME DI REALTÀ /</span>
      </div>
      <section id="progetti" className="project-universes section-space">
        <SectionLabel number="02">UNIVERSI DIGITALI</SectionLabel>
        <div className="projects-heading">
          <h2>
            OGNI PROGETTO.
            <br />
            <span>UN ALTROVE.</span>
          </h2>
          <p>
            Tre ricerche personali.
            <br />
            Nessun mondo è uguale al precedente.
          </p>
        </div>
        <div className="portal-gallery">
          {projects.map((project, i) => (
            <article
              id={`portale-${project.slug}`}
              key={project.slug}
              className={`universe-project portal-${project.environment}`}
              style={{ "--accent": project.accent } as React.CSSProperties}
            >
              <div className="project-index">
                <span>UNIVERSO / {project.number}</span>
                <span>{project.category}</span>
              </div>
              <PortalLink
                href={`/progetti/${project.slug}`}
                className="portal-link"
                label={`Esplora ${project.title}`}
              >
                <div
                  className="portal-perspective reality-body"
                  onPointerMove={pointer}
                  onPointerLeave={(e) => {
                    e.currentTarget.style.setProperty("--px", "0");
                    e.currentTarget.style.setProperty("--py", "0");
                  }}
                >
                  <div className="portal-visual" data-portal-art>
                    <img
                      className="portal-image"
                      src={project.images[0].src}
                      alt={project.images[0].alt}
                      width={1440}
                      height={1000}
                      loading="lazy"
                    />
                    <div className="portal-crosshair" aria-hidden="true" />
                    <span className="portal-caption">
                      ENTRA NELL’UNIVERSO <b>↗</b>
                    </span>
                    <div className="portal-description">
                      <span>RICERCA PERSONALE / 0{i + 1}</span>
                      <p>{project.summary}</p>
                    </div>
                  </div>
                </div>
                <div className="portal-title">
                  <h3>{project.title}</h3>
                  <span aria-hidden="true">↗</span>
                </div>
              </PortalLink>
              <p className="mobile-project-description">{project.summary}</p>
            </article>
          ))}
        </div>
      </section>
      <section id="competenze" className="engine-universe section-space">
        <SectionLabel number="03">IL MOTORE</SectionLabel>
        <div className="engine-heading">
          <h2>
            IL CODICE È<br />
            <span>SOLO L’INIZIO.</span>
          </h2>
          <p>
            Ogni connessione apre una possibilità.
            <br />
            Seleziona un nodo per esplorare.
          </p>
        </div>
        <SkillSystem />
      </section>
      <LivingControls />
      <UniverseOverlay />
      <section id="contatti" className="final-universe section-space">
        <SectionLabel number="04">IL PORTALE FINALE</SectionLabel>
        <div className="contact-heading">
          <h2>
            <span className="kinetic-word">DIAMO FORMA</span>
            <span className="kinetic-word">
              ALL’<em>IMPOSSIBILE.</em>
            </span>
          </h2>
          <span className="contact-orbit-label" aria-hidden="true">
            IL PROSSIMO UNIVERSO
            <br />
            INIZIA DA UNA CONVERSAZIONE.
          </span>
        </div>
        <ContactPanel />
        <div className="final-actions">
          <button className="outline-button" onClick={onReplay}>
            Rivivi l’introduzione ↗
          </button>
          <a href="#contenuto">Torna all’inizio ↑</a>
        </div>
      </section>
      <footer className="portfolio-footer">
        <span className="brand">
          ONE MAN
          <span className="brand-dot" />
        </span>
        <span>UN SOLO CREATORE. INFINITE POSSIBILITÀ.</span>
        <span>© {new Date().getFullYear()} ONE MAN</span>
      </footer>
    </main>
  );
}
