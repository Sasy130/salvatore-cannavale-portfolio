"use client";
import { useState } from "react";
import { skills } from "@/lib/portfolio-data";
export default function SkillSystem() {
  const [selected, setSelected] = useState(skills[0].id);
  const skill = skills.find((s) => s.id === selected)!;
  return (
    <div className="skill-system">
      <div className="node-map" role="group" aria-label="Esplora le competenze">
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <circle cx="50" cy="50" r="35" />
          {skills.map((s) => (
            <path
              key={s.id}
              d={`M50 50L${s.x} ${s.y}`}
              className={selected === s.id ? "selected" : ""}
            />
          ))}
        </svg>
        <div className="node-core" aria-hidden="true">
          OM<span>IL MOTORE</span>
        </div>
        {skills.map((s, i) => (
          <button
            key={s.id}
            className={`skill-node ${selected === s.id ? "is-selected" : ""}`}
            style={
              {
                "--node-x": `${s.x}%`,
                "--node-y": `${s.y}%`,
              } as React.CSSProperties
            }
            onClick={() => setSelected(s.id)}
            aria-pressed={selected === s.id}
            aria-controls="skill-detail"
          >
            <i aria-hidden="true" />
            <small>0{i + 1}</small>
            <span>{s.label}</span>
          </button>
        ))}
      </div>
      <div
        className="mobile-skill-list"
        role="group"
        aria-label="Esplora le competenze"
      >
        {skills.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setSelected(s.id)}
            aria-pressed={selected === s.id}
            aria-controls="skill-detail"
          >
            <small>0{i + 1}</small>
            <span>{s.label}</span>
            <i aria-hidden="true" />
          </button>
        ))}
      </div>
      <div
        id="skill-detail"
        className="skill-detail"
        aria-live="polite"
        aria-atomic="true"
      >
        <span className="eyebrow">{skill.tag} / SISTEMA APERTO</span>
        <h3>{skill.label}</h3>
        <p>{skill.description}</p>
        <span className="skill-tools">{skill.tools}</span>
        <p className="honesty-note">
          Ambiti e strumenti esplorati in questo portfolio. Nessun livello o
          certificazione dichiarati.
        </p>
      </div>
    </div>
  );
}
