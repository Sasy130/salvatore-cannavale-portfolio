"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, type ReactNode } from "react";
import gsap from "gsap";
import { usePerformance } from "@/lib/performance-store";
import { beginInteraction, endInteraction } from "@/lib/interaction-orchestrator";
import { usePortfolioScene } from "@/lib/portfolio-store";
export default function PortalLink({
  href,
  children,
  className = "",
  label,
}: {
  href: string;
  children: ReactNode;
  className?: string;
  label?: string;
}) {
  const router = useRouter();
  const anchor = useRef<HTMLAnchorElement>(null),
    flight = useRef<HTMLElement | null>(null),
    tween = useRef<gsap.core.Tween | null>(null),
    timer = useRef<ReturnType<typeof setTimeout> | null>(null),
    busy = useRef(false),
    navigated = useRef(false);
  useEffect(() => {
    const link = anchor.current;
    link?.setAttribute("data-portal-state", "idle");
    const cancel = (e: KeyboardEvent) => {
      if(e.key !== "Escape" || !busy.current || navigated.current)return;
      if(timer.current)clearTimeout(timer.current);
      tween.current?.kill(); flight.current?.remove();
      busy.current=false; usePortfolioScene.setState({opening:false,portal:null});
      delete document.documentElement.dataset.portalFlight; endInteraction("portal");
      if(link){link.dataset.portalState="idle"; link.focus({preventScroll:true});}
    };
    window.addEventListener("keydown",cancel);
    return () => {
      window.removeEventListener("keydown",cancel); endInteraction("portal");
      tween.current?.kill();
      flight.current?.remove();
      if (timer.current) clearTimeout(timer.current);
      busy.current = false;
      navigated.current = false;
      flight.current = null;
      tween.current = null;
      usePortfolioScene.setState({ opening: false, portal: null });
      delete document.documentElement.dataset.portalFlight;
    };
  }, []);
  return (
    <Link
      ref={anchor}
      href={href}
      className={className}
      aria-label={label}
      onPointerMove={(e) => {
        if (
          e.pointerType !== "mouse" ||
          matchMedia("(prefers-reduced-motion: reduce)").matches
        )
          return;
        const r = e.currentTarget.getBoundingClientRect();
        e.currentTarget.style.setProperty(
          "--px",
          String(((e.clientX - r.left) / r.width - 0.5) * 2),
        );
        e.currentTarget.style.setProperty(
          "--py",
          String(((e.clientY - r.top) / r.height - 0.5) * 2),
        );
      }}
      onPointerLeave={(e) => {
        e.currentTarget.style.setProperty("--px", "0");
        e.currentTarget.style.setProperty("--py", "0");
      }}
      onClick={(e) => {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0)
          return;
        const performance = usePerformance.getState();
        if (
          matchMedia("(prefers-reduced-motion: reduce)").matches ||
          !performance.webgl ||
          performance.tier === "low"
        )
          return;
        e.preventDefault();
        if (busy.current) return;
        if(!beginInteraction("portal",-1))return;
        busy.current = true;
        const link = e.currentTarget;
        link.dataset.portalState = "opening";
        usePortfolioScene.setState({ opening: true, portal: {href, started: window.performance.now(), duration: 1550, room: usePortfolioScene.getState().section} });
        document.documentElement.dataset.portalFlight = "active";
        const art = link.querySelector<HTMLElement>("[data-portal-art]");
        const clone = (art ?? link).cloneNode(true) as HTMLElement;
        const rect = (art ?? link).getBoundingClientRect();
        clone.className = "portal-flight";
        clone.setAttribute("aria-hidden", "true");
        document.body.appendChild(clone);
        flight.current = clone;
        gsap.set(clone, {
          position: "fixed",
          left: rect.left,
          top: rect.top,
          width: rect.width,
          height: rect.height,
          zIndex: 90,
          margin: 0,
        });
        const navigate = () => {
          if (navigated.current) return;
          navigated.current = true;
          if (timer.current) clearTimeout(timer.current);
          link.dataset.portalState = "navigating";
          usePortfolioScene.setState(s => ({portal:s.portal ? {...s.portal,navigating:true} : null}));
          router.push(href, { scroll: true });
        };
        timer.current = setTimeout(navigate, 1550);
        tween.current = gsap.to(clone, {
          left: 0,
          top: 0,
          width: innerWidth,
          height: innerHeight,
          duration: 0.5,
          ease: "power3.inOut",
          onComplete: () => {
            tween.current = gsap.to(clone, {opacity: 0, duration: 0.28,
              onComplete: () => clone.remove()});
          },
        });
      }}
    >
      {children}
    </Link>
  );
}
