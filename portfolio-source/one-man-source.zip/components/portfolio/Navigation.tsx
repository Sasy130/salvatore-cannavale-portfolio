"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
const items = [
  ["contenuto", "Home"],
  ["chi-sono", "Chi sono"],
  ["progetti", "Progetti"],
  ["competenze", "Competenze"],
  ["contatti", "Contatti"],
];
export default function Navigation({ project = false }: { project?: boolean }) {
  const [active, setActive] = useState(project ? "progetti" : "contenuto"),
    [open, setOpen] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (project) return;
    const sections = items
      .map(([id]) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) setActive(e.target.id);
      },
      { rootMargin: "-18% 0px -55% 0px", threshold: 0 },
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, [project]);
  useEffect(() => {
    if (!open) return;
    const element = dialog.current;
    element?.showModal();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
      element?.close();
    };
  }, [open]);
  const close = () => {
    setOpen(false);
    toggle.current?.focus();
  };
  const NavLink = project ? Link : "a";
  const href = (id: string) => (project ? `/#${id}` : `#${id}`);
  return (
    <>
      <header className="portfolio-nav">
        <NavLink
          href={href("contenuto")}
          className="brand"
          aria-label="ONE MAN — Home"
        >
          ONE MAN
          <span className="brand-dot" />
        </NavLink>
        <nav className="desktop-navigation" aria-label="Navigazione principale">
          {items.map(([id, label]) => (
            <NavLink
              key={id}
              href={href(id)}
              aria-label={label}
              aria-current={active === id ? "location" : undefined}
            >
              {label}
              <span />
            </NavLink>
          ))}
        </nav>
        <button
          ref={toggle}
          className="menu-toggle"
          aria-expanded={open}
          aria-controls="menu-mobile"
          onClick={() => setOpen(true)}
        >
          Menu <span aria-hidden="true">＋</span>
        </button>
      </header>
      <dialog
        id="menu-mobile"
        className="mobile-navigation"
        ref={dialog}
        onCancel={() => setOpen(false)}
        onClose={() => setOpen(false)}
      >
        <div className="mobile-menu-top">
          <span className="brand">ONE MAN</span>
          <button onClick={close} autoFocus>
            Chiudi ×
          </button>
        </div>
        <nav aria-label="Navigazione mobile">
          {items.map(([id, label], i) => (
            <NavLink
              key={id}
              href={href(id)}
              aria-label={label}
              onClick={close}
              aria-current={active === id ? "location" : undefined}
            >
              <small>0{i + 1}</small>
              {label}
              <span>↗</span>
            </NavLink>
          ))}
        </nav>
        <p>
          UN SOLO CREATORE.
          <br />
          INFINITE POSSIBILITÀ.
        </p>
      </dialog>
    </>
  );
}
