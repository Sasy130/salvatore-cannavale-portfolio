"use client";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { useReality } from "@/lib/reality-store";
import { usePerformance, qualitySettings } from "@/lib/performance-store";
import ImpossibleArchitecture from "@/components/universe/ImpossibleArchitecture";
import FinaleStructure from "@/components/universe/FinaleStructure";
import ProjectGate from "@/components/universe/ProjectGate";
import MapRooms from "@/components/universe/MapRooms";
import CinematicCamera from "@/components/universe/CinematicCamera";
import CinematicLights from "@/components/universe/CinematicLights";
import { roomFor } from "@/lib/universe-config";
import WordFragments from "@/components/reality/WordFragments";
import GpuDiagnostics from "@/components/reality/GpuDiagnostics";
import { createMonolithGeometry } from "@/lib/monolith";
import { usePortfolioScene, type EnvironmentName } from "@/lib/portfolio-store";
type Props = {
  environment?: EnvironmentName;
  detail: boolean;
  paused: boolean;
  amplitude: number;
  visible: boolean;
  onFailure: () => void;
  diagnostics?: boolean;
};
function World({
  environment,
  detail,
  paused,
  amplitude,
  low,
  controlled = false,
}: {
  environment?: EnvironmentName;
  detail: boolean;
  paused: boolean;
  amplitude: number;
  low: boolean;
  controlled?: boolean;
}) {
  const monolith = useRef<THREE.Group>(null),
    orbit = useRef<THREE.Group>(null),
    portal = useRef<THREE.Group>(null),
    field = useRef<THREE.InstancedMesh>(null);
  const t = useRef(0);
  const origin = useRef<THREE.Group>(null);
  const { size, gl } = useThree();
  const pointer = useRef(new THREE.Vector2());
  useEffect(() => {
    const source = detail ? gl.domElement : window;
    const move = (event: Event) => {
      const e = event as PointerEvent;
      const rect = detail
        ? gl.domElement.getBoundingClientRect()
        : { left: 0, top: 0, width: innerWidth, height: innerHeight };
      pointer.current.set(
        ((e.clientX - rect.left) / rect.width) * 2 - 1,
        -(((e.clientY - rect.top) / rect.height) * 2 - 1),
      );
    };
    source.addEventListener("pointermove", move, { passive: true });
    return () => source.removeEventListener("pointermove", move);
  }, [detail, gl]);
  const geometry = useMemo(() => createMonolithGeometry(), []);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const tier = usePerformance((s) => s.tier);
  const warp = useMemo(() => ({ uReality: { value: 0 } }), []);
  const count = qualitySettings[tier].particles;
  const side = Math.sqrt(count);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(({ camera }, dt) => {
    const reality = useReality.getState();
    const distortion = reality.active ? reality.distortion : 0;
    warp.uReality.value = THREE.MathUtils.damp(
      warp.uReality.value,
      distortion,
      5,
      dt,
    );
    const state = usePortfolioScene.getState();
    const env = environment ?? state.environment;
    if (origin.current) {
      const room = roomFor(state.section);
      const target = controlled && !detail ? room.center : [0, 0, 0];
      origin.current.position.x = THREE.MathUtils.damp(
        origin.current.position.x,
        target[0],
        3,
        dt,
      );
      origin.current.position.y = THREE.MathUtils.damp(
        origin.current.position.y,
        target[1],
        3,
        dt,
      );
      origin.current.position.z = THREE.MathUtils.damp(
        origin.current.position.z,
        target[2],
        3,
        dt,
      );
    }
    if (!paused) t.current += Math.min(dt, 0.06);
    const time = t.current;
    const contact = !detail && state.section === "contatti";
    const hero = !detail && state.section === "contenuto";
    const opening = !detail && state.opening;
    if (monolith.current) {
      monolith.current.visible =
        controlled && !detail
          ? false
          : detail
            ? env === "room"
            : hero || state.section === "chi-sono";
      monolith.current.rotation.set(
        0.08 + pointer.current.y * 0.12,
        -0.4 + pointer.current.x * 0.3 + time * 0.08,
        -0.13,
      );
      monolith.current.position.set(
        detail ? 0 : size.width < 768 ? 0.45 : 2.2,
        Math.sin(time * 0.6) * (reality.gravity ? 0.22 : 0.12),
        0,
      );
      monolith.current.scale.setScalar(
        detail ? 0.8 : size.width < 768 ? 0.68 : 1,
      );
    }
    if (orbit.current) {
      orbit.current.visible =
        !contact &&
        (detail
          ? env === "orbit"
          : state.section === "competenze" ||
            (state.section === "progetti" && env === "orbit"));
      orbit.current.position.x = detail ? 0 : 1;
      orbit.current.rotation.set(
        pointer.current.y * 0.2,
        time * 0.15 + pointer.current.x * 0.3,
        0,
      );
      orbit.current.children.forEach((child, i) => {
        child.rotation.x = i * 0.9 + time * 0.15;
        child.rotation.y = i * 0.5 + amplitude * 0.6;
      });
    }
    if (portal.current) {
      portal.current.visible =
        contact || (!detail && state.section === "progetti" && env === "room");
      portal.current.position.set(contact ? 0 : 1, 0, -2);
      portal.current.rotation.set(
        pointer.current.y * 0.12,
        pointer.current.x * 0.18,
        time * 0.025,
      );
      portal.current.children.forEach((child, i) => {
        child.rotation.z = i * 0.23 + time * 0.04;
        child.position.z = -i * (0.7 + distortion * 0.3);
      });
    }
    if (field.current) {
      field.current.visible = detail
        ? env === "field"
        : !contact && state.section === "progetti" && env === "field";
      if (field.current.visible) {
        for (let i = 0; i < count; i++) {
          const x = ((i % side) - side / 2) * 0.32,
            y = (Math.floor(i / side) - side / 2) * 0.32;
          dummy.position.set(
            x,
            y,
            Math.sin(x * 1.5 + time) *
              Math.cos(y * 1.3 + time * 0.5) *
              (amplitude + distortion * 0.4),
          );
          dummy.rotation.set(time * 0.08, x * 0.2, y * 0.1);
          dummy.scale.set(0.17, 0.17, 0.4);
          dummy.updateMatrix();
          field.current.setMatrixAt(i, dummy.matrix);
        }
        field.current.instanceMatrix.needsUpdate = true;
        field.current.rotation.set(
          -0.3 + pointer.current.y * 0.1,
          0.15 + pointer.current.x * 0.2,
          0.1,
        );
      }
    }
    if (!controlled) {
      const targetZ = detail
        ? 7
        : opening
          ? 2.5
          : contact
            ? 6.6
            : hero
              ? 7.2
              : 8 - state.progress * 1.1;
      camera.position.z = THREE.MathUtils.damp(
        camera.position.z,
        targetZ - distortion * 0.8,
        3,
        dt,
      );
      camera.position.x = THREE.MathUtils.damp(
        camera.position.x,
        detail ? pointer.current.x * 0.2 : state.progress * 0.25,
        3,
        dt,
      );
      camera.rotation.z = THREE.MathUtils.damp(
        camera.rotation.z,
        opening ? -0.12 : 0,
        3,
        dt,
      );
    }
  });
  return (
    <group ref={origin}>
      <group ref={monolith}>
        <mesh geometry={geometry}>
          <meshStandardMaterial
            color="#535560"
            metalness={0.95}
            roughness={0.2}
            onBeforeCompile={(program) => {
              program.uniforms.uReality = warp.uReality;
              program.vertexShader =
                "uniform float uReality;\n" + program.vertexShader;
              program.vertexShader = program.vertexShader.replace(
                "#include <begin_vertex>",
                "#include <begin_vertex>\n transformed.z+=sin(position.y*2.+position.x*3.)*uReality*.45; transformed.x+=position.y*position.y*uReality*.06;",
              );
            }}
          />
        </mesh>
        <mesh position={[0.8, 0, 0]}>
          <boxGeometry args={[0.016, 3.3, 0.6]} />
          <meshBasicMaterial color="#ff3038" />
        </mesh>
      </group>
      <group ref={orbit}>
        {[0, 1, 2].map((i) => (
          <mesh key={i}>
            <torusGeometry
              args={[1.65 + i * 0.14, 0.045, low ? 6 : 12, low ? 48 : 90]}
            />
            <meshStandardMaterial
              color="#c4ccd5"
              metalness={1}
              roughness={0.17}
            />
          </mesh>
        ))}
        <mesh>
          <icosahedronGeometry args={[0.47, 1]} />
          <meshStandardMaterial
            color="#ff3038"
            emissive="#ff3038"
            emissiveIntensity={0.7}
            metalness={0.7}
            roughness={0.25}
          />
        </mesh>
      </group>
      <group ref={portal}>
        {Array.from({ length: low ? 6 : 10 }, (_, i) => (
          <mesh key={i}>
            <torusGeometry args={[2.4, 0.025, 6, 4]} />
            <meshStandardMaterial
              color={i % 2 ? "#ff3038" : "#a7a8b5"}
              emissive={i % 2 ? "#ff3038" : "#000000"}
              emissiveIntensity={0.6}
              metalness={0.8}
              roughness={0.22}
            />
          </mesh>
        ))}
      </group>
      <instancedMesh ref={field} args={[undefined, undefined, count]}>
        <boxGeometry />
        <meshStandardMaterial
          color="#a498a1"
          metalness={0.9}
          roughness={0.23}
        />
      </instancedMesh>
    </group>
  );
}
export default function WorldScene(props: Props) {
  const tier = usePerformance((s) => s.tier);
  const low = tier !== "high";
  return (
    <Canvas
      dpr={qualitySettings[tier].dpr}
      frameloop={props.visible ? "always" : "never"}
      camera={{ position: [0, 0, 7.2], fov: 46 }}
      gl={{ alpha: true, antialias: !low, powerPreference: "low-power" }}
    >
      <WorldContents {...props} />
    </Canvas>
  );
}

export function WorldContents(props: Props) {
  const tier = usePerformance((s) => s.tier);
  const [environmentResolution] = useState(() => qualitySettings[tier].environment);
  const low = tier !== "high";
  return (
    <>
      {" "}
      <ambientLight intensity={0.4} />
      <pointLight position={[3, 1, 3]} intensity={35} color="#ff3038" />
      <spotLight
        position={[-3, 5, 4]}
        intensity={90}
        angle={0.7}
        penumbra={1}
      />
      <Environment frames={1} resolution={environmentResolution}>
        <Lightformer position={[-3, 3, 2]} scale={[2, 8, 1]} intensity={5} />
        <Lightformer
          position={[3, 0, 1]}
          scale={[1, 7, 1]}
          color="#ff3038"
          intensity={7}
        />
      </Environment>
      <ProjectGate detail={props.detail ?? false} />
      <World {...props} low={low} controlled={!props.detail} />
      {!props.detail && (
        <>
          <ImpossibleArchitecture />
          <CinematicLights />
          <CinematicCamera />
          <MapRooms />
          <FinaleStructure />
        </>
      )}
      {!props.detail && <WordFragments />}
      {props.diagnostics !== false && (
        <GpuDiagnostics onFailure={props.onFailure} />
      )}
    </>
  );
}
