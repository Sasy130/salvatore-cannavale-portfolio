"use client";
import { useEffect, useRef, useState } from "react";
import { identity } from "@/lib/portfolio-data";
export default function ContactPanel() {
  const [message, setMessage] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const email = identity.email.trim();
  const available = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(email);
      setMessage("Indirizzo email copiato.");
    } catch {
      setMessage(`Copia manualmente l’indirizzo: ${email}`);
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(""), 8000);
  };
  return (
    <div className="contact-panel">
      <p>{identity.collaboration}</p>
      {available ? (
        <div className="email-row">
          <a className="email-link" href={`mailto:${email}`}>
            {email}
            <span>↗</span>
          </a>
          <button className="outline-button" onClick={copy}>
            Copia email
          </button>
        </div>
      ) : (
        <div className="contact-pending">
          <span className="status-light" />
          Recapiti in preparazione
          <span>Email e profili social saranno pubblicati qui.</span>
        </div>
      )}
      <p className="copy-status" role="status">
        {message}
      </p>
      {identity.socials.filter((s) => /^https:\/\//.test(s.url)).length > 0 && (
        <nav className="social-links" aria-label="Profili social">
          {identity.socials
            .filter((s) => /^https:\/\//.test(s.url))
            .map((s) => (
              <a
                href={s.url}
                key={s.url}
                target="_blank"
                rel="noopener noreferrer"
              >
                {s.label} ↗
                <span className="sr-only"> (si apre in una nuova scheda)</span>
              </a>
            ))}
        </nav>
      )}
    </div>
  );
}
