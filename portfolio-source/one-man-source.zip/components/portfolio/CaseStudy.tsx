"use client";
import Link from "next/link";
import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import type { Project } from "@/lib/portfolio-data";
import { usePortfolioScene } from "@/lib/portfolio-store";
import RealityControl from "@/components/reality/RealityControl";
import Navigation from "./Navigation";
import SceneLayer from "./SceneLayer";
import PortalLink from "./PortalLink";
import "./portfolio.css";
export default function CaseStudy({
  project,
  next,
}: {
  project: Project;
  next: Project;
}) {
  const root = useRef<HTMLElement>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const [live, setLive] = useState(false);
  const [paused, setPaused] = useState(false),
    [amplitude, setAmplitude] = useState(0.6);
  useLayoutEffect(() => {
    usePortfolioScene.setState({
      opening: false,
      environment: project.environment,
    });
    window.scrollTo({ top: 0, behavior: "instant" });
    heading.current?.focus({ preventScroll: true });
    const ready = () => root.current?.setAttribute("data-transition", "ready");
    root.current?.setAttribute("data-transition", "entering");
    const ctx = gsap.context(() => {
      if (!matchMedia("(prefers-reduced-motion: reduce)").matches)
        gsap.from(".case-enter", {
          y: 45,
          opacity: 0,
          duration: 0.85,
          stagger: 0.1,
          ease: "power3.out",
          onComplete: ready,
        });
      else ready();
    }, root);
    return () => ctx.revert();
  }, [project]);
  return (
    <main
      className={`portfolio case-study case-${project.environment}`}
      ref={root}
      style={{ "--accent": project.accent } as React.CSSProperties}
    >
      <a className="skip-link" href="#case-title">
        Vai al progetto
      </a>
      <Navigation project />
      <RealityControl />
      <header className="case-header section-space">
        <Link className="case-back" href="/#progetti">
          ← Tutti gli universi
        </Link>
        <div className="case-meta case-enter">
          <span>RICERCA PERSONALE / {project.number}</span>
          <span>{project.category}</span>
        </div>
        <h1 id="case-title" className="case-enter" ref={heading} tabIndex={-1}>
          {project.title}
        </h1>
        <p className="case-summary case-enter">{project.summary}</p>
        <a className="explore-button case-enter" href="#demo">
          Esplora la demo <b aria-hidden="true">↓</b>
        </a>
      </header>
      <figure className="case-cover case-enter reality-body">
        <img
          src={project.images[0].src}
          alt={project.images[0].alt}
          width={1440}
          height={1000}
          fetchPriority="high"
        />
        <figcaption>{project.images[0].caption}</figcaption>
      </figure>
      <section
        className="case-narrative section-space"
        aria-labelledby="idea-heading"
      >
        <span className="eyebrow">01 / L’IDEA</span>
        <div>
          <h2 id="idea-heading">
            Una domanda.
            <br />
            Un nuovo spazio.
          </h2>
          <p>{project.description}</p>
          <ul className="technology-list" aria-label="Tecnologie utilizzate">
            {project.technologies.map((t) => (
              <li key={t}>{t}</li>
            ))}
          </ul>
        </div>
      </section>
      <section className="case-process section-space">
        <article>
          <span className="eyebrow">02 / LA SFIDA</span>
          <h2>Oltre la superficie.</h2>
          <p>{project.challenge}</p>
        </article>
        <article>
          <span className="eyebrow">03 / LA SOLUZIONE</span>
          <h2>Dare forma al gesto.</h2>
          <p>{project.solution}</p>
        </article>
      </section>
      <figure className="case-detail">
        <img
          src={project.images[1].src}
          alt={project.images[1].alt}
          width={1440}
          height={1000}
          loading="lazy"
        />
        <figcaption>
          {project.images[1].caption}
          <span>Illustrazione procedurale originale</span>
        </figcaption>
      </figure>
      <section id="demo" className="case-demo section-space">
        <div>
          <span className="eyebrow">04 / ESPLORA LA MATERIA</span>
          <h2>
            Prova un altro
            <br />
            punto di vista.
          </h2>
          <p>
            Muovi il puntatore sulla scena. Su touch, trascina per orientare la
            composizione. La versione essenziale resta visibile anche senza
            WebGL.
          </p>
          {project.demo ? (
            <Link className="explore-button" href={project.demo}>
              Rivivi l’esperienza completa ↗
            </Link>
          ) : live ? (
            <div className="demo-controls">
              <button
                className="outline-button"
                onClick={() => setPaused(!paused)}
                aria-pressed={paused}
              >
                {paused ? "Riprendi movimento" : "Ferma movimento"}
              </button>
              <label>
                {project.environment === "field"
                  ? "Ampiezza dell’onda"
                  : "Apertura degli anelli"}
                <input
                  type="range"
                  min="0"
                  max="1.4"
                  step=".05"
                  value={amplitude}
                  onChange={(e) => setAmplitude(Number(e.target.value))}
                />
              </label>
            </div>
          ) : (
            <p className="demo-static-note" role="status">
              Visualizzazione essenziale: una composizione statica, senza
              animazioni 3D.
            </p>
          )}
        </div>
        <div
          className="demo-viewport"
          aria-label={`Studio tridimensionale: ${project.title}`}
        >
          <SceneLayer
            environment={project.environment}
            detail
            paused={paused}
            amplitude={amplitude}
            onModeChange={setLive}
          />
          <span className="demo-caption">
            {live ? "STUDIO IN TEMPO REALE" : "COMPOSIZIONE ESSENZIALE"} /{" "}
            {project.number}
          </span>
        </div>
      </section>
      <section className="next-universe section-space">
        <span className="eyebrow">LA RICERCA CONTINUA</span>
        <PortalLink
          href={`/progetti/${next.slug}`}
          className="next-project-link"
        >
          <span>Prossimo universo</span>
          <strong>{next.title}</strong>
          <b aria-hidden="true">↗</b>
        </PortalLink>
      </section>
      <footer className="portfolio-footer">
        <Link className="brand" href="/#contenuto">
          ONE MAN
        </Link>
        <span>LA REALTÀ SI RISCRIVE.</span>
        <Link href="/#contatti">Apriamo una conversazione ↗</Link>
      </footer>
    </main>
  );
}
