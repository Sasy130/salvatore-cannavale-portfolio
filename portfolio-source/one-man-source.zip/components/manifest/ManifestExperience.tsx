"use client";
import {useEffect,useRef,useState} from "react";
import gsap from "gsap";
import {ScrollTrigger} from "gsap/ScrollTrigger";
import {galleryWorks,galleryCopy,galleryPreviews,type GalleryWork} from "@/lib/gallery-data";
import {identity} from "@/lib/portfolio-data";
import GalleryDetail from "@/components/gallery/GalleryDetail";
import "@/components/gallery/gallery.css";
import "./manifest.css";

function Artwork({work,index,onOpen}:{work:GalleryWork;index:number;onOpen:()=>void}){
 const root=useRef<HTMLElement>(null),handle=useRef<HTMLButtonElement>(null);
 const gesture=useRef<{id:number;x:number;y:number}|null>(null);
 const values=useRef({x:0,y:0,vx:0,vy:0,tx:0,ty:0});
 const [held,setHeld]=useState(false);
 const image=work.project?.cover??work.preview?.src;
 useEffect(()=>{
  const media=matchMedia("(prefers-reduced-motion: reduce)");let frame=0;
  const tick=()=>{const el=root.current;if(!el)return;const s=values.current;
   s.vx=(s.vx+(s.tx-s.x)*.075)*.77;s.vy=(s.vy+(s.ty-s.y)*.075)*.77;s.x+=s.vx;s.y+=s.vy;
   el.style.setProperty("--pull-angle",`${media.matches?0:s.x*.18}deg`);el.style.setProperty("--pull-x",`${media.matches?0:s.x}px`);el.style.setProperty("--pull-y",`${media.matches?0:s.y}px`);
   if(Math.abs(s.x-s.tx)+Math.abs(s.y-s.ty)+Math.abs(s.vx)+Math.abs(s.vy)>.05)frame=requestAnimationFrame(tick);else frame=0;
  };
  const wake=()=>{if(!frame)frame=requestAnimationFrame(tick);};
  const el=handle.current;
  const move=(e:PointerEvent)=>{const d=gesture.current;if(!d||e.pointerId!==d.id)return;safelySet(e.clientX-d.x,e.clientY-d.y);wake();};
  const safelySet=(x:number,y:number)=>{values.current.tx=Math.max(-90,Math.min(90,x));values.current.ty=Math.max(-75,Math.min(75,y));};
  const end=()=>{gesture.current=null;setHeld(false);safelySet(0,0);wake();};
  const down=(e:PointerEvent)=>{if(e.button!==0)return;gesture.current={id:e.pointerId,x:e.clientX,y:e.clientY};el?.setPointerCapture(e.pointerId);setHeld(true);};
  const key=(e:KeyboardEvent)=>{if(e.key==="Escape")end();if(e.key.startsWith("Arrow")){e.preventDefault();safelySet(e.key==="ArrowLeft"?-65:e.key==="ArrowRight"?65:0,e.key==="ArrowUp"?-55:e.key==="ArrowDown"?55:0);wake();}};
  el?.addEventListener("pointerdown",down);el?.addEventListener("pointermove",move);el?.addEventListener("pointerup",end);el?.addEventListener("pointercancel",end);el?.addEventListener("lostpointercapture",end);el?.addEventListener("keydown",key);el?.addEventListener("keyup",end);el?.addEventListener("blur",end);window.addEventListener("blur",end);
  return()=>{cancelAnimationFrame(frame);el?.removeEventListener("pointerdown",down);el?.removeEventListener("pointermove",move);el?.removeEventListener("pointerup",end);el?.removeEventListener("pointercancel",end);el?.removeEventListener("lostpointercapture",end);el?.removeEventListener("keydown",key);el?.removeEventListener("keyup",end);el?.removeEventListener("blur",end);window.removeEventListener("blur",end);};
 },[]);
 return <article ref={root} className={`m-work m-work-${index%3}`} data-held={held}>
  <div className="m-art"><button className="m-image-button" onClick={onOpen} aria-label={`Apri ${work.project?work.title:`l’anteprima ${work.number}`}`}><span className="m-art-under" aria-hidden="true">{work.number}<br/>UN ALTRO<br/>PUNTO DI VISTA.</span><span className="m-shards" aria-hidden="true">{Array.from({length:8},(_,i)=><span key={i} className="m-shard" style={{left:`${i*12.5}%`,width:"12.6%","--i":i} as React.CSSProperties}><img src={image} alt="" style={{left:`${-i*100}%`}}/></span>)}</span></button>
  <button ref={handle} className="m-handle" aria-label={`Deforma l’immagine ${work.number}`} aria-describedby="m-gesture-help" aria-pressed={held}><span/></button></div>
  <div className="m-work-caption"><span>{work.number} / {work.category}</span><h3>{work.title}</h3><button onClick={onOpen}>Esplora <span aria-hidden="true">↗</span></button></div>
 </article>;
}
export default function ManifestExperience(){
 const root=useRef<HTMLElement>(null),last=useRef<HTMLElement|null>(null);
 const [flight,setFlight]=useState<{work:GalleryWork;rect:DOMRect}|null>(null);
 const flightRef=useRef<HTMLDivElement>(null);
 const [selected,setSelected]=useState<GalleryWork|null>(null),[menu,setMenu]=useState(false),[intro,setIntro]=useState(false);
 const introTimeline=useRef<gsap.core.Timeline|null>(null);
 const replay=()=>{window.scrollTo({top:0,behavior:"instant"});if(!matchMedia("(prefers-reduced-motion: reduce)").matches)setIntro(true);};
 useEffect(()=>{const reduced=matchMedia("(prefers-reduced-motion: reduce)");try{if(!reduced.matches&&sessionStorage.getItem("one-man-manifest")!=="vista")setIntro(true);}catch{}},[]);
 useEffect(()=>{if(!intro)return;const tl=gsap.timeline({onComplete:()=>{setIntro(false);try{sessionStorage.setItem("one-man-manifest","vista");}catch{}}});introTimeline.current=tl;tl.fromTo(".m-intro-word span",{yPercent:120,rotate:12},{yPercent:0,rotate:0,duration:.8,stagger:.12,ease:"power4.out"}).to(".m-intro-word span",{xPercent:(i)=>i%2?110:-110,duration:1,ease:"power4.inOut"},"+=.35").to(".m-intro",{opacity:0,duration:.35});return()=>{tl.kill();introTimeline.current=null;};},[intro]);
 useEffect(()=>{gsap.registerPlugin(ScrollTrigger);const media=gsap.matchMedia();media.add("(prefers-reduced-motion: no-preference)",()=>{const ctx=gsap.context(()=>{
  gsap.to(".m-hero-type",{yPercent:25,rotate:-5,scale:.86,ease:"none",scrollTrigger:{trigger:".m-hero",start:"top top",end:"bottom top",scrub:.7}});
  gsap.to(".m-ribbon",{xPercent:18,rotate:8,ease:"none",scrollTrigger:{trigger:".m-hero",start:"top top",end:"bottom top",scrub:.5}});
  gsap.utils.toArray<HTMLElement>(".m-work").forEach((el,i)=>{gsap.fromTo(el,{"--split":0,"--orbit":-1},{"--split":1,"--orbit":1,ease:"none",scrollTrigger:{trigger:el,start:"top 95%",end:"bottom 10%",scrub:.5}});gsap.fromTo(el.querySelector(".m-work-caption"),{y:35,opacity:.2},{y:0,opacity:1,scrollTrigger:{trigger:el,start:"top 85%",end:"top 45%",scrub:true}});el.style.setProperty("--direction",i%2?"-1":"1");});
  gsap.from(".m-about h2 span",{yPercent:100,rotate:6,stagger:.15,duration:1,scrollTrigger:{trigger:".m-about",start:"top 75%"}});
 },root);return()=>ctx.revert();});return()=>media.revert();},[]);
 useEffect(()=>{if(!flight)return;const el=flightRef.current;if(!el)return;
  const r=flight.rect;const tl=gsap.timeline({onComplete:()=>{setSelected(flight.work);setFlight(null);}});
  tl.fromTo(el,{left:r.left,top:r.top,width:r.width,height:r.height,rotate:-5,borderRadius:8},{left:0,top:0,width:innerWidth,height:innerHeight,rotate:0,borderRadius:0,duration:.75,ease:"expo.inOut"});
  const cancel=(e:KeyboardEvent)=>{if(e.key==="Escape"){tl.kill();setFlight(null);last.current?.focus({preventScroll:true});}};window.addEventListener("keydown",cancel);
  return()=>{tl.kill();window.removeEventListener("keydown",cancel);};
 },[flight]);
 useEffect(()=>{if(!intro)return;const key=(e:KeyboardEvent)=>{if(e.key==="Tab"){e.preventDefault();root.current?.querySelector<HTMLButtonElement>(".m-intro button")?.focus();}if(e.key==="Escape"){introTimeline.current?.kill();setIntro(false);}};document.addEventListener("keydown",key);return()=>document.removeEventListener("keydown",key);},[intro]);
 const open=(work:GalleryWork)=>{if(flight||selected)return;last.current=document.activeElement as HTMLElement;
  if(matchMedia("(prefers-reduced-motion: reduce)").matches){setSelected(work);return;}
  const article=last.current?.closest(".m-work");const rect=article?.querySelector(".m-art")?.getBoundingClientRect();
  if(rect)setFlight({work,rect});else setSelected(work);
 };
 const close=()=>{const finish=()=>{setSelected(null);requestAnimationFrame(()=>last.current?.focus({preventScroll:true}));};if(matchMedia("(prefers-reduced-motion: reduce)").matches)finish();else gsap.to(".manifest .gallery-detail",{opacity:0,y:30,duration:.25,onComplete:finish});};
 return <main ref={root} className="manifest" id="inizio" style={{"--m-photo-01":`url(${galleryPreviews[0].src})`,"--m-photo-02":`url(${galleryPreviews[1].src})`} as React.CSSProperties}>
 <a className="m-skip" href="#progetti">Vai ai progetti</a>
 <header className="m-header" onKeyDown={e=>{if(e.key==="Escape"){setMenu(false);root.current?.querySelector<HTMLButtonElement>(".m-header>button")?.focus();}}}><a href="#inizio" className="m-logo">ONE MAN</a><button aria-expanded={menu} aria-controls="m-nav" onKeyDown={e=>{if(e.key==="Escape")setMenu(false);}} onClick={()=>setMenu(!menu)}>{menu?"Chiudi":"Menu"} <span aria-hidden="true">{menu?"×":"☰"}</span></button><nav id="m-nav" hidden={!menu} aria-label="Navigazione principale">{[["Progetti","#progetti"],["Chi sono","#chi-sono"],["Contatti","#contatti"]].map(([label,href])=><a key={href} href={href} onClick={()=>setMenu(false)}>{label} ↗</a>)}</nav></header>
 <section className="m-hero" aria-labelledby="m-title"><p className="m-eyebrow">IDENTITÀ CREATIVA INDIPENDENTE / 2026</p><h1 id="m-title" className="m-hero-type"><span>ONE</span><span>MAN</span></h1><div className="m-ribbon" aria-hidden="true"/><div className="m-hero-bottom"><p>LA REALTÀ<br/>SI RISCRIVE.</p><a href="#progetti">Entra nella composizione <span>↓</span></a></div><span className="m-side-note" aria-hidden="true">OGNI GESTO CAMBIA LA PROSPETTIVA.</span></section>
 <section id="progetti" className="m-projects" aria-labelledby="m-projects-title"><div className="m-section-label"><span>01 / PUNTI DI VISTA</span><span>SCORRI. TOCCA. RISCRIVI.</span></div><h2 id="m-projects-title">Niente resta<br/><em>al suo posto.</em></h2><p id="m-gesture-help" className="m-instruction"><span aria-hidden="true">●</span> Trascina il punto rosa. Rilascia per ricomporre.<br/><small>Da tastiera: usa le frecce sul punto, Esc per ripristinare.</small></p><div className="m-works">{galleryWorks.map((work,i)=><Artwork key={work.id} work={work} index={i} onOpen={()=>open(work)}/>)}</div><p className="m-demo-note">Immagini dimostrative. I progetti personali saranno inseriti qui.</p></section>
 <section id="chi-sono" className="m-about"><div className="m-section-label">02 / DIETRO ONE MAN</div><h2><span>UNA PERSONA.</span><span>PIÙ POSSIBILITÀ.</span></h2><p>{galleryCopy.about}</p><button onClick={replay}>Rivedi l’introduzione ↗</button><a href={`${process.env.NEXT_PUBLIC_ASSET_BASE??""}/mostra${process.env.NEXT_PUBLIC_ASSET_BASE?".html":""}`}>Esplora la precedente galleria 3D ↗</a></section>
 <section id="contatti" className="m-contact"><div className="m-section-label">03 / IL PROSSIMO INIZIO</div><h2>Facciamo<br/><em>succedere</em><br/>qualcosa.</h2>{identity.email?<a className="m-email" href={`mailto:${identity.email}`}>{identity.email} ↗</a>:<p>Recapiti in preparazione.<br/>Email e profili saranno disponibili qui.</p>}{identity.socials.filter(s=>/^https:\/\//.test(s.url)).map(s=><a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">{s.label} ↗</a>)}<footer><span>ONE MAN — LA REALTÀ SI RISCRIVE.</span><a href="#inizio">Torna su ↑</a></footer></section>
 {intro&&<div className="m-intro" role="dialog" aria-modal="true" aria-label="Introduzione ONE MAN"><div className="m-intro-word" aria-hidden="true"><span>ONE</span><span>MAN</span></div><button autoFocus onClick={()=>{introTimeline.current?.kill();setIntro(false);}}>Salta introduzione ↗</button><p>LA REALTÀ SI RISCRIVE.</p></div>}
 {flight&&<div className="m-flight-curtain" aria-hidden="true"><div ref={flightRef} className="m-flight"><img src={flight.work.project?.cover??flight.work.preview?.src} alt=""/><span>UN ALTRO PUNTO DI VISTA.</span></div></div>}
 {selected&&<GalleryDetail work={selected} onClose={close}/>}
 </main>;
}
