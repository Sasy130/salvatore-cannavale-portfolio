import {identity} from '@/lib/portfolio-data';
import './final-contact.css';
export default function FinalContact({onCopy,onReplay,status}:{onCopy:()=>void;onReplay:()=>void;status:string}){
 return <section id="contatti" className="vc-contact vf-contact" aria-labelledby="vf-title">
  <div className="vf-composition"><div className="vf-artwork" aria-hidden="true"><svg viewBox="0 0 600 800" fill="none"><path d="M600-70C240-70 130 70 130 240s270 170 270 340S150 800-60 800" stroke="#292033" strokeWidth="130"/><path d="M660-40C300-40 190 100 190 270s270 170 270 340S210 830 0 830" stroke="#fff1df" strokeWidth="2"/><path d="M660 15C300 15 245 140 245 270s270 170 270 340S210 885 0 885" stroke="#9ae4d4" strokeWidth="22"/></svg></div>
   <p className="vc-eyebrow">L’INIZIO DI QUALCOSA DI NUOVO.</p><h2 id="vf-title">FACCIAMO<br/>IL PROSSIMO<br/><em>SEGNO.</em></h2>
   <div className="vf-message"><p>Il prossimo progetto può iniziare<br/>da un messaggio.</p><a href={`mailto:${identity.email}`} className="vf-write">Raccontami la tua idea <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" strokeWidth="1.5"/></svg></a></div>
  </div>
  <div className="vf-contact-line"><a className="vc-email" href={`mailto:${identity.email}`}>{identity.email}</a><button onClick={onCopy}>Copia email</button></div><p className="vc-copy-status" role="status">{status}</p>
  <div className="vf-signoff" aria-hidden="true"><span>ONE</span><em>MAN</em></div>
  <footer><span>ONE MAN — LA REALTÀ SI RISCRIVE.</span><button onClick={onReplay}>Rivedi l’introduzione ↻</button><a href="#inizio">Torna all’inizio ↑</a></footer>
 </section>;
}
