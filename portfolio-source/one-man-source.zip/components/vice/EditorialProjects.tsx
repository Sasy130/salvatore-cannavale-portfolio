'use client';
import {useEffect,useRef,useState} from 'react';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {projects} from '@/lib/restored-projects';
import './editorial-projects.css';
type Project=typeof projects[number];
function Arrow(){return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" strokeWidth="1.4"/></svg>;}
function Preview({project,onOpen,compact=false}:{project:Project;onOpen:(p:Project)=>void;compact?:boolean}){
 return <div className={`ep-preview ${compact?'ep-preview-inline':''}`}>
  <a className="ep-image-link" href={project.url} aria-label={`Esplora ${project.name}`} onClick={e=>{e.preventDefault();onOpen(project);}}><img src={project.image} alt={project.alt} loading="lazy"/><span className="ep-image-label">{project.label}</span><span className="ep-image-arrow"><Arrow/></span></a>
  <div className="ep-caption"><div><span className="ep-kicker">{project.category}</span><h3>{project.name}</h3></div><p>{project.description}</p></div>
  <a className="ep-explore" href={project.url} onClick={e=>{e.preventDefault();onOpen(project);}}>Esplora il progetto <Arrow/></a>
 </div>;
}
export default function EditorialProjects({onOpen}:{onOpen:(p:Project)=>void}){
 const [active,setActive]=useState<number|null>(0);const root=useRef<HTMLElement>(null);const project=projects[active??0];
 useEffect(()=>{let frame=0;const observer=new ResizeObserver(()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>ScrollTrigger.refresh());});const section=root.current;if(section){section.dataset.enhanced='true';observer.observe(section);}return()=>{observer.disconnect();cancelAnimationFrame(frame);if(section)delete section.dataset.enhanced;};},[]);
 return <section ref={root} id="progetti" className="vc-projects ep-section" aria-labelledby="vc-projects-title">
  <span id="indice" className="ep-legacy-anchor" aria-hidden="true"/><div className="ep-heading"><div><p className="ep-kicker">LAVORI DI SALVATORE CANNAVALE</p><h2 id="vc-projects-title">I MIEI <em>PROGETTI.</em></h2></div><p>Ideati, disegnati e sviluppati da me.<br/>Scegli un nome. Entra nel progetto.</p></div>
  <div className="ep-layout"><div className="ep-directory"><div className="ep-directory-head" aria-hidden="true"><span>INDICE DEI LAVORI</span><span>{String(projects.length).padStart(2,'0')} PROGETTI</span></div>
   {projects.map((p,i)=><details className="ep-row" key={p.slug} open={active===i} onPointerEnter={e=>{if(e.pointerType==='mouse'&&matchMedia('(min-width: 960px) and (hover: hover)').matches)setActive(i);}}>
    <summary id={`ep-select-${p.slug}`} onClick={e=>{e.preventDefault();setActive(active===i?null:i);}} aria-controls={`ep-panel-${p.slug}`}><span className="ep-number">{String(i+1).padStart(2,'0')}</span><span className="ep-row-name">{p.name}<small>{p.subtitle}</small></span><span className="ep-row-mark" aria-hidden="true"><Arrow/></span></summary>
    <div id={`ep-panel-${p.slug}`} className="ep-inline"><Preview project={p} onOpen={onOpen} compact/></div>
   </details>)}
   <p className="ep-note">Questi sono i progetti che ho creato.<br/>Apri un lavoro per scoprirne i dettagli.</p>
  </div><div className="ep-stage"><div className="ep-stage-sticky"><div className="ep-stage-top"><span>IN PRIMO PIANO</span><span>{String((active??0)+1).padStart(2,'0')} / {String(projects.length).padStart(2,'0')}</span></div><div key={project.slug} className="ep-stage-reveal"><Preview project={project} onOpen={onOpen}/></div><div className="ep-stage-bottom" aria-hidden="true"><span>ONE MAN / SELEZIONE PERSONALE</span><span>↙ SCEGLI UN’ALTRA REALTÀ</span></div></div></div></div>
 </section>;
}
