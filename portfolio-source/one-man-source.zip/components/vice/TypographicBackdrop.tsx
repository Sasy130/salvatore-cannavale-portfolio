'use client';
import {useEffect,useId,useRef} from 'react';

/** Scenografia decorativa: nessuna cattura del tocco, nessun rendering continuo. */
export default function TypographicBackdrop(){
 const ref=useRef<HTMLDivElement>(null);
 const id=useId().replace(/:/g,'');
 useEffect(()=>{
  const el=ref.current,hero=el?.closest('section');if(!el||!hero)return;
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  let frame=0,x=0,y=0,tx=0,ty=0,visible=true;
  const paint=()=>{frame=0;if(!visible||media.matches)return;x+=(tx-x)*.09;y+=(ty-y)*.09;el.style.setProperty('--type-x',`${x.toFixed(3)}px`);el.style.setProperty('--type-y',`${y.toFixed(3)}px`);if(Math.abs(tx-x)+Math.abs(ty-y)>.03)frame=requestAnimationFrame(paint);};
  const start=()=>{if(!frame&&visible&&!media.matches)frame=requestAnimationFrame(paint);};
  const move=(e:PointerEvent)=>{const r=hero.getBoundingClientRect();tx=((e.clientX-r.left)/r.width-.5)*48;ty=((e.clientY-r.top)/r.height-.5)*36;start();};
  const reset=()=>{tx=ty=0;start();};
  const stop=()=>{cancelAnimationFrame(frame);frame=0;};
  const preference=()=>{stop();x=y=tx=ty=0;el.style.removeProperty('--type-x');el.style.removeProperty('--type-y');};
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting&&!document.hidden;if(!visible)stop();else start();});observer.observe(hero);
  const visibility=()=>{visible=!document.hidden&&hero.getBoundingClientRect().bottom>0;if(visible)start();else stop();};
  hero.addEventListener('pointermove',move,{passive:true});hero.addEventListener('pointerleave',reset);hero.addEventListener('pointerup',reset);hero.addEventListener('pointercancel',reset);document.addEventListener('visibilitychange',visibility);media.addEventListener('change',preference);
  return()=>{stop();observer.disconnect();hero.removeEventListener('pointermove',move);hero.removeEventListener('pointerleave',reset);hero.removeEventListener('pointerup',reset);hero.removeEventListener('pointercancel',reset);document.removeEventListener('visibilitychange',visibility);media.removeEventListener('change',preference);};
 },[]);
 return <div ref={ref} className="vc-hero-photo vc-type-backdrop" aria-hidden="true">
  <svg className="vc-type-plane" viewBox="0 0 1000 1000" preserveAspectRatio="xMidYMid slice" focusable="false">
   <defs><linearGradient id={`${id}-pink`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#ff97cb"/><stop offset=".5" stopColor="#c74b92"/><stop offset="1" stopColor="#391c48"/></linearGradient><linearGradient id={`${id}-aqua`} x1="0" y1="0" x2="1" y2="1"><stop stopColor="#9ae4d4"/><stop offset="1" stopColor="#285768"/></linearGradient></defs>
   <g className="vc-type-layer vc-type-layer-one" fill={`url(#${id}-pink)`}>
    <path fillRule="evenodd" d="M-110 100C-110-125 430-125 430 100V220C430 445-110 445-110 220ZM45 100V220C45 305 275 305 275 220V100C275 15 45 15 45 100Z" transform="rotate(-19 160 145)"/>
    <path d="M620-100H740L900 165V-100H1020V440H910L740 170V440H620Z" transform="rotate(-19 820 150)"/>
   </g>
   <g className="vc-type-layer vc-type-layer-two" fill={`url(#${id}-aqua)`}>
    <path d="M-130 730H15L130 950 245 730H390V1200H255V940L130 1150 5 940V1200H-130Z" transform="rotate(-19 130 950)"/>
    <path fillRule="evenodd" d="M540 800C540 580 1090 580 1090 800V1000C1090 1220 540 1220 540 1000ZM690 800V1000C690 1080 940 1080 940 1000V800C940 720 690 720 690 800Z" transform="rotate(-19 800 900)"/>
   </g>
   <g className="vc-type-layer vc-type-layer-three" fill="none" stroke="#ffb6d8" strokeWidth="1.2" opacity=".38"><path d="M-100 540 1100 125M-100 565 1100 150M-100 1110 1100 695"/><path d="M700 400 870 340 925 500 755 560Z"/></g>
  </svg>
 </div>;
}
