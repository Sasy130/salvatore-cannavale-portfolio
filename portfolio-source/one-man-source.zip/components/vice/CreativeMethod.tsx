import './creative-method.css';
const steps=[
 {title:'Identità',text:'Prima di disegnare, capire cosa rendere riconoscibile. Un’idea precisa guida colori, caratteri e composizione.'},
 {title:'Interazione',text:'Dare un senso al movimento. Scroll, transizioni e dettagli accompagnano il contenuto, senza mettersi in mezzo.'},
 {title:'Sviluppo',text:'Portare la visione nel browser. Un’esperienza curata anche sul telefono, con attenzione a leggibilità e accessibilità.'},
];
export default function CreativeMethod(){
 return <section id="metodo" className="vm-method" aria-labelledby="vm-title"><span id="indice" className="vm-legacy-anchor" aria-hidden="true"/>
  <div className="vm-top"><p>IL PENSIERO DIETRO IL PROGETTO</p><span aria-hidden="true">ONE MAN / 01—03</span></div>
  <div className="vm-layout"><div className="vm-intro"><h2 id="vm-title"><span>PRIMA L’IDEA.</span><em>POI IL SEGNO.</em></h2><p>Non partire dall’effetto.<br/>Partire da ciò che vuoi comunicare.</p><div className="vm-symbol" aria-hidden="true"><svg viewBox="0 0 260 180" fill="none"><g className="vm-symbol-orbits" stroke="currentColor" strokeWidth="1"><ellipse cx="130" cy="90" rx="115" ry="47" transform="rotate(-30 130 90)"/><ellipse cx="130" cy="90" rx="115" ry="47" transform="rotate(30 130 90)"/><ellipse cx="130" cy="90" rx="115" ry="47" transform="rotate(90 130 90)"/></g><path d="M114 90h32M130 74v32" stroke="#fff1df" strokeWidth="1.5"/></svg><span>DALL’INTUIZIONE ALLA FORMA</span></div></div>
  <ol className="vm-steps">{steps.map((step,i)=><li key={step.title}><span className="vm-step-number" aria-hidden="true">0{i+1}</span><div><h3>{step.title}<span aria-hidden="true">.</span></h3><p>{step.text}</p></div></li>)}</ol></div>
  <a className="vm-invitation" href="#contatti"><span>Hai un’idea da cui partire?</span><span>Parliamone <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" strokeWidth="1.5"/></svg></span></a>
 </section>;
}
