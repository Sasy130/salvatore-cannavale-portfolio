'use client';
import {localSeries,seriesProjects} from '@/lib/local-series';
import type {projects} from '@/lib/restored-projects';
import './local-redesign-series.css';
type Project=typeof projects[number];
function Arrow(){return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14" stroke="currentColor" strokeWidth="1.5"/></svg>;}
export default function LocalRedesignSeries({onOpen}:{onOpen:(project:Project)=>void}){
 return <section id={localSeries.id} className="ls-series" aria-labelledby="ls-title">
  <div className="ls-overline"><span>UNA SERIE PERSONALE / REDESIGN DEL TERRITORIO</span><span>{String(seriesProjects.length).padStart(2,'0')} PROPOSTE DA ESPLORARE</span></div>
  <div className="ls-intro"><div><p className="ls-kicker">SI PARTE DA VICINO.</p><h2 id="ls-title">DALLA MAPPA<br/><em>AL SITO.</em></h2></div><div className="ls-story"><p>{localSeries.description}</p><p>Una serie di redesign pensata per Instagram: osservo un’attività, ripenso la sua presenza online e costruisco la mia proposta.</p><div className="ls-route" aria-hidden="true"><span>ESPLORO</span><i/><span>RIPENSO</span><i/><span>CREO</span></div></div></div>
  <div className="ls-cases">{seriesProjects.map((project,i)=><article className="ls-case" key={project.slug}>
   <div className="ls-case-top"><span>REDESIGN {String(i+1).padStart(2,'0')}</span><span>PROPOSTA INDIPENDENTE</span></div>
   <a className="ls-cover" href={project.url} aria-label={`Esplora la proposta ${project.name}`} onClick={e=>{e.preventDefault();onOpen(project);}}><img src={project.image} alt={project.alt} loading="lazy"/><span className="ls-cover-arrow"><Arrow/></span></a>
   <div className="ls-case-heading"><h3>{project.name}</h3><span>NOLEGGIO / SITO WEB</span></div><p className="ls-description">{project.description}</p>
   <a className="ls-open" href={project.url} onClick={e=>{e.preventDefault();onOpen(project);}}>Esplora la proposta <Arrow/></a>
  </article>)}</div>
  <div className="ls-bottom"><p>Iniziative personali, non siti ufficiali delle attività.<br/>Ogni proposta è un’esplorazione indipendente, senza implicare una collaborazione con l’azienda.</p>{localSeries.instagramProfileUrl?<a href={localSeries.instagramProfileUrl} target="_blank" rel="noopener noreferrer">Segui la serie su Instagram <Arrow/></a>:<a href="#contatti">Hai un’attività da suggerirmi? <Arrow/></a>}</div>
 </section>;
}
