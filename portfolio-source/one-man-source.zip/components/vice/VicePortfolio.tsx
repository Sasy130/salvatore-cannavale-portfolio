"use client";
import {useCallback,useEffect,useLayoutEffect,useRef,useState} from 'react';
import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {ProjectView,Navigation} from '@/components/cinema/CinemaPortfolio';
import {projects} from '@/lib/restored-projects';
import {identity} from '@/lib/portfolio-data';
import SignatureOpening,{openingMemory} from './SignatureOpening';
import TypographicBackdrop from './TypographicBackdrop';
import EditorialProjects from './EditorialProjects';
import CreativeMethod from './CreativeMethod';
import './vice.css';
const memory=openingMemory;
function Name({className=''}:{className?:string}){return <div className={`vc-name ${className}`} aria-hidden="true">{['SALVATORE','CANNAVALE'].map(word=><span key={word}>{Array.from(word).map((letter,i)=><i className="vc-glyph" key={i}>{letter}</i>)}</span>)}</div>;}
export default function VicePortfolio(){
 const root=useRef<HTMLElement>(null);const [intro,setIntro]=useState(true),[selected,setSelected]=useState<typeof projects[number]|null>(null),[menu,setMenu]=useState(false),[copied,setCopied]=useState('');
 useEffect(()=>{const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;try{const forced=new URLSearchParams(location.search).get('intro')==='1';if((reduced&&!forced)||(!forced&&sessionStorage.getItem(memory)==='vista'))setIntro(false);}catch{if(reduced)setIntro(false);}},[]);
 useLayoutEffect(()=>{gsap.registerPlugin(ScrollTrigger);const media=gsap.matchMedia();media.add('(prefers-reduced-motion: no-preference)',()=>{const ctx=gsap.context(()=>{
  gsap.timeline({scrollTrigger:{trigger:'.vc-hero',start:'top top',end:'bottom top',scrub:.5}}).to('.vc-hero-photo',{scale:1.15,yPercent:12,ease:'none'},0).to('.vc-hero .vc-name>span:first-child',{xPercent:-14,skewX:-8,ease:'none'},0).to('.vc-hero .vc-name>span:last-child',{xPercent:14,skewX:8,ease:'none'},0);
  gsap.utils.toArray<HTMLElement>('.vc-manifesto-line').forEach((line,i)=>gsap.fromTo(line,{xPercent:i%2?16:-16},{xPercent:0,ease:'none',scrollTrigger:{trigger:'.vc-manifesto',start:'top bottom',end:'center center',scrub:.6}}));
  gsap.fromTo('.vm-symbol-orbits',{rotation:-24},{rotation:24,ease:'none',scrollTrigger:{trigger:'.vm-method',start:'top bottom',end:'bottom top',scrub:.8}});
  gsap.fromTo('.vm-intro h2>em',{x:18},{x:0,ease:'none',scrollTrigger:{trigger:'.vm-method',start:'top bottom',end:'top 35%',scrub:.6}});
  gsap.from('.vc-about h2',{yPercent:22,rotation:-3,ease:'none',scrollTrigger:{trigger:'.vc-about',start:'top bottom',end:'top 30%',scrub:.5}});
 },root);return()=>ctx.revert();});return()=>media.revert();},[]);
 const closeOpening=useCallback(()=>setIntro(false),[]);
 const replay=()=>{scrollTo({top:0,behavior:'instant'});if(!matchMedia('(prefers-reduced-motion: reduce)').matches)setIntro(true);};
 const copy=async()=>{try{await navigator.clipboard.writeText(identity.email);setCopied('Email copiata.');}catch{setCopied('Puoi selezionare l’indirizzo oppure aprire il collegamento email.');}};
 return <main ref={root} className="vc-site" id="inizio"><noscript><style>{'.vc-opening{display:none!important}'}</style></noscript><a className="vc-skip" href="#progetti">Vai ai progetti</a><header className="vc-header"><a href="#inizio" aria-label="ONE MAN — Inizio">ONE MAN</a><span>SALVATORE CANNAVALE<br/>DESIGN / SVILUPPO / MOVIMENTO</span><button onClick={()=>setMenu(true)} aria-haspopup="dialog">Menu <b aria-hidden="true">≡</b></button></header>
 <section className="vc-hero" aria-labelledby="vc-title"><TypographicBackdrop/><div className="vc-hero-shade"/><div className="vc-hero-copy"><p className="vc-eyebrow">CREATORE INDIPENDENTE. VISIONE PERSONALE.</p><h1 id="vc-title" className="vc-sr">Salvatore Cannavale — ONE MAN</h1><Name/><div className="vc-hero-footer"><p>IL TUO PROSSIMO SITO<br/><em>DEVE LASCIARE IL SEGNO.</em></p><a href="#progetti">Esplora i progetti <span aria-hidden="true">↓</span></a></div></div><div className="vc-hero-edge"><span>LA REALTÀ SI RISCRIVE.</span><button onClick={replay}>Rivedi l’apertura ↻</button></div></section>
 <section className="vc-manifesto" aria-labelledby="vc-manifesto-title"><p className="vc-eyebrow">UNA VISIONE CHE PRENDE SPAZIO.</p><h2 id="vc-manifesto-title"><span className="vc-manifesto-line">IL WEB PUÒ</span><span className="vc-manifesto-line"><em>FARE DI PIÙ.</em></span></h2><p>Identità, interazione e codice.<br/>Per idee che hanno il coraggio di farsi notare.</p></section>
 <EditorialProjects onOpen={setSelected}/>
 <CreativeMethod/>
 <section id="chi-sono" className="vc-about"><p className="vc-eyebrow">DIETRO ONE MAN / SALVATORE CANNAVALE</p><h2>UN SOLO<br/>CREATORE.<br/><em>IDEE CHE FANNO RUMORE.</em></h2><div><p>{identity.bio}</p><p>{identity.approach}</p><span>IDEAZIONE / DIREZIONE ARTISTICA / DESIGN / SVILUPPO</span></div></section>
 <section id="contatti" className="vc-contact"><p className="vc-eyebrow">IL PROSSIMO MOVIMENTO È TUO.</p><h2>FACCIAMOCI<br/><em>NOTARE.</em></h2><a className="vc-email" href={`mailto:${identity.email}`}>{identity.email} ↗</a><button onClick={copy}>Copia email</button><p className="vc-copy-status" role="status">{copied}</p><footer><span>ONE MAN — LA REALTÀ SI RISCRIVE.</span><button onClick={replay}>Rivedi l’introduzione ↻</button><a href="#inizio">Torna all’inizio ↑</a></footer></section>
 {menu&&<Navigation editorial onClose={()=>setMenu(false)}/>}{selected&&<ProjectView project={selected} onClose={()=>setSelected(null)}/>}{intro&&<SignatureOpening onClose={closeOpening}/>}
 </main>;
}
