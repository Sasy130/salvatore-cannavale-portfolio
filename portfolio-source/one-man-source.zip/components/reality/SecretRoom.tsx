"use client";
import SceneSlot from "@/components/universe/SceneSlot";
import { siteConfig } from "@/lib/site-data";
import { useEffect, useRef } from "react";
import { useReality } from "@/lib/reality-store";
import { usePerformance } from "@/lib/performance-store";
import SceneBoundary from "@/components/portfolio/SceneBoundary";

export default function SecretRoom() {
  const dialog = useRef<HTMLDialogElement>(null);
  const polarity = useReality((s) => s.polarity);
  const reduced = usePerformance((s) => s.reduced),
    webgl = usePerformance((s) => s.webgl);
  useEffect(() => {
    const previousFocus =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    const el = dialog.current;
    el?.showModal();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      el?.close();
      document.body.style.overflow = previous;
      if (previousFocus?.isConnected)
        previousFocus.focus({ preventScroll: true });
    };
  }, []);
  return (
    <dialog
      className="secret-room"
      ref={dialog}
      aria-labelledby="secret-heading"
      onCancel={() => useReality.getState().closeSecret()}
    >
      <div className="secret-room-top">
        <span className="eyebrow">ANOMALIA / 07</span>
        <button
          autoFocus
          className="outline-button"
          onClick={() => useReality.getState().closeSecret()}
        >
          Torna al portfolio ×
        </button>
      </div>
      <h2 id="secret-heading">
        OLTRE IL
        <br />
        <span>VISIBILE.</span>
      </h2>
      <p className="secret-phrase">{siteConfig.secretPhrase}</p>
      <div className="secret-art" data-cursor="drag">
        {webgl && !reduced ? (
          <SceneBoundary
            onError={() => usePerformance.setState({ webgl: false })}
          >
            <SceneSlot kind="secret" />
          </SceneBoundary>
        ) : (
          <div
            className={`secret-static ${polarity < 0 ? "inverted" : ""}`}
            aria-hidden="true"
          >
            <i />
            <i />
            <i />
          </div>
        )}
      </div>
      <div className="secret-actions">
        <p id="secret-instruction">
          Tocca l’oggetto o inverti la materia.
          <br />
          La forma cambia. Il centro rimane.
        </p>
        <button
          className="outline-button"
          onClick={() => useReality.getState().invert()}
          aria-describedby="secret-instruction"
        >
          Inverti la materia ↔
        </button>
        <span role="status">
          Configurazione {polarity > 0 ? "01" : "02"} / 02
        </span>
      </div>
    </dialog>
  );
}
