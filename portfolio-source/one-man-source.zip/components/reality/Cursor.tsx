"use client";
import { useEffect, useRef } from "react";
import { useReality } from "@/lib/reality-store";
export default function Cursor() {
  const cursor = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = cursor.current;
    if (!el) return;
    const media = matchMedia(
      "(hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
    );
    let raf = 0,
      x = 0,
      y = 0,
      drag = false;
    const move = (e: PointerEvent) => {
      if (e.pointerType === "touch" || !media.matches) {
        el.hidden = true;
        return;
      }
      el.hidden = false;
      x = e.clientX;
      y = e.clientY;
      const target = e.target as Element;
      const state = drag
        ? "drag"
        : target.closest(".portal-link,.next-project-link")
          ? "project"
          : target.closest(".reality-hud,.reality-launch") || useReality.getState().active
            ? "reality"
            : target.closest("button,a,input,summary")
              ? "interaction"
              : "normal";
      el.dataset.state = state;
      el.textContent =
        state === "project"
          ? "ESPLORA"
          : state === "drag"
            ? "TRASCINA"
            : state === "reality"
              ? "RISCRIVI"
              : "";
      if (!raf)
        raf = requestAnimationFrame(() => {
          el.style.transform = `translate3d(${x}px,${y}px,0)`;
          raf = 0;
        });
    };
    const down = (e: PointerEvent) => {
      drag = !!(e.target as Element).closest(
        '[data-cursor="drag"],input[type="range"]',
      );
      move(e);
    };
    const up = () => {
      drag = false;
    };
    const hide = () => {
      el.hidden = true;
    };
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("pointerdown", down);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    window.addEventListener("blur", hide);
    document.addEventListener("mouseleave", hide);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerdown", down);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
      window.removeEventListener("blur", hide);
      document.removeEventListener("mouseleave", hide);
    };
  }, []);
  return (
    <div className="advanced-cursor" ref={cursor} hidden aria-hidden="true" />
  );
}
