"use client";
import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { fractureAmount, useReality } from "@/lib/reality-store";
import { interactionFrame } from "@/lib/interaction-orchestrator";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { usePerformance } from "@/lib/performance-store";
export default function WordFragments() {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const tier = usePerformance((s) => s.tier);
  const { size } = useThree();
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const rect = useRef<DOMRect | null>(null);
  const points = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = 600;
    c.height = 450;
    const ctx = c.getContext("2d");
    if (!ctx) return [];
    ctx.fillStyle = "white";
    ctx.font = "900 240px Arial";
    ctx.textBaseline = "top";
    ctx.fillText("ONE", 0, 0);
    ctx.fillText("MAN", 0, 225);
    const data = ctx.getImageData(0, 0, 600, 450).data;
    const out: { x: number; y: number; angle: number }[] = [];
    const step = tier === "high" ? 10 : tier === "medium" ? 13 : 17;
    for (let y = 0; y < 450; y += step)
      for (let x = 0; x < 600; x += step)
        if (data[(y * 600 + x) * 4 + 3] > 120)
          out.push({ x: x / 600, y: y / 450, angle: out.length * 2.399 });
    return out;
  }, [tier]);
  useEffect(() => {
    const update = () => {
      rect.current =
        document.getElementById("portfolio-title")?.getBoundingClientRect() ??
        null;
    };
    update();
    window.addEventListener("resize", update);
    const unsub = useReality.subscribe((s, p) => {
      if (s.fragmentStart !== p.fragmentStart) update();
    });
    return () => {
      window.removeEventListener("resize", update);
      unsub();
    };
  }, []);
  useFrame(({ camera, gl }) => {
    if (!mesh.current) return;
    const state = useReality.getState();
    const r = rect.current;
    mesh.current.visible = state.fragmenting && !!r && usePortfolioScene.getState().view === "world";
    gl.domElement.dataset.typographyPieces = String(points.length);
    gl.domElement.dataset.typographyActive = String(mesh.current.visible);
    if (!mesh.current.visible || !r) return;
    const amount = fractureAmount(performance.now(), state.fragmentStart);
    const distance = 6;
    const height =
      2 *
      Math.tan(
        THREE.MathUtils.degToRad((camera as THREE.PerspectiveCamera).fov / 2),
      ) *
      distance;
    const width = (height * size.width) / size.height;
    points.forEach((p, i) => {
      const px = r.left + p.x * r.width,
        py = r.top + p.y * r.height;
      const x = (px / size.width - 0.5) * width,
        y = (0.5 - py / size.height) * height;
      dummy.position.set(
        x + Math.sin(p.angle) * amount * 1.2,
        y + Math.cos(p.angle * 1.3) * amount * 0.8,
        -distance + Math.sin(i * 1.73) * amount * 2 +
          Math.exp(-Math.hypot(x / width * 2 - interactionFrame.x, y / height * 2 - interactionFrame.y) * 3) * amount * .8,
      );
      dummy.position.applyQuaternion(camera.quaternion).add(camera.position);
      dummy.rotation.set(amount * p.angle, amount * i * 0.13, amount * 0.4);
      dummy.scale.setScalar(
        Math.max(
          0.018,
          (((r.width / size.width) * width) / 600) * (tier === "high" ? 8 : 11),
        ),
      );
      dummy.updateMatrix();
      mesh.current!.setMatrixAt(i, dummy.matrix);
    });
    mesh.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh
      ref={mesh}
      args={[undefined, undefined, points.length]}
      frustumCulled={false}
    >
      <boxGeometry />
      <meshBasicMaterial color="#f4f1ed" toneMapped={false} />
    </instancedMesh>
  );
}
