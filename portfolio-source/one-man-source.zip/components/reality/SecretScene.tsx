"use client";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useReality } from "@/lib/reality-store";
import { usePerformance } from "@/lib/performance-store";
import GpuDiagnostics from "./GpuDiagnostics";
class ImpossibleLoop extends THREE.Curve<THREE.Vector3> {
  constructor() {
    super();
  }
  getPoint(t: number, target = new THREE.Vector3()) {
    const a = t * Math.PI * 2;
    const r = 1.3 + 0.28 * Math.cos(a * 5);
    return target.set(Math.cos(a) * r, Math.sin(a) * r, 0.48 * Math.sin(a * 3));
  }
}
function Sculpture() {
  const tier = usePerformance((s) => s.tier);
  const ref = useRef<THREE.Mesh>(null);
  const uniforms = useMemo(
    () => ({ uFold: { value: 1 }, uTime: { value: 0 } }),
    [],
  );
  const geometry = useMemo(
    () =>
      new THREE.TubeGeometry(
        new ImpossibleLoop(),
        tier === "low" ? 64 : 128,
        0.12,
        tier === "low" ? 6 : 10,
        true,
      ),
    [tier],
  );
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(({ clock, pointer }, dt) => {
    uniforms.uTime.value = clock.elapsedTime;
    uniforms.uFold.value = THREE.MathUtils.damp(
      uniforms.uFold.value,
      useReality.getState().polarity,
      3,
      dt,
    );
    if (ref.current) {
      ref.current.rotation.set(
        pointer.y * 0.3,
        clock.elapsedTime * 0.14 + pointer.x * 0.4,
        0.2,
      );
    }
  });
  return (
    <mesh
      ref={ref}
      geometry={geometry}
      onClick={() => useReality.getState().invert()}
    >
      <meshStandardMaterial
        color="#b8b5c2"
        metalness={0.95}
        roughness={0.18}
        side={THREE.DoubleSide}
        onBeforeCompile={(program) => {
          Object.assign(program.uniforms, uniforms);
          program.vertexShader =
            "uniform float uFold; uniform float uTime;\n" +
            program.vertexShader;
          program.vertexShader = program.vertexShader.replace(
            "#include <begin_vertex>",
            "#include <begin_vertex>\n transformed.z *= uFold; transformed.xy *= 1.+sin(position.z*5.+uTime)*.055*(1.-abs(uFold));",
          );
        }}
      />
    </mesh>
  );
}
export default function SecretScene() {
  const tier = usePerformance((s) => s.tier);
  return (
    <Canvas
      dpr={tier === "high" ? 1.35 : 1}
      camera={{ position: [0, 0, 5.5], fov: 45 }}
      gl={{ antialias: tier === "high", alpha: true }}
    >
      <SecretContents />
    </Canvas>
  );
}

export function SecretContents({
  diagnostics = true,
}: {
  diagnostics?: boolean;
}) {
  const tier = usePerformance((s) => s.tier);
  return (
    <>
      {" "}
      <ambientLight intensity={0.5} />
      <pointLight position={[2, -1, 3]} color="#ff3038" intensity={35} />
      <Environment resolution={tier === "high" ? 128 : 64} frames={1}>
        <Lightformer position={[-3, 2, 3]} scale={[2, 7, 1]} intensity={7} />
        <Lightformer
          position={[3, -1, 2]}
          scale={[1, 5, 1]}
          color="#ff3038"
          intensity={6}
        />
      </Environment>
      <Sculpture />
      {diagnostics && (
        <GpuDiagnostics
          onFailure={() => usePerformance.setState({ webgl: false })}
        />
      )}
    </>
  );
}
