"use client";
import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useRef } from "react";
export default function GpuDiagnostics({
  onFailure,
}: {
  onFailure?: () => void;
}) {
  const last = useRef(-1);
  const samples = useRef(0);
  const { gl } = useThree();
  useEffect(() => {
    if (!onFailure) return;
    const lost = () => onFailure();
    gl.domElement.addEventListener("webglcontextlost", lost);
    return () => gl.domElement.removeEventListener("webglcontextlost", lost);
  }, [gl, onFailure]);
  useFrame(({ gl }) => {
    const now = performance.now() / 1000;
    if (now - last.current < 1) return;
    last.current = now;
    gl.domElement.dataset.gpuSamples = String(++samples.current);
    gl.domElement.dataset.gpuCalls = String(gl.info.render.calls);
    gl.domElement.dataset.gpuGeometries = String(gl.info.memory.geometries);
    gl.domElement.dataset.gpuTextures = String(gl.info.memory.textures);
  });
  return null;
}
