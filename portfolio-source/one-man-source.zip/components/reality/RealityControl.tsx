"use client";
import dynamic from "next/dynamic";
import { usePathname } from "next/navigation";
import { useRef, useState } from "react";
import { useReality } from "@/lib/reality-store";
import {
  usePerformance,
  qualitySettings,
  type Quality,
} from "@/lib/performance-store";
import { enableAudio, silenceAudio, playTone } from "@/lib/audio";
const SecretRoom = dynamic(() => import("./SecretRoom"), { ssr: false });
export default function RealityControl() {
  const pathname = usePathname();
  const active = useReality((s) => s.active),
    gravity = useReality((s) => s.gravity),
    distortion = useReality((s) => s.distortion),
    fragmenting = useReality((s) => s.fragmenting),
    secret = useReality((s) => s.secret);
  const tier = usePerformance((s) => s.tier),
    choice = usePerformance((s) => s.choice),
    audio = usePerformance((s) => s.audio),
    reduced = usePerformance((s) => s.reduced);
  const [status, setStatus] = useState("");
  const launch = useRef<HTMLButtonElement>(null);
  const exit = () => {
    useReality.getState().deactivate();
    launch.current?.focus();
  };
  const sound = async () => {
    if (audio) {
      silenceAudio();
      usePerformance.setState({ audio: false });
      return;
    }
    const enabled = await enableAudio();
    usePerformance.setState({ audio: enabled });
    if (enabled) playTone();
    else setStatus("L’audio non è disponibile in questo browser.");
  };
  return (
    <>
      <div className="reality-dock" data-reality>
        <button
          className="sound-switch"
          aria-pressed={audio}
          onClick={sound}
          aria-label={audio ? "Disattiva audio" : "Attiva audio"}
        >
          <i aria-hidden="true" />
          {audio ? "Audio acceso" : "Audio spento"}
        </button>
        <button
          ref={launch}
          className="reality-launch"
          aria-expanded={active}
          aria-controls="reality-console"
          onClick={() => (active ? exit() : useReality.getState().activate())}
        >
          <span aria-hidden="true">⌘</span>
          {active ? "ESCI DAL CONTROLLO" : "CONTROLLA LA REALTÀ"}
        </button>
      </div>
      {active && (
        <aside
          id="reality-console"
          className="reality-console"
          aria-label="Controlli della realtà"
          data-reality
        >
          <header>
            <span className="eyebrow">CONTROLLO DELLA REALTÀ / ATTIVO</span>
            <button onClick={exit} aria-label="Disattiva il controllo della realtà">
              ×
            </button>
          </header>
          <p>
            {reduced
              ? "Movimento ridotto: niente fluttuazioni automatiche. Puoi separare le lettere e modificare la superficie."
              : "La materia risponde. I collegamenti restano liberi."}
          </p>
          <button
            className="reality-option"
            aria-pressed={gravity}
            disabled={reduced}
            onClick={() => useReality.getState().setGravity(!gravity)}
          >
            <span>Gravità alterata</span>
            <i aria-hidden="true">{gravity ? "ATTIVA" : "SPENTA"}</i>
          </button>
          <label className="distortion-control" data-cursor="drag">
            <span>
              Distorsione della realtà{" "}
              <output>{Math.round(distortion * 100)}%</output>
            </span>
            <div className="distortion-track" aria-hidden="true">
              <i style={{ left: `${(distortion + 1) * 50}%` }} />
              <span />
            </div>
            <input
              aria-label="Distorsione della realtà"
              type="range"
              min="-100"
              max="100"
              step="1"
              value={Math.round(distortion * 100)}
              onChange={(e) =>
                useReality.getState().distort(Number(e.target.value) / 100)
              }
            />
            <small>Trascina il punto o usa le frecce.</small>
          </label>
          <button
            className="reality-option"
            onClick={() => {
              const hero = document.getElementById("portfolio-title");
              if (hero) {
                hero.scrollIntoView({ behavior: "instant", block: "center" });
                useReality.getState().fragment();
                setStatus(
                  "ONE MAN si frammenta e si ricompone in 4,2 secondi.",
                );
              } else
                setStatus(
                  "La tipografia monumentale si trova nella Home. Torna alla Home per frammentarla.",
                );
            }}
            aria-controls={pathname === "/" ? "portfolio-title" : undefined}
          >
            <span>
              {fragmenting ? "Ripeti la frammentazione" : "Frammenta ONE MAN"}
            </span>
            <i aria-hidden="true">↗</i>
          </button>
          <div className="reality-quality">
            <label htmlFor="render-quality">Qualità visiva</label>
            <select
              id="render-quality"
              value={choice}
              onChange={(e) =>
                usePerformance
                  .getState()
                  .setQuality(e.target.value as Quality | "auto")
              }
            >
              <option value="auto">Automatica</option>
              <option value="high">Alta</option>
              <option value="medium">Media</option>
              <option value="low">Bassa</option>
            </select>
            <span>
              Attuale: {qualitySettings[tier].label}
              {reduced ? " · movimento ridotto" : ""}
            </span>
          </div>
          <details className="secret-clue">
            <summary>C’è qualcosa oltre il visibile.</summary>
            <p>La settima stanza non compare sulle mappe.</p>
            <button onClick={() => useReality.getState().openSecret()}>
              Apri la stanza 07 ↗
            </button>
          </details>
          <div className="reality-console-bottom">
            <button
              onClick={() => {
                useReality.getState().reset();
                setStatus("Disposizione originale ripristinata.");
              }}
            >
              Ripristina tutto ↺
            </button>
            <span>ESC / USCITA</span>
          </div>
          <p className="reality-status" role="status">
            {status}
          </p>
        </aside>
      )}
      {secret && <SecretRoom />}
    </>
  );
}
