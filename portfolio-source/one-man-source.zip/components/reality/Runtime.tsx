"use client";
import { useEffect } from "react";
import dynamic from "next/dynamic";
import gsap from "gsap";
const UniversalRenderer = dynamic(
  () => import("@/components/universe/UniversalRenderer"),
  { ssr: false },
);
import { usePathname } from "next/navigation";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useReality } from "@/lib/reality-store";
import { usePerformance, type Quality } from "@/lib/performance-store";
import { playTone, silenceAudio } from "@/lib/audio";
import { updatePointer, endInteraction } from "@/lib/interaction-orchestrator";
import PortalStage from "@/components/universe/PortalStage";
import VisualMemoryRuntime from "@/components/universe/VisualMemoryRuntime";
import Cursor from "./Cursor";
import "./reality.css";
export default function Runtime() {
  const pathname = usePathname();
  const legacy = pathname.startsWith("/progetti/");
  const capable = usePerformance((s) => s.ready && s.webgl && !s.reduced);
  useEffect(() => {
    useReality.getState().deactivate();
  }, [pathname]);
  useEffect(() => {
    // Le rivelazioni HTML rispettano il tempo reale anche durante una compilazione GPU.
    gsap.ticker.lagSmoothing(0);
    const media = matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => {
      usePerformance.setState({ reduced: media.matches });
      if (media.matches) {
        useReality.getState().reset();
        usePerformance.setState({ tier: "low" });
      }
    };
    update();
    media.addEventListener("change", update);
    let webgl = false;
    try {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl2");
      webgl = !!gl;
      gl?.getExtension("WEBGL_lose_context")?.loseContext();
    } catch {}
    const mobile = innerWidth < 768 || navigator.hardwareConcurrency <= 4;
    usePerformance.setState({
      ready: true,
      webgl,
      tier: media.matches ? "low" : mobile ? "medium" : "high",
    });
    const pointer = { x: innerWidth / 2, y: innerHeight / 2 };
    let last = performance.now(),
      windowStart = last,
      frames = 0,
      slowWindows = 0,
      raf = 0;
    const bodies = new Map<
      HTMLElement,
      { x: number; y: number; vx: number; vy: number; index: number }
    >();
    const move = (e: PointerEvent) => {
      pointer.x = e.clientX;
      pointer.y = e.clientY;
      updatePointer(e.clientX, e.clientY, innerWidth, innerHeight);
    };
    const resetBodies = () => {
      for (const [el] of bodies) {
        el.style.removeProperty("--reality-x");
        el.style.removeProperty("--reality-y");
        el.style.removeProperty("--reality-r");
      }
      bodies.clear();
    };
    const key = (e: KeyboardEvent) => {
      if (
        e.key === "Escape" &&
        usePortfolioScene.getState().view === "world" &&
        (useReality.getState().active || useReality.getState().secret)
      ) {
        useReality.getState().deactivate();
        requestAnimationFrame(() =>
          document.querySelector<HTMLButtonElement>(".reality-launch")?.focus(),
        );
      }
    };
    const hidden = () => {
      endInteraction();
      last = performance.now();
      windowStart = last;
      frames = 0;
      if (document.hidden) {
        silenceAudio();
        usePerformance.setState({ audio: false });
      }
    };
    let previousActive = false,
      previousRevision = -1;
    const setData = (el: HTMLElement, key: string, value: string) => {
      if (el.dataset[key] !== value) el.dataset[key] = value;
    };
    let surface: HTMLElement | null = null,
      lastProbe = -1000;
    const frame = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.04);
      last = now;
      const state = useReality.getState();
      const perf = usePerformance.getState();
      if (!document.hidden) {
        frames++;
        if (now - windowStart > 4000) {
          const average = (now - windowStart) / frames;
          if (
            perf.choice === "auto" &&
            !perf.reduced &&
            document.querySelector("canvas") &&
            average > 40
          ) {
            slowWindows++;
            if (slowWindows >= 2) {
              const tier: Quality = perf.tier === "high" ? "medium" : "low";
              usePerformance.setState({ tier });
              slowWindows = 0;
            }
          } else slowWindows = 0;
          windowStart = now;
          frames = 0;
        }
        setData(
          document.documentElement,
          "reality",
          state.active ? "active" : "idle",
        );
        setData(document.documentElement, "quality", perf.tier);
        setData(
          document.documentElement,
          "webgl",
          perf.webgl && !perf.reduced ? "ready" : "fallback",
        );
        setData(
          document.documentElement,
          "fragment",
          state.fragmenting ? "active" : "idle",
        );
        if (state.fragmenting && now - state.fragmentStart >= 4200)
          useReality.setState({ fragmenting: false, fragmentStart: 0 });
        if (
          state.revision !== previousRevision ||
          !state.active ||
          !state.gravity ||
          perf.reduced ||
          usePortfolioScene.getState().view !== "world"
        ) {
          if (bodies.size) resetBodies();
          previousRevision = state.revision;
        } else {
          if (!bodies.size)
            document
              .querySelectorAll<HTMLElement>(".reality-body")
              .forEach((el, index) =>
                bodies.set(el, { x: 0, y: 0, vx: 0, vy: 0, index }),
              );
          const reads = Array.from(bodies, ([el, body]) => ({
            el,
            body,
            rect: el.getBoundingClientRect(),
          }));
          for (const { el, body: b, rect: r } of reads) {
            if (r.bottom < 0 || r.top > innerHeight) continue;
            const nx = Math.max(
                -1,
                Math.min(1, (pointer.x - r.left - r.width / 2) / innerWidth),
              ),
              ny = Math.max(
                -1,
                Math.min(1, (pointer.y - r.top - r.height / 2) / innerHeight),
              );
            const tx = nx * 18,
              ty = Math.sin(now * 0.001 + b.index) * 7 + ny * 12;
            b.vx += (tx - b.x) * 32 * dt;
            b.vy += (ty - b.y) * 32 * dt;
            b.vx *= Math.exp(-8 * dt);
            b.vy *= Math.exp(-8 * dt);
            b.x += b.vx * dt;
            b.y += b.vy * dt;
            el.style.setProperty("--reality-x", `${b.x.toFixed(2)}px`);
            el.style.setProperty("--reality-y", `${b.y.toFixed(2)}px`);
            el.style.setProperty("--reality-r", `${(nx * 2.2).toFixed(2)}deg`);
          }
        }
        if (!surface?.isConnected && now - lastProbe > 150) {
          surface = document.querySelector<HTMLElement>(".portfolio");
          lastProbe = now;
        }
        if (surface?.isConnected) {
          const value = String(state.active ? state.distortion : 0);
          if (surface.style.getPropertyValue("--distortion") !== value)
            surface.style.setProperty("--distortion", value);
          setData(
            surface,
            "gravity",
            state.active && state.gravity ? "active" : "idle",
          );
          setData(surface, "fragment", state.fragmenting ? "active" : "idle");
        }
        if (state.active !== previousActive && perf.audio) playTone();
        previousActive = state.active;
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    const unsubscribe = useReality.subscribe((s, p) => {
      if (s.revision !== p.revision)
        usePortfolioScene.setState({ matter: "AUTO" });
      if (!usePerformance.getState().audio) return;
      if (s.fragmentStart !== p.fragmentStart && s.fragmenting)
        playTone("fracture");
      if (s.secret && !p.secret) playTone("secret");
    });
    window.addEventListener("pointermove", move, { passive: true });
    window.addEventListener("keydown", key);
    document.addEventListener("visibilitychange", hidden);
    return () => {
      cancelAnimationFrame(raf);
      resetBodies();
      unsubscribe();
      silenceAudio();
      media.removeEventListener("change", update);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("keydown", key);
      document.removeEventListener("visibilitychange", hidden);
      delete document.documentElement.dataset.reality;
      delete document.documentElement.dataset.fragment;
    };
  }, []);
  return (
    <>
      {legacy && <><VisualMemoryRuntime /><PortalStage /><Cursor />{capable && <UniversalRenderer />}</>}
    </>
  );
}
