"use client";
import {
  Canvas,
  useFrame,
  useThree,
  type ThreeEvent,
} from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { usePerformance, qualitySettings } from "@/lib/performance-store";
import GpuDiagnostics from "./reality/GpuDiagnostics";
import { createMonolithGeometry } from "@/lib/monolith";
import { useIntro } from "@/lib/intro-store";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { ShaderPass } from "three/addons/postprocessing/ShaderPass.js";
type CaptureTarget = {
  setPointerCapture: (id: number) => void;
  releasePointerCapture: (id: number) => void;
};
const vertex = `uniform float uTime;uniform float uEnergy;varying vec3 vPosition;varying vec3 vNormal;void main(){vPosition=position;vNormal=normal;vec3 p=position;float wave=sin(p.y*11.+uTime*6.)*sin(p.x*8.-uTime*3.);p+=normal*wave*uEnergy*.13;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`;
const fragment = `uniform float uTime;uniform float uEnergy;varying vec3 vPosition;varying vec3 vNormal;void main(){float line=abs(vPosition.x+.12*sin(vPosition.y*9.)+.09*sin(vPosition.y*21.));float crack=(1.-smoothstep(.006,.027,line))*uEnergy;float edge=pow(1.-abs(dot(normalize(vNormal),normalize(vec3(.4,.3,1.)))),3.);vec3 base=vec3(.025,.028,.034)+edge*vec3(.25,.27,.29);float pulse=.75+.25*sin(uTime*9.);gl_FragColor=vec4(vec3(1.,.025,.04)*(crack*3.*pulse+edge*.22),clamp(crack+edge*.4,0.,1.));}`;
function Monolith() {
  const phase = useIntro((s) => s.phase);
  const group = useRef<THREE.Group>(null);
  const parts = useRef<THREE.Group>(null);
  const shader = useMemo(
    () =>
      new THREE.ShaderMaterial({
        uniforms: { uTime: { value: 0 }, uEnergy: { value: 0 } },
        vertexShader: vertex,
        fragmentShader: fragment,
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      }),
    [],
  );
  const geometry = useMemo(() => createMonolithGeometry(), []);
  useEffect(
    () => () => {
      shader.dispose();
      geometry.dispose();
    },
    [shader, geometry],
  );
  useFrame(({ clock, pointer, gl }, dt) => {
    if (group.current && !gl.domElement.dataset.sceneReady)
      gl.domElement.dataset.sceneReady = "true";
    const s = useIntro.getState();
    shader.uniforms.uTime.value = clock.elapsedTime;
    shader.uniforms.uEnergy.value = s.energy;
    const visible = ["IDLE", "CONTACT", "FRACTURE"].includes(s.phase);
    if (group.current) {
      group.current.visible = visible;
      group.current.rotation.y = THREE.MathUtils.damp(
        group.current.rotation.y,
        -0.38 + pointer.x * 0.28,
        4,
        dt,
      );
      group.current.rotation.x = THREE.MathUtils.damp(
        group.current.rotation.x,
        0.08 - pointer.y * 0.12,
        4,
        dt,
      );
      group.current.position.y = Math.sin(clock.elapsedTime * 0.7) * 0.08;
    }
    if (parts.current) {
      const fracture = s.phase === "FRACTURE" ? Math.min(s.elapsed / 2, 1) : 0;
      parts.current.children.forEach((part, i) => {
        const angle = i * 2.399;
        part.position.set(
          Math.cos(angle) * fracture * (2 + i * 0.15),
          (i - 5) * 0.38 * fracture,
          Math.sin(angle) * fracture * 2,
        );
        part.rotation.set(
          fracture * i * 0.3,
          fracture * i * 0.7,
          fracture * (i % 2 ? 1 : -1),
        );
      });
    }
  });
  const press = (e: ThreeEvent<PointerEvent>) => {
    if (["IDLE", "CONTACT"].includes(useIntro.getState().phase)) {
      e.stopPropagation();
      (e.target as unknown as CaptureTarget).setPointerCapture(e.pointerId);
      useIntro.getState().hold(true);
    }
  };
  return (
    <group ref={group} position={[0, 0, 0]}>
      <group rotation={[0, 0, -0.13]}>
        <mesh
          geometry={geometry}
          raycast={
            phase === "IDLE" || phase === "CONTACT" ? undefined : () => {}
          }
          onPointerDown={press}
          onPointerUp={() => useIntro.getState().hold(false)}
          onPointerCancel={() => useIntro.getState().hold(false)}
          visible={phase !== "FRACTURE"}
        >
          <meshStandardMaterial
            color="#55565e"
            metalness={0.88}
            roughness={0.26}
            onBeforeCompile={(program) => {
              program.uniforms.uTime = shader.uniforms.uTime;
              program.uniforms.uEnergy = shader.uniforms.uEnergy;
              program.vertexShader =
                "uniform float uTime; uniform float uEnergy;\n" +
                program.vertexShader;
              program.vertexShader = program.vertexShader.replace(
                "#include <begin_vertex>",
                "#include <begin_vertex>\n transformed += normal * sin(position.y*11.+uTime*6.)*sin(position.x*8.-uTime*3.)*uEnergy*.13;",
              );
            }}
          />
        </mesh>
        <mesh
          geometry={geometry}
          material={shader}
          scale={1.003}
          visible={phase !== "FRACTURE"}
        />
        <group ref={parts} visible={phase === "FRACTURE"}>
          {Array.from({ length: 12 }, (_, i) => (
            <mesh key={i} position={[0, (i - 5.5) * 0.29, 0]}>
              <boxGeometry args={[1.45, 0.28, 0.6]} />
              <meshStandardMaterial
                color={i % 3 === 0 ? "#ff3038" : "#35363c"}
                metalness={0.95}
                roughness={0.22}
                emissive="#ff1524"
                emissiveIntensity={i % 3 === 0 ? 1 : 0.03}
              />
            </mesh>
          ))}
        </group>
      </group>
      <mesh position={[0, 0, -0.5]}>
        <planeGeometry args={[0.045, 5]} />
        <meshBasicMaterial color="#ff3038" toneMapped={false} />
      </mesh>
    </group>
  );
}
function Architecture() {
  const room = useRef<THREE.Group>(null);
  const instanced = useRef<THREE.InstancedMesh>(null);
  const baseMatrices = useMemo(
    () => Array.from({ length: 48 }, () => new THREE.Matrix4()),
    [],
  );
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useEffect(() => {
    if (!instanced.current) return;
    for (let i = 0; i < 48; i++) {
      const side = i % 4;
      const depth = Math.floor(i / 4);
      dummy.position.set(
        side === 0 ? -4 : side === 1 ? 4 : ((i % 3) - 1) * 2.4,
        side === 2 ? 3.2 : side === 3 ? -3.2 : ((i % 5) - 2) * 1.2,
        -depth * 2.8 - 2,
      );
      dummy.rotation.set(i * 0.13, (side * Math.PI) / 2, i * 0.19);
      dummy.scale.set(side < 2 ? 0.1 : 2.3, side < 2 ? 2.8 : 0.12, 1.8);
      dummy.updateMatrix();
      instanced.current.setMatrixAt(i, dummy.matrix);
      baseMatrices[i].copy(dummy.matrix);
    }
    instanced.current.instanceMatrix.needsUpdate = true;
  }, [dummy, baseMatrices]);
  useFrame(({ clock }, dt) => {
    const s = useIntro.getState();
    if (instanced.current && s.phase === "CREATION") {
      for (let i = 0; i < 48; i++) {
        baseMatrices[i].decompose(
          dummy.position,
          dummy.quaternion,
          dummy.scale,
        );
        dummy.position.x *= 1 - s.creationProgress * 0.25;
        dummy.position.y *= 1 - s.creationProgress * 0.25;
        dummy.position.z += s.creationProgress * Math.floor(i / 4) * 0.4;
        dummy.rotation.z *= 1 - s.creationProgress;
        dummy.updateMatrix();
        instanced.current.setMatrixAt(i, dummy.matrix);
      }
      instanced.current.instanceMatrix.needsUpdate = true;
    }
    if (room.current) {
      room.current.visible = ["ROOM", "CREATION", "REVEAL"].includes(s.phase);
      room.current.rotation.z = THREE.MathUtils.damp(
        room.current.rotation.z,
        s.phase === "CREATION"
          ? Math.sin(clock.elapsedTime * 0.3) * 0.03 * (1 - s.creationProgress)
          : 0,
        2,
        dt,
      );
    }
  });
  return (
    <group ref={room}>
      <instancedMesh ref={instanced} args={[undefined, undefined, 48]}>
        <boxGeometry />
        <meshStandardMaterial
          color="#464850"
          metalness={0.95}
          roughness={0.22}
        />
      </instancedMesh>
      {Array.from({ length: 7 }, (_, i) => (
        <group
          key={i}
          position={[0, 0, -i * 4 - 3]}
          rotation={[0, 0, i * 0.24]}
        >
          <mesh>
            <torusGeometry args={[4, 0.035, 4, 4]} />
            <meshStandardMaterial
              color="#aaaab4"
              metalness={1}
              roughness={0.15}
            />
          </mesh>
          <mesh position={[2.9, 0, 0]}>
            <boxGeometry args={[0.035, 4, 0.04]} />
            <meshBasicMaterial color="#ff3038" toneMapped={false} />
          </mesh>
        </group>
      ))}
      <gridHelper
        args={[60, 30, "#ff3038", "#24242b"]}
        position={[0, -3.5, -15]}
      />
    </group>
  );
}
function LetterCloud({ low }: { low: boolean }) {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const targets = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 700;
    canvas.height = 150;
    const ctx = canvas.getContext("2d")!;
    ctx.fillStyle = "white";
    ctx.font = "900 145px Arial";
    ctx.textAlign = "center";
    ctx.fillText("ONE MAN", 350, 125);
    const pixels = ctx.getImageData(0, 0, 700, 150).data;
    const points: THREE.Vector3[] = [];
    const step = low ? 8 : 6;
    for (let y = 0; y < 150; y += step)
      for (let x = 0; x < 700; x += step)
        if (pixels[(y * 700 + x) * 4 + 3] > 100)
          points.push(new THREE.Vector3((x - 350) / 85, (75 - y) / 85, 0));
    return points;
  }, [low]);
  useFrame(({ clock }) => {
    if (!mesh.current) return;
    const s = useIntro.getState();
    mesh.current.visible = ["CREATION", "REVEAL"].includes(s.phase);
    const t =
      s.phase === "REVEAL"
        ? Math.min(0.12 + s.creationProgress * 0.76 + s.elapsed / 1.3, 1)
        : 0.12 + s.creationProgress * 0.76;
    targets.forEach((target, i) => {
      const angle = i * 2.399;
      dummy.position.set(
        Math.sin(angle) * 6,
        Math.cos(angle * 1.2) * 4,
        Math.sin(i * 3.1) * 4 - 1,
      );
      dummy.position.lerp(target, t);
      dummy.position.y += Math.sin(clock.elapsedTime + i) * 0.018 * (1 - t);
      dummy.rotation.set((1 - t) * i, (1 - t) * angle, 0);
      dummy.scale.setScalar(low ? 0.065 : 0.045);
      dummy.updateMatrix();
      mesh.current!.setMatrixAt(i, dummy.matrix);
    });
    mesh.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh
      ref={mesh}
      args={[undefined, undefined, targets.length]}
      position={[0, 0.2, -3]}
      scale={
        typeof window !== "undefined" && window.innerWidth < 768 ? 0.52 : 1
      }
    >
      <boxGeometry />
      <meshStandardMaterial
        color="#f4f1ed"
        emissive="#e5c9c0"
        emissiveIntensity={0.2}
        metalness={0.75}
        roughness={0.2}
      />
    </instancedMesh>
  );
}
function Core() {
  const ref = useRef<THREE.Mesh>(null);
  const dragging = useRef(false);
  const plane = useMemo(
    () => new THREE.Plane(new THREE.Vector3(0, 0, 1), 0),
    [],
  );
  const hit = useMemo(() => new THREE.Vector3(), []);
  const phase = useIntro((s) => s.phase);
  const mobile = useThree((s) => s.size.width < 768);
  const startX = mobile ? -0.65 : -1.5;
  const targetX = mobile ? 0.65 : 1.45;
  const target = new THREE.Vector3(targetX, 0.35, 0);
  const move = (e: ThreeEvent<PointerEvent>) => {
    if (!dragging.current || !ref.current) return;
    e.stopPropagation();
    e.ray.intersectPlane(plane, hit);
    ref.current.position.copy(hit);
    useIntro.setState({
      creationProgress: THREE.MathUtils.clamp(
        1 - hit.distanceTo(target) / (targetX - startX),
        0,
        1,
      ),
    });
    if (hit.distanceTo(target) < (mobile ? 0.3 : 0.6)) {
      dragging.current = false;
      (e.target as unknown as CaptureTarget).releasePointerCapture(e.pointerId);
      useIntro.getState().transition("REVEAL");
    }
  };
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = clock.elapsedTime;
      ref.current.rotation.z = clock.elapsedTime * 0.3;
      if (!dragging.current && useIntro.getState().phase !== "CREATION")
        ref.current.position.set(startX, 0.3, 0);
    }
  });
  // Rays intersect a world-space plane; pointer capture keeps the drag alive outside the core.

  if (phase !== "CREATION") return null;
  return (
    <group>
      <mesh
        ref={ref}
        position={[startX, 0.3, 0]}
        onPointerDown={(e) => {
          e.stopPropagation();
          dragging.current = true;
          (e.target as unknown as CaptureTarget).setPointerCapture(e.pointerId);
        }}
        onPointerMove={move}
        onPointerUp={(e) => {
          dragging.current = false;
          (e.target as unknown as CaptureTarget).releasePointerCapture(
            e.pointerId,
          );
        }}
        onPointerCancel={() => {
          dragging.current = false;
        }}
      >
        <icosahedronGeometry args={[mobile ? 0.2 : 0.28, 1]} />
        <meshStandardMaterial
          color="#fff2dd"
          emissive="#ff3038"
          emissiveIntensity={3}
          wireframe={false}
        />
        <pointLight color="#ff3038" intensity={4} />
      </mesh>
      <mesh position={[targetX, 0.35, 0]}>
        <torusGeometry args={[mobile ? 0.3 : 0.48, 0.025, 8, 40]} />
        <meshBasicMaterial color="#ff3038" toneMapped={false} />
      </mesh>
      <mesh position={[targetX, 0.35, 0]}>
        <sphereGeometry args={[0.06, 8, 8]} />
        <meshBasicMaterial color="white" />
      </mesh>
    </group>
  );
}
function CameraRig() {
  const orientation = useRef({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number } | null>(null);
  const { gl } = useThree();
  useEffect(() => {
    const canvas = gl.domElement;
    const down = (e: PointerEvent) => {
      if (useIntro.getState().phase === "ROOM") {
        drag.current = { x: e.clientX, y: e.clientY };
        canvas.setPointerCapture(e.pointerId);
      }
    };
    const move = (e: PointerEvent) => {
      if (!drag.current || useIntro.getState().phase !== "ROOM") return;
      const dx = (e.clientX - drag.current.x) / 300,
        dy = (e.clientY - drag.current.y) / 300;
      orientation.current.x = THREE.MathUtils.clamp(
        orientation.current.x + dx,
        -0.65,
        0.65,
      );
      orientation.current.y = THREE.MathUtils.clamp(
        orientation.current.y + dy,
        -0.35,
        0.35,
      );
      useIntro.getState().explore(Math.abs(dx) + Math.abs(dy));
      drag.current = { x: e.clientX, y: e.clientY };
    };
    const up = () => {
      drag.current = null;
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);
    return () => {
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
    };
  }, [gl]);
  useFrame(({ camera }, dt) => {
    const s = useIntro.getState();
    let z = 7 - s.energy * 0.8;
    let x = 0,
      y = 0.15;
    if (s.phase === "FRACTURE") z = 6.2 - s.elapsed * 2.6;
    if (s.phase === "ROOM" || s.phase === "CREATION") z = 5.8;
    if (s.phase === "REVEAL") {
      const t = THREE.MathUtils.smoothstep(s.elapsed, 1.4, 4.2);
      z = 5.8 - t * 10;
      x = -3.1 * t * (gl.domElement.clientWidth < 768 ? 0.52 : 1);
      y = 0.2 * t;
    }
    camera.position.x = THREE.MathUtils.damp(camera.position.x, x, 4, dt);
    camera.position.y = THREE.MathUtils.damp(camera.position.y, y, 4, dt);
    camera.position.z = THREE.MathUtils.damp(camera.position.z, z, 5, dt);
    camera.rotation.y = THREE.MathUtils.damp(
      camera.rotation.y,
      s.phase === "ROOM" ? orientation.current.x : 0,
      4,
      dt,
    );
    camera.rotation.x = THREE.MathUtils.damp(
      camera.rotation.x,
      s.phase === "ROOM" ? orientation.current.y : 0,
      4,
      dt,
    );
    camera.updateProjectionMatrix();
  });
  return null;
}
export default function Universe() {
  const tier = usePerformance((s) => s.tier);
  const low = tier !== "high";
  return (
    <Canvas
      dpr={qualitySettings[tier].dpr}
      camera={{ position: [0, 0.15, 7], fov: 48, near: 0.1, far: 80 }}
      gl={{ antialias: !low, powerPreference: "high-performance" }}
      onCreated={({ gl }) => {
        gl.domElement.setAttribute(
          "aria-label",
          "Universo tridimensionale interattivo: monolite, stanza e nucleo",
        );
      }}
    >
      <IntroContents />
    </Canvas>
  );
}

export function IntroContents({
  diagnostics = true,
}: {
  diagnostics?: boolean;
}) {
  const tier = usePerformance((s) => s.tier);
  const low = tier !== "high";
  return (
    <>
      {" "}
      <color attach="background" args={["#050506"]} />
      <fog attach="fog" args={["#050506", 12, 45]} />
      <ambientLight intensity={0.24} />
      <spotLight
        position={[-4, 5, 4]}
        intensity={65}
        color="#e9e8ff"
        angle={0.55}
        penumbra={1}
      />
      <pointLight position={[2, 0, 2]} color="#ff3038" intensity={22} />
      <Environment resolution={qualitySettings[tier].environment} frames={1}>
        <Lightformer position={[-3, 3, 2]} scale={[2, 8, 1]} intensity={5} />
        <Lightformer
          position={[3, 0, 1]}
          scale={[1, 7, 1]}
          color="#ff3038"
          intensity={8}
        />
        <Lightformer position={[0, 5, -2]} scale={[8, 1, 1]} intensity={4} />
      </Environment>
      <Monolith />
      <Architecture />
      <LetterCloud low={low} />
      <Core />
      <CameraRig />
      <PulseLight />
      {diagnostics && (
        <GpuDiagnostics
          onFailure={() => {
            useIntro.setState({ fallback: true, holding: false });
            usePerformance.setState({ webgl: false });
          }}
        />
      )}
      {!low && <LensDistortion />}
    </>
  );
}

function PulseLight() {
  const light = useRef<THREE.PointLight>(null);
  useFrame(({ clock }) => {
    const s = useIntro.getState();
    if (light.current)
      light.current.intensity =
        8 + s.energy * (18 + Math.sin(clock.elapsedTime * 15) * 10);
  });
  return (
    <pointLight
      ref={light}
      position={[-1, 0, 1]}
      color="#ff3038"
      intensity={8}
    />
  );
}
function LensDistortion() {
  const { gl, scene, camera, size } = useThree();
  const pass = useMemo(
    () =>
      new ShaderPass({
        uniforms: { tDiffuse: { value: null }, uAmount: { value: 0 } },
        vertexShader:
          "varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
        fragmentShader:
          "uniform sampler2D tDiffuse;uniform float uAmount;varying vec2 vUv;void main(){vec2 p=vUv-.5;vec2 uv=.5+p*(1.+uAmount*dot(p,p)*.8);vec2 offset=p*uAmount*.018;vec3 col=vec3(texture2D(tDiffuse,uv+offset).r,texture2D(tDiffuse,uv).g,texture2D(tDiffuse,uv-offset).b);gl_FragColor=vec4(col,1.);}",
      }),
    [],
  );
  const composer = useMemo(() => {
    const c = new EffectComposer(gl);
    c.addPass(new RenderPass(scene, camera));
    c.addPass(pass);
    return c;
  }, [gl, scene, camera, pass]);
  useEffect(() => {
    composer.setSize(size.width, size.height);
  }, [composer, size]);
  useEffect(
    () => () => {
      composer.dispose();
      composer.passes.forEach((p) => p.dispose());
    },
    [composer],
  );
  useFrame((_, dt) => {
    const s = useIntro.getState();
    pass.uniforms.uAmount.value =
      s.phase === "FRACTURE"
        ? Math.sin(Math.min(s.elapsed / 3.2, 1) * Math.PI) * 1.2
        : s.phase === "REVEAL"
          ? Math.max(0, s.elapsed - 1.8) * 0.3
          : 0;
    composer.render(dt);
  }, 1);
  return null;
}
