"use client";
import { Canvas, useFrame, useThree, type ThreeEvent } from "@react-three/fiber";
import { Environment, Lightformer } from "@react-three/drei";
import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import AnamorphicSurface from "./AnamorphicSurface";
import RecursiveFrames, { MiniatureGallery } from "./RecursiveFrames";
import { galleryChoreography, galleryChapter, ramp } from "@/lib/gallery-choreography";
import { galleryMotion } from "@/lib/gallery-motion";
import { galleryWorks, galleryCopy, type GalleryWork } from "@/lib/gallery-data";
import { usePerformance } from "@/lib/performance-store";

type Props = {
  intro: boolean;
  run: number;
  selected: string | null;
  visible: boolean;
  onIntroDone: () => void;
  onSelect: (id: string) => void;
  onExpanded: () => void;
  onFailure: () => void;
  onReady: () => void;
  labels: React.RefObject<Map<string,HTMLButtonElement>>;
};
const bend = `uniform float uFold;
#include <common>`;
const bentPosition = `#include <begin_vertex>
float edge = smoothstep(.28,1.,uv.x) * smoothstep(.05,.95,uv.y);
transformed.z += edge * sin(uFold * 3.14159265) * 1.7;
transformed.x -= edge * sin(uFold * 3.14159265) * .45;`;

function Cover({src, w, h, time, revealing}:{src:string;w:number;h:number;time:React.RefObject<number>;revealing:boolean}) {
  const group=useRef<THREE.Group>(null), flat=useRef({value:0});
  useFrame(()=>{if(group.current)group.current.position.z=revealing?THREE.MathUtils.lerp(-1.32,.075,ramp(time.current,4.8,5.8)):.075;});
  return <group ref={group} position={[0,0,revealing?-1.32:.075]}><AnamorphicSurface width={w-.18} height={h-.18} amountRef={flat} src={src}/></group>;
}
function MovingShadow({introTime}:{introTime:React.RefObject<number>}) {
  const mesh=useRef<THREE.Mesh>(null);
  const material=useMemo(()=>new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,
    uniforms:{},
    vertexShader:"varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
    fragmentShader:"varying vec2 vUv;void main(){vec2 q=(vUv-.5)*2.;float a=exp(-dot(q*vec2(1.,2.2),q*vec2(1.,2.2))*2.8)*.23;gl_FragColor=vec4(.12,.105,.09,a);}",
  }),[]);
  useEffect(()=>()=>material.dispose(),[material]);
  useFrame(()=>{
    if(!mesh.current)return;
    const t=introTime.current;
    // L'ombra precede il gesto della cornice, anziché seguirlo.
    mesh.current.position.x= t<2.8 ? -Math.sin(Math.min(t/1.4,1)*Math.PI/2)*.85 : -.85;
  });
  return <mesh ref={mesh} position={[0,-2.12,.1]} rotation={[-Math.PI/2,0,0]} material={material}><planeGeometry args={[9,6]}/></mesh>;
}
function PictureRoom({time, first}:{time:React.RefObject<number>;first:boolean}) {
  const door=useRef<THREE.Mesh>(null);
  const wall=useRef<THREE.Mesh>(null), left=useRef<THREE.Group>(null), right=useRef<THREE.Group>(null);
  const uniform=useMemo(()=>({value:0}),[]);
  useFrame(()=>{
    const p=first?THREE.MathUtils.smoothstep(time.current,1.25,4.7):1;
    uniform.value=p;
    if(door.current)door.current.scale.y=1-ramp(galleryMotion.scroll,.10,.30);
    if(wall.current){wall.current.position.z=-.18-p*.9;wall.current.rotation.y=-p*.12;}
    if(left.current)left.current.rotation.y=-p*1.35;
    if(right.current)right.current.rotation.y=p*1.3;
  });
  return <group position={[0,0,-.08]}>
    <mesh ref={wall}>
      <planeGeometry args={[2.78,3.4,20,20]}/>
      <meshStandardMaterial color="#d8d3c9" roughness={.95} side={THREE.DoubleSide}
        onBeforeCompile={program=>{program.uniforms.uFold=uniform;program.vertexShader=program.vertexShader.replace("#include <common>",bend).replace("#include <begin_vertex>",bentPosition);}}/>
    </mesh>
    <mesh ref={door} position={[0,-.23,-.15]}><planeGeometry args={[.72,1.95]}/><meshBasicMaterial color="#262622"/></mesh>
    <mesh position={[.39,-.23,-.12]}><planeGeometry args={[.016,1.95]}/><meshBasicMaterial color="#ef3a32"/></mesh>
    <group ref={left} position={[-1.4,0,.01]}><mesh position={[.29,0,0]}><planeGeometry args={[.58,3.4]}/><meshStandardMaterial color="#ede8de" side={THREE.DoubleSide} roughness={.9}/></mesh></group>
    <group ref={right} position={[1.4,0,.01]}><mesh position={[-.29,0,0]}><planeGeometry args={[.58,3.4]}/><meshStandardMaterial color="#e5e0d6" side={THREE.DoubleSide} roughness={.9}/></mesh></group>
  </group>;
}
function WorkFrame({work,index,count,props,time}:{work:GalleryWork;index:number;count:number;props:Props;time:React.RefObject<number>}) {
  const group=useRef<THREE.Group>(null);
  const target=useMemo(()=>new THREE.Vector3(),[]);
  const anchor=useMemo(()=>new THREE.Vector3(),[]);
  const anamorph=useRef({value:0});
  const hit=useRef<THREE.Mesh>(null);
  const face=useRef<THREE.Group>(null),fracture=useRef<THREE.Group>(null);
  const reference=useRef(new THREE.Vector3());
  const inverse=useMemo(()=>new THREE.Matrix4(),[]);
  const width=useThree(s=>s.size.width);
  const mobile=width<768;
  const baseWidth=index%3===2?3.25:index%3===1?3:2.5;
  const baseHeight=index%3===2?2.4:index%3===1?3.6:3.15;
  const middle=Math.floor(count/2);
  const first=index===middle;
  const selectedIndex=props.selected?galleryWorks.findIndex(item=>item.id===props.selected):middle;
  const dimensionScale=mobile?.62:1;
  const w=baseWidth,h=baseHeight;
  const cover=work.project?.cover??work.preview?.src;
  useFrame(({camera,size,gl},rawDt)=>{
    if(!group.current)return;
    const dt=Math.min(rawDt,.08), p=galleryMotion.scroll;
    const opened=THREE.MathUtils.smoothstep(time.current,2.65,5.8);
    const choreography=galleryChoreography(p);
    const sequence=THREE.MathUtils.clamp((p-.70)/.3,0,1)*(count-1);
    const strength=ramp(p,.82,1);
    const d=index-sequence, focus=Math.exp(-d*d*3.3)*strength;
    const spread=mobile?2.15:4.15;
    let x=(index-middle)*spread;
    x=THREE.MathUtils.lerp(x,Math.tanh(d*1.25)*(mobile?2.25:4.9),strength);
    let y= index%3===2?.2:first?-.1:.12;
    let z=(first?.45:-1.3)-strength*(1-focus)*1.6+focus*1.5;
    let ry=(index-middle)*-.17*(1-strength)+Math.sign(d)*strength*-.22;
    let scale=dimensionScale*(1-strength*.2+focus*.24);
    if(props.intro){
      if(first){x=0;y=0;z=0;ry=-Math.sin(Math.max(0,time.current-1.25)*.7)*.055;scale=THREE.MathUtils.lerp(1,dimensionScale,opened);}
      else {x=(index-middle)*spread*(.55+opened*.45);z=-4+opened*2.7;scale*=opened;}
    }
    anamorph.current.value=THREE.MathUtils.damp(anamorph.current.value,props.intro||props.selected?0:choreography.anamorph,4,dt);
    if(first)gl.domElement.dataset.galleryAnamorphRendered=anamorph.current.value.toFixed(2);
    if(hit.current)hit.current.scale.set(1+anamorph.current.value*.6,1+anamorph.current.value*.6,1+anamorph.current.value*75);
    if(face.current)face.current.visible=anamorph.current.value<.025;
    if(fracture.current)fracture.current.visible=!props.intro&&anamorph.current.value>=.005;
    if(props.selected){
      const chosen=props.selected===work.id;
      const wing=index<selectedIndex?index:index-1;
      x=chosen?0:(wing%2===0?-1:1)*2.4;
      y=chosen?0:y;z=chosen?4:2.5;ry=chosen?0:Math.sign(x)*1.22;
      scale=chosen?1:dimensionScale*.75;
    }
    const k=1-Math.exp(-4.8*dt);
    target.set(x,y,z);
    group.current.position.lerp(target,k);
    group.current.rotation.y=THREE.MathUtils.damp(group.current.rotation.y,ry,4,dt);
    group.current.rotation.z=THREE.MathUtils.damp(group.current.rotation.z,first?-.012:.018*(index-middle),4,dt);
    group.current.scale.setScalar(THREE.MathUtils.damp(group.current.scale.x,scale,5,dt));
    group.current.updateWorldMatrix(true,false);
    inverse.copy(group.current.matrixWorld).invert();
    reference.current.set(0,.35,mobile?18:12).applyMatrix4(inverse);reference.current.z-=.075;
    const label=props.labels.current.get(work.id);
    if(label){
      group.current.updateWorldMatrix(true,false);
      anchor.set(0,-h/2-.34,.2).applyMatrix4(group.current.matrixWorld).project(camera);
      const px=(anchor.x*.5+.5)*size.width, py=(.5-anchor.y*.5)*size.height;
      const labelWidth=mobile?Math.min(116,size.width/count-12)-choreography.nested*24:230-choreography.nested*80;
      label.style.width=`${labelWidth.toFixed(1)}px`;
      const safeX=Math.max(labelWidth/2+10,Math.min(size.width-labelWidth/2-10,px));
      const safeY=Math.max(mobile?335:350,Math.min(size.height-175,py));
      label.style.transform=`translate3d(${safeX.toFixed(2)}px,${safeY.toFixed(2)}px,0) translateX(-50%)`;
      label.dataset.positioned="true";
    }
  },-1);
  const select=(e:ThreeEvent<MouseEvent>)=>{e.stopPropagation();if(!props.intro && e.delta<7)props.onSelect(work.id);};
  return <group ref={group} position={[(index-middle)*(mobile?2.15:4.15),props.intro?0:index%3===2?.2:first?-.1:.12,props.intro?(first?0:-3):(first?.45:-1.3)]} scale={props.intro?(first?1:.01):dimensionScale}>
    <mesh ref={hit} onClick={select} position={[0,0,.18]} onPointerOver={e=>{e.stopPropagation();if(!props.intro)document.body.style.cursor="pointer";}} onPointerOut={()=>{document.body.style.cursor="";}}>
      <boxGeometry args={[w+.16,h+.16,.12]}/><meshBasicMaterial transparent opacity={0} depthWrite={false} colorWrite={false}/>
    </mesh>
    {[[0,h/2+.04,w+.16,.08],[0,-h/2-.04,w+.16,.08],[-w/2-.04,0,.08,h],[w/2+.04,0,.08,h]].map(([x,y,bw,bh],j)=><mesh key={j} position={[x,y,0]}>
      <boxGeometry args={[bw,bh,.13]}/><meshStandardMaterial color={index%3===2?"#57554f":"#272722"} roughness={.5} metalness={.18}/>
    </mesh>)}
    <group ref={face}>
    <mesh position={[0,0,first&&(!cover||props.intro)?-1.35:.071]}><planeGeometry args={[w,h]}/><meshStandardMaterial color={index%3===2?"#d4cec3":"#f5f1e9"} roughness={1}/></mesh>
    {cover && <Suspense fallback={null}><Cover src={cover} w={w} h={h} time={time} revealing={first&&props.intro}/></Suspense>}
    {first&&(!cover||props.intro) ? <group scale={[w/3,h/3.6,1]}><PictureRoom time={time} first={first}/></group> : !cover ? <group position={[0,0,.08]}>
      <mesh position={[0,0,.01]}><planeGeometry args={[w*.72,h*.68]}/><meshBasicMaterial color={index%3===2?"#efebe3":"#e3ded5"}/></mesh>
      <mesh position={[-w*.32,-h*.27,.025]}><planeGeometry args={[.015,h*.38]}/><meshBasicMaterial color="#e13b31"/></mesh>
    </group> : null}
    {first&&!props.intro&&!work.project&&<MiniatureGallery/>}
    </group>
    <group ref={fracture} visible={false} position={[0,0,.075]}><AnamorphicSurface width={cover?w-.18:w} height={cover?h-.18:h} amountRef={anamorph} src={cover} referenceRef={reference} lightweight={mobile} variant={first?"portal":"paper"} baseColor={index%3===2?"#efebe3":"#e7e1d7"}/></group>
  </group>;
}
function Contents(props:Props) {
  const ready=useRef(false);
  const time=useRef(props.intro?0:galleryCopy.introDuration);
  const ended=useRef(!props.intro), expanded=useRef(false), focusTime=useRef(0);
  const cameraTarget=useMemo(()=>new THREE.Vector3(),[]), look=useMemo(()=>new THREE.Vector3(),[]);
  const {gl}=useThree();
  const onFailure=props.onFailure;
  useEffect(()=>{
    const lost=(e:Event)=>{e.preventDefault();onFailure();};
    gl.domElement.addEventListener("webglcontextlost",lost);
    gl.debug.onShaderError=(context,program,vertex,fragment)=>{console.error("Errore shader della galleria",context.getProgramInfoLog(program),context.getShaderInfoLog(vertex),context.getShaderInfoLog(fragment));queueMicrotask(onFailure);};
    return()=>{document.body.style.cursor="";gl.domElement.removeEventListener("webglcontextlost",lost);};
  },[gl,onFailure]);
  useEffect(()=>{focusTime.current=0;expanded.current=false;},[props.selected]);
  useFrame(({camera,size,gl},rawDt)=>{
    const dt=Math.min(rawDt,.08);
    if(props.intro)time.current+=Math.min(rawDt,.15);
    else time.current=Math.max(time.current,galleryCopy.introDuration);
    if(props.intro && time.current>=galleryCopy.introDuration && !ended.current){ended.current=true;queueMicrotask(props.onIntroDone);}
    const mobile=size.width<768;
    const t=props.intro?THREE.MathUtils.smoothstep(time.current,2.65,5.8):1;
    const choreography=galleryChoreography(galleryMotion.scroll);
    const dolly=(mobile?18:12)+choreography.nested*(mobile?10:16);
    cameraTarget.set(choreography.orbit*(mobile?4.8:7.5)+galleryMotion.yaw*2.2+galleryMotion.pointerX*(mobile?.025:.1),.35+choreography.orbit*1.7+galleryMotion.pointerY*.04,THREE.MathUtils.lerp(7,dolly,t));
    look.set(0,-.08,0);
    if(galleryMotion.front&&!props.intro){cameraTarget.set(0,.35,mobile?18:12);}
    if(props.selected){
      cameraTarget.set(0,.05,mobile?8.7:8.5);look.set(0,0,4);
      focusTime.current+=Math.min(rawDt,.15);
      if(focusTime.current>1.35 && !expanded.current){expanded.current=true;queueMicrotask(props.onExpanded);}
    }
    camera.position.lerp(cameraTarget,1-Math.exp(-4*dt));
    camera.lookAt(look);
    camera.rotateZ(galleryMotion.front?0:choreography.orbit*(mobile?.018:.035));
    camera.updateMatrixWorld();
    const perspective=camera as THREE.PerspectiveCamera;
    perspective.fov=mobile?42:40;perspective.updateProjectionMatrix();
    if(!ready.current){ready.current=true;queueMicrotask(props.onReady);}
    gl.domElement.dataset.galleryReady="true";
    gl.domElement.dataset.galleryPhase=props.intro?"introduzione":props.selected?"apertura":"panoramica";
    gl.domElement.dataset.galleryScroll=galleryMotion.scroll.toFixed(2);
    gl.domElement.dataset.galleryYaw=galleryMotion.yaw.toFixed(2);
    gl.domElement.dataset.galleryChapter=galleryChapter(galleryMotion.scroll);
    gl.domElement.dataset.galleryAnamorph=choreography.anamorph.toFixed(2);
    gl.domElement.dataset.galleryFront=String(galleryMotion.front);
    gl.domElement.dataset.galleryCamera=`${camera.position.x.toFixed(2)},${camera.position.y.toFixed(2)},${camera.position.z.toFixed(2)}`;
  },-2);
  return <>
    <color attach="background" args={["#e9e5dc"]}/><fog attach="fog" args={["#e9e5dc",25,65]}/>
    <ambientLight intensity={1.55}/>
    <directionalLight position={[-5,7,6]} intensity={3.5} color="#fff5df"/>
    <directionalLight position={[6,2,3]} intensity={.8} color="#e9edff"/>
    <Environment resolution={32} frames={1}>
      <Lightformer position={[-4,5,3]} scale={[4,7,1]} intensity={2}/>
      <Lightformer position={[5,1,2]} scale={[2,6,1]} intensity={1}/>
    </Environment>
    <MovingShadow introTime={time}/>
    <RecursiveFrames intro={props.intro} selected={!!props.selected}/>
    {galleryWorks.map((work,index)=><WorkFrame key={work.id} work={work} index={index} count={galleryWorks.length} props={props} time={time}/>)}
  </>;
}
export default function GalleryStage(props:Props) {
  const tier=usePerformance(s=>s.tier);
  const [cameraOptions]=useState(()=>({position:[0,.35,props.intro?7:window.innerWidth<768?18:12] as [number,number,number],fov:window.innerWidth<768?42:40,near:.1,far:80}));
  return <Canvas key={props.run} dpr={tier==="high"?1.35:1} frameloop={props.visible?"always":"never"}
    camera={cameraOptions}
    onCreated={({gl})=>{gl.setClearColor("#e9e5dc");gl.domElement.setAttribute("aria-hidden","true");}}
    gl={{alpha:false,antialias:false,powerPreference:"low-power"}}
>
    <Suspense fallback={null}><Contents {...props}/></Suspense>
  </Canvas>;
}
