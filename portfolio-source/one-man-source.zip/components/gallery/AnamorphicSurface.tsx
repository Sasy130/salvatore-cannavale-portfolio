"use client";
import { Suspense, useEffect, useMemo, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";
import { createAnamorphicGeometry } from "@/lib/anamorphic-geometry";

export interface AnamorphicSurfaceProps {
  width: number;
  height: number;
  amountRef: RefObject<{ value: number }>;
  src?: string;
  baseColor?: string;
  variant?: "portal" | "paper";
  referenceDistance?: number;
  referenceOrigin?: readonly [number, number];
  /** Coordinate del punto di vista frontale nello spazio locale della superficie. */
  referenceRef?: RefObject<THREE.Vector3>;
  lightweight?: boolean;
}
const vertexShader = `
attribute vec3 aCenter;
attribute vec3 aSeed;
uniform float uAmount;
uniform float uDepthScale;
uniform vec3 uReference;
uniform vec2 uSize;
varying vec3 vLocalPosition;
void main(){
  vec2 local = position.xy-aCenter.xy;
  float slopeX = sin(aSeed.y*6.2831853)*.72*uAmount;
  float slopeY = cos(aSeed.z*6.2831853)*.68*uAmount;
  float depth = (aSeed.x-.5)*min(uSize.x,uSize.y)*uDepthScale*uAmount;
  depth += local.x*slopeX+local.y*slopeY;
  float distance = max(3.,uReference.z);
  vec3 transformed;
  transformed.z = depth;
  transformed.xy = uReference.xy+(position.xy-uReference.xy)*(distance-depth)/distance;
  vLocalPosition=transformed;
  gl_Position=projectionMatrix*modelViewMatrix*vec4(transformed,1.);
}`;
const fragmentShader = `
uniform float uHasMap;
uniform sampler2D uMap;
uniform vec3 uColor;
uniform vec3 uInk;
uniform vec3 uInset;
uniform float uVariant;
uniform vec3 uRed;
uniform vec3 uReference;
uniform vec2 uSize;
uniform vec2 uCrop;
varying vec3 vLocalPosition;
void main(){
  float distance=max(3.,uReference.z);
  vec2 flatPoint=uReference.xy+(vLocalPosition.xy-uReference.xy)*distance/max(.1,distance-vLocalPosition.z);
  vec2 uv=flatPoint/uSize+.5;
  vec3 color=uColor;
  if(uHasMap>.5){
    color=texture2D(uMap,(uv-.5)*uCrop+.5).rgb;
  }else{
    if(uVariant<.5){
      float door=step(.38,uv.x)*step(uv.x,.62)*step(.165,uv.y)*step(uv.y,.707);
      float line=step(.63,uv.x)*step(uv.x,.635)*step(.165,uv.y)*step(uv.y,.707);
      color=mix(color,uInk,door);
      color=mix(color,uRed,line);
    }else{
      float inset=step(.14,uv.x)*step(uv.x,.86)*step(.16,uv.y)*step(uv.y,.84);
      float line=step(.17,uv.x)*step(uv.x,.175)*step(.23,uv.y)*step(uv.y,.42);
      color=mix(color,uInset,inset);
      color=mix(color,uRed,line);
    }
  }
  // La luce del retro rende riconoscibili i piani esposti dal punto di vista obliquo.
  if(!gl_FrontFacing)color*=.72;
  gl_FragColor=vec4(color,1.);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

function Surface({ texture, ...props }: Omit<AnamorphicSurfaceProps, "src"> & { texture?: THREE.Texture }) {
  const { width, height, amountRef, referenceRef, lightweight = false,
    baseColor = "#e7e1d7", variant = "portal", referenceDistance = 12, referenceOrigin } = props;
  const geometry = useMemo(() => createAnamorphicGeometry(width, height, lightweight), [width, height, lightweight]);
  const uniforms = useMemo(() => ({
    uAmount: { value: 0 },
    uDepthScale: { value: 1.7 },
    uReference: { value: new THREE.Vector3(0, 0, 12) },
    uSize: { value: new THREE.Vector2() },
    uMap: { value: null as THREE.Texture | null },
    uHasMap: { value: 0 },
    uCrop: { value: new THREE.Vector2(1, 1) },
    uColor: { value: new THREE.Color() },
    uInk: { value: new THREE.Color("#262622") },
    uInset: { value: new THREE.Color("#e3ded5") },
    uVariant: { value: 0 },
    uRed: { value: new THREE.Color("#e13b31") },
  }), []);
  const material = useMemo(() => new THREE.ShaderMaterial({
    vertexShader, fragmentShader, uniforms,
    side: THREE.DoubleSide, transparent: false, toneMapped: false,
  }), [uniforms]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useEffect(() => () => material.dispose(), [material]);
  useEffect(() => {
    uniforms.uSize.value.set(width, height);
    uniforms.uDepthScale.value=lightweight?1.7:2.8;
    uniforms.uColor.value.set(baseColor);
    uniforms.uInset.value.set(uniforms.uColor.value.r < .75 ? "#efebe3" : "#e3ded5");
    uniforms.uVariant.value = variant === "paper" ? 1 : 0;
    uniforms.uMap.value = texture ?? null;
    uniforms.uHasMap.value = texture ? 1 : 0;
    uniforms.uCrop.value.set(1, 1);
    if (texture) {
      const image = texture.image as { width?: number; height?: number } | undefined;
      const imageAspect = (image?.width ?? width) / (image?.height ?? height);
      const planeAspect = width / height;
      uniforms.uCrop.value.set(imageAspect > planeAspect ? planeAspect / imageAspect : 1,
        imageAspect < planeAspect ? imageAspect / planeAspect : 1);
    }
  }, [width, height, baseColor, variant, texture, uniforms, lightweight]);
  useFrame(() => {
    uniforms.uAmount.value = THREE.MathUtils.clamp(amountRef.current.value, 0, 1);
    if (referenceRef) uniforms.uReference.value.copy(referenceRef.current);
    else uniforms.uReference.value.set(referenceOrigin?.[0] ?? 0, referenceOrigin?.[1] ?? 0, referenceDistance);
  });
  return <mesh name="Superficie anamorfica" geometry={geometry} material={material} frustumCulled={false} raycast={() => {}} userData={{ anamorphicShards: geometry.userData.shards }} />;
}
function ImageSurface({ src, ...props }: AnamorphicSurfaceProps & { src: string }) {
  const original = useTexture(src);
  // La copia appartiene alla superficie; la risorsa della cache può essere condivisa con altre copertine.
  const texture = useMemo(() => {
    const owned = original.clone();
    owned.colorSpace = THREE.SRGBColorSpace;
    owned.needsUpdate = true;
    return owned;
  }, [original]);
  useEffect(() => () => texture.dispose(), [texture]);
  return <Surface {...props} texture={texture} />;
}
export default function AnamorphicSurface(props: AnamorphicSurfaceProps) {
  if (props.src) return <Suspense fallback={<Surface {...props} />}><ImageSurface {...props} src={props.src} /></Suspense>;
  return <Surface {...props} />;
}
