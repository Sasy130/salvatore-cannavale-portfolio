"use client";
import { useLayoutEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { galleryMotion } from "@/lib/gallery-motion";
import { galleryChoreography, ramp } from "@/lib/gallery-choreography";
import { galleryWorks } from "@/lib/gallery-data";

/** Copia geometrica finita dell'allestimento: due livelli, stesso renderer. */
export function MiniatureGallery(){
  const mesh=useRef<THREE.InstancedMesh>(null),group=useRef<THREE.Group>(null);
  const object=useMemo(()=>new THREE.Object3D(),[]);
  const parts=useMemo(()=>{
    const out:{x:number;y:number;z:number;w:number;h:number;d:number;color:string}[]=[];
    const frame=(x:number,y:number,z:number,w:number,h:number,s:number)=>{
      [[0,h/2,w+.16,.08],[0,-h/2,w+.16,.08],[-w/2,0,.08,h],[w/2,0,.08,h]].forEach(([dx,dy,bw,bh])=>out.push({x:x+dx*s,y:y+dy*s,z,w:bw*s,h:bh*s,d:.08*s,color:"#25241f"}));
      out.push({x,y,z:z-.04*s,w:w*s,h:h*s,d:.025*s,color:"#e8e2d7"});
      out.push({x:x-w*s*.31,y:y-h*s*.12,z:z+.03*s,w:.025*s,h:h*.55*s,d:.02*s,color:"#bb3026"});
    };
    for(let level=0;level<2;level++){
      const s=Math.pow(.22,level),z=level*.12;
      frame(0,0,z,15,8.2,s);
      galleryWorks.forEach((_,i)=>frame((i-(galleryWorks.length-1)/2)*4.1*s,0,z+.05, i%3===2?3.25:2.7,i%3===2?2.4:3.5,s));
    }
    return out;
  },[]);
  useLayoutEffect(()=>{
    if(!mesh.current)return;
    const color=new THREE.Color();
    parts.forEach((p,i)=>{object.position.set(p.x,p.y,p.z);object.scale.set(p.w,p.h,p.d);object.rotation.set(0,0,0);object.updateMatrix();mesh.current!.setMatrixAt(i,object.matrix);mesh.current!.setColorAt(i,color.set(p.color));});
    mesh.current.instanceMatrix.needsUpdate=true;if(mesh.current.instanceColor)mesh.current.instanceColor.needsUpdate=true;
  },[parts,object]);
  useFrame((_,dt)=>{
    if(!group.current)return;
    const amount=ramp(galleryMotion.scroll,.12,.3);
    group.current.scale.setScalar(THREE.MathUtils.damp(group.current.scale.x,.17*amount,5,Math.min(dt,.08)));
    group.current.rotation.y=galleryMotion.yaw*.1;
  });
  return <group ref={group} scale={0} position={[0,0,.14]}><instancedMesh ref={mesh} args={[undefined,undefined,parts.length]} frustumCulled={false}><boxGeometry/><meshBasicMaterial color="#ffffff" toneMapped={false}/></instancedMesh></group>;
}
function OuterFrame({rear,selected}:{rear:boolean;selected:boolean}){
  const group=useRef<THREE.Group>(null),bars=useRef<THREE.InstancedMesh>(null),back=useRef<THREE.Mesh>(null);
  const mobile=useThree(s=>s.size.width<768);
  const object=useMemo(()=>new THREE.Object3D(),[]);
  const dimensions=useRef({w:mobile?7.7:16,h:mobile?6.8:9});
  useFrame(({gl},rawDt)=>{
    if(!group.current||!bars.current||!back.current)return;
    const dt=Math.min(rawDt,.08),p=galleryMotion.scroll;
    const {nested}=galleryChoreography(p);
    const leave=selected&&!rear?0:ramp(p,.45,.69);
    const baseW=rear?(mobile?14:31):(mobile?7.7:16);
    const baseH=rear?(mobile?14:18):(mobile?6.8:9);
    dimensions.current.w=THREE.MathUtils.damp(dimensions.current.w,selected&&!rear?4.2:baseW,5,dt);
    dimensions.current.h=THREE.MathUtils.damp(dimensions.current.h,selected&&!rear?4.8:baseH,5,dt);
    const {w,h}=dimensions.current;
    const sizes=[[0,h/2,w+.18,.1],[0,-h/2,w+.18,.1],[-w/2,0,.1,h],[w/2,0,.1,h]];
    sizes.forEach(([x,y,bw,bh],i)=>{object.position.set(x,y,0);object.rotation.set(0,0,0);object.scale.set(bw,bh,rear?.14:.22);object.updateMatrix();bars.current!.setMatrixAt(i,object.matrix);});
    bars.current.instanceMatrix.needsUpdate=true;
    group.current.position.x=THREE.MathUtils.damp(group.current.position.x,(rear?-1:1)*leave*(mobile?9:20),5,dt);
    group.current.position.z=rear?-14:2.6;
    group.current.rotation.y=THREE.MathUtils.damp(group.current.rotation.y,(rear?1:-1)*leave*1.05,5,dt);
    group.current.rotation.z=(rear?-.018:.012)*nested;
    group.current.visible=p>.06||selected;
    back.current.scale.set(w,h,1);
    if(!rear){gl.domElement.dataset.galleryNesting=nested.toFixed(2);gl.domElement.dataset.galleryRecursionLevels="3";}
  },-1);
  return <group ref={group} visible={false}>
    <mesh ref={back} position={[0,0,rear?-3.5:-6]}><planeGeometry/><meshStandardMaterial color={rear?"#d7d0c3":"#e6dfd2"} roughness={1}/></mesh>
    <instancedMesh ref={bars} args={[undefined,undefined,4]} frustumCulled={false}><boxGeometry/><meshStandardMaterial color={rear?"#b22e25":"#24231e"} roughness={.55} metalness={.15}/></instancedMesh>

  </group>;
}
export default function RecursiveFrames({intro,selected}:{intro:boolean;selected:boolean}){
  return <group visible={!intro}><OuterFrame rear={false} selected={selected}/><OuterFrame rear selected={selected}/></group>;
}
