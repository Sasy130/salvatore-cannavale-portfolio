"use client";
import GalleryArrow from "./GalleryArrow";
import { useEffect, useRef } from "react";
import type { GalleryWork } from "@/lib/gallery-data";
export default function GalleryDetail({work,onClose}:{work:GalleryWork;onClose:()=>void}) {
  const dialog=useRef<HTMLDialogElement>(null);
  useEffect(()=>{
    const el=dialog.current, prior=document.activeElement as HTMLElement|null;
    const overflow=document.body.style.overflow;
    el?.showModal();document.body.style.overflow="hidden";
    return()=>{el?.close();document.body.style.overflow=overflow;if(prior?.isConnected)prior.focus({preventScroll:true});};
  },[]);
  const project=work.project;
  return <dialog ref={dialog} className="gallery-detail" aria-labelledby="gallery-detail-title" onCancel={e=>{e.preventDefault();onClose();}}>
    <header><span className="gallery-wordmark">ONE MAN</span><button autoFocus onClick={onClose}>Torna alla panoramica <span aria-hidden="true">×</span></button></header>
    <div className="gallery-detail-meta"><span>{work.number} / {project?project.category:work.preview?"IMMAGINE DI PROVA":"CORNICE VUOTA"}</span><span>{project?"PROGETTO":"ANTEPRIMA DELLO SPAZIO"}</span></div>
    <h2 id="gallery-detail-title">{project?project.title:<>Il prossimo<br/><em>punto di vista.</em></>}</h2>
    <p className="gallery-detail-description">{project?project.description:work.preview?"Questa fotografia è un’immagine di prova per valutare colori, proporzioni e trasformazioni della galleria. Non rappresenta un mio progetto: sarà sostituita da uno dei miei lavori.":"Questa cornice è ancora vuota. Qui troverà posto uno dei tuoi lavori, con immagini, racconto e dettagli del progetto."}</p>
    {project?<>
      <figure className="gallery-detail-cover"><img src={project.cover} alt={project.title} width={1400} height={1000}/></figure>
      {!!project.technologies?.length && <ul className="gallery-tech" aria-label="Tecnologie del progetto">{project.technologies.map(t=><li key={t}>{t}</li>)}</ul>}
      {project.images?.map(image=><figure className="gallery-detail-cover" key={image.src}><img src={image.src} alt={image.alt} width={1400} height={1000}/></figure>)}
      {project.href && <a className="gallery-primary-link" href={project.href}>Visita il progetto <GalleryArrow/></a>}
    </>:work.preview?<figure className="gallery-detail-cover"><img src={work.preview.src} alt={work.preview.alt} width={work.preview.width} height={work.preview.height}/><figcaption>Immagine dimostrativa — il progetto reale sarà inserito qui.</figcaption></figure>:<div className="gallery-empty-detail" aria-hidden="true"><i/><span>{work.number}</span><p>LO SPAZIO C’È.<br/>IL LAVORO SARÀ TUO.</p></div>}
    <footer><span>ONE MAN — LA REALTÀ SI RISCRIVE.</span><button onClick={onClose}>Tutti i progetti <GalleryArrow/></button></footer>
  </dialog>;
}
