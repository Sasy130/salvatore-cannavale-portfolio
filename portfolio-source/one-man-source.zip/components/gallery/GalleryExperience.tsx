"use client";
import GalleryArrow from "./GalleryArrow";
import dynamic from "next/dynamic";
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { galleryCopy, galleryWorks } from "@/lib/gallery-data";
import { galleryChapter } from "@/lib/gallery-choreography";
import { galleryMotion } from "@/lib/gallery-motion";
import { identity } from "@/lib/portfolio-data";
import { usePerformance } from "@/lib/performance-store";
import SceneBoundary from "@/components/portfolio/SceneBoundary";
import GalleryDetail from "./GalleryDetail";
import "./gallery.css";
const GalleryStage=dynamic(()=>import("./GalleryStage"),{ssr:false});
export default function GalleryExperience(){
  const [booted,setBooted]=useState(false),[front,setFront]=useState(false);
  const [intro,setIntro]=useState(true),[run,setRun]=useState(0),[list,setList]=useState(false);
  const [failed,setFailed]=useState(false),[rendered,setRendered]=useState(false),[visible,setVisible]=useState(true);
  const [selected,setSelected]=useState<string|null>(null),[expanded,setExpanded]=useState(false);
  const chapter=useRef<HTMLSpanElement>(null);
  const track=useRef<HTMLElement>(null),world=useRef<HTMLDivElement>(null),counter=useRef<HTMLSpanElement>(null),progress=useRef<HTMLSpanElement>(null);
  const labels=useRef(new Map<string,HTMLButtonElement>());
  const labelLayer=useRef<HTMLDivElement>(null);
  // Il livello fisso segue il canvas senza entrare nello scrollIntoView dello sticky.
  const positionLabels=useCallback(()=>{
    const layer=labelLayer.current,rect=world.current?.getBoundingClientRect();
    if(!layer||!rect)return;
    layer.style.top=`${rect.top}px`;layer.style.height=`${rect.height}px`;
    // Uscendo dalla scena si rimuovono anche i pulsanti dal percorso di Tab.
    layer.style.display=rect.top>=-1&&rect.top<innerHeight?"block":"none";
  },[]);
  const selectedScroll=useRef(0);
  const lastFocus=useRef<HTMLElement|null>(null),overviewButton=useRef<HTMLButtonElement>(null);
  const drag=useRef<{id:number;x:number;y:number;last:number;active:boolean}|null>(null);
  const ready=usePerformance(s=>s.ready),reduced=usePerformance(s=>s.reduced),webgl=usePerformance(s=>s.webgl);
  const capable=booted&&ready&&webgl&&!reduced&&!failed&&!list;
  const finishIntro=useCallback(()=>{setIntro(false);try{sessionStorage.setItem("one-man-gallery-intro","vista");}catch{}},[]);
  const fail=useCallback(()=>{setFailed(true);setIntro(false);},[]);
  const frameReady=useCallback(()=>setRendered(true),[]);
  const showExpanded=useCallback(()=>setExpanded(true),[]);
  const select=useCallback((id:string)=>{selectedScroll.current=window.scrollY;lastFocus.current=document.activeElement as HTMLElement|null;setSelected(id);setExpanded(false);},[]);
  const close=useCallback(()=>{
    const id=selected,restoreY=selectedScroll.current;setSelected(null);setExpanded(false);
    window.scrollTo({top:restoreY,behavior:"instant"});
    requestAnimationFrame(()=>requestAnimationFrame(()=>{window.scrollTo({top:restoreY,behavior:"instant"});const projected=id?labels.current.get(id):undefined;const prior=lastFocus.current;
      if(projected)projected.focus({preventScroll:true});else if(prior?.isConnected&&prior.tagName==="BUTTON")prior.focus({preventScroll:true});else overviewButton.current?.focus({preventScroll:true});}));
  },[selected]);
  useEffect(()=>{
    document.body.classList.add("gallery-page");
    setBooted(true);
    if(location.hash && location.hash!=="#inizio")setIntro(false);
    try{if(sessionStorage.getItem("one-man-gallery-intro")==="vista"&&new URLSearchParams(location.search).get("intro")!=="1")setIntro(false);}catch{}
    return()=>{document.body.classList.remove("gallery-page");document.body.style.cursor="";galleryMotion.scroll=0;galleryMotion.yaw=0;galleryMotion.front=false;};
  },[]);
  useEffect(()=>{
    if(!ready||!intro)return;
    if(reduced){setIntro(false);return;}
    const timer=setTimeout(finishIntro,capable?10000:1800);
    return()=>clearTimeout(timer);
  },[intro,ready,capable,reduced,finishIntro,run]);
  useEffect(()=>{
    if(!selected)return;
    const timer=setTimeout(showExpanded,capable?1800:0);
    return()=>clearTimeout(timer);
  },[selected,capable,showExpanded]);
  useEffect(()=>{
    const key=(e:KeyboardEvent)=>{if(e.key==="Escape"&&selected)close();};
    window.addEventListener("keydown",key);
    return()=>window.removeEventListener("keydown",key);
  },[selected,close]);
  useEffect(()=>{
    const element=world.current;
    const observer=new IntersectionObserver(entries=>setVisible(entries[0].isIntersecting&&!document.hidden),{rootMargin:"100px"});
    if(element)observer.observe(element);
    const visibility=()=>{setVisible(!document.hidden&&!!element&&element.getBoundingClientRect().bottom>0);drag.current=null;};
    document.addEventListener("visibilitychange",visibility);
    window.addEventListener("blur",visibility);
    return()=>{observer.disconnect();document.removeEventListener("visibilitychange",visibility);window.removeEventListener("blur",visibility);};
  },[]);
  useLayoutEffect(()=>{
    gsap.registerPlugin(ScrollTrigger);
    const sync=()=>{
      const element=track.current;if(!element)return;
      positionLabels();
      const rect=element.getBoundingClientRect();
      const value=Math.max(0,Math.min(1,-rect.top/Math.max(1,rect.height-innerHeight)));
      if(galleryMotion.front&&Math.abs(galleryMotion.scroll-value)>.006){galleryMotion.front=false;setFront(false);}
      galleryMotion.scroll=value;
      const name=galleryChapter(value);
      if(world.current)world.current.dataset.chapter=name;
      if(chapter.current)chapter.current.textContent=name==="panoramica"?"I / LA MOSTRA":name==="cornice"?"II / IL QUADRO NEL QUADRO":"III / OLTRE L’IMMAGINE";
      if(progress.current)progress.current.style.transform=`scaleX(${value})`;
      if(counter.current)counter.current.textContent=String(Math.min(galleryWorks.length,Math.floor(value*galleryWorks.length)+1)).padStart(2,"0");
    };
    const trigger=ScrollTrigger.create({trigger:track.current,start:"top top",end:"bottom bottom",onUpdate:sync});
    window.addEventListener("scroll",sync,{passive:true});window.addEventListener("resize",sync);sync();
    return()=>{trigger.kill();window.removeEventListener("scroll",sync);window.removeEventListener("resize",sync);};
  },[intro,list,positionLabels]);
  const overview=()=>{
    setSelected(null);setExpanded(false);galleryMotion.yaw=0;galleryMotion.front=false;setFront(false);
    track.current?.scrollIntoView({behavior:reduced?"instant":"smooth"});
  };
  const replay=()=>{
    overview();setList(false);setRendered(false);setRun(r=>r+1);setIntro(true);
    window.scrollTo({top:0,behavior:"instant"});
  };
  const work=galleryWorks.find(item=>item.id===selected);
  const hasWork=galleryWorks.some(item=>item.project);
  return <main className="art-gallery" id="inizio" data-gallery-mode={intro?"introduzione":list?"elenco":"spazio"}>
    <a className="gallery-skip" href="#progetti" onClick={finishIntro}>Vai ai progetti</a>
    <header className="gallery-header">
      <a className="gallery-wordmark" href="#inizio" onClick={overview} aria-label="ONE MAN — Inizio">ONE MAN</a>
      <span className="gallery-edition">PORTFOLIO PERSONALE<br/>EDIZIONE / {new Date().getFullYear()}</span>
      <nav aria-label="Navigazione principale"><a href="#progetti" onClick={finishIntro}>Progetti</a><a href="#chi-sono" onClick={finishIntro}>Chi sono</a><a href="#contatti" onClick={finishIntro}>Contatti <span aria-hidden="true"><GalleryArrow/></span></a></nav>
    </header>
    <section ref={track} id="progetti" className={`gallery-track ${list?"is-list":""}`} aria-labelledby="gallery-title">
      <div ref={world} className="gallery-viewport" data-chapter="panoramica">
        <div className="gallery-canvas" aria-hidden={intro?true:undefined}
          onPointerDown={e=>{if(intro||selected||e.button!==0)return;drag.current={id:e.pointerId,x:e.clientX,y:e.clientY,last:e.clientX,active:false};}}
          onPointerMove={e=>{
            const r=e.currentTarget.getBoundingClientRect();galleryMotion.pointerX=(e.clientX-r.left)/r.width*2-1;galleryMotion.pointerY=1-(e.clientY-r.top)/r.height*2;
            const d=drag.current;if(!d||d.id!==e.pointerId)return;
            if(!d.active&&Math.abs(e.clientX-d.x)>8&&Math.abs(e.clientX-d.x)>Math.abs(e.clientY-d.y)){d.active=true;e.currentTarget.setPointerCapture(e.pointerId);}
            if(d.active){if(galleryMotion.front){galleryMotion.front=false;setFront(false);}galleryMotion.yaw=Math.max(-.8,Math.min(.8,galleryMotion.yaw+(e.clientX-d.last)*.003));d.last=e.clientX;}
          }}
          onPointerUp={()=>{drag.current=null;}} onPointerCancel={()=>{drag.current=null;}} onLostPointerCapture={e=>{if(!e.currentTarget.hasPointerCapture(e.pointerId))drag.current=null;}}>
          {capable&&<SceneBoundary key={run} onError={fail}><GalleryStage intro={intro} run={run} selected={selected} visible={visible} onIntroDone={finishIntro} onSelect={select} onExpanded={showExpanded} onFailure={fail} onReady={frameReady} labels={labels}/></SceneBoundary>}
        </div>
        {(!capable||!rendered)&&<div className={`gallery-fallback ${intro?"fallback-intro":""}`} role="group" aria-label="Panoramica essenziale dei progetti">
          {galleryWorks.map((item,i)=><button key={item.id} className={`gallery-flat-frame flat-${i%3}`} onClick={()=>select(item.id)} disabled={intro} aria-label={item.project?`Apri il progetto ${item.title}`:`Esplora la cornice ${item.number}`}>
            <span className="flat-art">{item.project?<img src={item.project.cover} alt={item.title}/>:item.preview&&!intro?<img src={item.preview.src} alt={item.preview.alt} width={item.preview.width} height={item.preview.height}/>:<><i/><b aria-hidden="true">{item.number}</b></>}</span>
            {!intro&&<span className="flat-caption"><small>{item.number} / {item.category}</small><strong>{item.title} ↗</strong></span>}
          </button>)}
        </div>}
        {intro?<>
          <div className="gallery-intro-word" aria-hidden="true">ONE MAN</div>
          <button className="gallery-skip-intro" onClick={finishIntro}>Salta introduzione <span aria-hidden="true"><GalleryArrow/></span></button>
          <p className="gallery-intro-footer">LA REALTÀ SI RISCRIVE.</p>
        </>:<>
          <div className="gallery-heading"><div><p className="gallery-eyebrow">01 / SPAZIO ESPOSITIVO</p><h1 id="gallery-title">{galleryCopy.title}<span className="gallery-title-dot"/></h1></div><p className="gallery-heading-note">{hasWork?"Una selezione di lavori.":"Le cornici sono pronte."}<br/><em>Un altro punto di vista.</em></p></div>
          {capable&&rendered&&!selected&&<div className="gallery-labels" ref={el=>{labelLayer.current=el;positionLabels();}}>{galleryWorks.map(item=><button
            key={item.id} ref={el=>{if(el)labels.current.set(item.id,el);else labels.current.delete(item.id);}}
            className="gallery-caption" onClick={()=>select(item.id)} aria-label={item.project?`Apri il progetto ${item.title}`:`Esplora la cornice ${item.number}`}>
            <span className="gallery-caption-number">{item.number}<span aria-hidden="true"><GalleryArrow/></span></span>
            <strong>{item.title}</strong><small>{item.category}</small>
          </button>)}</div>}
          <div className="gallery-toolbar"><div className="gallery-view-switch" role="group" aria-label="Vista dei progetti"><button aria-pressed={!list} onClick={()=>{if(list){setList(false);setRendered(false);}}}>Spazio</button><button aria-pressed={list} onClick={()=>{setList(true);galleryMotion.scroll=0;galleryMotion.front=false;setFront(false);track.current?.scrollIntoView({behavior:"instant"});}}>Elenco</button></div><button className="gallery-front" aria-pressed={front} onClick={()=>{galleryMotion.front=!front;galleryMotion.yaw=0;setFront(!front);}}>Vista frontale <span aria-hidden="true">◎</span></button><button ref={overviewButton} onClick={overview} className="gallery-overview">Vista d’insieme <span aria-hidden="true"><GalleryArrow/></span></button></div>
          <div className="gallery-bottom"><p><span ref={chapter} className="gallery-chapter">I / LA MOSTRA</span>{hasWork?"SELEZIONA UN LAVORO PER ESPLORARLO":"TRE IMMAGINI DI PROVA. I TUOI PROGETTI ARRIVANO QUI."}<span>{reduced||!webgl||failed||list?"Scegli una cornice.":"Scorri per attraversare la mostra. Trascina per cambiare punto di vista."}</span></p><span className="gallery-counter"><span ref={counter}>01</span><i/> {String(galleryWorks.length).padStart(2,"0")}</span></div>
          <div className="gallery-progress"><span ref={progress}/></div>

        </>}
      </div>
    </section>
    <section id="chi-sono" className="gallery-about">
      <div className="gallery-section-index"><span>02 / DIETRO ONE MAN</span><span>UN’IDENTITÀ PERSONALE, UNA VISIONE APERTA.</span></div>
      <div className="gallery-about-body"><h2>Una persona.<br/><em>Più prospettive.</em></h2><div><p>{galleryCopy.about}</p><p>Questo spazio è il luogo in cui raccogliere i lavori e raccontare le idee che li fanno nascere.</p><button onClick={replay} className="gallery-text-link">Rivedi l’introduzione <span aria-hidden="true"><GalleryArrow/></span></button></div></div>
    </section>
    <section id="contatti" className="gallery-contact">
      <div className="gallery-section-index"><span>03 / CONTATTI</span><span>IL PROSSIMO PUNTO D’INCONTRO.</span></div>
      <h2>Hai un’idea?<br/><em>Diamole spazio.</em></h2>
      {identity.email?<a className="gallery-email" href={`mailto:${identity.email}`}>{identity.email} ↗</a>:<p className="gallery-contact-pending"><span/>Recapiti in preparazione.<small>Email e profili social saranno disponibili qui.</small></p>}
      {!!identity.socials.length&&<nav aria-label="Profili social">{identity.socials.filter(s=>/^https:\/\//.test(s.url)).map(s=><a key={s.url} href={s.url} target="_blank" rel="noopener noreferrer">{s.label} ↗</a>)}</nav>}
    </section>
    <footer className="gallery-footer"><a href="#inizio" className="gallery-footer-brand" onClick={overview}>ONE MAN</a><div><span>LA REALTÀ SI RISCRIVE.</span><span>© {new Date().getFullYear()} ONE MAN</span><a href="#inizio" onClick={overview}>Torna all’inizio ↑</a></div></footer>
    {work&&expanded&&<GalleryDetail work={work} onClose={close}/>}
  </main>;
}
