export default function GalleryArrow(){
  return <svg aria-hidden="true" viewBox="0 0 16 16" fill="none" width="1em" height="1em"><path d="M3.5 12.5 12.5 3.5M4 3.5h8.5V12" stroke="currentColor" strokeWidth="1.2"/></svg>;
}
