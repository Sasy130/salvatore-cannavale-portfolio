"use client";
import FinalePanel from "./FinalePanel";
import { createPortal } from "react-dom";
import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { usePerformance } from "@/lib/performance-store";
import { useVisualMemory } from "@/lib/visual-memory";
import { universeRooms } from "@/lib/universe-config";
import { beginInteraction, endInteraction } from "@/lib/interaction-orchestrator";
export default function UniverseOverlay() {
  const visits = useVisualMemory(s => s.memory.portals);
  const view = usePortfolioScene(s => s.view);
  const destination = usePortfolioScene(s => s.destination);
  const root = useRef<HTMLDivElement>(null), stage = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const live = usePerformance(s => s.webgl && !s.reduced);
  const gestures = useRef(new Map<number, {x:number; y:number}>());
  const close = () => usePortfolioScene.setState({view:"world", mapSurface:null, destination:null});
  useEffect(() => {
    if (view === "world") return;
    const points = gestures.current;
    const prior = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow="hidden";
    document.documentElement.dataset.universeView=view;
    const siblings = Array.from(document.querySelectorAll<HTMLElement>("body > *")).filter(el => el !== root.current && !el.contains(root.current) && el.tagName !== "SCRIPT");
    // Il main contiene il canvas: rendiamo inerti i suoi contenuti HTML, non il renderer.
    const contents = Array.from(document.querySelectorAll<HTMLElement>(".portfolio > *")).filter(el => !el.classList.contains("world-layer"));
    const inert = [...new Set([...siblings.filter(el => !el.querySelector("canvas")), ...contents])];
    const priorInert = inert.map(el => el.inert);
    inert.forEach(el => el.inert=true);
    usePortfolioScene.setState({mapSurface:stage.current});
    root.current?.querySelector<HTMLButtonElement>("button")?.focus();
    const key = (e: KeyboardEvent) => {
      if(e.key === "Escape") {e.preventDefault(); close();}
      if(e.key === "Tab") {
        const focusable=Array.from(root.current?.querySelectorAll<HTMLElement>('button, a[href], [tabindex="0"]') ?? []);
        const first=focusable[0], last=focusable.at(-1);
        if(e.shiftKey && document.activeElement===first){e.preventDefault();last?.focus();}
        else if(!e.shiftKey && document.activeElement===last){e.preventDefault();first?.focus();}
      }
    };
    const release = () => { points.clear(); endInteraction("map"); };
    const hidden = () => {if(document.hidden)release();};
    window.addEventListener("blur",release);
    document.addEventListener("visibilitychange",hidden);
    window.addEventListener("keydown", key);
    return () => {
      window.removeEventListener("blur",release);document.removeEventListener("visibilitychange",hidden);
      window.removeEventListener("keydown", key); endInteraction("map"); points.clear();
      inert.forEach((el,i) => el.inert=priorInert[i]);
      document.body.style.overflow=overflow; delete document.documentElement.dataset.universeView;
      if(prior?.isConnected) prior.focus({preventScroll:true});
    };
  }, [view]);
  useEffect(() => {
    if(!destination) return;
    close(); router.push(`/#${destination}`, {scroll:false});
    requestAnimationFrame(() => {
      const section=document.getElementById(destination);
      section?.scrollIntoView({behavior:"instant"});
      const heading=section?.querySelector<HTMLElement>("h1, h2") ?? section;
      heading?.setAttribute("tabindex","-1"); heading?.focus({preventScroll:true});
    });
  }, [destination, router]);
  if(view === "world") return null;
  const turn = (yaw:number,pitch=0) => usePortfolioScene.setState(s => ({mapYaw:s.mapYaw+yaw,mapPitch:Math.max(0.15,Math.min(1.25,s.mapPitch+pitch))}));
  const zoom = (delta:number) => usePortfolioScene.setState(s => ({mapZoom:Math.max(0.65,Math.min(1.8,s.mapZoom+delta))}));
  return createPortal(<div ref={root} className={`universe-overlay ${view === "finale" ? "finale-overlay" : ""}`} role="dialog" aria-modal="true" aria-labelledby="universe-title">
    <div ref={stage} className="universe-stage" tabIndex={live && view === "map" ? 0 : undefined} role={live && view === "map" ? "application" : undefined} aria-label={live && view === "map" ? "Mappa tridimensionale. Frecce per ruotare, più e meno per ingrandire. Usa anche i collegamenti alle stanze." : undefined} aria-hidden={!live || view !== "map" ? true : undefined}
      onKeyDown={e => {if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","+","-"].includes(e.key)){e.preventDefault(); if(e.key==="+")zoom(.1);else if(e.key==="-")zoom(-.1);else turn(e.key==="ArrowLeft"?-.15:e.key==="ArrowRight"?.15:0,e.key==="ArrowUp"?.1:e.key==="ArrowDown"?-.1:0);}}}
      onWheel={e => {if(view === "map")zoom(-e.deltaY*.001);}}
      onPointerDown={e => {if(!live || view !== "map" || !beginInteraction("map",e.pointerId))return;gestures.current.set(e.pointerId,{x:e.clientX,y:e.clientY});e.currentTarget.setPointerCapture(e.pointerId);}}
      onPointerMove={e => {
        const points=gestures.current, prior=points.get(e.pointerId);if(!prior)return;
        if(points.size===2){const other=Array.from(points).find(([id])=>id!==e.pointerId)?.[1];if(other){const old=Math.hypot(prior.x-other.x,prior.y-other.y);const now=Math.hypot(e.clientX-other.x,e.clientY-other.y);zoom((now-old)*.004);}}
        else turn((prior.x-e.clientX)*.007,(e.clientY-prior.y)*.005);
        points.set(e.pointerId,{x:e.clientX,y:e.clientY});
      }}
      onPointerUp={e => {gestures.current.delete(e.pointerId);if(!gestures.current.size)endInteraction("map");}}
      onPointerCancel={() => {gestures.current.clear();endInteraction("map");}}
      onLostPointerCapture={e => {gestures.current.delete(e.pointerId);if(!gestures.current.size)endInteraction("map");}}
    />
    <header className="universe-bar"><span>ONE MAN / ATLANTE VIVENTE</span><button onClick={close}>Torna al portfolio <span aria-hidden="true">×</span></button></header>
    {view === "finale" ? <FinalePanel /> : <>
    <div className="universe-caption"><p>LA STRUTTURA IMPOSSIBILE</p><h2 id="universe-title">ESPLORA<br/>L’UNIVERSO.</h2><p>{live ? "Trascina per ruotare. Allarga due dita per ingrandire. Seleziona un nucleo luminoso o una stanza qui sotto." : "Scegli una stanza per raggiungere la sezione del portfolio."}</p></div>
    {live && <div className="map-tools" aria-label="Controlli della mappa"><button onClick={()=>turn(-.2)}>Ruota a sinistra</button><button onClick={()=>turn(.2)}>Ruota a destra</button><button onClick={()=>zoom(.15)}>Ingrandisci +</button><button onClick={()=>zoom(-.15)}>Riduci −</button><button onClick={()=>usePortfolioScene.setState({mapYaw:.55,mapPitch:.55,mapZoom:1})}>Ripristina visuale</button></div>}
    <nav className="map-destinations" aria-label="Stanze dell’universo">{universeRooms.map((room,i)=><a key={room.id} href={`/#${room.id}`} onClick={e=>{if(e.metaKey||e.ctrlKey)return;e.preventDefault();usePortfolioScene.setState({destination:room.id});}}><span>0{i+1}</span>{room.label}<small>{visits.includes(room.id)?"Portale già visitato":room.subtitle}</small><b aria-hidden="true">↗</b></a>)}</nav>
    </>}
  </div>, document.body);
}
