"use client";
import { useId, useLayoutEffect, useRef } from "react";
import {
  useRendererRegistry,
  type SceneSlot as Slot,
} from "@/lib/renderer-registry";
export default function SceneSlot({
  kind,
  visible = true,
  detail,
  environment,
  paused,
  amplitude,
  run,
}: {
  kind: Slot["kind"];
  visible?: boolean;
  detail?: boolean;
  environment?: Slot["environment"];
  paused?: boolean;
  amplitude?: number;
  run?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const id = useId();
  useLayoutEffect(() => () => useRendererRegistry.getState().remove(id), [id]);
  useLayoutEffect(() => {
    if (ref.current)
      useRendererRegistry.getState().put({
        id,
        element: ref.current,
        kind,
        visible,
        detail,
        environment,
        paused,
        amplitude,
        run,
      });
  }, [id, kind, visible, detail, environment, paused, amplitude, run]);
  return <div ref={ref} className="scene-slot" data-slot-kind={kind} />;
}
