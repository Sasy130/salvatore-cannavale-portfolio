"use client";
import StaticMatter from "./StaticMatter";
import MemoryTraces from "./MemoryTraces";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { matterLabels, matterStates } from "@/lib/universe-config";
export default function LivingControls() {
  const selected = usePortfolioScene((s) => s.matter);
  return (
    <section id="universo" className="living-lab section-space">
      <div className="section-label">
        <span>05</span>
        <span>IL NUCLEO / MATERIA VIVENTE</span>
        <i />
      </div>
      <h2>
        UNA MATERIA.
        <br />
        <span>INFINITE FORME.</span>
      </h2>
      <p>
        Il monolite non scompare: la stessa superficie si piega, si frattura e
        diventa linguaggio. Scegli una forma per riscriverla.
      </p>
      <StaticMatter />
      <div
        className="matter-controls"
        role="group"
        aria-label="Forma del nucleo"
      >
        {matterStates.map((state) => (
          <button
            key={state}
            aria-pressed={selected === state}
            onClick={() => usePortfolioScene.setState({ matter: state })}
          >
            {matterLabels[state]}
          </button>
        ))}
        <button
          aria-pressed={selected === "AUTO"}
          onClick={() => usePortfolioScene.setState({ matter: "AUTO" })}
        >
          Ricompone il nucleo ↺
        </button>
      </div>
      <button className="universe-launch" onClick={() => usePortfolioScene.setState({view: "map"})}>
        Esplora l’universo <span aria-hidden="true">↗</span>
      </button>
      <MemoryTraces />
      <p className="lab-note">
        La versione essenziale mostra lo stato selezionato senza movimenti
        automatici.
      </p>
    </section>
  );
}
