"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useVisualMemory } from "@/lib/visual-memory";
import { useIntro } from "@/lib/intro-store";
import { useReality } from "@/lib/reality-store";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { projects } from "@/lib/portfolio-data";
export default function VisualMemoryRuntime(){
  const pathname=usePathname();
  useEffect(()=>{
    const memory=useVisualMemory.getState(); memory.hydrate();
    if(useIntro.getState().phase==='COMPLETE') memory.flag('introSeen');
    const intro=useIntro.subscribe((s,p)=>{if(s.phase==='COMPLETE' && p.phase!=='COMPLETE'){memory.flag('introSeen');if(p.phase==='REVEAL')memory.flag('introCompleted');}});
    const reality=useReality.subscribe((s,p)=>{if(s.active && !p.active)memory.flag('realityUsed');if(s.secret && !p.secret)memory.flag('secretUnlocked');});
    const scene=usePortfolioScene.subscribe((s,p)=>{
      if(s.matter!==p.matter && s.matter!=='AUTO')memory.visit('matterForms',s.matter);
      if(s.view==='map' && (s.mapYaw!==p.mapYaw || s.mapPitch!==p.mapPitch || s.mapZoom!==p.mapZoom))memory.flag('mapUsed');
      if(s.destination && s.destination!==p.destination){memory.visit('portals',s.destination);memory.flag('mapUsed');}
    });
    return()=>{intro();reality();scene();};
  },[]);
  useEffect(()=>{const project=projects.find(p=>pathname.replace(/\/$/,'')===`/progetti/${p.slug}`);if(project)useVisualMemory.getState().visit('projects',project.slug);},[pathname]);
  return null;
}
