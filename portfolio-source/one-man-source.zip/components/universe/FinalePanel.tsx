"use client";
import Link from "next/link";
import { useEffect } from "react";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useVisualMemory } from "@/lib/visual-memory";
const phrases=["HAI ATTRAVERSATO IL MIO UNIVERSO.","ORA IMMAGINA COSA POSSIAMO CREARE INSIEME.","ONE MAN — LA REALTÀ SI RISCRIVE."];
export default function FinalePanel(){
  const step=usePortfolioScene(s=>s.finaleStep);
  useEffect(()=>{if(step===2)useVisualMemory.getState().flag('finaleSeen');},[step]);
  return <div className="finale-panel"><p className="eyebrow">OLTRE LE TRACCE / 0{step+1} DI 03</p><h2 id="universe-title">IL NUCLEO.</h2><p className="finale-phrase" aria-live="polite" aria-atomic="true">{phrases[step]}</p><p className="finale-hint">Ogni passaggio ricompone la stessa materia. Avanza quando vuoi.</p><div className="finale-actions"><button onClick={()=>usePortfolioScene.setState({finaleStep:step<2?step+1:0})}>{step===0?'Riscrivi la materia':step===1?'Ricomponi l’universo':'Rivedi la trasformazione ↺'}</button><Link href="/#contatti" onClick={e=>{e.preventDefault();usePortfolioScene.setState({destination:'contatti'});}}>Creiamo il prossimo universo ↗</Link></div></div>;
}
