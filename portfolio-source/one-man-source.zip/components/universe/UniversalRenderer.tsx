"use client";
import { createPortal } from "react-dom";
import { Canvas, events, useFrame, useThree, type RootStore } from "@react-three/fiber";
import { Suspense, useEffect, useLayoutEffect, useRef, useState } from "react";
import * as THREE from "three";
import {
  chooseSlot,
  useRendererRegistry,
  type SceneSlot,
} from "@/lib/renderer-registry";
import { usePerformance, qualitySettings } from "@/lib/performance-store";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useIntro } from "@/lib/intro-store";
import { IntroContents } from "@/components/Universe";
import { WorldContents } from "@/components/portfolio/WorldScene";
import { SecretContents } from "@/components/reality/SecretScene";
import LivingMatter from "./LivingMatter";
import GpuDiagnostics from "@/components/reality/GpuDiagnostics";
import SceneBoundary from "@/components/portfolio/SceneBoundary";
import "./universe.css";
// Un calcolo di raycasting coerente anche quando il canvas cambia contenitore.
function sharedEvents(store: RootStore) {
  const manager = events(store);
  manager.compute = (event, state) => {
    const bounds = state.gl.domElement.getBoundingClientRect();
    state.pointer.set((event.clientX - bounds.left) / Math.max(1,bounds.width) * 2 - 1,
      1 - (event.clientY - bounds.top) / Math.max(1,bounds.height) * 2);
    state.raycaster.setFromCamera(state.pointer, state.camera);
  };
  return manager;
}
function SceneCoordinator({ slot }: { slot: SceneSlot | null }) {
  const { camera, scene, gl, setSize, frameloop } = useThree();
  useLayoutEffect(() => {
    gl.domElement.dataset.frameLoop = frameloop;
  }, [gl, frameloop]);
  const prior = useRef("");
  useLayoutEffect(() => {
    if (!slot) return;
    const rect = slot.element.getBoundingClientRect();
    setSize(Math.max(1, rect.width), Math.max(1, rect.height));
    const key = (slot.kind === "portal" ? "world" : slot.kind) + ":" + String(slot.detail) + ":" + String(slot.run);
    if (prior.current !== key) {
      prior.current = key;
      camera.rotation.set(0, 0, 0);
      camera.position.set(
        0,
        slot.kind === "intro" ? 0.15 : 0,
        slot.kind === "intro" ? 7 : slot.kind === "secret" ? 5.5 : 7.2,
      );
      (camera as THREE.PerspectiveCamera).fov =
        slot.kind === "intro" ? 48 : slot.kind === "secret" ? 45 : 46;
      camera.updateProjectionMatrix();
      if(slot.kind !== "intro") {scene.background = null; scene.fog = null;}
      gl.domElement.removeAttribute("data-scene-ready");
    }
    gl.domElement.dataset.sceneKind = slot.kind;
    gl.domElement.setAttribute(
      "aria-label",
      slot.kind === "intro"
        ? "Universo tridimensionale interattivo: monolite, stanza e nucleo"
        : "Universo tridimensionale ONE MAN",
    );
  }, [slot, camera, scene, gl, setSize]);
  useFrame(() => {
    if (slot?.kind !== "intro") gl.domElement.dataset.sceneReady = "true";
  });
  return null;
}
export default function UniversalRenderer() {
  const eventSource = usePortfolioScene(s => s.view === "map" ? s.mapSurface : null);
  const slots = useRendererRegistry((s) => s.slots);
  const selected = chooseSlot(slots) ?? chooseSlot(slots, true);
  const tier = usePerformance((s) => s.tier),
    webgl = usePerformance((s) => s.webgl),
    reduced = usePerformance((s) => s.reduced);
  const [host, setHost] = useState<HTMLElement | null>(null),
    [started, setStarted] = useState(false);
  const [glOptions] = useState(() => ({alpha:true, antialias:false, powerPreference:"high-performance" as const}));
  const [cameraOptions] = useState(() => ({position:[0, .15, 7] as [number,number,number], fov:48, near:.1, far:100}));
  const parked = useRef<HTMLElement | null>(null);
  useEffect(() => {
    const park = document.createElement("div");
    park.className = "renderer-parking";
    park.setAttribute("aria-hidden", "true");
    document.body.appendChild(park);
    parked.current = park;
    const node = document.createElement("div");
    node.className = "universal-render-host";
    park.appendChild(node);
    setHost(node);
    return () => {
      node.remove();
      park.remove();
      parked.current = null;
    };
  }, []);
  useLayoutEffect(() => {
    if (!host) return;
    const target = selected?.element ?? parked.current;
    if (target && host.parentElement !== target) target.appendChild(host);
    if (selected) setStarted(true);
  }, [selected, host]);
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const handler = () => setVisible(!document.hidden);
    document.addEventListener("visibilitychange", handler);
    return () => document.removeEventListener("visibilitychange", handler);
  }, []);
  if (!host || !started || !webgl || reduced) return null;
  const fail = () => {
    usePerformance.setState({ webgl: false });
    useIntro.setState({ fallback: true, holding: false });
  };
  return createPortal(
    <SceneBoundary onError={fail}>
      <Canvas
        events={sharedEvents}
        eventSource={eventSource ?? undefined}
        dpr={qualitySettings[tier].dpr}
        frameloop={selected?.visible && visible ? "always" : "never"}
        camera={cameraOptions}
        shadows={tier === "high"}
        gl={glOptions}
        onCreated={({gl}) => {gl.debug.onShaderError = () => queueMicrotask(fail);}}
      >
        <SceneCoordinator slot={selected} />
        <Suspense fallback={null}>
        {selected?.kind === "intro" ? (
          <IntroContents
            key={`intro-${selected.run ?? 0}`}
            diagnostics={false}
          />
        ) : selected?.kind === "secret" ? (
          <SecretContents diagnostics={false} />
        ) : selected?.kind === "world" || selected?.kind === "portal" ? (
          <WorldContents
            detail={selected.detail ?? false}
            environment={selected.environment}
            paused={selected.paused ?? false}
            amplitude={selected.amplitude ?? 0.6}
            visible={selected.visible}
            onFailure={fail}
            diagnostics={false}
          />
        ) : null}
        <LivingMatter active={(selected?.kind === "world" || selected?.kind === "portal") && !selected.detail} />
        </Suspense>
        <GpuDiagnostics onFailure={fail} />
      </Canvas>
    </SceneBoundary>,
    host,
  );
}
