"use client";
import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useVisualMemory, memoryScore } from "@/lib/visual-memory";
import { createLivingGeometry } from "@/lib/living-geometry";
import { matterStates, roomFor, type MatterState } from "@/lib/universe-config";
import { usePerformance } from "@/lib/performance-store";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useReality, fractureAmount } from "@/lib/reality-store";
import { interactionFrame } from "@/lib/interaction-orchestrator";
const declarations = `attribute vec3 aCenter;attribute vec3 aSeed;attribute vec3 aTypography;uniform vec4 uMatter;uniform float uTime;uniform float uDistortion;uniform vec2 uPointer;varying vec3 vCore;
mat3 spin(float a){float c=cos(a),s=sin(a);return mat3(c,-s,0.,s,c,0.,0.,0.,1.);}`;
const transform = `#include <begin_vertex>
vCore=position;float noise=sin(position.y*2.8+uTime)*cos(position.x*3.1-uTime*.7)+sin(position.z*5.+uTime)*.3;
vec3 fluid=position+normal*noise*(.15+abs(uDistortion)*.12);fluid.x+=sin(position.y*2.+uTime*.8)*.1;
vec3 local=position-aCenter;vec3 broken=aCenter*(1.35+aSeed.x*.8)+spin((aSeed.y-.5)*2.)*local;
vec3 particles=vec3((aSeed.x-.5)*6.,(aSeed.y-.5)*4.,(aSeed.z-.5)*4.)+local*.25;particles.y+=sin(uTime*.7+aSeed.x*20.)*.15;
vec3 letters=aTypography;letters.z+=sin(aTypography.x*1.6+uTime)*.06;letters.xy+=uPointer*.07;
transformed=position*(1.-dot(uMatter,vec4(1.)))+fluid*uMatter.x+broken*uMatter.y+particles*uMatter.z+letters*uMatter.w;
transformed.z+=sin(position.y*2.+position.x)*uDistortion*.22;`;
export default function LivingMatter({ active }: { active: boolean }) {
  const mesh = useRef<THREE.Mesh>(null);
  const tier = usePerformance((s) => s.tier);
  const geometry = useMemo(() => createLivingGeometry(tier), [tier]);
  const uniforms = useMemo(
    () => ({
      uMatter: { value: new THREE.Vector4() },
      uTime: { value: 0 },
      uMemory: { value: 0 },
      uDistortion: { value: 0 },
      uPointer: { value: new THREE.Vector2() },
    }),
    [],
  );
  const target = useMemo(() => new THREE.Vector4(), []);
  const time = useRef(0),
    sample = useRef(0);
  useEffect(() => () => geometry.dispose(), [geometry]);
  useFrame(({ size, gl }, dt) => {
    if (!mesh.current) return;
    mesh.current.visible = active;
    if (!active) return;
    time.current += Math.min(dt, 0.06);
    const scene = usePortfolioScene.getState(),
      reality = useReality.getState();
    let state: MatterState =
      scene.matter === "AUTO"
        ? scene.section === "chi-sono"
          ? "LIQUID"
          : scene.section === "progetti"
            ? "FRACTURED"
            : scene.section === "competenze"
              ? "PARTICLES"
              : scene.section === "contatti"
                ? "TYPOGRAPHY"
                : "MONOLITH"
        : scene.matter;
    if (reality.fragmenting) state = "FRACTURED";
    if (scene.view === "finale") state = scene.finaleStep === 0 ? "LIQUID" : scene.finaleStep === 1 ? "FRACTURED" : "TYPOGRAPHY";
    target.set(0, 0, 0, 0);
    const index = matterStates.indexOf(state) - 1;
    if (index >= 0) target.setComponent(index, 1);
    uniforms.uMatter.value.lerp(
      target,
      1 - Math.exp(-3.4 * Math.min(dt, 0.08)),
    );
    uniforms.uTime.value = time.current;
    uniforms.uMemory.value = Math.min(1, memoryScore(useVisualMemory.getState().memory) / 6);
    uniforms.uDistortion.value = THREE.MathUtils.damp(
      uniforms.uDistortion.value,
      reality.active ? reality.distortion : 0,
      4,
      dt,
    );
    uniforms.uPointer.value.set(interactionFrame.x, interactionFrame.y);
    const room = scene.view === "finale" ? {center: [0, 0, -11]} : roomFor(scene.section);
    const offset = state === "TYPOGRAPHY" || scene.view === "finale" ? 0 : size.width < 768 ? 0.45 : 2.2;
    mesh.current.position.x = THREE.MathUtils.damp(
      mesh.current.position.x,
      room.center[0] + offset,
      3,
      dt,
    );
    mesh.current.position.y = THREE.MathUtils.damp(
      mesh.current.position.y,
      room.center[1] + Math.sin(time.current * 0.5) * 0.08,
      3,
      dt,
    );
    mesh.current.position.z = THREE.MathUtils.damp(
      mesh.current.position.z,
      room.center[2],
      3,
      dt,
    );
    mesh.current.rotation.set(
      0.06 + interactionFrame.y * 0.04,
      state === "TYPOGRAPHY" ? 0 : -0.35 + interactionFrame.x * 0.14,
      -0.1 * (1 - uniforms.uMatter.value.w),
    );
    mesh.current.scale.setScalar(
      THREE.MathUtils.damp(
        mesh.current.scale.x,
        size.width < 768 ? (state === "TYPOGRAPHY" ? 0.32 : 0.66) : 1,
        4,
        dt,
      ),
    );
    if (reality.fragmenting)
      uniforms.uDistortion.value +=
        fractureAmount(performance.now(), reality.fragmentStart) * 0.1;
    if (performance.now() / 1000 - sample.current > 0.3) {
      sample.current = performance.now() / 1000;
      gl.domElement.dataset.matterState = state;
      gl.domElement.dataset.visualMemory = uniforms.uMemory.value.toFixed(2);
      gl.domElement.dataset.matterFaces = String(
        geometry.getAttribute("position").count / 3,
      );
      gl.domElement.dataset.matterWeights = uniforms.uMatter.value
        .toArray()
        .map((n) => n.toFixed(2))
        .join(",");
    }
  });
  const compile: THREE.MeshStandardMaterial["onBeforeCompile"] = (program) => {
          Object.assign(program.uniforms, uniforms);
          program.fragmentShader = "varying vec3 vCore; uniform float uMemory; uniform vec4 uMatter;\n" + program.fragmentShader;
          program.fragmentShader = program.fragmentShader.replace("#include <emissivemap_fragment>", "#include <emissivemap_fragment>\n totalEmissiveRadiance += vec3(1.,.025,.04) * pow(1.-abs(sin(vCore.y*5.+vCore.x*4.)),30.) * uMemory * .35; totalEmissiveRadiance += vec3(.7,.66,.64) * uMatter.w * 1.2;");
          program.vertexShader = declarations + "\n" + program.vertexShader;
          program.vertexShader = program.vertexShader.replace(
            "#include <begin_vertex>",
            transform,
          );
  };
  return (
    <mesh
      ref={mesh}
      geometry={geometry}
      frustumCulled={false}
      castShadow={tier === "high"}
    >
      {tier === "low" ? <meshPhongMaterial color="#62636f" specular="#dad4df" shininess={100} side={THREE.DoubleSide} onBeforeCompile={compile} /> : <meshStandardMaterial
        color="#62636f"
        metalness={0.97}
        roughness={0.2}
        side={THREE.DoubleSide}
        onBeforeCompile={compile}
      />}
    </mesh>
  );
}
