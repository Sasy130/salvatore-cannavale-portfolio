"use client";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { universeRooms } from "@/lib/universe-config";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useReality } from "@/lib/reality-store";
import { interactionFrame } from "@/lib/interaction-orchestrator";
export default function CinematicCamera() {
  const progress = useRef(0),
    sample = useRef(0);
  const cache = useMemo(
    () => ({
      path: new THREE.CatmullRomCurve3(
        universeRooms.map((r) => new THREE.Vector3(...r.camera)),
      ),
      targets: new THREE.CatmullRomCurve3(
        universeRooms.map((r) => new THREE.Vector3(...r.center)),
      ),
      position: new THREE.Vector3(),
      target: new THREE.Vector3(),
      up: new THREE.Vector3(0, 1, 0),
      matrix: new THREE.Matrix4(),
      quaternion: new THREE.Quaternion(),
      roll: new THREE.Quaternion(),
      axis: new THREE.Vector3(0, 0, 1),
    }),
    [],
  );
  useFrame(({ camera, size, gl }, dt) => {
    dt = Math.min(dt, .08);
    const state = usePortfolioScene.getState();
    const index = Math.max(
      0,
      universeRooms.findIndex((r) => r.id === state.section),
    );
    const desired = index / (universeRooms.length - 1);
    progress.current = THREE.MathUtils.damp(
      progress.current,
      desired,
      2.5,
      Math.min(dt, 0.08),
    );
    cache.path.getPoint(progress.current, cache.position);
    cache.targets.getPoint(progress.current, cache.target);
    if (state.view === "map") {
      const distance = (size.width < 768 ? 48 : 34) / state.mapZoom;
      cache.target.set(0, 0, -11);
      cache.position.set(Math.sin(state.mapYaw) * Math.cos(state.mapPitch) * distance,
        Math.sin(state.mapPitch) * distance, -11 + Math.cos(state.mapYaw) * Math.cos(state.mapPitch) * distance);
    }
    if (state.view === "finale") {
      const angle = (state.finaleStep - 2) * .12;
      cache.target.set(0, 0, -11);
      cache.position.set(Math.sin(angle) * 8, .3 + state.finaleStep * .05, -11 + Math.cos(angle) * 8);
    }
    if (state.portal) {
      const room = universeRooms.find(r => r.id === state.portal!.room) ?? universeRooms[0];
      const t = Math.min(1, (performance.now() - state.portal.started) / state.portal.duration);
      const ease = t * t * (3 - 2 * t);
      cache.position.set(room.center[0] + Math.sin(t * Math.PI) * .5, room.center[1] + .15,
        room.center[2] + 7.2 - ease * 8.6);
      cache.target.set(room.center[0], room.center[1], room.center[2] - 4);
      gl.domElement.dataset.portalProgress = t.toFixed(2);
    }
    const distortion = useReality.getState().distortion;
    cache.position.x += interactionFrame.x * (size.width < 768 ? 0.04 : 0.13);
    cache.position.z -= distortion * 0.65;
    cache.position.y += Math.sin(state.progress * Math.PI * 2) * 0.06;
    camera.position.lerp(cache.position, 1 - Math.exp(-(state.portal ? 12 : 4) * dt));
    cache.matrix.lookAt(camera.position, cache.target, cache.up);
    cache.quaternion.setFromRotationMatrix(cache.matrix);
    cache.roll.setFromAxisAngle(
      cache.axis,
      Math.sin(progress.current * Math.PI * 2) *
        (size.width < 768 ? 0.01 : 0.022),
    );
    cache.quaternion.multiply(cache.roll);
    camera.quaternion.slerp(cache.quaternion, 1 - Math.exp(-4 * dt));
    const perspective = camera as THREE.PerspectiveCamera;
    perspective.fov = THREE.MathUtils.damp(
      perspective.fov,
      state.view === "map" ? 50 : 46 - index * 0.4 + distortion,
      3,
      dt,
    );
    perspective.updateProjectionMatrix();
    if (performance.now() / 1000 - sample.current > 0.4) {
      sample.current = performance.now() / 1000;
      gl.domElement.dataset.cameraArea = state.view === "map" ? "mappa" : state.view === "finale" ? "nucleo" : state.section;
      gl.domElement.dataset.cameraPosition = `${camera.position.x.toFixed(2)},${camera.position.y.toFixed(2)},${camera.position.z.toFixed(2)}`;
    }
  });
  return null;
}
