"use client";
import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useVisualMemory } from "@/lib/visual-memory";
import { universeRooms } from "@/lib/universe-config";
import { usePortfolioScene } from "@/lib/portfolio-store";
export default function MapRooms() {
  const visits = useVisualMemory(s => s.memory.portals);
  const surface = usePortfolioScene(s => s.mapSurface);
  const view = usePortfolioScene(s => s.view);
  const width = useThree(s => s.size.width);
  const point = useRef(new THREE.Vector3());
  const last = useRef(0);
  useFrame(({camera, gl, size}) => {
    if (view !== "map" || performance.now() - last.current < 400) return;
    last.current = performance.now();
    gl.domElement.dataset.mapRooms = JSON.stringify(universeRooms.map(room => {
      point.current.set(room.center[0], room.center[1] + 1, room.center[2] + 2.2).project(camera);
      return {id: room.id, x: (point.current.x + 1) * size.width / 2, y: (1 - point.current.y) * size.height / 2};
    }));
  });
  if (view !== "map") return null;
  return <group name="Ambienti selezionabili">{universeRooms.map((room, i) =>
    <mesh key={room.id} position={[room.center[0], room.center[1] + 1, room.center[2] + 2.2]}
      onClick={e => { e.stopPropagation(); if (e.delta < 8) usePortfolioScene.setState({destination: room.id}); }}
      onPointerOver={e => {e.stopPropagation(); if(surface) surface.style.cursor="pointer";}}
      onPointerOut={() => {if(surface) surface.style.cursor="grab";}}>
      <octahedronGeometry args={[width < 768 ? 1.4 : .85, 0]} />
      <meshStandardMaterial color={i % 2 ? "#ff3038" : "#f4f1ed"} emissive="#ff3038" emissiveIntensity={visits.includes(room.id) ? 2 : 0.6} metalness={0.7} roughness={0.2} />
    </mesh>)}</group>;
}
