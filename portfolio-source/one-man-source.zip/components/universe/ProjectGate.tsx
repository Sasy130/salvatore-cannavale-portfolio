"use client";
import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { projects } from "@/lib/portfolio-data";
import { roomFor } from "@/lib/universe-config";
export default function ProjectGate({detail}:{detail:boolean}) {
  const group=useRef<THREE.Group>(null);
  const opening=usePortfolioScene(s=>s.portal);
  const project=projects.find(p=>opening?.href.includes(p.slug));
  useFrame(({gl})=>{
    if(!group.current)return;
    group.current.visible=!!opening;
    if(!opening)return;
    const room=roomFor(opening.room);
    group.current.position.set(detail ? 0 : room.center[0], detail ? 0 : room.center[1], detail ? 1 : room.center[2]+2);
    const t=Math.min(1,(performance.now()-opening.started)/opening.duration);
    group.current.children.forEach((child,i)=>{
      child.position.z=-i*.8;
      child.rotation.z=(1-t)*(.12+i*.08);
      child.scale.setScalar(.8+t*.2+i*.07);
    });
    gl.domElement.dataset.projectGate=project?.slug ?? "progetto";
  });
  return <group ref={group} visible={false} name="Portale dimensionale">{[0,1,2,3,4].map(i=><mesh key={i}>
    <torusGeometry args={[2.3,.045,6,4]}/><meshStandardMaterial color={project?.accent??"#ff3038"} emissive={project?.accent??"#ff3038"} emissiveIntensity={1.1} metalness={.9} roughness={.2}/>
  </mesh>)}</group>;
}
