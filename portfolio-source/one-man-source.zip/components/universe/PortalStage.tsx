"use client";
import { createPortal } from "react-dom";
import { useEffect, useRef } from "react";
import { usePortfolioScene } from "@/lib/portfolio-store";
import SceneSlot from "./SceneSlot";
export default function PortalStage(){
  const portal=usePortfolioScene(s=>s.portal);
  const cancel=useRef<HTMLButtonElement>(null), direct=useRef<HTMLAnchorElement>(null);
  const active=!!portal;
  useEffect(()=>{
    if(!active)return;
    const prior=document.activeElement as HTMLElement|null;
    const main=document.querySelector('main');const inert=main?.inert;
    if(main)main.inert=true;
    cancel.current?.focus({preventScroll:true});
    const tab=(e:KeyboardEvent)=>{
      if(e.key!=='Tab')return;
      const first=cancel.current?.disabled?direct.current:cancel.current,last=direct.current;
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}
    };
    window.addEventListener('keydown',tab);
    return()=>{window.removeEventListener('keydown',tab);if(main)main.inert=!!inert;if(prior?.isConnected&&prior.getClientRects().length)prior.focus({preventScroll:true});};
  },[active]);
  useEffect(()=>{if(portal?.navigating)direct.current?.focus({preventScroll:true});},[portal?.navigating]);
  if(!portal)return null;
  return createPortal(<div className="portal-world-stage" role="dialog" aria-modal="true" aria-label="Attraversamento del portale">
    <div aria-hidden="true"><SceneSlot kind="portal"/></div>
    <div className="portal-transit-copy"><p role="status">{portal.navigating?'Caricamento del progetto.':'Attraversamento del portale.'}</p><button ref={cancel} disabled={portal.navigating} onClick={()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}))}>Annulla attraversamento</button><a ref={direct} href={portal.href}>Apri subito il progetto ↗</a></div>
  </div>,document.body);
}
