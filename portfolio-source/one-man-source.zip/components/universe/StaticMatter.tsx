"use client";
import { usePerformance } from "@/lib/performance-store";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { matterLabels } from "@/lib/universe-config";
export default function StaticMatter(){
  const live=usePerformance(s=>s.webgl && !s.reduced);
  const selected=usePortfolioScene(s=>s.matter);
  if(live)return null;
  const state=selected==='AUTO'?'MONOLITH':selected;
  return <figure className="static-matter"><svg viewBox="0 0 400 140" role="img" aria-label={`Vista essenziale del nucleo: ${matterLabels[state]}`}>
    <defs><linearGradient id="matter-metal"><stop stopColor="#272631"/><stop offset=".5" stopColor="#dfdce4"/><stop offset="1" stopColor="#57515e"/></linearGradient></defs>
    {state==='TYPOGRAPHY'?<text x="200" y="90" textAnchor="middle" fill="#f4f1ed" fontFamily="Arial,sans-serif" fontWeight="900" fontSize="68">ONE MAN</text>:
      state==='PARTICLES'?Array.from({length:90},(_,i)=><circle key={i} cx={30+(i*137)%340} cy={20+(i*71)%100} r={i%3+1} fill={i%4?'#aaa4b3':'#ff3038'}/>):
      state==='FRACTURED'?<g fill="url(#matter-metal)" stroke="#ff3038" strokeWidth=".6"><path d="M155 15 205 18 190 66 140 80Z"/><path d="m225 8 26 43-42 24-9-29Z"/><path d="m200 87 52-25-10 58-54 13Z"/><path d="m153 94 30-17-8 48-35-4Z"/></g>:
      state==='LIQUID'?<path d="M178 14C231-8 280 31 252 62S237 138 191 129 122 88 149 64 127 36 178 14Z" fill="url(#matter-metal)" stroke="#ff3038"/>:
      <path d="m180 12 56 12 11 97-67 12-28-25 10-84Z" fill="url(#matter-metal)" stroke="#ff3038"/>}
  </svg><figcaption>VISTA ESSENZIALE / {matterLabels[state]}</figcaption></figure>;
}
