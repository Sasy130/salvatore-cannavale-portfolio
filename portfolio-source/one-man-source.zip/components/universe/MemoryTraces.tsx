"use client";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { useVisualMemory, memorySteps, memoryScore, finaleUnlocked } from "@/lib/visual-memory";
export default function MemoryTraces(){
  const memory=useVisualMemory(s=>s.memory);
  return <div className="memory-traces"><p className="eyebrow">TRACCE DEL PASSAGGIO / {Math.min(3,memoryScore(memory))} DI 3</p><h3>Il mondo ricorda il tuo gesto.</h3><p>Tre esperienze diverse aprono una stanza ulteriore. Scegli il tuo percorso.</p><ul>{memorySteps(memory).map(s=><li key={s.label} data-done={s.done}><span aria-hidden="true">{s.done?'◆':'◇'}</span> {s.label}<span className="sr-only">{s.done?' — completato':' — da esplorare'}</span></li>)}</ul><button className="finale-entry" disabled={!finaleUnlocked(memory)} onClick={()=>usePortfolioScene.setState({view:"finale",finaleStep:0})}>{finaleUnlocked(memory) ? memory.finaleSeen ? "Rivedi il nucleo ↗" : "Entra nel nucleo ↗" : "Il nucleo attende tre tracce"}</button><p className="memory-note">Solo stati di interazione in questa scheda. Nessun dato personale, nessun invio in rete.</p><button onClick={()=>useVisualMemory.getState().reset()}>Azzera la memoria visiva</button></div>;
}
