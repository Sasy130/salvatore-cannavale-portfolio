"use client";
import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { usePortfolioScene } from "@/lib/portfolio-store";
export default function FinaleStructure(){
  const frames=useRef<THREE.InstancedMesh>(null), pieces=useRef<THREE.InstancedMesh>(null);
  const object=useMemo(()=>new THREE.Object3D(),[]), blend=useRef(0), time=useRef(0);
  const view=usePortfolioScene(s=>s.view);
  useFrame(({gl},dt)=>{
    if(view!=="finale" || !frames.current || !pieces.current)return;
    time.current+=Math.min(dt,.06);
    const step=usePortfolioScene.getState().finaleStep;
    blend.current=THREE.MathUtils.damp(blend.current,step/2,2,Math.min(dt,.08));
    for(let i=0;i<12;i++){
      const a=i/12*Math.PI*2;
      object.position.set(Math.cos(a)*(1-blend.current)*5,Math.sin(a)*(1-blend.current)*4,-11-i*.55);
      object.rotation.set((1-blend.current)*Math.sin(a)*.8,(1-blend.current)*Math.cos(a)*.8,a*.15*(1-blend.current));
      object.scale.setScalar(1+i*.07);object.updateMatrix();frames.current.setMatrixAt(i,object.matrix);
      for(let j=0;j<4;j++){
        const angle=a+j*Math.PI/2+time.current*.06;
        object.position.set(Math.cos(angle)*(3+blend.current*2),Math.sin(angle)*(3+blend.current*2),-11+(i-6)*.6);
        object.rotation.set(a*(1-blend.current),j*.4,time.current*.08);
        object.scale.set(.1+blend.current*.15,.35,.6);object.updateMatrix();pieces.current.setMatrixAt(i*4+j,object.matrix);
      }
    }
    frames.current.instanceMatrix.needsUpdate=true;pieces.current.instanceMatrix.needsUpdate=true;
    gl.domElement.dataset.finaleStep=String(step);
    gl.domElement.dataset.finaleGeometry="60";
  });
  if(view!=="finale")return null;
  return <group name="Il nucleo monumentale"><instancedMesh ref={frames} args={[undefined,undefined,12]} frustumCulled={false}><torusGeometry args={[3.8,.035,6,4]}/><meshStandardMaterial color="#ff3038" emissive="#ff3038" emissiveIntensity={.8} metalness={.8} roughness={.25}/></instancedMesh><instancedMesh ref={pieces} args={[undefined,undefined,48]} frustumCulled={false}><boxGeometry/><meshStandardMaterial color="#aaa5b5" metalness={.95} roughness={.18}/></instancedMesh></group>;
}
