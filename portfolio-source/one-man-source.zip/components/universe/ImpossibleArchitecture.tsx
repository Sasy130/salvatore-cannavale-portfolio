"use client";
import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { universeRooms } from "@/lib/universe-config";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { usePerformance } from "@/lib/performance-store";
import { useReality } from "@/lib/reality-store";
type Piece = {
  p: [number, number, number];
  s: [number, number, number];
  r: [number, number, number];
  room: number;
  hinge: number;
};
export default function ImpossibleArchitecture() {
  const bodies = useRef<THREE.InstancedMesh>(null),
    frames = useRef<THREE.InstancedMesh>(null);
  const tier = usePerformance((s) => s.tier);
  const { gl } = useThree();
  const object = useMemo(() => new THREE.Object3D(), []);
  const finaleBlend = useRef(0);
  const levels = useMemo(() => new Float32Array(universeRooms.length), []);
  const pieces = useMemo(() => {
    const out: Piece[] = [];
    universeRooms.forEach((room, index) => {
      const [x, y, z] = room.center;
      const count = tier === "high" ? 6 : tier === "medium" ? 4 : 3;
      for (let j = 0; j < count; j++)
        out.push({
          p: [x + (j % 2 ? 1.05 : -1.05), y - 2.2, z + 1 - j * 1.2],
          s: [1.95, 0.12, 1.1],
          r: [0, 0, (index % 2 ? 1 : -1) * 0.02],
          room: index,
          hinge: j % 2 ? 1 : -1,
        });
      for (let side = -1; side <= 1; side += 2) {
        out.push({
          p: [x + side * 3.5, y + 0.2, z - 1],
          s: [0.12, 3.8, 3.4],
          r: [0, side * (0.16 + index * 0.11), side * 0.04],
          room: index,
          hinge: side,
        });
        out.push({
          p: [x + side * 2.1, y + 2.6, z - 1.5],
          s: [2, 0.12, 2.4],
          r: [0, index * 0.25, side * 0.11],
          room: index,
          hinge: side,
        });
      }
      if (index < universeRooms.length - 1) {
        const next = universeRooms[index + 1].center;
        const dx = next[0] - x,
          dz = next[2] - z;
        out.push({
          p: [(x + next[0]) / 2, y - 2.4, (z + next[2]) / 2],
          s: [1.25, 0.12, Math.hypot(dx, dz)],
          r: [0, Math.atan2(dx, dz), 0],
          room: index,
          hinge: 0,
        });
      }
    });
    return out;
  }, [tier]);
  useEffect(() => {
    gl.domElement.dataset.architectureRooms = String(universeRooms.length);
    gl.domElement.dataset.architectureParts = String(
      pieces.length + universeRooms.length * 4,
    );
  }, [gl, pieces]);
  useFrame(({ clock }, dt) => {
    const state = usePortfolioScene.getState();
    const section = state.section;
    finaleBlend.current = THREE.MathUtils.damp(finaleBlend.current, state.view === "finale" ? 1 : 0, 1.8, Math.min(dt,.08));
    const distortion = useReality.getState().distortion;
    universeRooms.forEach(
      (room, i) =>
        (levels[i] = THREE.MathUtils.damp(
          levels[i],
          state.view === "finale" || room.id === section ? 1 : 0.2,
          2.4,
          dt,
        )),
    );
    if (bodies.current) {
      pieces.forEach((p, i) => {
        const active = levels[p.room];
        object.position.set(
          p.p[0],
          p.p[1] + Math.sin(clock.elapsedTime * 0.35 + i) * 0.025,
          p.p[2],
        );
        if(finaleBlend.current > .001) {
          const room = universeRooms[p.room], angle = p.room / universeRooms.length * Math.PI * 2;
          const radius = 18 - state.finaleStep * 1.5;
          const blend = finaleBlend.current;
          object.position.x += (Math.cos(angle) * radius - room.center[0]) * blend;
          object.position.z += (-11 + Math.sin(angle) * radius - room.center[2]) * blend;
        }
        object.rotation.set(
          p.r[0] + p.hinge * (1 - active) * 0.18,
          p.r[1] + p.hinge * (1 - active) * 0.45 + distortion * 0.08,
          p.r[2],
        );
        object.scale.set(...p.s);
        object.updateMatrix();
        bodies.current!.setMatrixAt(i, object.matrix);
      });
      bodies.current.instanceMatrix.needsUpdate = true;
    }
    if (frames.current) {
      universeRooms.forEach((room, i) => {
        const active = levels[i];
        for (let j = 0; j < 4; j++) {
          const horizontal = j < 2;
          object.position.set(
            room.center[0] + (horizontal ? 0 : j === 2 ? -2.6 : 2.6),
            room.center[1] + (horizontal ? (j === 0 ? -2.1 : 2.7) : 0.3),
            room.center[2] + 2 + (1 - active) * 0.7,
          );
          object.rotation.set(0, 0, room.form * 0.035 * (1 - active));
          object.scale.set(
            horizontal ? 5.3 : 0.035,
            horizontal ? 0.035 : 4.8,
            0.035,
          );
          object.updateMatrix();
          frames.current!.setMatrixAt(i * 4 + j, object.matrix);
        }
      });
      frames.current.instanceMatrix.needsUpdate = true;
    }
  });
  return (
    <group name="La struttura impossibile">
      <instancedMesh
        ref={bodies}
        args={[undefined, undefined, pieces.length]}
        castShadow={tier === "high"}
        receiveShadow={tier === "high"}
        frustumCulled={false}
      >
        <boxGeometry />
        {tier === "low" ? <meshPhongMaterial color="#41424d" specular="#c6c1cc" shininess={90}/> : <meshStandardMaterial
          color="#41424d"
          metalness={0.94}
          roughness={0.23}
        />}
      </instancedMesh>
      <instancedMesh
        ref={frames}
        args={[undefined, undefined, universeRooms.length * 4]}
        frustumCulled={false}
      >
        <boxGeometry />
        {tier === "low" ? <meshBasicMaterial color="#ff3038"/> : <meshStandardMaterial
          color="#ff3038"
          emissive="#ff3038"
          emissiveIntensity={0.8}
          metalness={0.6}
          roughness={0.22}
        />}
      </instancedMesh>
    </group>
  );
}
