"use client";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { roomFor } from "@/lib/universe-config";
import { usePortfolioScene } from "@/lib/portfolio-store";
import { usePerformance } from "@/lib/performance-store";
export default function CinematicLights() {
  const group = useRef<THREE.Group>(null);
  const target = useMemo(() => new THREE.Object3D(), []);
  const tier = usePerformance((s) => s.tier);
  useFrame((_, dt) => {
    const state = usePortfolioScene.getState();
    const room = state.view !== "world" ? {center: [0, 0, -11] as [number,number,number]} : roomFor(state.section);
    if (group.current) {
      group.current.position.x = THREE.MathUtils.damp(
        group.current.position.x,
        room.center[0],
        3,
        dt,
      );
      group.current.position.z = THREE.MathUtils.damp(
        group.current.position.z,
        room.center[2],
        3,
        dt,
      );
    }
    target.position.set(room.center[0], room.center[1], room.center[2]);
    target.updateMatrixWorld();
  });
  return (
    <group ref={group}>
      <spotLight
        position={[-3, 5, 4]}
        target={target}
        intensity={55}
        angle={0.8}
        penumbra={0.8}
        castShadow={tier === "high"}
        shadow-mapSize={[512, 512]}
        shadow-bias={-0.001}
      />
      <pointLight position={[3, 0.6, 1]} color="#ff3038" intensity={22} />
    </group>
  );
}
