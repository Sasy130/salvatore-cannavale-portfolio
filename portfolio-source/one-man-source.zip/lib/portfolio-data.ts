export interface Project {
  slug: string;
  number: string;
  title: string;
  category: string;
  summary: string;
  description: string;
  challenge: string;
  solution: string;
  technologies: string[];
  images: { src: string; alt: string; caption: string }[];
  accent: string;
  environment: "room" | "orbit" | "field";
  demo?: string;
}
// Inserire qui esclusivamente contenuti e recapiti personali verificati.
export const identity = {
  name: "ONE MAN",
  email: "sasycannavale1999@gmail.com",
  socials: [] as { label: string; url: string }[],
  bio: "ONE MAN è la mia identità creativa personale. Uno spazio indipendente in cui esplorare il confine fra immaginazione, materia digitale e codice.",
  approach:
    "Ogni esperimento parte da una domanda. La forma arriva attraverso prototipi, interazioni e dettagli: dal primo segno all’ultimo fotogramma.",
  collaboration:
    "Hai un’idea che merita una forma diversa? Questo è il punto da cui iniziare una conversazione.",
};
export const projects: Project[] = [
  {
    slug: "la-stanza-impossibile",
    number: "01",
    title: "La stanza impossibile",
    category: "Esperienza interattiva · Ricerca personale",
    summary: "Un contatto. Una frattura. Un universo che risponde.",
    description:
      "L’introduzione di ONE MAN trasforma l’ingresso nel portfolio in un gesto fisico. Il visitatore carica un monolite, esplora una stanza e ricompone un’identità.",
    challenge:
      "Rendere comprensibile un’esperienza tridimensionale senza trasformare l’introduzione in un ostacolo alla navigazione.",
    solution:
      "Una macchina a stati governa sei scene. Raycasting e cattura del puntatore gestiscono i gesti, mentre pulsanti equivalenti, tastiera e modalità essenziale mantengono disponibile il percorso.",
    technologies: [
      "Next.js",
      "React Three Fiber",
      "Three.js",
      "GLSL",
      "Zustand",
      "GSAP",
    ],
    accent: "#ff3038",
    environment: "room",
    demo: "/?intro=1",
    images: [
      {
        src: "/progetti/stanza.svg",
        alt: "Architettura prospettica di cornici cromate attraversate da una frattura rossa",
        caption: "01 / Studio originale delle strutture sospese",
      },
      {
        src: "/progetti/stanza-dettaglio.svg",
        alt: "Dettaglio del monolite irregolare e della sua crepa luminosa",
        caption: "02 / Materia, contatto e luce",
      },
    ],
  },
  {
    slug: "orbita-zero",
    number: "02",
    title: "Orbita zero",
    category: "Scultura digitale · Ricerca personale",
    summary: "La gravità è un’ipotesi. La forma, una possibilità.",
    description:
      "Uno studio procedurale di anelli metallici che condividono un centro e abitano piani differenti. Il movimento del puntatore cambia il punto di osservazione.",
    challenge:
      "Costruire una scultura leggibile fatta di geometrie essenziali e riflessi, mantenendo un costo di rendering contenuto.",
    solution:
      "Tre anelli toroidali e un nucleo sfaccettato compongono una struttura animata. La demo consente di fermare il movimento e modificare l’apertura degli anelli.",
    technologies: ["Three.js", "React Three Fiber", "Drei", "TypeScript"],
    accent: "#c7d4e6",
    environment: "orbit",
    images: [
      {
        src: "/progetti/orbita.svg",
        alt: "Tre orbite argentee incrociate intorno a un nucleo rosso",
        caption: "01 / Sistema orbitale, vista principale",
      },
      {
        src: "/progetti/orbita-dettaglio.svg",
        alt: "Sezione ravvicinata di un anello metallico con un nucleo sospeso",
        caption: "02 / Studio della superficie riflettente",
      },
    ],
  },
  {
    slug: "campo-rosso",
    number: "03",
    title: "Campo rosso",
    category: "Materia generativa · Ricerca personale",
    summary: "Una superficie. Migliaia di traiettorie possibili.",
    description:
      "Un campo di frammenti metallici diventa una superficie viva. Una funzione periodica controlla la posizione di ogni elemento senza ricorrere a una simulazione di corpi rigidi.",
    challenge:
      "Rendere percepibile una deformazione collettiva attraverso un numero limitato di geometrie ripetute.",
    solution:
      "Una sola InstancedMesh raccoglie i frammenti. La demo permette di variare l’ampiezza dell’onda e sospendere il tempo, mentre il puntatore orienta l’intera composizione.",
    technologies: ["Three.js", "InstancedMesh", "React", "TypeScript"],
    accent: "#ff553d",
    environment: "field",
    images: [
      {
        src: "/progetti/campo.svg",
        alt: "Campo di frammenti rossi disposti lungo una superficie ondulata",
        caption: "01 / Paesaggio generativo",
      },
      {
        src: "/progetti/campo-dettaglio.svg",
        alt: "Dettaglio di lamelle cromate illuminate di rosso",
        caption: "02 / Ritmo e profondità",
      },
    ],
  },
];
export const skills = [
  {
    id: "direzione",
    label: "Direzione visiva",
    tag: "VISIONE",
    description:
      "Identità, gerarchie e composizione: definire un linguaggio coerente prima di moltiplicare gli effetti.",
    tools: "Tipografia · Colore · Sistemi visivi",
    x: 21,
    y: 25,
  },
  {
    id: "interazione",
    label: "Interazione",
    tag: "GESTO",
    description:
      "Trasformare il movimento in una risposta comprensibile, con alternative equivalenti per mouse, touch e tastiera.",
    tools: "React · Accessibilità · Prototipazione",
    x: 73,
    y: 20,
  },
  {
    id: "webgl",
    label: "Universi 3D",
    tag: "MATERIA",
    description:
      "Geometrie, materiali e illuminazione in tempo reale. Il monolite e gli ambienti di questo portfolio sono applicazioni concrete.",
    tools: "Three.js · React Three Fiber · GLSL",
    x: 85,
    y: 65,
  },
  {
    id: "motion",
    label: "Movimento",
    tag: "TEMPO",
    description:
      "Ritmo e transizioni legati ai gesti e allo scroll nativo, con una modalità dedicata al movimento ridotto.",
    tools: "GSAP · ScrollTrigger",
    x: 43,
    y: 83,
  },
  {
    id: "sviluppo",
    label: "Sviluppo creativo",
    tag: "CODICE",
    description:
      "Componenti, dati configurabili e pagine dedicate trasformano gli esperimenti in un sistema navigabile e mantenibile.",
    tools: "Next.js · TypeScript · Zustand",
    x: 13,
    y: 65,
  },
];
