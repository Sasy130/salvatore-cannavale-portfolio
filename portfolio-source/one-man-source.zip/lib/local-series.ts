import {projects} from './restored-projects';

/** Aggiungi qui gli slug dei prossimi redesign. Nessun episodio Instagram è inventato. */
export const localSeries={
 id:'dalla-mappa-al-sito',
 title:'Dalla mappa al sito',
 description:'Parto dalla mia zona su Maps, scopro le attività vicine e immagino un nuovo sito per loro. Un’attività alla volta, il percorso si allarga.',
 instagramProfileUrl:'',
 projectSlugs:['aj-rent-car','rent-car-station'],
};
const seriesSlugs=new Set(localSeries.projectSlugs);
export const seriesProjects=localSeries.projectSlugs.flatMap(slug=>projects.filter(project=>project.slug===slug));
export const portfolioProjects=projects.filter(project=>!seriesSlugs.has(project.slug));
