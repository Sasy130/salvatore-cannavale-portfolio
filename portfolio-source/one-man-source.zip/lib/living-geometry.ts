import * as THREE from "three";
import { TessellateModifier } from "three/addons/modifiers/TessellateModifier.js";
import { createMonolithGeometry } from "./monolith";
import type { Quality } from "./performance-store";
/** Un’unica superficie: ogni faccia conserva identità e vertici in tutte le forme. */
export function createLivingGeometry(tier: Quality) {
  const base = createMonolithGeometry();
  const modifier = new TessellateModifier(
    tier === "high" ? 0.45 : tier === "medium" ? 0.65 : 1,
    tier === "high" ? 6 : tier === "medium" ? 5 : 3,
  );
  const geometry = modifier.modify(base);
  base.dispose();
  const position = geometry.getAttribute("position");
  const centers = new Float32Array(position.count * 3),
    seeds = new Float32Array(position.count * 3),
    types = new Float32Array(position.count * 3);
  const glyphs = sampleGlyphs();
  const corners = [[-.065,-.035],[.065,-.035],[0,.075]];
  const a = new THREE.Vector3(),
    b = new THREE.Vector3(),
    c = new THREE.Vector3();
  for (let i = 0; i < position.count; i += 3) {
    a.fromBufferAttribute(position, i);
    b.fromBufferAttribute(position, i + 1);
    c.fromBufferAttribute(position, i + 2);
    const x = (a.x + b.x + c.x) / 3,
      y = (a.y + b.y + c.y) / 3,
      z = (a.z + b.z + c.z) / 3;
    const n = i / 3;
    const point = glyphs[(n * 137) % glyphs.length] ?? { x: 0, y: 0 };
    for (let j = 0; j < 3; j++) {
      centers.set([x, y, z], (i + j) * 3);
      seeds.set(
        [
          Math.sin(n * 12.9898) * 0.5 + 0.5,
          Math.cos(n * 7.123) * 0.5 + 0.5,
          Math.sin(n * 4.37) * 0.5 + 0.5,
        ],
        (i + j) * 3,
      );
      types.set([point.x + corners[j][0], point.y + corners[j][1], Math.sin(n * 4.37) * .012], (i + j) * 3);
    }
  }
  geometry.setAttribute("aCenter", new THREE.BufferAttribute(centers, 3));
  geometry.setAttribute("aSeed", new THREE.BufferAttribute(seeds, 3));
  geometry.setAttribute("aTypography", new THREE.BufferAttribute(types, 3));
  geometry.computeBoundingSphere();
  return geometry;
}
function sampleGlyphs() {
  const canvas = document.createElement("canvas");
  canvas.width = 700;
  canvas.height = 150;
  const context = canvas.getContext("2d");
  if (!context) return [{ x: 0, y: 0 }];
  context.font = "900 140px Arial";
  context.fillStyle = "white";
  context.textAlign = "center";
  context.fillText("ONE MAN", 350, 120);
  const data = context.getImageData(0, 0, 700, 150).data;
  const points: { x: number; y: number }[] = [];
  for (let y = 0; y < 150; y += 4)
    for (let x = 0; x < 700; x += 4)
      if (data[(y * 700 + x) * 4 + 3] > 100)
        points.push({ x: (x - 350) / 95, y: (75 - y) / 95 });
  return points;
}
