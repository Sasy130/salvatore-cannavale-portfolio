/** Partitura dello scroll: nessuna nuova pagina o simulazione fisica. */
export function ramp(value:number,start:number,end:number){
  const t=Math.max(0,Math.min(1,(value-start)/(end-start)));
  return t*t*(3-2*t);
}
export function galleryChapter(progress:number){
  return progress<.15?"panoramica":progress<.48?"cornice":"anamorfosi";
}
export function galleryChoreography(progress:number){
  const nested=ramp(progress,.10,.36)*(1-ramp(progress,.46,.64));
  const anamorph=ramp(progress,.48,.74)*(1-ramp(progress,.84,1));
  const orbit=ramp(progress,.45,.73)*(1-ramp(progress,.85,1));
  return {nested,anamorph,orbit};
}
