// Solo dati volatili del gesto. Nessuna scrittura nello storage o invio in rete.
export const interactionFrame = {
  clientX: 0,
  clientY: 0,
  x: 0,
  y: 0,
  owner: null as string | null,
  pointerId: -1,
  distance: 0,
};
export function updatePointer(
  x: number,
  y: number,
  width: number,
  height: number,
) {
  interactionFrame.clientX = x;
  interactionFrame.clientY = y;
  interactionFrame.x = (x / Math.max(1, width)) * 2 - 1;
  interactionFrame.y = 1 - (y / Math.max(1, height)) * 2;
}
export function beginInteraction(owner: string, pointerId: number) {
  if (interactionFrame.owner && interactionFrame.owner !== owner) return false;
  interactionFrame.owner = owner;
  interactionFrame.pointerId = pointerId;
  interactionFrame.distance = 0;
  return true;
}
export function endInteraction(owner?: string) {
  if (owner && interactionFrame.owner !== owner) return;
  interactionFrame.owner = null;
  interactionFrame.pointerId = -1;
  interactionFrame.distance = 0;
}
