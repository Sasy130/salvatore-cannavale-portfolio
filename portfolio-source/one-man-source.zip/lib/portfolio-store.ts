import type { MatterState } from "./universe-config";
import { create } from "zustand";
export type EnvironmentName = "room" | "orbit" | "field";
export const usePortfolioScene = create<{
  progress: number;
  section: string;
  environment: EnvironmentName;
  opening: boolean;
  portal: {href: string; started: number; duration: number; room: string; navigating?: boolean} | null;
  finaleStep: number;
  view: "world" | "map" | "finale";
  mapYaw: number;
  mapPitch: number;
  mapZoom: number;
  mapSurface: HTMLElement | null;
  destination: string | null;
  matter: MatterState | "AUTO";
}>(() => ({
  progress: 0,
  section: "contenuto",
  environment: "room",
  opening: false,
  portal: null,
  view: "world",
  finaleStep: 0,
  mapYaw: 0.55, mapPitch: 0.55, mapZoom: 1,
  mapSurface: null, destination: null,
  matter: "AUTO",
}));
