import * as THREE from "three";

/** Geometria condivisa fra introduzione e portfolio. */
export function createMonolithGeometry() {
  const shape = new THREE.Shape();
  shape.moveTo(-0.8, -1.75);
  shape.lineTo(0.38, -1.75);
  shape.lineTo(0.9, -1.12);
  shape.lineTo(0.9, 1.62);
  shape.lineTo(-0.3, 1.9);
  shape.lineTo(-0.8, 1.3);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 0.55,
    bevelEnabled: true,
    bevelSegments: 3,
    steps: 16,
    bevelSize: 0.09,
    bevelThickness: 0.09,
    curveSegments: 1,
  });
  geo.center();
  return geo;
}
