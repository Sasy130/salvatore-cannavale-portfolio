import { create } from "zustand";
interface RealityState {
  active: boolean;
  gravity: boolean;
  distortion: number;
  fragmenting: boolean;
  fragmentStart: number;
  secret: boolean;
  polarity: number;
  revision: number;
  activate: () => void;
  deactivate: () => void;
  reset: () => void;
  setGravity: (value: boolean) => void;
  distort: (value: number) => void;
  fragment: () => void;
  openSecret: () => void;
  closeSecret: () => void;
  invert: () => void;
}
const neutral = {
  gravity: false,
  distortion: 0,
  fragmenting: false,
  fragmentStart: 0,
  secret: false,
  polarity: 1,
};
export const useReality = create<RealityState>((set, get) => ({
  active: false,
  ...neutral,
  revision: 0,
  activate: () => set({ active: true }),
  deactivate: () =>
    set({ active: false, ...neutral, revision: get().revision + 1 }),
  reset: () => set({ ...neutral, revision: get().revision + 1 }),
  setGravity: (gravity) => set({ gravity }),
  distort: (value) => set({ distortion: Math.max(-1, Math.min(1, value)) }),
  fragment: () => {
    set({ active: true, fragmenting: true, fragmentStart: performance.now() });
  },
  openSecret: () => set({ secret: true }),
  closeSecret: () => set({ secret: false }),
  invert: () => set({ polarity: -get().polarity }),
}));
/** Esplosione e ritorno in 4,2 secondi, senza stato React per fotogramma. */
export function fractureAmount(now: number, start: number) {
  if (!start) return 0;
  const elapsed = (now - start) / 1000;
  if (elapsed < 0.65)
    return Math.sin(((Math.max(0, elapsed) / 0.65) * Math.PI) / 2);
  if (elapsed < 1.45) return 1;
  return Math.max(0, 1 - (elapsed - 1.45) / 2.75) ** 2;
}
