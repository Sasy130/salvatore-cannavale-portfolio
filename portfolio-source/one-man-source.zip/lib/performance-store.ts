import { create } from "zustand";
export type Quality = "high" | "medium" | "low";
export const qualitySettings = {
  high: { label: "Alta", dpr: 1.5, environment: 128, particles: 324 },
  medium: { label: "Media", dpr: 1.15, environment: 64, particles: 196 },
  low: { label: "Bassa", dpr: 1, environment: 32, particles: 100 },
};
export const usePerformance = create<{
  tier: Quality;
  choice: Quality | "auto";
  reduced: boolean;
  webgl: boolean;
  ready: boolean;
  audio: boolean;
  setQuality: (value: Quality | "auto") => void;
}>((set, get) => ({
  tier: "high",
  choice: "auto",
  reduced: false,
  webgl: false,
  ready: false,
  audio: false,
  setQuality(choice) {
    const initial =
      typeof window !== "undefined" &&
      (innerWidth < 768 || navigator.hardwareConcurrency <= 4)
        ? "medium"
        : "high";
    set({
      choice,
      tier: get().reduced ? "low" : choice === "auto" ? initial : choice,
    });
  },
}));
