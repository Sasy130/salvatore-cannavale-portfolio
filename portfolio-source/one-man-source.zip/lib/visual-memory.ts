import { create } from "zustand";
import { projects } from "./portfolio-data";
import { universeRooms, matterStates, type MatterState } from "./universe-config";
export const MEMORY_KEY="one-man-universe-v1";
export interface VisualMemory {
  version:1; introSeen:boolean; introCompleted:boolean; projects:string[];
  realityUsed:boolean; portals:string[]; mapUsed:boolean; matterForms:MatterState[];
  secretUnlocked:boolean; finaleSeen:boolean;
}
const empty = ():VisualMemory => ({version:1,introSeen:false,introCompleted:false,projects:[],realityUsed:false,portals:[],mapUsed:false,matterForms:[],secretUnlocked:false,finaleSeen:false});
function clean(value:unknown):VisualMemory {
  if(!value || typeof value!=="object")return empty();
  const raw=value as Record<string,unknown>, result=empty();
  for(const key of ['introSeen','introCompleted','realityUsed','mapUsed','secretUnlocked','finaleSeen'] as const) result[key]=raw[key]===true;
  const list=(key:string,allowed:readonly string[]) => Array.isArray(raw[key]) ? [...new Set((raw[key] as unknown[]).filter((v):v is string=>typeof v==='string' && allowed.includes(v)))]:[];
  result.projects=list('projects',projects.map(p=>p.slug));
  result.portals=list('portals',universeRooms.map(r=>r.id));
  result.matterForms=list('matterForms',matterStates) as MatterState[];
  return result;
}
function save(memory:VisualMemory){try{sessionStorage.setItem(MEMORY_KEY,JSON.stringify(memory));}catch{/* Lo storage è facoltativo. */}}
type Flag='introSeen'|'introCompleted'|'realityUsed'|'mapUsed'|'secretUnlocked'|'finaleSeen';
export const useVisualMemory=create<{
  ready:boolean; memory:VisualMemory;
  hydrate:()=>void; flag:(key:Flag)=>void;
  visit:(kind:'projects'|'portals'|'matterForms',value:string)=>void;
  reset:()=>void;
}>((set,get)=>({
  ready:false,memory:empty(),
  hydrate(){if(get().ready)return;let memory=empty();try{memory=clean(JSON.parse(sessionStorage.getItem(MEMORY_KEY)??'null'));}catch{}set({ready:true,memory});},
  flag(key){if(get().memory[key])return;const memory={...get().memory,[key]:true};set({memory});save(memory);},
  visit(kind,value){const current=get().memory;if((current[kind] as string[]).includes(value))return;const memory=clean({...current,[kind]:[...current[kind],value]});set({memory});save(memory);},
  reset(){const memory=empty();set({memory});try{sessionStorage.removeItem(MEMORY_KEY);}catch{}},
}));
export function memorySteps(m:VisualMemory){return [
  {label:'Attraversa l’introduzione',done:m.introCompleted},
  {label:'Esplora un progetto',done:m.projects.length>0},
  {label:'Attiva il controllo della realtà',done:m.realityUsed},
  {label:'Ruota la mappa o scegli una stanza',done:m.mapUsed},
  {label:'Prova due forme del nucleo',done:m.matterForms.length>=2},
  {label:'Scopri la stanza 07',done:m.secretUnlocked},
];}
export function memoryScore(m:VisualMemory){return Number(m.introCompleted)+Number(m.projects.length>0)+Number(m.realityUsed)+Number(m.mapUsed)+Number(m.matterForms.length>=2)+Number(m.secretUnlocked);}
export function finaleUnlocked(m:VisualMemory){return memoryScore(m)>=3 || m.finaleSeen;}
