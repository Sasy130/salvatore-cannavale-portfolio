// Suoni originali sintetizzati: nessun campione esterno e nessun avvio automatico.
let context: AudioContext | null = null;
const voices = new Set<OscillatorNode>();
export async function enableAudio() {
  try {
    context ??= new AudioContext();
    await context.resume();
    return context.state === "running";
  } catch {
    return false;
  }
}
export function silenceAudio() {
  for (const node of voices) {
    try {
      node.stop();
    } catch {}
  }
  voices.clear();
  const old = context;
  context = null;
  if (old) void old.close().catch(() => {});
}
export function playTone(kind: "touch" | "fracture" | "secret" = "touch") {
  if (!context || context.state !== "running") return;
  const ctx = context;
  const oscillator = ctx.createOscillator(),
    gain = ctx.createGain();
  const now = ctx.currentTime;
  oscillator.type = "sine";
  const frequency = kind === "secret" ? 220 : kind === "fracture" ? 95 : 480;
  oscillator.frequency.setValueAtTime(frequency, now);
  oscillator.frequency.exponentialRampToValueAtTime(
    frequency * (kind === "touch" ? 1.4 : 0.5),
    now + 0.18,
  );
  gain.gain.setValueAtTime(0, now);
  gain.gain.linearRampToValueAtTime(0.035, now + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.26);
  oscillator.connect(gain);
  gain.connect(ctx.destination);
  voices.add(oscillator);
  oscillator.onended = () => {
    voices.delete(oscillator);
    oscillator.disconnect();
    gain.disconnect();
  };
  oscillator.start();
  oscillator.stop(now + 0.28);
}
