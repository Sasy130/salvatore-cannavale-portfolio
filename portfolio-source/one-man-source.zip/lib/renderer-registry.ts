import { create } from "zustand";
import type { EnvironmentName } from "./portfolio-store";
export interface SceneSlot {
  id: string;
  element: HTMLElement;
  kind: "intro" | "world" | "secret" | "portal";
  visible: boolean;
  detail?: boolean;
  environment?: EnvironmentName;
  paused?: boolean;
  amplitude?: number;
  run?: number;
}
export const useRendererRegistry = create<{
  slots: Record<string, SceneSlot>;
  put: (slot: SceneSlot) => void;
  remove: (id: string) => void;
}>((set) => ({
  slots: {},
  put: (slot) => set((s) => ({ slots: { ...s.slots, [slot.id]: slot } })),
  remove: (id) =>
    set((s) => {
      const slots = { ...s.slots };
      delete slots[id];
      return { slots };
    }),
}));
export function chooseSlot(slots: Record<string, SceneSlot>, includeHidden = false) {
  return (
    Object.values(slots)
      .filter((s) => s.element.isConnected && (s.visible || includeHidden))
      .sort((a, b) => priority(b) - priority(a))[0] ?? null
  );
}
function priority(s: SceneSlot) {
  return s.kind === "portal"
    ? 110
    : s.kind === "secret"
    ? 100
    : s.kind === "intro"
      ? 80
      : s.detail
        ? 40
        : 20;
}
