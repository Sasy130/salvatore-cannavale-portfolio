/** Canale volatile: nessun dato del gesto viene conservato o inviato. */
export const galleryMotion = {
  scroll: 0,
  front: false,
  yaw: 0,
  pointerX: 0,
  pointerY: 0,
};
