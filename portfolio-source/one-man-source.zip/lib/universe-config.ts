export type Vec3 = readonly [number, number, number];
export interface UniverseRoom {
  id: string;
  label: string;
  subtitle: string;
  center: Vec3;
  camera: Vec3;
  form: number;
}
export const universeRooms: UniverseRoom[] = [
  {
    id: "contenuto",
    label: "Home",
    subtitle: "L’origine",
    center: [0, 0, 0],
    camera: [0, 0.2, 7.2],
    form: 0,
  },
  {
    id: "chi-sono",
    label: "Chi sono",
    subtitle: "La visione",
    center: [-3, 0.4, -5],
    camera: [-3, 0.8, 2],
    form: 1,
  },
  {
    id: "progetti",
    label: "Progetti",
    subtitle: "Gli universi",
    center: [4, 0, -10],
    camera: [4, 0.4, -3],
    form: 2,
  },
  {
    id: "competenze",
    label: "Competenze",
    subtitle: "Il motore",
    center: [-3.5, -0.3, -16],
    camera: [-3.5, 0.3, -9],
    form: 3,
  },
  {
    id: "universo",
    label: "Esplora l’universo",
    subtitle: "Il laboratorio",
    center: [4.5, 1, -20],
    camera: [4.5, 1.2, -13],
    form: 5,
  },
  {
    id: "contatti",
    label: "Contatti",
    subtitle: "Il prossimo possibile",
    center: [0, 0, -23],
    camera: [0, 0.4, -16],
    form: 4,
  },
];
export function roomFor(id: string) {
  return universeRooms.find((r) => r.id === id) ?? universeRooms[0];
}

export const matterStates = [
  "MONOLITH",
  "LIQUID",
  "FRACTURED",
  "PARTICLES",
  "TYPOGRAPHY",
] as const;
export type MatterState = (typeof matterStates)[number];
export const matterLabels: Record<MatterState, string> = {
  MONOLITH: "Monolite",
  LIQUID: "Materia liquida",
  FRACTURED: "Frammenti",
  PARTICLES: "Particelle",
  TYPOGRAPHY: "ONE MAN",
};
