export const siteConfig = {
  name: "ONE MAN",
  slogan: "LA REALTÀ SI RISCRIVE.",
  description:
    "Il portfolio personale di ONE MAN. Una galleria di progetti, immagini e punti di vista. La realtà si riscrive.",
  url: (
    process.env.NEXT_PUBLIC_SITE_URL ??
    "https://one-man-realta-7f26.one-man13.chatgpt.site"
  ).replace(/\/$/, ""),
  locale: "it_IT",
  language: "it-IT",
  secretPhrase: "Non esiste un solo modo di essere reali.",
};
export function jsonLd(value: unknown) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}
