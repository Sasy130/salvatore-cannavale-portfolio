/** Inserisci qui esclusivamente i tuoi progetti reali. Le immagini di prova sono separate. */
export interface GalleryProject {
  id: string;
  title: string;
  category: string;
  cover: string;
  description: string;
  images?: { src: string; alt: string }[];
  technologies?: string[];
  href?: string;
}
export const galleryProjects: GalleryProject[] = [];
/** Fotografie temporanee: non rappresentano lavori o clienti di ONE MAN. */
const assetBase = process.env.NEXT_PUBLIC_ASSET_BASE ?? "";
export const galleryPreviews = [
  { src: `${assetBase}/anteprime/01.jpg`, alt: "Immagine di prova: architettura scultorea chiara", width: 1200, height: 800 },
  { src: `${assetBase}/anteprime/02.jpg`, alt: "Immagine di prova: composizione dai toni rossi e arancioni", width: 1200, height: 800 },
  { src: `${assetBase}/anteprime/03.jpg`, alt: "Immagine di prova: dettaglio botanico verde", width: 675, height: 1200 },
];
export interface GalleryWork {
  id: string;
  number: string;
  title: string;
  category: string;
  project?: GalleryProject;
  preview?: { src: string; alt: string; width: number; height: number };
}
export const galleryWorks: GalleryWork[] = galleryProjects.length
  ? galleryProjects.map((project, i) => ({
      id: project.id,
      number: String(i + 1).padStart(2, "0"),
      title: project.title,
      category: project.category,
      project,
    }))
  : ["01", "02", "03"].map((number, index) => ({
      id: `spazio-${number}`,
      number,
      title: "Spazio per un progetto",
      category: "Immagine di prova",
      preview: galleryPreviews[index],
    }));
export const galleryCopy = {
  title: "PROGETTI.",
  introDuration: 5.8,
  about: "ONE MAN è la mia identità creativa personale. Un punto d’incontro tra immaginazione, sensibilità visiva e codice.",
};
