import * as THREE from "three";

/** Tasselli con identità stabile: l'immagine frontale e la scultura usano gli stessi vertici. */
export function createAnamorphicGeometry(width: number, height: number, lightweight = false) {
  const columns = lightweight ? 5 : 8;
  const rows = lightweight ? 6 : 10;
  const vertices = columns * rows * 6;
  const position = new Float32Array(vertices * 3);
  const center = new Float32Array(vertices * 3);
  const seed = new Float32Array(vertices * 3);
  const uv = new Float32Array(vertices * 2);
  const corners = [[0, 0], [1, 0], [1, 1], [0, 0], [1, 1], [0, 1]];
  const random = (n: number) => {
    const value = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return value - Math.floor(value);
  };
  let vertex = 0;
  for (let row = 0; row < rows; row++) {
    for (let column = 0; column < columns; column++) {
      const id = row * columns + column;
      const cx = ((column + .5) / columns - .5) * width;
      const cy = ((row + .5) / rows - .5) * height;
      const sx = random(id + 1), sy = random(id + 83), sz = random(id + 179);
      for (const [dx, dy] of corners) {
        const u = (column + dx) / columns, v = (row + dy) / rows;
        position.set([(u - .5) * width, (v - .5) * height, 0], vertex * 3);
        center.set([cx, cy, 0], vertex * 3);
        seed.set([sx, sy, sz], vertex * 3);
        uv.set([u, v], vertex * 2);
        vertex++;
      }
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.BufferAttribute(position, 3));
  geometry.setAttribute("aCenter", new THREE.BufferAttribute(center, 3));
  geometry.setAttribute("aSeed", new THREE.BufferAttribute(seed, 3));
  geometry.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
  geometry.computeBoundingSphere();
  geometry.userData.shards = columns * rows;
  return geometry;
}
