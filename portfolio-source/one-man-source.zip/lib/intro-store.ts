import { create } from "zustand";
export type Phase =
  "IDLE" | "CONTACT" | "FRACTURE" | "ROOM" | "CREATION" | "REVEAL" | "COMPLETE";
export const phases: Phase[] = [
  "IDLE",
  "CONTACT",
  "FRACTURE",
  "ROOM",
  "CREATION",
  "REVEAL",
  "COMPLETE",
];
interface IntroState {
  phase: Phase;
  energy: number;
  elapsed: number;
  exploration: number;
  creationProgress: number;
  holding: boolean;
  reduced: boolean;
  fallback: boolean;
  run: number;
  transition: (next: Phase) => void;
  hold: (value: boolean) => void;
  tick: (dt: number) => void;
  explore: (amount: number) => void;
  replay: () => void;
  skip: () => void;
}
const nextPhase: Partial<Record<Phase, Phase>> = {
  IDLE: "CONTACT",
  CONTACT: "FRACTURE",
  FRACTURE: "ROOM",
  ROOM: "CREATION",
  CREATION: "REVEAL",
  REVEAL: "COMPLETE",
};
export const useIntro = create<IntroState>((set, get) => ({
  phase: "IDLE",
  energy: 0,
  elapsed: 0,
  exploration: 0,
  creationProgress: 0,
  holding: false,
  reduced: false,
  fallback: false,
  run: 0,
  transition(next) {
    const s = get();
    if (nextPhase[s.phase] === next)
      set({ phase: next, elapsed: 0, holding: false });
  },
  hold(value) {
    const s = get();
    if (value && (s.phase === "IDLE" || s.phase === "CONTACT"))
      set({ phase: "CONTACT", holding: true });
    else if (!value) set({ holding: false });
  },
  tick(dt) {
    const s = get();
    if (s.phase === "COMPLETE") return;
    const elapsed = s.elapsed + dt;
    if (s.phase === "CONTACT") {
      const energy = Math.max(
        0,
        Math.min(1, s.energy + (s.holding ? dt / 1.5 : -dt * 0.8)),
      );
      if (energy >= 1)
        set({ phase: "FRACTURE", energy: 1, elapsed: 0, holding: false });
      else if (energy === 0 && !s.holding)
        set({ phase: "IDLE", energy: 0, elapsed: 0 });
      else set({ energy, elapsed });
    } else if (s.phase === "FRACTURE" && elapsed > (s.reduced ? 0.25 : 3.2))
      set({ phase: "ROOM", elapsed: 0 });
    else if (s.phase === "REVEAL" && elapsed > (s.reduced ? 0.25 : 4.2))
      set({ phase: "COMPLETE", elapsed: 0 });
    else set({ elapsed });
  },
  explore(amount) {
    const s = get();
    if (s.phase !== "ROOM") return;
    const exploration = s.exploration + Math.abs(amount);
    set(
      exploration >= 0.65
        ? { exploration, phase: "CREATION", elapsed: 0 }
        : { exploration },
    );
  },
  replay() {
    set({
      phase: "IDLE",
      energy: 0,
      elapsed: 0,
      exploration: 0,
      creationProgress: 0,
      holding: false,
      run: get().run + 1,
    });
  },
  skip() {
    set({ phase: "COMPLETE", holding: false, elapsed: 0 });
  },
}));
