const base = process.env.NEXT_PUBLIC_ASSET_BASE ?? "";
export const restoredProjects = [
  {
    "slug": "velar",
    "name": "VELAR",
    "subtitle": "Exotic Car Rental",
    "description": "Sei vetture esclusive, un Key Vault cinematografico e un percorso di noleggio dimostrativo.",
    "category": "Automotive",
    "tags": [
      "KEY VAULT",
      "AUTOMOTIVE EXPERIENCE",
      "MOTION"
    ],
    "url": "/demos/velar/",
    "access": "public",
    "image": "/one-man/assets/projects/velar.webp",
    "alt": "Anteprima del concept VELAR"
  },
  {
    "slug": "kinetic",
    "name": "KÍNETIC",
    "subtitle": "The Art of Movement",
    "description": "Un’accademia di danza immaginaria, tra sequenze cinematografiche, corsi e percorsi da esplorare.",
    "category": "Esperienze",
    "tags": [
      "DANCE EXPERIENCE",
      "SCROLL CINEMA",
      "INTERAZIONE"
    ],
    "url": "/demos/kinetic/",
    "access": "public",
    "image": "/one-man/assets/projects/kinetic.webp",
    "alt": "Anteprima del concept KÍNETIC"
  },
  {
    "slug": "velmora",
    "name": "VELMORA",
    "subtitle": "Atria 54",
    "description": "Uno yacht a tre ponti da esplorare in tempo reale. Tour continuo, materiali e configuratore integrato.",
    "category": "Luxury",
    "tags": [
      "REALTIME 3D",
      "CONFIGURATORE"
    ],
    "url": "/velmora/index.html",
    "image": "/one-man/assets/velmora.jpg",
    "caseButton": "open-case",
    "caseDialog": "case-dialog",
    "access": "public",
    "alt": "Anteprima del progetto VELMORA"
  },
  {
    "slug": "vera",
    "name": "VÉRA",
    "subtitle": "Luxury Real Estate",
    "description": "Residenze, architetture e luoghi da vivere in un’esperienza immobiliare editoriale e interattiva.",
    "category": "Luxury",
    "tags": [
      "REAL ESTATE",
      "ART DIRECTION",
      "CATALOGO"
    ],
    "url": "/demos/vera/",
    "access": "public",
    "image": "/one-man/assets/projects/vera.webp",
    "alt": "Anteprima del concept VÉRA"
  },
  {
    "slug": "apex-karting",
    "name": "APEX KARTING",
    "subtitle": "Born to race",
    "description": "Un’esperienza racing tra circuito, formati di gara e richiesta di prenotazione demo.",
    "category": "Sport",
    "tags": [
      "RACING EXPERIENCE",
      "MOTION",
      "INTERAZIONE"
    ],
    "url": "/demos/apex-karting/",
    "access": "public",
    "image": "/one-man/assets/projects/apex-karting.webp",
    "alt": "Fotografia racing usata nella hero del concept APEX KARTING"
  },
  {
    "slug": "black-label",
    "name": "BLACK LABEL",
    "subtitle": "The Art of Grooming",
    "description": "Un’identità contemporanea per il grooming, tra rituali, professionisti e prenotazione dimostrativa.",
    "category": "Lifestyle",
    "tags": [
      "BRAND EXPERIENCE",
      "WEB DESIGN",
      "BOOKING DEMO"
    ],
    "url": "/demos/black-label/",
    "access": "public",
    "image": "/one-man/assets/projects/black-label.webp",
    "alt": "Fotografia stock usata nella hero del concept BLACK LABEL"
  },
  {
    "slug": "fuoco",
    "name": "FUOCO",
    "subtitle": "L’arte della pizza",
    "description": "Un concept di pizzeria con sei pizze in Pizza Orbit, menu rapido con ricerca e dettagli degli ingredienti.",
    "category": "Food",
    "tags": [
      "RESTAURANT EXPERIENCE",
      "LIVING MENU",
      "MOTION"
    ],
    "url": "/fuoco",
    "access": "public",
    "image": "/one-man/assets/projects/fuoco.webp",
    "alt": "Home del concept FUOCO, tra tipografia editoriale e fotografia di pizza"
  },
  {
    "slug": "mare",
    "name": "MARÉ",
    "subtitle": "The Art of Escape",
    "description": "Yacht, destinazioni e itinerari da esplorare, fino alla richiesta di viaggio personalizzata.",
    "category": "Luxury",
    "tags": [
      "YACHT EXPERIENCE",
      "MOTION",
      "CONCIERGE"
    ],
    "url": "/demos/mare/",
    "access": "public",
    "image": "/one-man/assets/projects/mare.webp",
    "alt": "Anteprima del progetto dimostrativo MARÉ"
  },
  {
    "slug": "fuorigioco",
    "name": "FUORIGIOCO",
    "subtitle": "Il tuo prossimo match",
    "description": "Campi, formati di gioco e calendario dimostrativo per organizzare il prossimo incontro.",
    "category": "Sport",
    "tags": [
      "SPORT EXPERIENCE",
      "BOOKING DEMO"
    ],
    "url": "/demos/fuorigioco/index.html",
    "access": "public",
    "image": "/one-man/assets/projects/fuorigioco.webp",
    "alt": "Anteprima del progetto dimostrativo FUORIGIOCO"
  },
  {
    "slug": "orbita",
    "name": "ORBITA",
    "subtitle": "Il cinema, in un altro universo",
    "description": "Un cinema indipendente immaginario, tra programmazione, rassegne e prenotazione dimostrativa.",
    "category": "Esperienze",
    "tags": [
      "CINEMA EXPERIENCE",
      "CATALOGO",
      "BOOKING DEMO"
    ],
    "url": "/demos/orbita/index.html",
    "access": "public",
    "image": "/one-man/assets/projects/orbita.webp",
    "alt": "Anteprima del progetto dimostrativo ORBITA"
  },
  {
    "slug": "rent-car-station",
    "kind": "redesign",
    "name": "RENT CAR STATION",
    "subtitle": "Napoli, si parte.",
    "description": "Proposta indipendente di redesign per esplorare flotta, servizi e una richiesta dimostrativa.",
    "category": "Automotive",
    "tags": [
      "REDESIGN INDIPENDENTE",
      "RENTAL EXPERIENCE"
    ],
    "url": "/demos/rent-car-station/",
    "access": "public",
    "image": "/one-man/assets/projects/rent-car-station.webp",
    "alt": "Anteprima del progetto dimostrativo RENT CAR STATION"
  },
  {
    "slug": "aj-rent-car",
    "kind": "redesign",
    "name": "A&J RENT CAR",
    "subtitle": "Napoli, al tuo ritmo",
    "description": "Un concept di redesign dedicato al noleggio e alla scoperta di Napoli, con flotta e percorsi guidati.",
    "category": "Automotive",
    "tags": [
      "REDESIGN INDIPENDENTE",
      "WEB DESIGN"
    ],
    "url": "/demos/aj-rent-car/",
    "access": "public",
    "image": "/one-man/assets/projects/aj-rent-car.webp",
    "alt": "Anteprima del progetto dimostrativo A&J RENT CAR"
  }
];
export const projects = restoredProjects.map(p=>({...p, image:base+p.image.replace(/^\/one-man/,""), label:"kind" in p&&p.kind==="redesign"?"Redesign indipendente":"Progetto dimostrativo"}));
