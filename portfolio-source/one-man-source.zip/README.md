# ONE MAN — Portfolio cinematografico

Revisione del 17 novembre 2026. Homepage: `components/cinema/CinemaPortfolio.tsx` e `cinema.css`. I progetti precedenti sono ripristinati da `public/one-man/projects-data.js` del repository originale, revisione `bb4c999ae6600ca8eff34f3444369bfa1037d977`: copertine, descrizioni, etichette dimostrative e collegamenti originali. Modificare `lib/restored-projects.ts` per i contenuti e `lib/portfolio-data.ts` per i recapiti.

## Tensione — nuova identità editoriale, 20 novembre 2026

Il riferimento indicato dall'utente è la selezione portfolio di Awwwards: https://www.awwwards.com/websites/portfolio/. La nuova composizione è originale; nessun premio, riconoscimento o affiliazione dichiarati. Rimossa l'estetica neon: carta chiara, nero e vermiglio, tipografia monumentale, gerarchie editoriali e disegno generativo condiviso fra intro, hero e ingresso ai lavori.

`components/cinema/cinema.css` è riscritto come sistema coerente, includendo navigazione, galleria, indice, schede, biografia, contatti e layout mobile. Il motore React/GSAP e il renderer WebGL delle anteprime restano riutilizzati. Tutti i 13 progetti, miniature, URL delle demo e backend esistente sono conservati.

## Opera interattiva

`BrandArtwork.tsx` genera 64 tracciati SVG da una funzione parametrica. Il pulsante **Riscrivi la forma** interpola realmente la geometria dei tracciati tramite GSAP, con ripristino ripetibile. Puntatore e touch modificano la prospettiva del disegno; il pulsante è utilizzabile da tastiera. Con reduced motion la forma cambia immediatamente e la parallasse è disattivata. È grafica SVG, non una simulazione fisica 3D.

La nuova intro mantiene salto, Escape, replay, sipari e termine automatico. Hero e ingresso non contengono copertine dei lavori. L'archivio presenta le miniature in scala di grigi, ripristinando il colore su hover/focus. Le schede conservano il collegamento reale e la demo interattiva in iframe.

## Verifiche

TypeScript, lint, build statica con prefisso /one-man e nove scenari Chromium superati. Copertura: 13 progetti, menu, iframe controllato, renderer, WebGL negato, touch CDP, ripristino, selettore miniature, focus, intro/skip/replay/uscita automatica, reduced motion, axe WCAG A/AA e cinque viewport. Nuovo test touch/tastiera sul controllo dell'opera con verifica del cambiamento dei tracciati. Controllo dedicato dell'apertura della maschera grafica dell'ingresso. Safari e dispositivi fisici non collaudati.

## Avvio e pubblicazione

`npm ci`, poi `npm run dev`. Per il dominio esistente:

```sh
NEXT_PUBLIC_ASSET_BASE=/one-man NEXT_PUBLIC_SITE_URL=https://www.salvatorecannavale.it npm run build:static
```

Copiare l’export `out/` in `public/one-man/` del repository `Sasy130/salvatore-cannavale-portfolio`, conservando gli altri file e le demo. Il repository principale riscrive `/` su `/one-man/index.html`; Vercel pubblica il branch `main`. La vecchia identità Sites non gestisce questo dominio. La pubblicazione usa commit con verifica del branch precedente, senza forzature. Le versioni precedenti restano recuperabili dalla cronologia Git.

---

## Documentazione della precedente galleria

# ONE MAN — Una questione di prospettiva

Nuova direzione artistica con continuazione anamorfica: un’introduzione surreale si apre in una panoramica di cornici tridimensionali. Scroll, trascinamento orizzontale e selezione dispongono i lavori nello spazio. L’interfaccia rimane essenziale: Progetti, Chi sono e Contatti.

I progetti reali non sono ancora stati forniti. La galleria mostra **tre fotografie di prova**, indicate come “Spazio per un progetto / Immagine di prova”. Sono materiali dimostrativi separati dai lavori personali; aprirli mostra la foto e una spiegazione esplicita, senza clienti o risultati inventati. Le fotografie locali e le fonti sono documentate in `docs/IMMAGINI-DI-PROVA.md`.

## Avvio

Node.js 20.19+ e npm; Node.js 24 consigliato.

```sh
npm ci
npm run dev
```

Aprire http://localhost:3000. Per la produzione Next:

```sh
npm run build
npm start
```

Per l’export statico:

```sh
npm run build:static
npm run preview:static
```

Il risultato è in `out/`, l’anteprima su http://localhost:4173. Dopo una build statica eseguire nuovamente `npm run build` prima di usare `npm start`.

## Nuova esperienza

- **Intro**: cornice, ombra che anticipa il movimento, parete interna deformata da un vertex shader e pannelli incernierati. La camera arretra e rivela le altre cornici nello stesso canvas. Nessun gesto obbligatorio o enigma; salto sempre disponibile e limite temporale per evitare blocchi. Il passaggio è procedurale, non un video.
- **Panoramica**: titoli e categorie sono pulsanti HTML proiettati sotto le cornici. Questo livello è indipendente dal ciclo di vita del canvas, leggibile da tastiera e stabile al cambio di vista. Le cornici sono selezionabili anche mediante raycasting.
- **Scroll**: nativo, con ScrollTrigger che comunica il progresso alla scena. I pannelli cambiano disposizione, profondità e orientamento; il controllo “Vista d’insieme” ripristina la composizione.
- **Punto di vista**: trascinamento orizzontale limitato. Su touch lo scroll verticale resta disponibile.
- **Apertura**: la cornice scelta avanza, le altre si allontanano e la camera si avvicina. Poi si apre il dettaglio HTML. In modalità essenziale il dettaglio si apre direttamente. Chiusura con pulsante o Escape, ripristino del focus e della disposizione precedente.
- **Elenco**: alternativa HTML accessibile, disponibile anche senza WebGL. Nessun canvas aggiuntivo.
- **Mobile**: dimensioni, camera e didascalie dedicate. I primi tre spazi sono contemporaneamente visibili; l’allestimento di molti lavori andrà calibrato sul numero e sui formati reali.
- **Sicurezza dell’interazione**: timer di uscita dell’intro, fallback su errore shader/perdita WebGL, pausa a scheda nascosta, cleanup di geometrie/materiali e movimento ridotto. L’audio e i controlli sperimentali delle vecchie edizioni non vengono attivati nella nuova homepage.

L’intro vista viene ricordata nella scheda con il solo valore `one-man-gallery-intro: vista`. Lo storage è facoltativo. `/?intro=1` e “Rivedi l’introduzione” la riaprono.

## La mostra dentro il quadro

Dopo l’intro, continuare a scorrere: la camera rivela la cornice che racchiude la panoramica e il quadro centrale contiene due miniature dell’allestimento. La successiva vista obliqua separa le immagini in piani tridimensionali. “Vista frontale” ricostruisce prospetticamente l’immagine senza azzerare la scultura; “Vista d’insieme” riavvolge il percorso. Aprendo una cornice, gli altri pannelli si dispongono ai suoi lati. Chiusura, scroll e focus vengono ripristinati.

La ricorsione è finita e geometrica. Le superfici anamorfiche sono procedurali, non ricostruzioni fotogrammetriche. Dettagli e verifiche in `docs/MOSTRA-IMPOSSIBILE.md`.

## Inserire i tuoi lavori

Modificare `lib/gallery-data.ts`. L’array `galleryProjects` è intenzionalmente vuoto. `galleryPreviews` contiene le tre immagini dimostrative in `public/anteprime/`: modificarlo per sostituire le foto di prova. Appena si inseriscono progetti reali, le anteprime vengono sostituite automaticamente. Esempio di struttura da compilare con dati reali:

```ts
{
  id: "identificativo-del-lavoro",
  title: "Titolo del tuo progetto",
  category: "Categoria del lavoro",
  cover: "/lavori/copertina.jpg",
  description: "Il racconto del tuo progetto.",
  images: [{ src: "/lavori/dettaglio.jpg", alt: "Descrizione dell’immagine" }],
  technologies: ["Strumenti realmente utilizzati"],
  href: "https://indirizzo-reale-del-progetto.it"
}
```

Mettere i file immagine in `public/lavori/`; ottimizzarli prima della pubblicazione. `images`, `technologies` e `href` sono facoltativi. Il primo allestimento è calibrato su tre lavori: prima di pubblicarne molti, adattare disposizione e formati alle immagini effettive. Il dettaglio si apre nella pagina; le foto di prova non generano case study fittizi.

Biografia della nuova homepage: `galleryCopy` nello stesso file. Recapiti e social: `identity` in `lib/portfolio-data.ts`, ancora vuoti come concordato. Slogan, dominio e metadati: `lib/site-data.ts`. Non inserire email, certificazioni o esperienze non verificate.

## File principali

```text
app/page.tsx                            Nuova homepage
app/layout.tsx                          Metadati italiani e runtime
app/sitemap.ts                          Homepage attuale
components/gallery/
  GalleryExperience.tsx                 Navigazione, intro, scroll e stato della vista
  GalleryStage.tsx                      Camera, cornici, deformazione GLSL e raycasting
  GalleryDetail.tsx                     Dettaglio, dialogo e focus
  RecursiveFrames.tsx                   Cornici annidate e miniature geometriche
  AnamorphicSurface.tsx                 Superfici e shader di ricomposizione
  GalleryArrow.tsx                      Icona vettoriale condivisa
  gallery.css                           Direzione artistica e responsive
lib/gallery-data.ts                     Contenuti reali e immagini di prova separate
lib/gallery-motion.ts                   Canale volatile dei gesti e dello scroll
lib/gallery-choreography.ts             Partitura reversibile dei capitoli
lib/anamorphic-geometry.ts               Tasselli con identità stabile
lib/performance-store.ts                Qualità e capacità del dispositivo
components/reality/Runtime.tsx          Capacità, qualità e attivazione condizionale del vecchio motore
tests/gallery.spec.ts                   Verifiche della nuova esperienza
.openai/hosting.json                    Identità del sito esistente
```

I componenti e le pagine delle edizioni precedenti rimangono nel repository. I vecchi esperimenti non sono collegati dalla nuova homepage e non vengono inclusi nella sitemap; le route già esistenti rimangono apribili da un vecchio segnalibro. `docs/EDIZIONE-UNIVERSO.md` e `docs/LIVING-UNIVERSE.md` documentano l’edizione precedente. I suoi test restano come archivio; la configurazione Playwright attuale seleziona la nuova suite `gallery.spec.ts`.

## Verifiche

```sh
npm run typecheck
npm run lint
npm run build
npm run test:e2e
npm run build:static
npm run test:static
```

Il browser richiesto dai test è Chromium di Playwright. Installarlo solo se assente, con `npx playwright install chromium`. I test includono intro, un solo canvas, panoramica, scroll, drag, apertura, elenco, navigazione, replay, touch emulato, WebGL/storage negati, perdita del contesto e audit axe nella modalità essenziale. Gli esiti dell’edizione iniziale sono in `docs/GALLERIA.md`; i risultati aggiornati e i limiti della continuazione sono in `docs/MOSTRA-IMPOSSIBILE.md`.

## Pubblicazione

Sito esistente:

https://one-man-realta-7f26.one-man13.chatgpt.site

La visibilità resta privata: sul telefono accedere con lo stesso account ChatGPT proprietario. Non è un’anteprima LAN. La nuova versione sostituisce la homepage all’indirizzo esistente.

Per Sites: costruire `out/`, sincronizzare il commit sorgente e pubblicare un archivio contenente `out/` e `.openai/hosting.json` riferito a quel commit. `scripts/push-site.mjs` riceve le credenziali temporanee soltanto su stdin nascosto. Per Vercel usare la build Next normale; per un altro hosting statico usare `out/` con risoluzione delle route `/percorso` verso `/percorso.html`. Configurare `NEXT_PUBLIC_SITE_URL` per un dominio diverso e ricostruire.

## Limiti

È una prima versione dell’intro e della galleria, pronta per valutare la direzione artistica. Le fotografie di prova sono temporanee e saranno sostituite dai lavori reali. I passaggi sono animazioni procedurali controllate, non una simulazione fisica completa. Se il rendering è troppo lento o non disponibile, il sito mantiene il percorso HTML. La velocità dipende dal dispositivo: nessuna garanzia di prestazioni identiche. Smartphone fisici e Safari richiedono ancora collaudo; il touch automatizzato è emulato in Chromium. Gli audit automatici non sostituiscono una verifica con screen reader.
