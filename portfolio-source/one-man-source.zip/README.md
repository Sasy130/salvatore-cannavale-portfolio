# ONE MAN — Portfolio cinematografico

Homepage attiva: `components/vice/VicePortfolio.tsx` e `vice.css`; apertura: `SignatureOpening.tsx`. Contenuti dei progetti in `lib/restored-projects.ts`, biografia ed email in `lib/portfolio-data.ts`. I componenti delle precedenti revisioni restano nel sorgente come archivio.

## Firma SC — 21 novembre 2026

Modifica limitata all'introduzione, nel nuovo `components/vice/SignatureOpening.tsx`. Iniziali SC ritagliate con una maschera SVG su una superficie color carta: attraverso le lettere si vede lo sfondo esistente. La geometria si ingrandisce e un'apertura circolare rivela la homepage. Non è un video né un nuovo renderer WebGL.

Apertura automatica, tocco, Entra subito, Escape, salto, replay e focus gestiti. Memoria `one-man-signature`; `?intro=1` forza l'apertura. Con reduced motion la visita normale accede direttamente al sito; il replay esplicitamente richiesto mostra la versione statica e si chiude senza animazioni. Overlay visibile solo quando il codice è pronto: con script bloccati la pagina rimane accessibile. Timer di sicurezza e cleanup dell'intera timeline anche interrompendo l'uscita.

Hero, parete dei lavori, indice, biografia e contatti conservano lo stesso blocco sorgente, verificato con SHA-256. Menu, 13 progetti, immagini, demo e backend mantenuti. Lo sfondo artistico esistente non è stato sostituito.

TypeScript, lint, build statica /one-man e nove scenari Chromium superati: apertura SC, automatico/tocco, skip/replay, interruzione e riapertura, menu/focus, demo controllata, touch, cinque viewport, asset, clipboard, assenza WebGL e script bloccati. Versione statica reduced motion e axe verificati nuovamente sull'ultima build. Schermata mobile ispezionata. Safari e telefoni fisici non collaudati.

## Archivio delle revisioni precedenti

## Nuova apertura automatica e opera originale — 20 novembre 2026

Modifica circoscritta all'intro e allo sfondo iniziale: il resto della pagina, i 13 lavori, il menu e le demo sono conservati. La fotografia è sostituita da `public/assets/one-man-vice-art.webp`, opera generata appositamente (rosa, magenta, turchese, texture e ombre tropicali), circa 206 KiB. Fonte e dettagli in `docs/OPERA-VICE.md`.

L'intro non richiede più trascinamenti: dopo l'entrata del nome, si apre automaticamente (circa 3,5 secondi). Un tocco in qualsiasi punto oppure **Entra subito** avvia subito la transizione. Tre tagli diagonali accompagnano l'uscita. Progressione visibile, Skip, Escape, tastiera, replay e reduced motion gestiti. Memoria aggiornata `one-man-vice-art`; `?intro=1` forza l'apertura.

L'overlay viene mostrato soltanto quando il codice interattivo è pronto. Se i file JavaScript non arrivano, il sito rimane accessibile dall'HTML statico, senza un'introduzione sovrapposta. Timer di sicurezza durante l'uscita e nel percorso automatico. Il disegno di sfondo è un'immagine originale; la transizione è HTML/CSS/GSAP, non un filmato.

TypeScript, lint e build statica /one-man superati. Otto scenari Chromium superati, incluso nuovo controllo dell'apertura automatica, tocco reale sul nome (con chiusura entro 2,2 secondi), pulsante, skip/replay e JavaScript bloccato. Conservati i controlli su 13 lavori, menu, demo simulata, immagini, cinque viewport, clipboard, assenza di WebGL, reduced motion e axe. Il controllo del pulsante è stato ripetuto separatamente dopo aver adeguato il test alla nuova apertura automatica. Safari e dispositivi fisici non collaudati.

## Versione precedente

## Vice Cut — ingresso personale e parete dei lavori, 20 novembre 2026

Homepage attiva: `components/vice/VicePortfolio.tsx`, importata da `app/page.tsx`. Nuova direzione rosa/turchese/viola scuro, fotografia di Miami a pieno schermo e nome SALVATORE CANNAVALE. Apertura interattiva: le 18 lettere entrano in prospettiva; trascinando il nome oltre la soglia oppure premendo Entra nel mio mondo, le lettere si separano e cinque tagli verticali rosa/turchese rivelano la homepage. È animazione HTML/CSS/GSAP, non un filmato o una simulazione WebGL. Skip, Escape, tastiera, replay, memoria facoltativa `one-man-vice-cut`, timeout di sicurezza all'uscita e reduced motion gestiti. `?intro=1` forza il replay.

## Progetti e navigazione

La lunga galleria con pannello fisso e miniature è sostituita da una parete continua: un'immagine a tutta larghezza alternata a due mezze pagine su desktop, singola colonna su telefono. Nessun canvas necessario; le immagini sono caricate progressivamente. Scroll verticale nativo, maschere diagonali, parallasse delle immagini, movimento della tipografia e reazione al puntatore. Titoli e link reali restano HTML accessibile. Indice testuale alternativo, menu fisso, biografia e contatti ridisegnati. Copia email usa realmente la clipboard e segnala il fallimento. Nessun form finto.

Tutti i 13 progetti, descrizioni, etichette dimostrative e demo originali sono conservati in `lib/restored-projects.ts`. Schede e menu nativi sono riutilizzati da `CinemaPortfolio.tsx` con esportazioni nominate. Le precedenti implementazioni restano nel sorgente come archivio, incluse le relative suite; i test attivi della nuova homepage sono in `tests/vice.spec.ts`. I backend e gli altri siti nel repository principale non sono sostituiti.

## Fotografia

Asset locale `public/assets/vice-portrait.webp`, circa 887 KiB, di Luise and Nic / Unsplash. Fonte, licenza e attribuzione in `docs/FOTOGRAFIA-VICE.md` e nel footer. Non è un'immagine di un progetto o luogo professionale attribuito a Salvatore. Nessun materiale del videogioco.

## Verifiche

TypeScript, lint e build statica di produzione con prefisso /one-man superati. Sette scenari Chromium superati: apertura, skip/replay, demo controllata e focus, touch/menu/hash, reduced motion/audit axe WCAG A/AA, cinque viewport (320×740, 390×844, 768×1024, 844×390, 1440×1000), tutte le 13 immagini HTTP 200, accesso senza WebGL, copia email reale e trascinamento touch del nome via CDP. Dopo la rifinitura delle icone SVG, ripetuti e superati i due scenari di apertura e navigazione touch sull'ultima build. Verificati anche scroll verso la sezione e posizione del menu fisso. Schermate ispezionate. Safari e telefoni fisici non collaudati.

## Avvio e pubblicazione

`npm ci`, poi `npm run dev`. Per il dominio esistente:

```sh
NEXT_PUBLIC_ASSET_BASE=/one-man NEXT_PUBLIC_SITE_URL=https://www.salvatorecannavale.it npm run build:static
```

Copiare l’export `out/` in `public/one-man/` del repository `Sasy130/salvatore-cannavale-portfolio`, conservando gli altri file e le demo. Il repository principale riscrive `/` su `/one-man/index.html`; Vercel pubblica il branch `main`. La vecchia identità Sites non gestisce questo dominio. La pubblicazione usa commit con verifica del branch precedente, senza forzature. Le versioni precedenti restano recuperabili dalla cronologia Git.

---

## Documentazione della precedente galleria

# ONE MAN — Una questione di prospettiva

Nuova direzione artistica con continuazione anamorfica: un’introduzione surreale si apre in una panoramica di cornici tridimensionali. Scroll, trascinamento orizzontale e selezione dispongono i lavori nello spazio. L’interfaccia rimane essenziale: Progetti, Chi sono e Contatti.

I progetti reali non sono ancora stati forniti. La galleria mostra **tre fotografie di prova**, indicate come “Spazio per un progetto / Immagine di prova”. Sono materiali dimostrativi separati dai lavori personali; aprirli mostra la foto e una spiegazione esplicita, senza clienti o risultati inventati. Le fotografie locali e le fonti sono documentate in `docs/IMMAGINI-DI-PROVA.md`.

## Avvio

Node.js 20.19+ e npm; Node.js 24 consigliato.

```sh
npm ci
npm run dev
```

Aprire http://localhost:3000. Per la produzione Next:

```sh
npm run build
npm start
```

Per l’export statico:

```sh
npm run build:static
npm run preview:static
```

Il risultato è in `out/`, l’anteprima su http://localhost:4173. Dopo una build statica eseguire nuovamente `npm run build` prima di usare `npm start`.

## Nuova esperienza

- **Intro**: cornice, ombra che anticipa il movimento, parete interna deformata da un vertex shader e pannelli incernierati. La camera arretra e rivela le altre cornici nello stesso canvas. Nessun gesto obbligatorio o enigma; salto sempre disponibile e limite temporale per evitare blocchi. Il passaggio è procedurale, non un video.
- **Panoramica**: titoli e categorie sono pulsanti HTML proiettati sotto le cornici. Questo livello è indipendente dal ciclo di vita del canvas, leggibile da tastiera e stabile al cambio di vista. Le cornici sono selezionabili anche mediante raycasting.
- **Scroll**: nativo, con ScrollTrigger che comunica il progresso alla scena. I pannelli cambiano disposizione, profondità e orientamento; il controllo “Vista d’insieme” ripristina la composizione.
- **Punto di vista**: trascinamento orizzontale limitato. Su touch lo scroll verticale resta disponibile.
- **Apertura**: la cornice scelta avanza, le altre si allontanano e la camera si avvicina. Poi si apre il dettaglio HTML. In modalità essenziale il dettaglio si apre direttamente. Chiusura con pulsante o Escape, ripristino del focus e della disposizione precedente.
- **Elenco**: alternativa HTML accessibile, disponibile anche senza WebGL. Nessun canvas aggiuntivo.
- **Mobile**: dimensioni, camera e didascalie dedicate. I primi tre spazi sono contemporaneamente visibili; l’allestimento di molti lavori andrà calibrato sul numero e sui formati reali.
- **Sicurezza dell’interazione**: timer di uscita dell’intro, fallback su errore shader/perdita WebGL, pausa a scheda nascosta, cleanup di geometrie/materiali e movimento ridotto. L’audio e i controlli sperimentali delle vecchie edizioni non vengono attivati nella nuova homepage.

L’intro vista viene ricordata nella scheda con il solo valore `one-man-gallery-intro: vista`. Lo storage è facoltativo. `/?intro=1` e “Rivedi l’introduzione” la riaprono.

## La mostra dentro il quadro

Dopo l’intro, continuare a scorrere: la camera rivela la cornice che racchiude la panoramica e il quadro centrale contiene due miniature dell’allestimento. La successiva vista obliqua separa le immagini in piani tridimensionali. “Vista frontale” ricostruisce prospetticamente l’immagine senza azzerare la scultura; “Vista d’insieme” riavvolge il percorso. Aprendo una cornice, gli altri pannelli si dispongono ai suoi lati. Chiusura, scroll e focus vengono ripristinati.

La ricorsione è finita e geometrica. Le superfici anamorfiche sono procedurali, non ricostruzioni fotogrammetriche. Dettagli e verifiche in `docs/MOSTRA-IMPOSSIBILE.md`.

## Inserire i tuoi lavori

Modificare `lib/gallery-data.ts`. L’array `galleryProjects` è intenzionalmente vuoto. `galleryPreviews` contiene le tre immagini dimostrative in `public/anteprime/`: modificarlo per sostituire le foto di prova. Appena si inseriscono progetti reali, le anteprime vengono sostituite automaticamente. Esempio di struttura da compilare con dati reali:

```ts
{
  id: "identificativo-del-lavoro",
  title: "Titolo del tuo progetto",
  category: "Categoria del lavoro",
  cover: "/lavori/copertina.jpg",
  description: "Il racconto del tuo progetto.",
  images: [{ src: "/lavori/dettaglio.jpg", alt: "Descrizione dell’immagine" }],
  technologies: ["Strumenti realmente utilizzati"],
  href: "https://indirizzo-reale-del-progetto.it"
}
```

Mettere i file immagine in `public/lavori/`; ottimizzarli prima della pubblicazione. `images`, `technologies` e `href` sono facoltativi. Il primo allestimento è calibrato su tre lavori: prima di pubblicarne molti, adattare disposizione e formati alle immagini effettive. Il dettaglio si apre nella pagina; le foto di prova non generano case study fittizi.

Biografia della nuova homepage: `galleryCopy` nello stesso file. Recapiti e social: `identity` in `lib/portfolio-data.ts`, ancora vuoti come concordato. Slogan, dominio e metadati: `lib/site-data.ts`. Non inserire email, certificazioni o esperienze non verificate.

## File principali

```text
app/page.tsx                            Nuova homepage
app/layout.tsx                          Metadati italiani e runtime
app/sitemap.ts                          Homepage attuale
components/gallery/
  GalleryExperience.tsx                 Navigazione, intro, scroll e stato della vista
  GalleryStage.tsx                      Camera, cornici, deformazione GLSL e raycasting
  GalleryDetail.tsx                     Dettaglio, dialogo e focus
  RecursiveFrames.tsx                   Cornici annidate e miniature geometriche
  AnamorphicSurface.tsx                 Superfici e shader di ricomposizione
  GalleryArrow.tsx                      Icona vettoriale condivisa
  gallery.css                           Direzione artistica e responsive
lib/gallery-data.ts                     Contenuti reali e immagini di prova separate
lib/gallery-motion.ts                   Canale volatile dei gesti e dello scroll
lib/gallery-choreography.ts             Partitura reversibile dei capitoli
lib/anamorphic-geometry.ts               Tasselli con identità stabile
lib/performance-store.ts                Qualità e capacità del dispositivo
components/reality/Runtime.tsx          Capacità, qualità e attivazione condizionale del vecchio motore
tests/gallery.spec.ts                   Verifiche della nuova esperienza
.openai/hosting.json                    Identità del sito esistente
```

I componenti e le pagine delle edizioni precedenti rimangono nel repository. I vecchi esperimenti non sono collegati dalla nuova homepage e non vengono inclusi nella sitemap; le route già esistenti rimangono apribili da un vecchio segnalibro. `docs/EDIZIONE-UNIVERSO.md` e `docs/LIVING-UNIVERSE.md` documentano l’edizione precedente. I suoi test restano come archivio; la configurazione Playwright attuale seleziona la nuova suite `gallery.spec.ts`.

## Verifiche

```sh
npm run typecheck
npm run lint
npm run build
npm run test:e2e
npm run build:static
npm run test:static
```

Il browser richiesto dai test è Chromium di Playwright. Installarlo solo se assente, con `npx playwright install chromium`. I test includono intro, un solo canvas, panoramica, scroll, drag, apertura, elenco, navigazione, replay, touch emulato, WebGL/storage negati, perdita del contesto e audit axe nella modalità essenziale. Gli esiti dell’edizione iniziale sono in `docs/GALLERIA.md`; i risultati aggiornati e i limiti della continuazione sono in `docs/MOSTRA-IMPOSSIBILE.md`.

## Pubblicazione

Sito esistente:

https://one-man-realta-7f26.one-man13.chatgpt.site

La visibilità resta privata: sul telefono accedere con lo stesso account ChatGPT proprietario. Non è un’anteprima LAN. La nuova versione sostituisce la homepage all’indirizzo esistente.

Per Sites: costruire `out/`, sincronizzare il commit sorgente e pubblicare un archivio contenente `out/` e `.openai/hosting.json` riferito a quel commit. `scripts/push-site.mjs` riceve le credenziali temporanee soltanto su stdin nascosto. Per Vercel usare la build Next normale; per un altro hosting statico usare `out/` con risoluzione delle route `/percorso` verso `/percorso.html`. Configurare `NEXT_PUBLIC_SITE_URL` per un dominio diverso e ricostruire.

## Limiti

È una prima versione dell’intro e della galleria, pronta per valutare la direzione artistica. Le fotografie di prova sono temporanee e saranno sostituite dai lavori reali. I passaggi sono animazioni procedurali controllate, non una simulazione fisica completa. Se il rendering è troppo lento o non disponibile, il sito mantiene il percorso HTML. La velocità dipende dal dispositivo: nessuna garanzia di prestazioni identiche. Smartphone fisici e Safari richiedono ancora collaudo; il touch automatizzato è emulato in Chromium. Gli audit automatici non sostituiscono una verifica con screen reader.

### Revisione: sfondo tipografico
La hero attiva usa `components/vice/TypographicBackdrop.tsx`, senza immagini di sfondo: lettere vettoriali astratte su viola scuro, parallasse mouse/touch, ritorno elastico e rispetto di reduced motion. Vedere `docs/SFONDO-TIPOGRAFICO.md`. Intro SC, tredici progetti, menu e sezioni successive conservati.

### Selezione editoriale dei progetti
La sezione progetti è ora `components/vice/EditorialProjects.tsx`: indice numerato e anteprima sticky desktop; dettagli espandibili mobile. Dati e copertine in `lib/restored-projects.ts`, stile in `editorial-projects.css`. Nessuna nuova dipendenza. Vedere `docs/PROGETTI-EDITORIALI.md`.

### Metodo creativo
Il secondo elenco di progetti è sostituito da `components/vice/CreativeMethod.tsx`: tre passaggi del processo creativo e invito ai contatti. Testi modificabili nel componente, stile in `creative-method.css`. Menu Metodo → #metodo; compatibilità con #indice preservata. Vedere `docs/METODO-CREATIVO.md`.
