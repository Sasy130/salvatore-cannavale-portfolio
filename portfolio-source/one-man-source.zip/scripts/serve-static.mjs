import http from "node:http";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
const root = path.resolve("out");
const port = Number(process.env.PORT ?? 4173);
const types = {
  ".html": "text/html; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".webp": "image/webp",
  ".jpg": "image/jpeg",
  ".json": "application/json",
  ".woff2": "font/woff2",
};
const exists = async (file) => {
  try {
    return (await stat(file)).isFile();
  } catch {
    return false;
  }
};
http
  .createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      const prefix = process.env.STATIC_ASSET_BASE ?? "";
      const localPath = prefix && pathname.startsWith(prefix + "/") ? pathname.slice(prefix.length) : pathname;
      const file = path.resolve(root, "." + localPath);
      if (file !== root && !file.startsWith(root + path.sep)) {
        res.writeHead(403);
        res.end();
        return;
      }
      let selected;
      for (const candidate of [
        file,
        file + ".html",
        path.join(file, "index.html"),
      ])
        if (await exists(candidate)) {
          selected = candidate;
          break;
        }
      const status = selected ? 200 : 404;
      selected ??= path.join(root, "404.html");
      if (!(await exists(selected))) {
        res.writeHead(404);
        res.end("Pagina non trovata.");
        return;
      }
      res.writeHead(status, {
        "Content-Type":
          types[path.extname(selected)] ?? "application/octet-stream",
        "Cache-Control": "no-store",
      });
      if (req.method === "HEAD") res.end();
      else createReadStream(selected).pipe(res);
    } catch {
      res.writeHead(400);
      res.end("Richiesta non valida.");
    }
  })
  .listen(port, "0.0.0.0", () =>
    console.log(`Anteprima statica: http://localhost:${port}`),
  );
