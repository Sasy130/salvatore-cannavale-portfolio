// Eseguire soltanto per la pubblicazione Sites. Le credenziali arrivano su stdin,
// restano in memoria e non vengono scritte né negli argomenti né nella configurazione Git.
import fs from "node:fs";
import { spawnSync } from "node:child_process";
const input = await new Promise((resolve, reject) => {
  let text = "";
  if (process.stdin.isTTY) process.stdin.setRawMode(true);
  process.stdout.write(
    "Pronto per le credenziali Sites su stdin (input nascosto).\n",
  );
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", (chunk) => {
    if (chunk.includes("\u0003")) process.exit(130);
    text += chunk;
    if (text.includes("\n")) {
      process.stdin.pause();
      if (process.stdin.isTTY) process.stdin.setRawMode(false);
      try {
        resolve(JSON.parse(text.trim()));
      } catch (error) {
        reject(error);
      }
    }
  });
});
const { credential } = input;
if (!credential?.remote_url || typeof credential.remote_url !== "string") throw new Error("Credenziali Sites non valide: manca il repository remoto. Nessuna configurazione Git modificata.");
process.stdin.destroy();
const manifest = JSON.parse(fs.readFileSync(".openai/hosting.json", "utf8"));
const env = { ...process.env, GIT_TERMINAL_PROMPT: "0" };
if (credential.auth_mode === "http_extra_header") {
  const index = Number(env.GIT_CONFIG_COUNT ?? 0);
  env.GIT_CONFIG_COUNT = String(index + 1);
  env[`GIT_CONFIG_KEY_${index}`] = "http.extraHeader";
  env[`GIT_CONFIG_VALUE_${index}`] =
    `Authorization: Bearer ${credential.token}`;
}
const redact = (text) =>
  credential.token ? text.replaceAll(credential.token, "[omesso]") : text;
const git = (args, allowFailure = false) => {
  const result = spawnSync("git", args, { encoding: "utf8", env });
  if (result.status && !allowFailure)
    throw new Error(
      redact(result.stderr || result.stdout || "Operazione Git non riuscita."),
    );
  return result;
};
const existing = fs.existsSync(".git");
if (!existing) git(["init", "-b", credential.branch ?? "main"]);
git(["remote", "remove", "sites"], true);
git(["remote", "add", "sites", credential.remote_url]);
const remote = git([
  "ls-remote",
  "sites",
  `refs/heads/${credential.branch ?? "main"}`,
]);
if (!existing && remote.stdout.trim()) {
  git(["fetch", "sites", credential.branch ?? "main"]);
  git(["reset", "--mixed", "FETCH_HEAD"]);
}
git(["add", "-u"]);
const files = [
  "app",
  "components",
  "lib",
  "public",
  "scripts",
  "tests",
  "docs",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "next-env.d.ts",
  "postcss.config.mjs",
  "next.config.ts",
  "eslint.config.mjs",
  "playwright.config.ts",
  "README.md",
  "AGENTS.md",
  ".gitignore",
  ".openai/hosting.json",
].filter((file) => fs.existsSync(file));
git(["add", "--", ...files]);
if (git(["diff", "--cached", "--quiet"], true).status !== 0)
  git([
    "-c",
    "user.name=Codex",
    "-c",
    "user.email=codex@localhost",
    "commit",
    "-m",
    "Aggiunge immagini di prova alla galleria ONE MAN",
  ]);
const sha = git(["rev-parse", "HEAD"]).stdout.trim();
git(["push", "sites", `HEAD:${credential.branch ?? "main"}`]);
console.log(
  JSON.stringify({ project_id: manifest.project_id, commit_sha: sha }),
);
