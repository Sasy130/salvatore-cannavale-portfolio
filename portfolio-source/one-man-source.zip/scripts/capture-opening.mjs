import {chromium,expect} from '@playwright/test';
import {mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
const origin=process.env.PRESENTATION_URL??'https://www.salvatorecannavale.it';
const output=path.resolve('consegna/ONE-MAN-apertura-neon.mp4');mkdirSync('consegna/video-source',{recursive:true});
const browser=await chromium.launch({headless:true,...(process.env.HTTPS_PROXY?{proxy:{server:process.env.HTTPS_PROXY}}:{})});
let result;
try{
 const context=await browser.newContext({viewport:{width:432,height:768},isMobile:true,hasTouch:true,recordVideo:{dir:'consegna/video-source',size:{width:432,height:768}}});
 const start=Date.now(),page=await context.newPage(),video=page.video();
 await page.goto(origin+'/?intro=1',{waitUntil:'domcontentloaded',timeout:45000});
 await expect(page.locator('.cp-intro')).toBeVisible({timeout:15000});const trim=Math.max(0,(Date.now()-start)/1000-.1);
 await expect(page.locator('.cp-intro')).toHaveCount(0,{timeout:10000});
 await page.waitForTimeout(850);
 await page.locator('#progetti').evaluate(el=>{const r=el.getBoundingClientRect();scrollTo({top:scrollY+r.top+(r.height-innerHeight)*.09,behavior:'smooth'});});
 await page.waitForTimeout(1800);
 await page.locator('#progetti').evaluate(el=>{const r=el.getBoundingClientRect();scrollTo({top:scrollY+r.top+(r.height-innerHeight)*.28,behavior:'smooth'});});
 await page.waitForTimeout(1500);
 await page.getByRole('button',{name:'Menu',exact:true}).tap();await expect(page.locator('.cp-navigation')).toBeVisible();await page.waitForTimeout(1300);
 await page.getByRole('button',{name:'Chiudi',exact:false}).tap();await page.waitForTimeout(750);
 await context.close();const source=await video.path();
 const command=spawnSync('ffmpeg',['-y','-ss',String(trim),'-i',source,'-vf','scale=720:1280:flags=lanczos,setsar=1','-an','-c:v','libx264','-preset','fast','-crf','20','-movflags','+faststart',output],{encoding:'utf8'});
 if(command.status!==0)throw Error(command.stderr.slice(-1500));result={file:output,format:'MP4 verticale 720 × 1280, senza audio'};
}finally{await browser.close();}
console.log(JSON.stringify(result));
