import {test,expect} from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
test('manifesto mobile: navigazione, presa e apertura',async({page})=>{
 await page.setViewportSize({width:390,height:844});await page.goto('/');
 const skip=page.getByRole('button',{name:'Salta introduzione'});if(await skip.isVisible())await skip.click();
 await expect(page.locator('.m-work')).toHaveCount(3);
 await page.getByRole('button',{name:'Menu',exact:false}).first().click();
 await page.getByRole('link',{name:'Progetti ↗',exact:true}).click();
 const handle=page.getByRole('button',{name:'Deforma l’immagine 01'});await handle.scrollIntoViewIfNeeded();
 await handle.focus();await page.keyboard.down('ArrowRight');await expect(page.locator('.m-work').first()).toHaveAttribute('style',/pull-x/);await page.keyboard.up('ArrowRight');
 await page.locator('.m-work-caption button').first().click();await expect(page.getByRole('dialog')).toBeVisible();
 await expect(page.getByRole('dialog')).toContainText('IMMAGINE DI PROVA');
 await page.keyboard.press('Escape');await expect(page.locator('.gallery-detail')).toHaveCount(0);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
});
test('movimento ridotto: anteprime, dialogo e accessibilità',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');
 await expect(page.locator('.m-intro')).toHaveCount(0);
 await page.locator('.m-work-caption button').first().click();await expect(page.locator('.gallery-detail')).toBeVisible();
 await expect(page.locator('.m-flight')).toHaveCount(0);
 const report=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();expect(report.violations).toEqual([]);
});
