import { test, expect, type Page } from "@playwright/test";
const gpuErrors=new WeakMap<Page,string[]>();
test.beforeEach(async ({page})=>{
  const errors:string[]=[];gpuErrors.set(page,errors);
  page.on("console",message=>{if(message.type()==="error" && /Shader Error|WebGLProgram|GL_INVALID/.test(message.text()))errors.push(message.text());});
});
test("M2: un solo renderer fra intro, homepage e stanza segreta", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.locator("canvas")).toHaveAttribute(
    "data-scene-ready",
    "true",
  );
  const canvas = await page.locator("canvas").elementHandle();
  await page.getByRole("button", { name: "Salta introduzione" }).click();
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  expect(await canvas!.evaluate((el) => el.isConnected)).toBe(true);
  await expect(page.locator("canvas")).toHaveCount(1);
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .click();
  await page.getByText("C’è qualcosa oltre il visibile.").click();
  await page.getByRole("button", { name: "Apri la stanza 07" }).click();
  await expect(page.locator(".secret-art canvas")).toBeVisible();
  expect(await canvas!.evaluate((el) => el.isConnected)).toBe(true);
  await expect(page.locator("canvas")).toHaveCount(1);
  await page.getByRole("button", { name: "Torna al portfolio" }).click();
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  expect(await canvas!.evaluate((el) => el.isConnected)).toBe(true);
  expect(errors).toEqual([]);
});

test("M3: architettura reale e camera collegate alle sezioni principali", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/#contenuto");
  const canvas = page.locator(".world-layer canvas");
  await page.getByRole("button", {name:"CONTROLLA LA REALTÀ",exact:true}).click();
  await page.getByLabel("Qualità visiva").selectOption("low");
  await page.getByRole("button",{name:"Disattiva il controllo della realtà"}).click();
  await expect(page.locator("html")).toHaveAttribute("data-quality","low");
  await expect.poll(()=>canvas.evaluate(el=>(el as HTMLCanvasElement).width)).toBe(1440);
  await expect(canvas).toHaveAttribute("data-architecture-rooms", "6");
  expect(
    Number(await canvas.getAttribute("data-architecture-parts")),
  ).toBeGreaterThan(30);
  await expect(canvas).toHaveAttribute("data-scene-ready", "true");
  await expect.poll(async () => Number(await canvas.getAttribute("data-gpu-samples"))).toBeGreaterThanOrEqual(2);
  const positions = new Set<string>();
  for (const [label, id] of [
    ["Home", "contenuto"],
    ["Chi sono", "chi-sono"],
    ["Progetti", "progetti"],
    ["Competenze", "competenze"],
    ["Contatti", "contatti"],
  ]) {
    await page
      .getByRole("navigation", { name: "Navigazione principale" })
      .getByRole("link", { name: label, exact: true })
      .click();
    const section = page.locator(id === "contenuto" ? ".portfolio-hero" : "#" + id);
    await expect.poll(()=>section.evaluate(el=>{const r=el.getBoundingClientRect();return r.top<innerHeight && r.bottom>0;})).toBe(true);
    await page.screenshot({path:`test-results/camera-${id}.png`});
    await expect(canvas).toHaveAttribute("data-camera-area", id);
    await page.waitForTimeout(300);
    positions.add((await canvas.getAttribute("data-camera-position"))!);
  }
  expect(positions.size).toBe(5);
  await page.screenshot({ path: "test-results/m3-architettura.png" });
  expect(errors).toEqual([]);
});

test("M4: cinque trasformazioni reali dello stesso nucleo", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error" && /Shader Error|WebGLProgram/.test(m.text()))
      errors.push(m.text());
  });
  await page.goto("/#universo");
  await expect(page.locator("#universo")).toBeInViewport();
  const canvas = page.locator(".world-layer canvas");
  await expect(canvas).toBeVisible();
  await expect
    .poll(async () => Number(await canvas.getAttribute("data-matter-faces")))
    .toBeGreaterThan(100);
  for (const [label, state] of [
    ["Monolite", "MONOLITH"],
    ["Materia liquida", "LIQUID"],
    ["Frammenti", "FRACTURED"],
    ["Particelle", "PARTICLES"],
    ["ONE MAN", "TYPOGRAPHY"],
  ]) {
    await page
      .getByRole("group", { name: "Forma del nucleo" })
      .getByRole("button", { name: label, exact: true })
      .click();
    await expect(canvas).toHaveAttribute("data-matter-state", state);
    await page.waitForTimeout(200);
  }
  await page.screenshot({ path: "test-results/m4-materia.png" });
  await page.getByRole("button", { name: "Ricompone il nucleo" }).click();
  await expect(canvas).toHaveAttribute("data-matter-state", "MONOLITH");
  expect(errors).toEqual([]);
});

test.afterEach(async ({ page }, info) => {
  if(info.status === info.expectedStatus)expect(gpuErrors.get(page)??[]).toEqual([]);
  if (info.status !== info.expectedStatus)
    console.log(
      "Stato renderer",
      JSON.stringify(await page.evaluate(() => ({
        portal: document.querySelector('[data-portal-state="navigating"], [data-portal-state="opening"]')?.outerHTML.slice(0,200),
        scroll: window.scrollY,
        hash: location.hash,
        sections: Array.from(document.querySelectorAll(".portfolio > section")).map(el=>({id:el.id,top:el.getBoundingClientRect().top})),
        hidden: document.hidden,
        time: performance.now(),
        quality: document.documentElement.dataset.quality,
        canvas: Array.from(document.querySelectorAll("canvas")).map((c) => ({
          data: { ...c.dataset },
          parent: c.parentElement?.parentElement?.parentElement?.className,
        })),
        selection: Array.from(
          document.querySelectorAll(".matter-controls [aria-pressed=true]"),
        ).map((e) => e.textContent),
      }))),
    );
});

test("M5: mappa condivisa, rotazione, zoom, raycasting e alternativa HTML", async ({page}) => {
  const errors:string[]=[]; page.on("pageerror",e=>errors.push(e.message));
  await page.goto('/#universo');
  const canvas=page.locator('.world-layer canvas');
  await expect(canvas).toHaveAttribute('data-scene-ready','true');
  const handle=await canvas.elementHandle();
  await page.getByRole('button',{name:'CONTROLLA LA REALTÀ',exact:true}).click();
  await page.getByLabel('Qualità visiva').selectOption('medium');
  await page.getByRole('button',{name:'Esplora l’universo',exact:true}).click();
  await expect(page.getByRole('dialog',{name:'ESPLORA L’UNIVERSO.'})).toBeVisible();
  await expect(canvas).toHaveAttribute('data-camera-area','mappa');
  const first=await canvas.getAttribute('data-camera-position');
  await page.getByRole('button',{name:'Ruota a destra'}).click();
  await page.getByRole('button',{name:'Ingrandisci +'}).click();
  await expect.poll(()=>canvas.getAttribute('data-camera-position')).not.toBe(first);
  await page.getByRole('button',{name:'Ripristina visuale'}).click();
  // Riproduce la discesa di qualità durante la mappa attraverso il controllo esistente.
  await page.evaluate(()=>{const select=document.getElementById('render-quality') as HTMLSelectElement;select.value='low';select.dispatchEvent(new Event('change',{bubbles:true}));});
  await expect(page.locator('html')).toHaveAttribute('data-quality','low');
  await expect.poll(()=>canvas.evaluate(el=>(el as HTMLCanvasElement).width)).toBe(1440);
  await page.waitForTimeout(2400);
  const rooms=JSON.parse((await canvas.getAttribute('data-map-rooms'))!) as {id:string;x:number;y:number}[];
  const target=rooms.find(r=>r.id==='progetti')!;
  await page.mouse.click(target.x,target.y);
  await expect(page.getByRole('dialog')).toHaveCount(0);
  await expect(page).toHaveURL(/#progetti$/);
  await expect(page.locator('#progetti')).toBeInViewport();
  expect(await handle!.evaluate(el=>el.isConnected)).toBe(true);
  await page.locator('#universo').scrollIntoViewIfNeeded();
  await page.getByRole('button',{name:'Esplora l’universo',exact:true}).click();
  await page.getByRole('navigation',{name:'Stanze dell’universo'}).getByRole('link',{name:/Contatti/}).click();
  await expect(page).toHaveURL(/#contatti$/);
  await expect(page.locator('#contatti')).toBeInViewport();
  expect(errors).toEqual([]);
});

test("M6: portale geometrico, URL progetto e cronologia browser", async ({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/#progetti');
  await page.getByRole('button',{name:'CONTROLLA LA REALTÀ',exact:true}).click();
  await page.getByRole('combobox',{name:'Qualità visiva'}).selectOption('medium');
  await page.getByRole('button',{name:'Disattiva il controllo della realtà'}).click();
  const canvas=page.locator('canvas');
  await expect(canvas).toHaveAttribute('data-scene-ready','true');
  await page.evaluate(()=>{
    const link=document.querySelector<HTMLAnchorElement>('[aria-label="Esplora La stanza impossibile"]');
    link?.click();window.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape'}));
  });
  await expect(page.locator('.portal-world-stage')).toHaveCount(0);
  await expect(page.locator('html')).not.toHaveAttribute('data-portal-flight','active');
  await page.getByRole('link',{name:'Esplora La stanza impossibile'}).click();
  await expect(canvas).toHaveAttribute('data-project-gate','la-stanza-impossibile');
  await expect.poll(async()=>Number(await canvas.getAttribute('data-portal-progress'))).toBeGreaterThan(.2);
  await expect(page).toHaveURL(/\/progetti\/la-stanza-impossibile\/?$/, {timeout:15000});
  await expect(page.getByRole('heading',{level:1})).toHaveText('La stanza impossibile');
  await page.goBack(); await expect(page).toHaveURL(/#progetti$/);
  await page.goForward(); await expect(page).toHaveURL(/la-stanza-impossibile\/?$/);
  const next=page.getByRole('link',{name:/Prossimo universo Orbita zero/});
  await next.scrollIntoViewIfNeeded(); await next.click();
  await expect(page.locator('.portal-world-stage canvas')).toBeVisible();
  await expect(page.locator('.portal-world-stage canvas')).toHaveAttribute('data-project-gate','orbita-zero');
  await expect(page).toHaveURL(/orbita-zero\/?$/);
  expect(errors).toEqual([]);
});

test("M7: titolo semantico e tipografia volumetrica reversibile", async ({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/#contenuto');
  const title=page.getByRole('heading',{level:1,name:'ONE MAN'});
  await expect(title).toBeVisible();
  const canvas=page.locator('.world-layer canvas');
  await expect(canvas).toHaveAttribute('data-scene-ready','true');
  await page.getByRole('button',{name:'Tocca la tipografia · frammenta ONE MAN'}).click();
  await expect(canvas).toHaveAttribute('data-typography-active','true');
  expect(Number(await canvas.getAttribute('data-typography-pieces'))).toBeGreaterThan(100);
  await page.mouse.move(920,450);
  await page.screenshot({path:'test-results/m7-tipografia.png'});
  await expect(canvas).toHaveAttribute('data-typography-active','false',{timeout:12000});
  await expect(title).toBeVisible();
  await page.getByRole('button',{name:'Frammenta ONE MAN',exact:true}).click();
  await expect(canvas).toHaveAttribute('data-typography-active','true');
  await page.getByRole('button',{name:'Ripristina tutto'}).click();
  await expect(canvas).toHaveAttribute('data-typography-active','false');
  expect(errors).toEqual([]);
});

test("M8: memoria locale, dettagli del nucleo e storage facoltativo", async ({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/#universo');
  const shapes=page.getByRole('group',{name:'Forma del nucleo'});
  await shapes.getByRole('button',{name:'Materia liquida'}).click();
  await shapes.getByRole('button',{name:'Particelle',exact:true}).click();
  await page.getByRole('button',{name:'CONTROLLA LA REALTÀ',exact:true}).click();
  await page.getByRole('button',{name:'Disattiva il controllo della realtà'}).click();
  await page.getByRole('button',{name:'Esplora l’universo',exact:true}).click();
  await page.getByRole('button',{name:'Ruota a destra'}).click();
  await page.getByRole('button',{name:'Torna al portfolio'}).click();
  await expect(page.locator('.memory-traces')).toContainText('3 DI 3');
  const memory=await page.evaluate(()=>JSON.parse(sessionStorage.getItem('one-man-universe-v1')!));
  expect(memory.matterForms).toEqual(['LIQUID','PARTICLES']);expect(memory.mapUsed).toBe(true);expect(memory.realityUsed).toBe(true);
  expect(Object.keys(memory).sort()).toEqual(['version','introSeen','introCompleted','projects','realityUsed','portals','mapUsed','matterForms','secretUnlocked','finaleSeen'].sort());
  await expect.poll(async()=>Number(await page.locator('.world-layer canvas').getAttribute('data-visual-memory'))).toBeGreaterThan(0);
  await page.goto('/');
  await expect(page.locator('#portfolio-title')).toBeVisible();
  await page.getByRole('button',{name:'Rivivi l’introduzione'}).click();
  await expect(page.locator('.intro')).toBeVisible();
  expect(errors).toEqual([]);
});

test("M8: esperienza utilizzabile se sessionStorage è negato",async ({page})=>{
  await page.addInitScript(()=>{Storage.prototype.getItem=()=>{throw new Error('Storage negato');};Storage.prototype.setItem=()=>{throw new Error('Storage negato');};});
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/#universo');
  await page.getByRole('group',{name:'Forma del nucleo'}).getByRole('button',{name:'Frammenti',exact:true}).click();
  await expect(page.locator('.world-layer canvas')).toHaveAttribute('data-matter-state','FRACTURED');
  await page.getByRole('button',{name:'Esplora l’universo',exact:true}).click();
  await page.getByRole('navigation',{name:'Stanze dell’universo'}).getByRole('link',{name:/Chi sono/}).click();
  await expect(page).toHaveURL(/#chi-sono$/);expect(errors).toEqual([]);
});

test("M9: finale sbloccabile, trasformazione reale, replay e contatti",async ({page})=>{
  const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('/#universo');
  await expect(page.getByRole('button',{name:'Il nucleo attende tre tracce'})).toBeDisabled();
  await page.getByRole('group',{name:'Forma del nucleo'}).getByRole('button',{name:'Materia liquida'}).click();
  await page.getByRole('group',{name:'Forma del nucleo'}).getByRole('button',{name:'Particelle',exact:true}).click();
  await page.getByRole('button',{name:'CONTROLLA LA REALTÀ',exact:true}).click();
  await page.getByRole('button',{name:'Disattiva il controllo della realtà'}).click();
  await page.getByRole('button',{name:'Esplora l’universo',exact:true}).click();
  await page.getByRole('button',{name:'Ruota a destra'}).click();
  await page.getByRole('button',{name:'Torna al portfolio'}).click();
  await page.getByRole('button',{name:'Entra nel nucleo'}).click();
  const dialog=page.getByRole('dialog',{name:'IL NUCLEO.'});
  const canvas=page.locator('.world-layer canvas');
  await expect(dialog).toContainText('HAI ATTRAVERSATO IL MIO UNIVERSO.');
  await expect(canvas).toHaveAttribute('data-finale-step','0');
  await expect(canvas).toHaveAttribute('data-finale-geometry','60');
  await dialog.getByRole('button',{name:'Riscrivi la materia'}).click();
  await expect(dialog).toContainText('ORA IMMAGINA COSA POSSIAMO CREARE INSIEME.');
  await expect(canvas).toHaveAttribute('data-matter-state','FRACTURED');
  await dialog.getByRole('button',{name:'Ricomponi l’universo'}).click();
  await expect(dialog).toContainText('ONE MAN — LA REALTÀ SI RISCRIVE.');
  await expect(canvas).toHaveAttribute('data-matter-state','TYPOGRAPHY');
  await expect.poll(async()=>Number((await canvas.getAttribute('data-matter-weights'))?.split(',')[3]??0),{timeout:15000}).toBeGreaterThan(.995);
  await page.screenshot({path:'test-results/m9-finale.png'});
  await dialog.getByRole('button',{name:'Rivedi la trasformazione'}).click();
  await expect(canvas).toHaveAttribute('data-finale-step','0');
  await dialog.getByRole('link',{name:'Creiamo il prossimo universo'}).click();
  await expect(page).toHaveURL(/#contatti$/);await expect(page.locator('#contatti')).toBeInViewport();
  await page.locator('#universo').scrollIntoViewIfNeeded();
  await page.getByRole('button',{name:'Rivedi il nucleo'}).click();
  await page.keyboard.press('Escape'); await expect(dialog).toHaveCount(0);
  await expect(page.getByRole('button',{name:'Rivedi il nucleo'})).toBeFocused();
  expect(errors).toEqual([]);
});
