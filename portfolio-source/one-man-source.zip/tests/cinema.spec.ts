import {test,expect} from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import {projects} from '../lib/restored-projects';
test.beforeEach(async({page})=>{await page.addInitScript(()=>sessionStorage.setItem('one-man-cinema-coast','vista'));});
test('cinema: progetti originali, menu e anteprima interattiva',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/');
 await expect(page.locator('.cp-header>a')).toHaveText('ONE MAN');await expect(page.locator('.cp-hero img,.cp-entry img')).toHaveCount(0);await expect(page.locator('.cp-hero .cp-brand-art')).toHaveCount(1);await expect(page.locator('.cp-index-item')).toHaveCount(projects.length);await expect(page.locator('.cp-index-item').first()).toContainText(projects[0].name);
 await page.getByRole('button',{name:'Menu',exact:true}).click();const nav=page.getByRole('dialog',{name:'Menu principale'});await expect(nav).toBeVisible();await expect(nav.getByRole('link',{name:/Progetti/})).toBeVisible();await page.keyboard.press('Escape');await expect(nav).toHaveCount(0);
 await page.locator('#progetti').evaluate((el,progress)=>{const r=el.getBoundingClientRect();scrollTo({top:scrollY+r.top+(r.height-innerHeight)*progress,behavior:'instant'});},projects.findIndex(p=>p.name==='VÉRA')/(projects.length-1));
 await expect(page.locator('.cp-stage-bottom>p')).toContainText('VÉRA');
 await expect(page.locator('.cinema')).toHaveAttribute('data-gpu','true');await expect(page.locator('canvas[data-warp-cursor]')).toHaveCount(1);
 await expect.poll(async()=>Number(await page.locator('canvas').getAttribute('data-warp-cursor'))).toBeGreaterThan(3);
 await page.screenshot({path:'test-results/cinema-surface.png'});
 await page.route('**/demos/velar/',route=>route.fulfill({contentType:'text/html',body:'<h1>Demo di verifica</h1>'}));
 await page.locator('.cp-index-item').filter({has:page.getByRole('heading',{name:'VELAR',exact:true})}).click();const dialog=page.getByRole('dialog',{name:'VELAR',exact:true});await expect(dialog).toBeVisible();await expect(dialog).toContainText('Progetto dimostrativo');
 await dialog.getByRole('button',{name:'Anteprima interattiva'}).click();await expect(dialog.frameLocator('iframe').getByRole('heading')).toHaveText('Demo di verifica');
 await dialog.getByRole('button',{name:'Copertina',exact:true}).click();await expect(dialog.locator('iframe')).toHaveCount(0);await dialog.getByRole('button',{name:'Chiudi progetto'}).click();await expect(dialog).toHaveCount(0);
 await expect(page.locator('.cp-index-item').filter({has:page.getByRole('heading',{name:'VELAR',exact:true})})).toBeFocused();expect(errors).toEqual([]);await page.screenshot({path:'test-results/cinema-desktop.png',fullPage:false});
});
test('cinema: mobile touch e navigazione senza overflow',async({browser})=>{
 const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const page=await context.newPage();await page.addInitScript(()=>sessionStorage.setItem('one-man-cinema-coast','vista'));await page.goto('/');
 await page.locator('#progetti').evaluate(el=>el.scrollIntoView({behavior:'instant'}));const handle=page.getByRole('button',{name:'Inclina le anteprime'});await handle.scrollIntoViewIfNeeded();
 const rect=await handle.boundingBox();expect(rect).toBeTruthy();const x=rect!.x+rect!.width/2,y=rect!.y+rect!.height/2;const session=await context.newCDPSession(page);
 const pull=()=>page.locator('.cp-stage').evaluate(el=>Number((el as HTMLElement).style.getPropertyValue('--drag-x')));
 await session.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y,id:1}]});
 await session.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+45,y:y-20,id:1}]});
 await expect.poll(pull).toBeGreaterThan(.2);
 await session.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 await expect.poll(async()=>Math.abs(await pull())).toBeLessThan(.01);
 expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await page.screenshot({path:'test-results/cinema-mobile.png'});
 await page.getByRole('button',{name:'Menu',exact:true}).tap();await expect(page.locator('.cp-navigation')).toBeVisible();await page.getByRole('dialog',{name:'Menu principale'}).getByRole('link',{name:/Contatti/}).tap();await expect(page.locator('.cp-navigation')).toHaveCount(0);await expect(page).toHaveURL(/#contatti$/);await context.close();
});
test('cinema: reduced motion e accessibilità',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/');await expect(page.locator('.cp-intro')).toHaveCount(0);await expect(page.locator('.cp-card')).toHaveCount(projects.length);
 const audit=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();expect(audit.violations).toEqual([]);
 await page.getByRole('button',{name:'Menu',exact:true}).click();const menu=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();expect(menu.violations).toEqual([]);await page.keyboard.press('Escape');
});
test('cinema: introduzione, replay e cinque dimensioni dello schermo',async({page})=>{
 await page.addInitScript(()=>sessionStorage.removeItem('one-man-cinema-coast'));await page.goto('/');
 await expect(page.getByRole('button',{name:'Salta introduzione'})).toBeVisible();await expect(page.locator('.cp-intro img')).toHaveCount(0);await expect(page.locator('.cp-intro .cp-brand-art')).toHaveCount(3);await page.keyboard.press('Escape');await expect(page.locator('.cp-intro')).toHaveCount(0);
 await page.getByRole('button',{name:'Rivedi l’introduzione'}).click();await expect(page.locator('.cp-intro')).toBeVisible();await page.getByRole('button',{name:'Salta introduzione'}).click();await expect(page.locator('.cp-intro')).toHaveCount(0);
 for(const [width,height] of [[320,740],[390,844],[768,1024],[844,390],[1440,1000]]){
  await page.setViewportSize({width,height});await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));
  await expect.poll(()=>page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await expect(page.getByRole('button',{name:'Menu',exact:true})).toBeVisible();
  const title=await page.locator('.cp-title').boundingBox(),photo=await page.locator('.cp-hero-image').boundingBox();
  expect(title&&photo).toBeTruthy();expect(title!.x+title!.width<=photo!.x+1||title!.y+title!.height<=photo!.y+1).toBe(true);
 }
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'test-results/cinema-hero-mobile.png'});
 await page.getByRole('button',{name:'Menu',exact:true}).click();
 await expect.poll(()=>page.locator('.cp-nav-link').first().evaluate(el=>Math.abs(new DOMMatrix(getComputedStyle(el).transform).m42))).toBeLessThan(.1);
 await page.screenshot({path:'test-results/cinema-menu-mobile.png'});
 await page.keyboard.press('Escape');
});

test('cinema: WebGL negato mantiene i progetti accessibili',async({page})=>{
 await page.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(this:HTMLCanvasElement,kind,...args){if(kind==='webgl'||kind==='webgl2')return null;return Reflect.apply(original,this,[kind,...args]);} as typeof original;});
 await page.goto('/');await expect(page.locator('canvas')).toHaveCount(0);await expect(page.locator('.cp-index-item')).toHaveCount(projects.length);await page.locator('.cp-index-item').filter({has:page.getByRole('heading',{name:'VELAR',exact:true})}).click();await expect(page.getByRole('dialog',{name:'VELAR',exact:true})).toBeVisible();
});

test('cinema: ingresso solare, pannelli in prospettiva e comandi dei progetti',async({page})=>{
 await page.goto('/');
 const seek=async(selector:string,fraction:number)=>page.locator(selector).evaluate((el,f)=>{const r=el.getBoundingClientRect();scrollTo({top:scrollY+r.top+(r.height-innerHeight)*f,behavior:'instant'});},fraction);
 await expect(page.locator('.cp-entry')).toHaveAttribute('data-animated','true');await seek('#universi',.6);
 await expect.poll(()=>page.locator('.cp-entry-sun').evaluate(el=>new DOMMatrix(getComputedStyle(el).transform).a)).toBeGreaterThan(1.2);
 await page.screenshot({path:'test-results/cinema-entrance.png'});
 await seek('#progetti',.5/(projects.length-1));await expect(page.locator('canvas[data-reel-panels="2"]')).toHaveCount(1);await expect.poll(async()=>Number(await page.locator('canvas').getAttribute('data-reel-phase'))).toBeGreaterThan(.35);
 await page.screenshot({path:'test-results/cinema-reel-transition.png'});
 for(const index of [0,5,projects.length-1]){await seek('#progetti',index/(projects.length-1));await expect(page.locator('.cp-stage-bottom>p')).toContainText(projects[index].name);await expect(page.locator('.cp-card:not([aria-hidden="true"])')).toHaveCount(1);}
 await expect(page.getByRole('button',{name:'Progetto successivo',exact:true})).toBeDisabled();
 await page.getByRole('button',{name:'Progetto precedente',exact:true}).click();await expect(page.locator('.cp-stage-bottom>p')).toContainText(projects[projects.length-2].name);
 await page.getByRole('button',{name:'Progetto successivo',exact:true}).click();await expect(page.locator('.cp-stage-bottom>p')).toContainText(projects[projects.length-1].name);
});

test('cinema: selettore delle anteprime su telefono e composizione leggibile',async({browser})=>{
 const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const page=await context.newPage();await page.addInitScript(()=>sessionStorage.setItem('one-man-cinema-coast','vista'));await page.goto('/');
 await page.locator('#progetti').evaluate(el=>el.scrollIntoView({behavior:'instant'}));
 const rail=page.getByRole('navigation',{name:'Scegli un progetto'});await expect(rail.getByRole('button')).toHaveCount(projects.length);
 await rail.getByRole('button',{name:'Mostra VÉRA',exact:true}).tap();await expect(rail.getByRole('button',{name:'Mostra VÉRA',exact:true})).toHaveAttribute('aria-pressed','true');await expect(page.locator('.cp-stage-bottom>p')).toContainText('VÉRA');
 const card=page.locator('.cp-card:not([aria-hidden="true"])');const image=await card.locator('.cp-project-image').boundingBox(),caption=await card.locator('.cp-project-caption').boundingBox();expect(image&&caption).toBeTruthy();expect(image!.y+image!.height<=caption!.y+1).toBe(true);await expect(card.getByRole('link',{name:'Esplora VÉRA'})).toBeVisible();
 await expect(page.locator('.cinema')).toHaveAttribute('data-gpu','true');await page.screenshot({path:'test-results/cinema-studio-mobile.png'});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await context.close();
});
