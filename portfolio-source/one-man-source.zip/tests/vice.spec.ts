import {test,expect} from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import {projects} from '../lib/restored-projects';
test.beforeEach(async({page})=>{await page.addInitScript(()=>sessionStorage.setItem('one-man-signature','vista'));});
test('vice: introduzione personale, apertura, salto e replay',async({page})=>{
 await page.goto('/?intro=1');const intro=page.getByRole('dialog',{name:'Introduzione di Salvatore Cannavale'});await expect(intro).toBeVisible();await expect(intro.locator('mask text')).toHaveText('SC');await expect(intro.locator('.vc-signature-portal')).toHaveCount(1);await intro.getByRole('button',{name:'Entra subito'}).click({noWaitAfter:true,timeout:4000});await expect(intro).toHaveCount(0,{timeout:7000});await expect(page.getByRole('heading',{name:/Salvatore Cannavale/})).toBeAttached();
 await page.getByRole('button',{name:'Rivedi l’apertura'}).click();await expect(intro).toBeVisible();await page.keyboard.press('Escape');await expect(intro).toHaveCount(0);await page.getByRole('button',{name:'Rivedi l’apertura'}).click();await intro.getByRole('button',{name:'Salta introduzione'}).click();await expect(intro).toHaveCount(0);
});
test('vice: tredici lavori, demo, menu e ritorno del focus',async({page})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/');await expect(page.locator('.vc-work')).toHaveCount(projects.length);await expect(page.locator('.vc-index nav>a')).toHaveCount(projects.length);await expect(page.locator('.vc-hero img')).toHaveCount(0);await expect(page.locator('.vc-hero-photo')).toHaveCSS('background-image',/one-man-vice-art\.webp/);
 await page.getByRole('button',{name:'Menu',exact:true}).click();const nav=page.getByRole('dialog',{name:'Menu principale'});await expect(nav).toBeVisible();await page.keyboard.press('Escape');await expect(nav).toHaveCount(0);
 await page.route('**/demos/velar/',r=>r.fulfill({contentType:'text/html',body:'<h1>Demo di verifica</h1>'}));const link=page.locator('.vc-work').filter({has:page.getByRole('heading',{name:'VELAR',exact:true})});await link.click();const dialog=page.getByRole('dialog',{name:'VELAR',exact:true});await expect(dialog).toBeVisible();await dialog.getByRole('button',{name:'Anteprima interattiva'}).click();await expect(dialog.frameLocator('iframe').getByRole('heading')).toHaveText('Demo di verifica');await dialog.getByRole('button',{name:'Chiudi progetto'}).click();await expect(dialog).toHaveCount(0);await expect(link).toBeFocused();expect(errors).toEqual([]);
});
test('vice: mobile touch, menu e progetti senza riquadri vuoti',async({browser})=>{
 const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const page=await context.newPage();await page.addInitScript(()=>sessionStorage.setItem('one-man-signature','vista'));await page.goto('/');await page.screenshot({path:'test-results/vice-hero-mobile.png'});
 await page.getByRole('link',{name:'Esplora i progetti'}).tap();await expect.poll(()=>page.locator('#progetti').evaluate(el=>Math.abs(el.getBoundingClientRect().top-90))).toBeLessThan(5);await expect.poll(async()=>Math.abs((await page.locator('.vc-header').boundingBox())!.y)).toBeLessThan(1);const first=page.locator('.vc-work').first();await expect(first).toBeVisible();await expect.poll(()=>first.locator('img').evaluate(el=>(el as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);await page.screenshot({path:'test-results/vice-work-mobile.png'});await first.tap();await expect(page.getByRole('dialog',{name:projects[0].name,exact:true})).toBeVisible();await page.getByRole('button',{name:'Chiudi progetto'}).tap();await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));await page.getByRole('button',{name:'Menu',exact:true}).tap();await page.getByRole('dialog',{name:'Menu principale'}).getByRole('link',{name:/Contatti/}).tap();await expect(page.locator('.cp-navigation')).toHaveCount(0);await expect(page).toHaveURL(/#contatti$/);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await context.close();
});
test('vice: reduced motion e accessibilità',async({page})=>{
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('/?intro=1');await expect(page.locator('.vc-opening')).toHaveAttribute('data-static','true');await page.getByRole('button',{name:'Entra subito',exact:true}).click({noWaitAfter:true});await expect(page.locator('.vc-opening')).toHaveCount(0);const main=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze();expect(main.violations).toEqual([]);await page.getByRole('button',{name:'Menu',exact:true}).click();const menu=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa']).analyze();expect(menu.violations).toEqual([]);await page.keyboard.press('Escape');
});
test('vice: cinque viewport, immagini e disposizione continua',async({page,request})=>{
 await page.goto('/');for(const [width,height] of [[320,740],[390,844],[768,1024],[844,390],[1440,1000]]){await page.setViewportSize({width,height});await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);const visibleName=page.locator('.vc-hero .vc-name');const bounds=await visibleName.boundingBox();expect(bounds).toBeTruthy();expect(bounds!.x).toBeGreaterThanOrEqual(0);expect(bounds!.x+bounds!.width).toBeLessThanOrEqual(width+1);}
 for(const p of projects){const result=await request.get(p.image);expect(result.status()).toBe(200);}await page.screenshot({path:'test-results/vice-hero-desktop.png'});
});
test('vice: accesso senza WebGL e copia email reale',async({page,context})=>{
 await context.grantPermissions(['clipboard-read','clipboard-write']);await page.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(this:HTMLCanvasElement,kind,...args){if(kind==='webgl'||kind==='webgl2')return null;return Reflect.apply(original,this,[kind,...args]);} as typeof original;});await page.goto('/');await expect(page.locator('canvas')).toHaveCount(0);await page.getByRole('button',{name:'Copia email',exact:true}).click();await expect(page.getByRole('status')).toHaveText('Email copiata.');expect(await page.evaluate(()=>navigator.clipboard.readText())).toBe('sasycannavale1999@gmail.com');
});


test('vice: apertura automatica e tocco immediato sul telefono',async({browser})=>{
 const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const page=await context.newPage();await page.goto('/?intro=1');await expect(page.locator('.vc-opening')).toBeVisible();await page.screenshot({path:'test-results/signature-opening-mobile.png'});await expect(page.locator('.vc-opening')).toHaveCount(0,{timeout:6500});await expect(page.locator('.vc-work')).toHaveCount(projects.length);await page.getByRole('button',{name:'Rivedi l’apertura'}).tap();await expect(page.locator('.vc-opening')).toBeVisible();const name=await page.locator('.vc-signature-portal').boundingBox();expect(name).toBeTruthy();await page.touchscreen.tap(name!.x+name!.width/2,name!.y+name!.height/2);await expect(page.locator('.vc-opening')).toHaveCount(0,{timeout:2200});await page.screenshot({path:'test-results/vice-original-art-mobile.png'});await context.close();
});


test('vice: ingresso non bloccante se gli script non arrivano',async({page})=>{
 await page.route('**/*.js',r=>r.abort());await page.goto('/?intro=1');await expect(page.locator('.vc-opening')).not.toBeVisible();await expect(page.locator('.vc-work')).toHaveCount(projects.length);await expect(page.locator('.vc-work').first()).toHaveAttribute('href',projects[0].url);
});


test('vice: interruzione dell’apertura e replay senza chiusure tardive',async({page})=>{
 await page.goto('/?intro=1');const intro=page.locator('.vc-opening');await expect(intro).toBeVisible();await page.getByRole('button',{name:'Entra subito',exact:true}).click({noWaitAfter:true});await page.keyboard.press('Escape');await expect(intro).toHaveCount(0);await page.getByRole('button',{name:'Rivedi l’apertura'}).click();await expect(intro).toBeVisible();await page.waitForTimeout(700);await expect(intro).toBeVisible();await page.keyboard.press('Escape');await expect(intro).toHaveCount(0);
});
