import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
test("Reality Control: gravità, distorsione, particelle, ripristino e uscita", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/#contenuto");
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .click();
  await expect(page.locator("html")).toHaveAttribute("data-reality", "active");
  const gravity = page.getByRole("button", { name: "Gravità alterata" });
  await gravity.click();
  await expect(gravity).toHaveAttribute("aria-pressed", "true");
  await page.locator("#progetti").scrollIntoViewIfNeeded();
  await page.mouse.move(1000, 420);
  await expect
    .poll(() =>
      page
        .locator(".portal-perspective")
        .first()
        .evaluate((el) => el.style.getPropertyValue("--reality-x")),
    )
    .not.toBe("");
  await page
    .getByRole("slider", { name: "Distorsione della realtà" })
    .fill("75");
  await expect
    .poll(() =>
      page
        .locator(".portfolio")
        .evaluate((el) => el.style.getPropertyValue("--distortion")),
    )
    .toBe("0.75");
  await page.screenshot({ path: "test-results/fase3-controllo.png" });
  await page
    .getByRole("button", { name: "Frammenta ONE MAN", exact: true })
    .click();
  await expect(page.locator("html")).toHaveAttribute("data-fragment", "active");
  await page.waitForTimeout(450);
  await page.screenshot({ path: "test-results/fase3-frammenti.png" });
  await expect(page.locator("html")).toHaveAttribute("data-fragment", "idle", {
    timeout: 10000,
  });
  await page
    .getByRole("button", { name: "Frammenta ONE MAN", exact: true })
    .click();
  await page.getByRole("button", { name: "Ripristina tutto" }).click();
  await expect(gravity).toHaveAttribute("aria-pressed", "false");
  await expect(
    page.getByRole("slider", { name: "Distorsione della realtà" }),
  ).toHaveValue("0");
  await expect(page.locator("html")).toHaveAttribute("data-fragment", "idle");
  await expect
    .poll(() =>
      page
        .locator(".portal-perspective")
        .first()
        .evaluate((el) => el.style.getPropertyValue("--reality-x")),
    )
    .toBe("");
  await page.keyboard.press("Escape");
  await expect(
    page.getByRole("complementary", { name: "Controlli della realtà" }),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true }),
  ).toBeFocused();
  expect(errors).toEqual([]);
});
test("stanza segreta, inversione, focus e risorse GPU dopo chiusura", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/#contenuto");
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  await expect
    .poll(() =>
      page.locator(".world-layer canvas").getAttribute("data-gpu-geometries"),
    )
    .not.toBeNull();
  await expect
    .poll(async () =>
      Number(
        await page
          .locator(".world-layer canvas")
          .getAttribute("data-gpu-samples"),
      ),
    )
    .toBeGreaterThanOrEqual(2);
  const initial = Number(
    await page
      .locator(".world-layer canvas")
      .getAttribute("data-gpu-geometries"),
  );
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .click();
  await page.getByText("C’è qualcosa oltre il visibile.").click();
  const opener = page.getByRole("button", { name: "Apri la stanza 07" });
  await opener.click();
  const dialog = page.getByRole("dialog", { name: "OLTRE IL VISIBILE." });
  await expect(dialog).toBeVisible();
  await expect(dialog.locator("canvas")).toBeVisible();
  await expect
    .poll(() => dialog.locator("canvas").getAttribute("data-gpu-geometries"))
    .not.toBeNull();
  await dialog.getByRole("button", { name: "Inverti la materia" }).click();
  await expect(dialog.getByRole("status")).toHaveText("Configurazione 02 / 02");
  await page.screenshot({ path: "test-results/fase3-stanza-segreta.png" });
  await dialog.getByRole("button", { name: "Torna al portfolio" }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.locator("canvas")).toHaveCount(1);
  await expect(opener).toBeFocused();
  await page.waitForTimeout(1200);
  const after = Number(
    await page
      .locator(".world-layer canvas")
      .getAttribute("data-gpu-geometries"),
  );
  expect(after).toBeLessThanOrEqual(initial + 2);
  await opener.click();
  await expect(dialog).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(page.locator("html")).toHaveAttribute("data-reality", "idle");
  expect(errors).toEqual([]);
});
test("qualità manuale senza ricreare il Canvas e audio solo su consenso", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const Base = window.AudioContext;
    const w = window as unknown as { audioStarts: number };
    w.audioStarts = 0;
    window.AudioContext = class extends Base {
      constructor(options?: AudioContextOptions) {
        super(options);
        w.audioStarts++;
      }
    };
  });
  await page.goto("/#contenuto");
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  expect(
    await page.evaluate(
      () => (window as unknown as { audioStarts: number }).audioStarts,
    ),
  ).toBe(0);
  await page.getByRole("button", { name: "Attiva audio", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Disattiva audio", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  expect(
    await page.evaluate(
      () => (window as unknown as { audioStarts: number }).audioStarts,
    ),
  ).toBe(1);
  await page
    .getByRole("button", { name: "Disattiva audio", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Attiva audio", exact: true }),
  ).toHaveAttribute("aria-pressed", "false");
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .click();
  const canvas = await page.locator(".world-layer canvas").elementHandle();
  for (const [value, label] of [
    ["high", "high"],
    ["medium", "medium"],
    ["low", "low"],
  ]) {
    await page.getByLabel("Qualità visiva").selectOption(value);
    await expect(page.locator("html")).toHaveAttribute("data-quality", label);
    expect(await canvas!.evaluate((el) => el.isConnected)).toBe(true);
  }
  await expect
    .poll(() =>
      page
        .locator(".world-layer canvas")
        .evaluate((el) => (el as HTMLCanvasElement).width),
    )
    .toBe(1440);
});
test("Reality Control mobile, tastiera, movimento ridotto e audit accessibilità", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    reducedMotion: "reduce",
  });
  const page = await context.newPage();
  await page.goto("/#contenuto");
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .tap();
  await expect(
    page.getByRole("button", { name: "Gravità alterata" }),
  ).toBeDisabled();
  const slider = page.getByRole("slider", { name: "Distorsione della realtà" });
  await slider.focus();
  await page.keyboard.press("ArrowRight");
  await expect(slider).toHaveValue("1");
  await page
    .getByRole("button", { name: "Frammenta ONE MAN", exact: true })
    .tap();
  await expect(page.locator("html")).toHaveAttribute("data-fragment", "active");
  await expect(page.locator("canvas")).toHaveCount(0);
  await expect(page.locator(".advanced-cursor")).toBeHidden();
  const results = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(results.violations).toEqual([]);
  await page.getByText("C’è qualcosa oltre il visibile.").tap();
  await page.getByRole("button", { name: "Apri la stanza 07" }).tap();
  await page.getByRole("button", { name: "Inverti la materia" }).tap();
  await expect(
    page.getByRole("status").filter({ hasText: "Configurazione" }),
  ).toHaveText("Configurazione 02 / 02");
  await page.getByRole("button", { name: "Torna al portfolio" }).tap();
  await page.getByRole("button", { name: "Disattiva il controllo della realtà" }).tap();
  await expect(page.locator("html")).toHaveAttribute("data-reality", "idle");
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await context.close();
});
test("metadati, sitemap, robots, favicon e collegamenti locali", async ({
  page,
  request,
}) => {
  await page.goto("/progetti/orbita-zero");
  await expect(page).toHaveTitle("Orbita zero — ONE MAN");
  await expect(page.locator("html")).toHaveAttribute("lang", "it");
  await expect(page.locator('meta[property="og:locale"]')).toHaveAttribute(
    "content",
    "it_IT",
  );
  expect(await page.locator('script[type="application/ld+json"]').count()).toBe(
    2,
  );
  for (const path of [
    "/sitemap.xml",
    "/robots.txt",
    "/icon.svg",
    "/og.png",
    "/apple-touch-icon.png",
    "/progetti/la-stanza-impossibile",
    "/progetti/campo-rosso",
  ]) {
    const response = await request.get(path);
    expect(response.status(), path).toBe(200);
  }
  await expect(page.locator(".case-study")).toHaveAttribute(
    "data-transition",
    "ready",
  );
  const result = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(result.violations).toEqual([]);
});

test("qualità automatica: riduzione con cadenza dei fotogrammi lenta", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = (callback) =>
      original(() => {
        window.setTimeout(() => callback(performance.now()), 70);
      });
  });
  await page.goto("/#contenuto");
  await expect(page.locator(".world-layer canvas")).toBeVisible();
  await page
    .getByRole("button", { name: "CONTROLLA LA REALTÀ", exact: true })
    .click();
  await expect(page.getByLabel("Qualità visiva")).toHaveValue("auto");
  const before = await page.locator("html").getAttribute("data-quality");
  expect(["high", "medium"]).toContain(before);
  await expect
    .poll(() => page.locator("html").getAttribute("data-quality"), {
      timeout: 45000,
      intervals: [500],
    })
    .not.toBe(before);
});
