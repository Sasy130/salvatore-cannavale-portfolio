import { test, expect, type Page, type Locator } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
async function inView(page:Page,id:string){
  await expect.poll(()=>page.locator(id).evaluate(el=>{const r=el.getBoundingClientRect();return r.top<innerHeight&&r.bottom>0;})).toBe(true);
}
/** Muove lo scroll nativo sulla lunghezza effettiva dell’allestimento. */
async function scrollGalleryTo(page:Page,fraction:number){
  await page.locator("#progetti").evaluate((element,progress)=>{
    const rect=element.getBoundingClientRect();
    const start=rect.top+window.scrollY;
    const length=Math.max(0,rect.height-innerHeight);
    window.scrollTo({top:start+length*progress,behavior:"instant"});
  },fraction);
  await expect.poll(async()=>Math.abs(Number(await page.locator("canvas").getAttribute("data-gallery-scroll"))-fraction)).toBeLessThan(.035);
}
const previewSources=["/anteprime/01.jpg","/anteprime/02.jpg","/anteprime/03.jpg"];
async function expectLoadedPreview(image:Locator,src:string){
  await expect(image).toHaveAttribute("src",src);
  await expect.poll(()=>image.evaluate(element=>{
    const img=element as HTMLImageElement;
    return img.complete&&img.naturalWidth>0&&img.naturalHeight>0;
  })).toBe(true);
}
async function expectDemonstrativeDetail(page:Page,src:string){
  const dialog=page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText("IMMAGINE DI PROVA");
  await expect(dialog).toContainText("Non rappresenta un mio progetto");
  await expect(dialog.locator("figcaption")).toHaveText("Immagine dimostrativa — il progetto reale sarà inserito qui.");
  const image=dialog.locator(".gallery-detail-cover img");
  await expect(image).toHaveCount(1);
  await expectLoadedPreview(image,src);
  await image.scrollIntoViewIfNeeded();
  await expect(image).toBeVisible();
  await expect(dialog.getByRole("link",{name:/Visita il progetto/})).toHaveCount(0);
}
test("introduzione surreale e panoramica, un solo canvas e nessun progetto inventato",async({page})=>{
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  page.on("console",m=>{if(m.type()==="error"&&/Shader Error|WebGLProgram/.test(m.text()))errors.push(m.text());});
  await page.goto("/mostra?intro=1");
  await expect(page.getByRole("button",{name:"Salta introduzione"})).toBeVisible();
  await expect(page.locator("canvas")).toHaveCount(1);
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  await page.screenshot({path:"test-results/galleria-intro.png"});
  await expect(page.getByRole("heading",{name:"PROGETTI.",level:1})).toBeVisible({timeout:18000});
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  await expect(page.locator(".gallery-caption strong")).toHaveText(["Spazio per un progetto","Spazio per un progetto","Spazio per un progetto"]);
  await expect(page.locator(".gallery-caption small")).toHaveText(["Immagine di prova","Immagine di prova","Immagine di prova"]);
  await expect(page.getByRole("button",{name:/^Apri il progetto /})).toHaveCount(0);
  await expect(page.getByText("Orbita zero",{exact:true})).toHaveCount(0);
  await expect(page.getByRole("button",{name:"CONTROLLA LA REALTÀ",exact:true})).toHaveCount(0);
  await page.screenshot({path:"test-results/galleria-desktop.png"});
  expect(errors).toEqual([]);
});
test("scroll, rotazione e ritorno alla vista d’insieme",async({page})=>{
  await page.goto("/mostra#progetti");const canvas=page.locator("canvas");
  await expect(canvas).toHaveAttribute("data-gallery-ready","true");
  await scrollGalleryTo(page,.25);
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-scroll"))).toBeGreaterThan(.2);
  await page.screenshot({path:"test-results/galleria-scroll.png"});
  await page.getByRole("button",{name:"Vista d’insieme"}).click();
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-scroll"))).toBeLessThan(.03);
  await page.mouse.move(700,370);await page.mouse.down();await page.mouse.move(860,375,{steps:8});await page.mouse.up();
  await expect.poll(async()=>Math.abs(Number(await canvas.getAttribute("data-gallery-yaw")))).toBeGreaterThan(.1);
  await expect(page.getByRole("dialog")).toHaveCount(0);
});
test("apertura della cornice, ripristino e vista elenco",async({page})=>{
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  await page.goto("/mostra#progetti");await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  await page.locator(".gallery-caption").nth(1).click();
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-phase","apertura");
  const dialog=page.getByRole("dialog");await expect(dialog).toBeVisible();
  await expectDemonstrativeDetail(page,previewSources[1]);
  await page.screenshot({path:"test-results/galleria-cornice-aperta.png"});
  await page.keyboard.press("Escape");await expect(dialog).toHaveCount(0);
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-phase","panoramica");
  await page.getByRole("button",{name:"Elenco",exact:true}).click();
  await expect(page.locator("canvas")).toHaveCount(0);
  await expect(page.locator(".gallery-flat-frame")).toHaveCount(3);
  const listImages=page.locator(".gallery-flat-frame .flat-art img");
  await expect(listImages).toHaveCount(3);
  await expect.poll(()=>listImages.evaluateAll(images=>images.map(image=>image.getAttribute("src")))).toEqual(previewSources);
  for(let index=0;index<previewSources.length;index++)await expectLoadedPreview(listImages.nth(index),previewSources[index]);
  await expect(page.locator(".gallery-flat-frame .flat-caption strong")).toHaveText(["Spazio per un progetto ↗","Spazio per un progetto ↗","Spazio per un progetto ↗"]);
  await page.getByRole("button",{name:"Esplora la cornice 01"}).click();
  await expectDemonstrativeDetail(page,previewSources[0]);
  await dialog.getByRole("button",{name:"Torna alla panoramica"}).click();
  await page.getByRole("button",{name:"Spazio",exact:true}).click();await expect(page.locator("canvas")).toHaveCount(1);
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  // Riselezionare la vista già attiva non deve riaprire il fallback sopra la scena.
  await page.getByRole("button",{name:"Spazio",exact:true}).click();
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  await expect(page.locator(".gallery-fallback")).toHaveCount(0);
  expect(errors).toEqual([]);
});
test("navigazione, replay e fallback dopo perdita WebGL",async({page})=>{
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  await page.goto("/mostra#progetti");await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  const nav=page.getByRole("navigation",{name:"Navigazione principale"});
  for(const [label,id] of [["Chi sono","#chi-sono"],["Contatti","#contatti"]]){
    await nav.getByRole("link",{name:label,exact:true}).click();await expect(page).toHaveURL(new RegExp(id+"$"));await inView(page,id);
    await expect(page.locator(".gallery-labels")).not.toBeVisible();
  }
  await nav.getByRole("link",{name:"Chi sono",exact:true}).click();
  await page.getByRole("button",{name:"Rivedi l’introduzione"}).click();
  await expect(page.getByRole("button",{name:"Salta introduzione"})).toBeVisible();
  await page.getByRole("button",{name:"Salta introduzione"}).click();
  await expect(page.getByRole("heading",{name:"PROGETTI.",level:1})).toBeVisible();
  await page.locator("canvas").evaluate(el=>(el as HTMLCanvasElement).getContext("webgl2")?.getExtension("WEBGL_lose_context")?.loseContext());
  await expect(page.locator("canvas")).toHaveCount(0);
  await expect(page.getByRole("group",{name:"Panoramica essenziale dei progetti"})).toBeVisible();
  expect(errors).toEqual([]);
});
test("mobile touch: panoramica, apertura e navigazione senza overflow",async({browser})=>{
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true});const page=await context.newPage();
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  await page.goto("/mostra#progetti");await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  await expect.poll(()=>page.locator(".gallery-caption").evaluateAll(items=>items.every(el=>{const r=el.getBoundingClientRect();return r.left>=0&&r.right<=innerWidth&&r.top>220&&r.bottom<innerHeight-90;}))).toBe(true);
  await page.screenshot({path:"test-results/galleria-mobile.png"});
  const touch=await context.newCDPSession(page);
  await touch.send("Input.dispatchTouchEvent",{type:"touchStart",touchPoints:[{x:120,y:680,id:1}]});
  for(let step=1;step<=6;step++)await touch.send("Input.dispatchTouchEvent",{type:"touchMove",touchPoints:[{x:120+step*20,y:680,id:1}]});
  await touch.send("Input.dispatchTouchEvent",{type:"touchEnd",touchPoints:[]});
  await expect.poll(async()=>Math.abs(Number(await page.locator("canvas").getAttribute("data-gallery-yaw")))).toBeGreaterThan(.1);
  await expect(page.getByRole("dialog")).toHaveCount(0);
  await scrollGalleryTo(page,.32);
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-chapter","cornice");
  await page.screenshot({path:"test-results/galleria-cornice-mobile.png"});
  await scrollGalleryTo(page,.7);
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-chapter","anamorfosi");
  await expect.poll(async()=>Number(await page.locator("canvas").getAttribute("data-gallery-anamorph"))).toBeGreaterThan(.05);
  await expect.poll(async()=>Number((await page.locator("canvas").getAttribute("data-gallery-camera"))?.split(",")[0]??0)).toBeGreaterThan(3);
  await expect.poll(async()=>Number((await page.locator("canvas").getAttribute("data-gallery-camera"))?.split(",")[2]??Infinity)).toBeLessThan(20);
  await expect.poll(async()=>Number(await page.locator("canvas").getAttribute("data-gallery-anamorph-rendered"))).toBeGreaterThan(.85);
  await page.screenshot({path:"test-results/galleria-anamorfosi-mobile.png"});
  await page.getByRole("button",{name:"Vista d’insieme"}).tap();
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-chapter","panoramica");
  await expect.poll(async()=>Number(await page.locator("canvas").getAttribute("data-gallery-scroll"))).toBeLessThan(.03);
  await page.locator(".gallery-caption").nth(1).tap();
  const dialog=page.getByRole("dialog");await expect(dialog).toBeVisible();
  await dialog.getByRole("button",{name:"Torna alla panoramica"}).tap();await expect(dialog).toHaveCount(0);
  await page.getByRole("button",{name:"Elenco",exact:true}).tap();await expect(page.locator(".gallery-flat-frame")).toHaveCount(3);
  await page.getByRole("navigation",{name:"Navigazione principale"}).getByRole("link",{name:"Contatti",exact:true}).tap();await inView(page,"#contatti");
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  await page.screenshot({path:"test-results/galleria-contatti-mobile.png"});expect(errors).toEqual([]);await context.close();
});
test("movimento ridotto, tastiera e audit accessibilità",async({page})=>{
  await page.emulateMedia({reducedMotion:"reduce"});await page.goto("/mostra#progetti");
  await expect(page.locator("canvas")).toHaveCount(0);
  await page.getByRole("button",{name:"Esplora la cornice 02"}).focus();await page.keyboard.press("Enter");
  const dialog=page.getByRole("dialog");await expect(dialog).toBeVisible();
  let audit=await new AxeBuilder({page}).withTags(["wcag2a","wcag2aa","wcag21aa"]).analyze();expect(audit.violations).toEqual([]);
  await page.keyboard.press("Escape");await expect(dialog).toHaveCount(0);
  audit=await new AxeBuilder({page}).withTags(["wcag2a","wcag2aa","wcag21aa"]).analyze();expect(audit.violations).toEqual([]);
});
test("WebGL e storage negati: la galleria rimane utilizzabile",async({page})=>{
  await page.addInitScript(()=>{HTMLCanvasElement.prototype.getContext=(()=>null) as typeof HTMLCanvasElement.prototype.getContext;Storage.prototype.getItem=()=>{throw Error("Storage negato");};Storage.prototype.setItem=()=>{throw Error("Storage negato");};});
  await page.goto("/mostra");await page.getByRole("button",{name:"Salta introduzione"}).click();await expect(page.locator("canvas")).toHaveCount(0);
  await expect(page.getByRole("heading",{name:"PROGETTI.",level:1})).toBeVisible();
  await page.getByRole("button",{name:"Esplora la cornice 03"}).click();await expect(page.getByRole("dialog")).toBeVisible();
});

test("selezione diretta della cornice tridimensionale con raycasting",async({page})=>{
  await page.goto("/mostra#progetti");
  await expect(page.locator("canvas")).toHaveAttribute("data-gallery-ready","true");
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  await page.mouse.click(720,480);
  await expect(page.getByRole("dialog")).toBeVisible();
  await expect(page.getByRole("dialog")).toContainText("IMMAGINE DI PROVA");
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});


test("la mostra si rivela dentro una cornice e diventa anamorfica con lo scroll",async({page})=>{
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  page.on("console",m=>{if(m.type()==="error"&&/Shader Error|WebGLProgram/.test(m.text()))errors.push(m.text());});
  await page.goto("/mostra#progetti");
  const canvas=page.locator("canvas");
  await expect(canvas).toHaveAttribute("data-gallery-ready","true");
  await expect(canvas).toHaveAttribute("data-gallery-chapter","panoramica");
  const renderer=await canvas.elementHandle();
  await scrollGalleryTo(page,.32);
  await expect(canvas).toHaveAttribute("data-gallery-chapter","cornice");
  await page.screenshot({path:"test-results/galleria-capitolo-cornice.png"});
  await scrollGalleryTo(page,.7);
  await expect(canvas).toHaveAttribute("data-gallery-chapter","anamorfosi");
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-anamorph"))).toBeGreaterThan(.05);
  await expect(page.locator(".gallery-caption")).toHaveCount(3);
  await expect(page.getByRole("navigation",{name:"Navigazione principale"})).toBeVisible();
  await expect.poll(async()=>Number((await canvas.getAttribute("data-gallery-camera"))?.split(",")[0]??0)).toBeGreaterThan(5);
  await expect.poll(async()=>Number((await canvas.getAttribute("data-gallery-camera"))?.split(",")[2]??Infinity)).toBeLessThan(14);
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-anamorph-rendered"))).toBeGreaterThan(.85);
  await page.screenshot({path:"test-results/galleria-capitolo-anamorfosi.png"});
  expect(await renderer!.evaluate(el=>el.isConnected)).toBe(true);
  await expect(canvas).toHaveCount(1);
  const front=page.getByRole("button",{name:"Vista frontale",exact:true});
  await expect(front).toHaveAttribute("aria-pressed","false");
  await front.click();
  await expect(front).toHaveAttribute("aria-pressed","true");
  await expect(canvas).toHaveAttribute("data-gallery-front","true");
  // La geometria resta scomposta: cambia il punto di osservazione, non l’intensità dell’effetto.
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-anamorph"))).toBeGreaterThan(.05);
  await expect.poll(async()=>Math.abs(Number((await canvas.getAttribute("data-gallery-camera"))?.split(",")[0]??Infinity))).toBeLessThan(.01);
  await expect.poll(async()=>Math.abs(Number((await canvas.getAttribute("data-gallery-camera"))?.split(",")[2]??Infinity)-12)).toBeLessThan(.01);
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-anamorph-rendered"))).toBeGreaterThan(.85);
  await page.screenshot({path:"test-results/galleria-anamorfosi-frontale.png"});
  await front.click();
  await expect(front).toHaveAttribute("aria-pressed","false");
  await expect(canvas).toHaveAttribute("data-gallery-front","false");
  await expect(canvas).toHaveAttribute("data-gallery-chapter","anamorfosi");
  await page.getByRole("button",{name:"Vista d’insieme"}).click();
  await expect(canvas).toHaveAttribute("data-gallery-chapter","panoramica");
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-anamorph"))).toBeLessThan(.03);
  await expect.poll(async()=>Number(await canvas.getAttribute("data-gallery-scroll"))).toBeLessThan(.03);
  expect(errors).toEqual([]);
});

test("apertura e chiusura del dettaglio preservano il punto nella mostra anamorfica",async({page})=>{
  const errors:string[]=[];page.on("pageerror",e=>errors.push(e.message));
  await page.goto("/mostra#progetti");
  const canvas=page.locator("canvas");
  await expect(canvas).toHaveAttribute("data-gallery-ready","true");
  await scrollGalleryTo(page,.7);
  await expect(canvas).toHaveAttribute("data-gallery-chapter","anamorfosi");
  const before=await page.evaluate(()=>window.scrollY);
  const progress=Number(await canvas.getAttribute("data-gallery-scroll"));
  await page.getByRole("button",{name:"Esplora la cornice 02",exact:true}).click();
  const dialog=page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText("IMMAGINE DI PROVA");
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(canvas).toHaveAttribute("data-gallery-phase","panoramica");
  await expect(canvas).toHaveAttribute("data-gallery-chapter","anamorfosi");
  await expect.poll(()=>page.evaluate(()=>window.scrollY)).toBeCloseTo(before,0);
  await expect.poll(async()=>Math.abs(Number(await canvas.getAttribute("data-gallery-scroll"))-progress)).toBeLessThan(.03);
  await expect.poll(()=>page.evaluate(()=>{const el=document.activeElement;if(!(el instanceof HTMLButtonElement)||!el.closest(".art-gallery"))return false;const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&r.top<innerHeight&&r.bottom>0;})).toBe(true);
  expect(errors).toEqual([]);
});

test.afterEach(async({page},info)=>{
  if(info.status===info.expectedStatus||page.isClosed())return;
  try{
    const diagnostic=await page.evaluate(()=>{
      const track=document.querySelector<HTMLElement>("#progetti");
      const viewport=document.querySelector<HTMLElement>(".gallery-viewport");
      const rect=(element:Element|null)=>{if(!element)return null;const r=element.getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,top:r.top,bottom:r.bottom};};
      return {
        url:location.href,
        windowY:window.scrollY,
        innerWidth,
        innerHeight,
        hidden:document.hidden,
        bodyHeight:document.body.scrollHeight,
        bodyOverflow:document.body.style.overflow,
        mode:document.querySelector<HTMLElement>(".art-gallery")?.dataset.galleryMode,
        trackRect:rect(track),
        trackCssHeight:track?getComputedStyle(track).height:null,
        viewportRect:rect(viewport),
        viewportChapter:viewport?.dataset.chapter,
        quality:document.documentElement.dataset.quality,
        canvas:Array.from(document.querySelectorAll("canvas")).map(canvas=>({rect:rect(canvas),data:{...canvas.dataset}})),
      };
    });
    console.log("Diagnostica galleria:",JSON.stringify(diagnostic));
  }catch(error){
    console.log("Diagnostica galleria non disponibile:",String(error));
  }
});
