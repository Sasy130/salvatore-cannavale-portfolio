import { test, expect } from "@playwright/test";
test("percorso completo, rilascio, esplorazione, creazione e replay", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(page.locator("canvas")).toBeVisible();
  await page.screenshot({ path: "test-results/intro-desktop.png" });
  const hold = page.getByRole("button", {
    name: "Tieni premuto per 1,5 secondi per aprire il monolite",
  });
  await hold.hover();
  await page.mouse.down();
  await page.waitForTimeout(400);
  await page.mouse.up();
  await expect(page.getByText("01 / 06 — IL VUOTO")).toBeVisible({
    timeout: 5000,
  });
  await hold.focus();
  await page.keyboard.down("Space");
  await expect(page.getByText("03 / 06 — LA FRATTURA")).toBeVisible({
    timeout: 15000,
  });
  await page.keyboard.up("Space");
  await expect(page.getByText("04 / 06 — LA STANZA IMPOSSIBILE")).toBeVisible({
    timeout: 15000,
  });
  await page.mouse.move(800, 600);
  await page.mouse.down();
  await page.mouse.move(1100, 640, { steps: 12 });
  await page.mouse.up();
  await expect(page.getByText("05 / 06 — LA CREAZIONE")).toBeVisible({
    timeout: 10000,
  });
  await page.screenshot({ path: "test-results/creazione-desktop.png" });
  await page.waitForTimeout(1200);
  await page.mouse.move(430, 471);
  await page.mouse.down();
  await page.mouse.move(1000, 461, { steps: 20 });
  await page.mouse.up();
  await expect(page.getByText("06 / 06 — LA RIVELAZIONE")).toBeVisible();
  await expect(page.locator("#contenuto")).toBeVisible({ timeout: 15000 });
  await expect(page.locator(".transition-veil")).toHaveCSS("opacity", "0");
  for (const name of ["Chi sono", "Progetti", "Contatti"]) {
    await page
      .getByRole("navigation")
      .getByRole("link", { name, exact: true })
      .click();
    await expect(page).toHaveURL(
      new RegExp(
        name === "Chi sono"
          ? "#chi-sono"
          : name === "Progetti"
            ? "#progetti"
            : "#contatti",
      ),
    );
  }
  await page.screenshot({
    path: "test-results/homepage-desktop.png",
    fullPage: true,
  });
  await page.getByRole("button", { name: "Rivivi l’introduzione" }).click();
  await expect(page.getByText("01 / 06 — IL VUOTO")).toBeVisible();
  await expect(page.locator("canvas")).toHaveAttribute(
    "data-scene-ready",
    "true",
  );
  await page.getByRole("button", { name: "Salta introduzione" }).click();
  await expect(page.locator("#contenuto")).toBeVisible();
  expect(errors).toEqual([]);
});
test("touch mobile e navigazione senza overflow", async ({ browser }) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  const page = await context.newPage();
  await page.goto("/");
  await expect(page.locator("canvas")).toBeVisible();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "test-results/intro-mobile.png" });
  const client = await context.newCDPSession(page);
  const box = await page
    .getByRole("button", {
      name: "Tieni premuto per 1,5 secondi per aprire il monolite",
    })
    .boundingBox();
  if (!box) throw Error("Pulsante assente");
  await client.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: box.x + 50, y: box.y + 30 }],
  });
  await expect(page.getByText("03 / 06 — LA FRATTURA")).toBeVisible({
    timeout: 15000,
  });
  await client.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await expect(page.getByText("04 / 06 — LA STANZA IMPOSSIBILE")).toBeVisible({
    timeout: 15000,
  });
  await client.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 120, y: 450 }],
  });
  for (let i = 1; i <= 8; i++)
    await client.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: 120 + i * 26, y: 450 }],
    });
  await client.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await expect(page.getByText("05 / 06 — LA CREAZIONE")).toBeVisible();
  await page.waitForTimeout(1200);
  await page.screenshot({ path: "test-results/creazione-mobile.png" });
  await client.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 89, y: 397 }],
  });
  for (let i = 1; i <= 12; i++)
    await client.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: 89 + i * 18, y: 397 }],
    });
  await client.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await page.screenshot({ path: "test-results/creazione-mobile-dopo.png" });
  await expect(page.locator("#contenuto")).toBeVisible({ timeout: 15000 });
  await expect(page.locator(".transition-veil")).toHaveCSS("opacity", "0");
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({
    path: "test-results/homepage-mobile.png",
    fullPage: true,
  });
  await context.close();
});
test("movimento ridotto: tastiera e percorso essenziale", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");
  await expect(
    page.getByText("MODALITÀ ESSENZIALE · MOVIMENTO RIDOTTO"),
  ).toBeVisible();
  await expect(page.locator("canvas")).toHaveCount(0);
  await page
    .getByRole("button", {
      name: "Tieni premuto per 1,5 secondi per aprire il monolite",
    })
    .focus();
  await page.keyboard.down("Space");
  await expect(page.getByText("04 / 06 — LA STANZA IMPOSSIBILE")).toBeVisible({
    timeout: 10000,
  });
  await page.keyboard.up("Space");
  await page.locator(".intro").focus();
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("ArrowRight");
  await expect(page.getByText("05 / 06 — LA CREAZIONE")).toBeVisible();
  await page.keyboard.press("Enter");
  await expect(page.locator("#contenuto")).toBeVisible();
});
test("WebGL non disponibile: sito e replay accessibili", async ({ page }) => {
  await page.addInitScript(() => {
    HTMLCanvasElement.prototype.getContext = (() =>
      null) as typeof HTMLCanvasElement.prototype.getContext;
  });
  await page.goto("/");
  await expect(
    page.getByText("MODALITÀ ESSENZIALE · WEBGL NON DISPONIBILE"),
  ).toBeVisible();
  await page.getByRole("button", { name: "Salta introduzione" }).click();
  await expect(page.locator("#contenuto")).toBeVisible();
  await page.getByRole("button", { name: "Rivivi l’introduzione" }).click();
  await expect(page.getByText("01 / 06 — IL VUOTO")).toBeVisible();
});

test("pressione diretta sul monolite con raycasting", async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("canvas")).toBeVisible();
  await expect(page.locator("canvas")).toHaveAttribute(
    "data-scene-ready",
    "true",
  );
  await page.mouse.move(770, 600);
  await page.mouse.down();
  await expect(page.getByText("03 / 06 — LA FRATTURA")).toBeVisible({
    timeout: 15000,
  });
  await page.mouse.up();
  await page.getByRole("button", { name: "Salta introduzione" }).click();
  await expect(page.locator("#contenuto")).toBeVisible();
});
