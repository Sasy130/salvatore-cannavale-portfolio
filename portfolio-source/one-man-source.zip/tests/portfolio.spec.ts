import { test, expect } from "@playwright/test";
test("portfolio: sezioni, nodi, portale, case study e ritorno", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/#contenuto");
  await expect(page.locator("#portfolio-title")).toBeVisible();
  await page.waitForTimeout(1500);
  await page.screenshot({ path: "test-results/fase2-hero-desktop.png" });
  const nav = page.getByRole("navigation", { name: "Navigazione principale" });
  for (const [label, id] of [
    ["Chi sono", "chi-sono"],
    ["Progetti", "progetti"],
    ["Competenze", "competenze"],
    ["Contatti", "contatti"],
    ["Home", "contenuto"],
  ]) {
    await nav.getByRole("link", { name: label, exact: true }).click();
    await expect(page).toHaveURL(new RegExp("#" + id));
    await expect(page.locator("#" + id)).toBeInViewport({ timeout: 15000 });
  }
  await page.locator("#competenze").scrollIntoViewIfNeeded();
  await page.getByRole("button", { name: "Universi 3D" }).click();
  await expect(page.locator("#skill-detail")).toContainText(
    "React Three Fiber",
  );
  await expect(
    page.getByRole("button", { name: "Universi 3D" }),
  ).toHaveAttribute("aria-pressed", "true");
  await page.locator("#progetti").scrollIntoViewIfNeeded();
  const link = page.getByRole("link", { name: "Esplora Orbita zero" });
  await link.scrollIntoViewIfNeeded();
  await link.hover();
  await expect(link.locator(".portal-description")).toHaveCSS("opacity", "1");
  await page.screenshot({ path: "test-results/fase2-portale.png" });
  await link.click();
  await expect(page).toHaveURL(/\/progetti\/orbita-zero$/);
  await expect(
    page.getByRole("heading", { level: 1, name: "Orbita zero" }),
  ).toBeVisible();
  await expect(page.locator(".portal-flight")).toHaveCount(0);
  await expect(page.locator("h1")).toBeFocused();
  await page.locator("#demo").scrollIntoViewIfNeeded();
  await expect(page.locator("canvas")).toBeVisible();
  await page.getByRole("button", { name: "Ferma movimento" }).click();
  await expect(
    page.getByRole("button", { name: "Riprendi movimento" }),
  ).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("slider", { name: "Apertura degli anelli" }).fill("1.2");
  await page.screenshot({ path: "test-results/fase2-demo-orbita.png" });
  await page.getByRole("link", { name: "Tutti gli universi" }).click();
  await expect(page).toHaveURL(/\/#progetti$/);
  await expect(page.locator("#progetti")).toBeInViewport({ timeout: 15000 });
  expect(errors).toEqual([]);
});
test("mobile: menu, focus, nodi e pagine progetto senza overflow", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    reducedMotion: "reduce",
  });
  const page = await context.newPage();
  await page.goto("/#contenuto");
  await page.getByRole("button", { name: "Menu", exact: true }).tap();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(
    page.getByRole("button", { name: "Menu", exact: true }),
  ).toBeFocused();
  await page.getByRole("button", { name: "Menu", exact: true }).tap();
  await dialog.getByRole("link", { name: "Competenze" }).tap();
  await expect(dialog).not.toBeVisible();
  await expect(page.locator("#competenze")).toBeInViewport();
  await page.getByRole("button", { name: "Movimento", exact: false }).tap();
  await expect(page.locator("#skill-detail")).toContainText("ScrollTrigger");
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({ path: "test-results/fase2-nodi-mobile.png" });
  await page.getByRole("button", { name: "Menu", exact: true }).tap();
  await dialog.getByRole("link", { name: "Progetti", exact: true }).tap();
  await page.getByRole("link", { name: "Esplora Campo rosso" }).tap();
  await expect(
    page.getByRole("heading", { level: 1, name: "Campo rosso" }),
  ).toBeVisible();
  await expect(page.locator("canvas")).toHaveCount(0);
  await page.locator("#demo").scrollIntoViewIfNeeded();
  await expect(
    page.getByText("Visualizzazione essenziale:", { exact: false }),
  ).toBeVisible();
  await expect(page.getByRole("slider")).toHaveCount(0);
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.screenshot({ path: "test-results/fase2-case-mobile.png" });
  await context.close();
});
test("tutti i case study, immagini locali, fallback e recapiti da configurare", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const [slug, title] of [
    ["la-stanza-impossibile", "La stanza impossibile"],
    ["orbita-zero", "Orbita zero"],
    ["campo-rosso", "Campo rosso"],
  ]) {
    await page.goto("/progetti/" + slug);
    await expect(
      page.getByRole("heading", { level: 1, name: title }),
    ).toBeVisible();
    await expect(page.getByText("02 / LA SFIDA")).toBeVisible();
    const images = page.locator("img");
    for (let i = 0; i < (await images.count()); i++) {
      await images.nth(i).scrollIntoViewIfNeeded();
      await expect
        .poll(() =>
          images
            .nth(i)
            .evaluate(
              (el: HTMLImageElement) => el.complete && el.naturalWidth > 0,
            ),
        )
        .toBe(true);
    }
  }
  await page.goto("/#contatti");
  await expect(page.getByText("Recapiti in preparazione")).toBeVisible();
  await expect(page.locator('a[href^="mailto:"]')).toHaveCount(0);
  await expect(page.locator("canvas")).toHaveCount(0);
  await page.goto("/progetti/non-esiste");
  await expect(
    page.getByRole("heading", { name: "QUESTA REALTÀ NON ESISTE." }),
  ).toBeVisible();
});
test("homepage e case study utilizzabili senza WebGL", async ({ page }) => {
  await page.addInitScript(() => {
    HTMLCanvasElement.prototype.getContext = (() =>
      null) as typeof HTMLCanvasElement.prototype.getContext;
  });
  await page.goto("/#contenuto");
  await expect(page.locator("#portfolio-title")).toBeVisible();
  await expect(page.locator(".world-fallback")).toBeVisible();
  await page
    .getByRole("link", { name: "Esplora La stanza impossibile" })
    .click();
  await expect(
    page.getByRole("heading", { level: 1, name: "La stanza impossibile" }),
  ).toBeVisible();
  await page
    .getByRole("link", { name: "Rivivi l’esperienza completa" })
    .click();
  await expect(page.getByText("01 / 06 — IL VUOTO")).toBeVisible();
  await expect(
    page.getByText("MODALITÀ ESSENZIALE · WEBGL NON DISPONIBILE"),
  ).toBeVisible();
});

test.afterEach(async ({ page }, info) => {
  if (info.status === info.expectedStatus) return;
  console.log(
    "Diagnostica navigazione:",
    await page.evaluate(() => ({
      url: location.href,
      scroll: scrollY,
      focus: document.activeElement?.outerHTML.slice(0, 150),
      portals: Array.from(document.querySelectorAll(".portal-link")).map(
        (el) => ({
          state: (el as HTMLElement).dataset.portalState,
          rect: {
            x: el.getBoundingClientRect().x,
            y: el.getBoundingClientRect().y,
          },
        }),
      ),
    })),
  );
  await page
    .screenshot({
      path: `test-results/navigazione-fallita-${info.repeatEachIndex}.png`,
    })
    .catch(() => {});
});
