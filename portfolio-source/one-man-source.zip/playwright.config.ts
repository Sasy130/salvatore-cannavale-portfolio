import { defineConfig } from "@playwright/test";
const staticMode = process.env.PLAYWRIGHT_STATIC === "1";
export default defineConfig({
  testDir: "./tests",
  // La homepage è stata ridisegnata: gli scenari delle edizioni precedenti restano come archivio.
  testMatch: ["**/gallery.spec.ts", "**/manifest.spec.ts"],
  timeout: 120000,
  workers: 1,
  expect: {timeout: 15000},
  use: {
    screenshot: "only-on-failure",
    trace: "retain-on-failure",
    baseURL: staticMode ? "http://127.0.0.1:4173" : "http://127.0.0.1:3000",
    launchOptions: {
      args: [
        "--enable-webgl",
        "--use-gl=angle",
        "--use-angle=swiftshader",
        "--enable-unsafe-swiftshader",
      ],
    },
    viewport: { width: 1440, height: 1000 },
  },
  webServer: {
    command: staticMode ? "npm run preview:static" : "npm run start",
    url: staticMode ? "http://127.0.0.1:4173" : "http://127.0.0.1:3000",
    reuseExistingServer: true,
  },
  reporter: "list",
});
