# ONE MAN — Continuazione della mostra

L’introduzione approvata rimane. La continuazione usa lo stesso canvas e le stesse cornici, con una partitura reversibile dello scroll.

Aggiornamento del 7 novembre 2026: le tre cornici ora contengono fotografie dimostrative locali. Non sono progetti personali: fonti, configurazione e verifiche dell’aggiornamento sono in `docs/IMMAGINI-DI-PROVA.md`.

## Sequenza realizzata

1. **La mostra**: panorama iniziale dei tre spazi per i progetti.
2. **Il quadro nel quadro**: la camera arretra; due cornici di dimensioni maggiori rendono visibile il perimetro dell’intera installazione. Nel quadro centrale compaiono due miniature geometriche dell’allestimento. Si tratta di tre livelli finiti di rappresentazione, non di una ricorsione infinita o di un filmato.
3. **Oltre l’immagine**: la camera raggiunge un punto obliquo mentre le superfici si separano in tasselli a profondità differenti. “Vista frontale” riporta la camera all’origine da cui l’immagine si ricompone prospetticamente; i tasselli restano tridimensionali.
4. **Apertura**: il lavoro scelto torna planare e avanza; gli altri pannelli si dispongono ai lati come elementi della cornice. Compare il dettaglio HTML. Alla chiusura vengono ripristinati scroll, capitolo e focus.

Lo scroll può riavvolgere la partitura. “Vista d’insieme” azzera prospettiva e percorso. Navigazione, testo e titoli rimangono HTML leggibile. Gli spazi per i progetti sono dichiarati come tali e le fotografie sono indicate come immagini di prova: non sono stati inseriti progetti fittizi.

## Tecnica

- `lib/gallery-choreography.ts`: funzioni deterministiche del percorso e nomi dei capitoli.
- `RecursiveFrames.tsx`: cornici fisiche, pannelli e miniature con geometrie instanziate nello stesso renderer.
- `AnamorphicSurface.tsx` + `lib/anamorphic-geometry.ts`: 80 tasselli desktop o 30 leggeri per superficie, raccolti in una BufferGeometry con un solo draw call. Profondità e inclinazione sono controllate dal vertex shader.
- Il riferimento frontale world viene trasformato nelle coordinate locali del quadro. I vertici deformati rimangono sulle rette che congiungono quel riferimento al piano originario. Il fragment shader retroproietta anche le coordinate dell’immagine. Le copertine reali condividono dimensioni e ritaglio fra superficie piatta e anamorfica.
- Le miniature sono geometriche e finite; non usano capture del browser o renderer WebGL aggiuntivi. Non vengono promessi dettaglio infinito, fotogrammetria o immagini 3D generate automaticamente.
- Selezione tramite pulsanti HTML o volumi di raycasting che seguono l’ingombro della deformazione. La superficie deformata sul GPU non viene simulata anche sul CPU.
- Scroll nativo e ScrollTrigger condividono la posizione reale del documento. Nessun blocco del gesto verticale durante l’esplorazione.
- Le didascalie sono un livello HTML fisso che segue il rettangolo del canvas: il focus o `scrollIntoView` non spostano lo sticky e il livello esce insieme alla mostra. I pulsanti mantengono nomi accessibili e ripristino del focus.
- Mobile: camera e intensità ridotte, meno tasselli, etichette limitate al viewport. Movimento ridotto e WebGL non disponibile usano elenco/cornici HTML e apertura diretta.
- Geometrie, materiali e texture clone di proprietà vengono eliminati al cleanup; le risorse condivise delle copertine restano nella cache del loader.

## Verifiche della consegna

Verifiche eseguite il 6 novembre 2026. Il riferimento browser è Chromium headless con WebGL tramite SwiftShader: non è una misurazione delle prestazioni di uno smartphone fisico.

| Controllo | Risultato |
| --- | --- |
| `npm run typecheck` | Superato |
| `npm run lint` | Superato, nessun avviso |
| `npm run build` | Build Next di produzione riuscita |
| `npm run build:static` | Export statico riuscito |
| `npm run test:static -- --reporter=line` | 10 test su 10 superati, 3 minuti |
| Test mirato apertura, elenco e doppia selezione di “Spazio” | 1 test su 1 superato dopo l’ultima correzione del cambio vista |
| Audit axe WCAG A/AA della vista essenziale e del dialogo | Nessuna violazione rilevata |
| Touch | Drag, apertura, capitoli e navigazione verificati con emulazione 390 × 844 |

La suite completa comprende introduzione, skip/replay, un solo canvas persistente tra i capitoli, scroll e ritorno alla panoramica, vista obliqua/frontale, selezione mediante raycasting, chiusura con ripristino di posizione e focus, assenza delle didascalie nelle sezioni successive, fallback senza WebGL/storage e dopo perdita del contesto. Le immagini dei capitoli desktop/mobile e della ricomposizione frontale sono state ispezionate.

Sono stati corretti un identificatore GLSL riservato, il rilascio anticipato del touch per bubbling della cattura, l’autoscroll del browser verso le didascalie e il clic ripetuto sulla vista “Spazio” già attiva. Le esecuzioni intermedie fallite hanno guidato queste correzioni; non vengono conteggiate tra quelle superate. Nessun benchmark GPU, test su Safari o dispositivo fisico è stato eseguito.

## Limiti

Allestimento iniziale di tre cornici con immagini di prova; i materiali e le copertine dei progetti reali restano da inserire. Il percorso è coreografato, non una simulazione fisica. Il movimento non certifica un’idea mai utilizzata sul web. Test mobile emulati e audit automatici non sostituiscono il collaudo su Safari, dispositivi fisici e screen reader. La qualità dipende dal dispositivo; il fallback mantiene sempre l’accesso.
