# Selezione editoriale dei progetti

`components/vice/EditorialProjects.tsx` riutilizza tutti i dati di `lib/restored-projects.ts` e il dialogo progetto già esistente. Copertine, link, demo e ordine non sono sostituiti.

Desktop da 960px: indice numerato, selezione al passaggio del mouse o attivazione con tastiera/clic, anteprima sticky con descrizione e link. L'apertura dell'anteprima è una maschera CSS animata; non è una simulazione 3D. La selezione resta sotto controllo dell'utente e non cambia automaticamente durante lo scroll.

Mobile e tablet: dettagli HTML espandibili, un progetto aperto alla volta. Il primo è aperto inizialmente. Nessun gesto orizzontale richiesto. Immagini lazy, reduced motion, link reali e controlli nativi. Se JavaScript non arriva, resta l'elenco di dettagli espandibili con link diretti. Nessuna nuova dipendenza.

Aspetto in `editorial-projects.css`: soglia desktop, tipografia, distanze e maschera. La sezione notifica ScrollTrigger quando cambia altezza per aggiornare le animazioni successive senza bloccare lo scroll. Intro, hero, sfondo tipografico, sezioni narrative, indice completo, menu e contatti sono preservati.
