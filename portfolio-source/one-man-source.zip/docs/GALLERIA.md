# Nuova direzione — Galleria d’arte

## Scopo

Dopo il feedback sull’edizione precedente, la homepage viene sostituita da uno spazio espositivo chiaro e utilizzabile. Nessun progetto dimostrativo viene presentato come lavoro personale. Si realizzano prima intro, panoramica e transizione di apertura, in attesa dei contenuti reali.

## Architettura e scelte

`app/page.tsx` carica `GalleryExperience`. Il vecchio codice rimane intatto nei suoi componenti e nelle route già esistenti; non viene montato nella nuova homepage. Il runtime comune fornisce capacità WebGL, movimento ridotto e qualità adattiva; il vecchio renderer viene caricato soltanto nelle vecchie route progetto.

Un solo canvas lazily loaded ospita introduzione e galleria. Parete deformabile, pannelli e cornici sono geometrie reali. Un canale volatile comunica lo scroll nativo e il gesto orizzontale ai callback R3F. I titoli sono HTML ordinario, proiettato nello spazio dopo l’aggiornamento della camera; nessuna radice React DOM esterna viene creata da Drei per le etichette. Questa scelta evita conflitti di cleanup durante elenco, replay e perdita del contesto.

La versione essenziale e l’elenco restano completamente HTML. L’apertura dei dettagli usa un dialogo nativo con focus, Escape e ripristino. Le tre cornici vuote sono dichiarate come tali, anche nel dettaglio. I progetti reali si configurano in un array separato; nessun titolo o cliente inventato.

Il primo fotogramma mobile usa direttamente camera e scale della panoramica, evitando la fase transitoria che inizialmente tagliava le etichette. I test controllano anche i rettangoli delle tre didascalie nel viewport.

## Verifica

Risultati realmente eseguiti:

| Controllo | Esito |
| --- | --- |
| TypeScript | Superato |
| ESLint senza warning | Superato |
| Build Next.js di produzione | Superata |
| Suite sulla build Next | 7/7 superati |
| Build statica di produzione | Superata |
| Suite finale sull’export | 8/8 superati, incluso clic diretto sulla geometria |
| Audit axe, modalità essenziale e dialogo | Nessuna violazione nei percorsi verificati |
| Desktop e mobile 390×844 | Fotogrammi esaminati; tre didascalie dentro il viewport |

La suite finale copre intro e salto, un solo canvas, assenza dei vecchi progetti nella homepage, scroll, drag, vista d’insieme, apertura/chiusura, elenco, focus, navigazione, replay, perdita WebGL, raycasting, touch, movimento ridotto e storage negato. Il browser è Chromium con WebGL software e touch emulato. La suite Next a sette casi precede l’ultimo affinamento dell’avvio mobile; la suite statica a otto casi include il codice finale. Le verifiche intermedie hanno rilevato e corretto errori DOM durante lo smontaggio delle etichette Drei e un problema di composizione iniziale su mobile. Nessuna di queste esecuzioni fallite viene dichiarata come test superato.

## Limiti dichiarati

Tre spazi espositivi vuoti, non progetti fittizi. L’allestimento va rifinito sui formati e sul numero dei lavori che verranno forniti. Test touch emulati; nessun collaudo su un telefono fisico o Safari. I movimenti simulano un’installazione, non fisica rigida completa. Il fallback può saltare il raccordo cinematografico per mantenere l’accesso ai contenuti.
