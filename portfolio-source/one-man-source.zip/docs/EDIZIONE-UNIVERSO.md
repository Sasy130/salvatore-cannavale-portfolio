# ONE MAN — La realtà si riscrive.

Portfolio personale sperimentale esteso attraverso le Fasi 1, 2, 3 e 4. Next.js App Router, React, TypeScript, Tailwind CSS, Three.js, React Three Fiber, Drei, GSAP/ScrollTrigger, GLSL e Zustand. Nessun cliente, risultato professionale, recapito o certificazione inventati.

## Avvio

Richiede Node.js 20.19 o superiore (Node.js 24 consigliato) e npm.

```sh
npm ci
npm run dev
```

Aprire http://localhost:3000. Per il server Next.js di produzione:

```sh
npm run build
npm start
```

Per una pubblicazione statica dello stesso progetto:

```sh
npm run build:static
npm run preview:static
```

L’export completo è in `out/`; l’anteprima statica risponde su http://localhost:4173. Non usare `next start` subito dopo la build statica: eseguire prima `npm run build` per ripristinare la build server. Non occorre cambiare stack, ricreare le pagine o usare un backend.

## Esperienza

### La stanza impossibile — introduzione originale

Macchina a stati `IDLE → CONTACT → FRACTURE → ROOM → CREATION → REVEAL → COMPLETE`.

- Tenere premuto il monolite o il pulsante per 1,5 secondi. Il rilascio anticipato scarica l’energia. Funziona anche con Spazio/Invio sul pulsante.
- Dopo la frattura, trascinare la visuale per circa 195 pixel complessivi. Alternative: tre frecce con focus sulla scena o il pulsante “Ruota la stanza”.
- Trascinare il nucleo chiaro verso l’anello rosso. Il gesto ricompone ONE MAN con cubi istanziati. Il comando “Connetti il nucleo” offre la stessa uscita da tastiera.
- Il passaggio alla homepage usa una traiettoria verso la O e un raccordo luminoso. “Salta introduzione” resta disponibile in ogni stato.
- Il replay azzera timer, energia, esplorazione e composizione e ricrea la scena. Perdita del focus o cambio scheda interrompono la pressione.
- `/?intro=1` apre esplicitamente l’intro; `/#progetti` e gli altri link alle sezioni aprono direttamente il portfolio.

### Il portfolio impossibile

Hero con la geometria del monolite dell’intro, sezioni narrative, tre portali con prospettiva al puntatore ed espansione dell’immagine, apertura di cornici 3D e dolly durante la navigazione. In modalità essenziale, reduced motion o qualità Bassa, la navigazione è immediata per evitare attese dovute all’espansione. Scroll nativo: nessuno scroll hijacking. ScrollTrigger sincronizza separazione delle lettere, rivelazioni, pannelli prospettici, parallasse, nastro e camera.

Tre ricerche personali realmente implementate:

1. **La stanza impossibile**: case study dell’intro, con link all’esperienza completa.
2. **Orbita zero**: scultura metallica con controllo di apertura e pausa.
3. **Campo rosso**: superficie generativa di frammenti istanziati con ampiezza regolabile e pausa.

Ogni case study include categoria, descrizione, due illustrazioni procedurali originali, tecnologie, sfida e soluzione. Le competenze sono un diagramma SVG con pulsanti HTML su desktop e una lista di selettori più grandi su mobile. Nessuna dipendenza da WebGL per leggere i contenuti o navigare.

### Reality Control

Attivare **CONTROLLA LA REALTÀ**, disponibile nel portfolio e nei case study.

- **Gravità alterata**: i pannelli designati rispondono al puntatore con una simulazione a molle smorzate, limitata a piccoli spostamenti e rotazioni. I collegamenti conservano il loro comportamento.
- **Distorsione**: trascinare il punto nel controllo dedicato, oppure usare le frecce sullo slider. Il valore modifica superficie, materiali, deformazione del monolite tramite shader, profondità dei pannelli 3D e camera.
- **Frammenta ONE MAN**: attivare il comando nella hero o nel pannello, oppure toccare il titolo quando il controllo è attivo. Le lettere diventano cubi 3D, si disperdono e si ricompongono in 4,2 secondi. La trasformazione è ripetibile. In modalità essenziale le lettere HTML si separano, senza particelle animate.
- **Ripristina tutto**: azzera gravità, distorsione, frammentazione e stato della stanza segreta, mantenendo aperto il pannello.
- **Uscita immediata**: pulsante di chiusura, comando ESCI DAL CONTROLLO o Escape. Il focus ritorna al comando di attivazione.
- **Stanza 07**: espandere l’indizio “C’è qualcosa oltre il visibile.”. La stanza contiene una curva tridimensionale originale deformabile, una frase italiana, il comando “Inverti la materia” e il ritorno al portfolio. Anche l’oggetto 3D è cliccabile. Il dialogo modale gestisce focus e tastiera; non servono combinazioni nascoste da indovinare.
- **Cursore**: indicatore aggiuntivo per mouse, con stati normale, interazione, trascinamento, progetto e Reality Control. Il puntatore nativo rimane visibile; l’indicatore è escluso su touch e con movimento ridotto.
- **Audio**: spento a ogni caricamento. Il visitatore può abilitarlo e disabilitarlo dal comando visibile. Suoni originali sintetizzati con Web Audio, senza file o licenze di terzi. Al cambio scheda viene disattivato. Il sito funziona anche se il browser non consente l’audio.

## Il motore dell’universo vivente — Fase 4

Il renderer è unico e persistente: l’host del Canvas si sposta fra intro, portfolio, demo e stanza 07. Le scene originali e i loro wrapper restano disponibili; non vengono mantenuti più canvas pesanti contemporaneamente. I contenuti che attendono risorse sono isolati da Suspense nel renderer, così un cambio di qualità non sospende l’intera interfaccia.

- **La struttura impossibile**: sei stanze corrispondono a Home, Chi sono, Progetti, Competenze, Esplora l’universo e Contatti. Pareti, pavimenti, ponti diagonali e cornici si articolano con lo spostamento della camera. Due InstancedMesh raccolgono l’architettura. Camera su spline, target interpolato, dolly, roll contenuto e prospettiva variabile seguono sezioni e interazioni, senza sostituire lo scroll nativo.
- **Il nucleo**: un mesh persistente del portfolio passa da monolite a materia liquida, frammenti, particelle e lettere ONE MAN. Attributi per triangolo e shader interpolano la medesima superficie; non sono modelli alternati tramite dissolvenze. Il laboratorio `#universo` permette di scegliere una forma o ripristinare il comportamento automatico. La tipografia HTML resta semanticamente presente.
- **Esplora l’universo**: apre la vista orbitale della stessa architettura. Trascinare, ruotare, ingrandire con ruota/pinch o controlli HTML e selezionare un nucleo luminoso tramite raycasting. Le sei destinazioni hanno anche link HTML reali e funzionano senza WebGL. Escape chiude e restituisce il focus. Il blocco dello scroll riguarda soltanto la finestra aperta.
- **Portali dei progetti**: la card originale si espande, la porta geometrica assume il colore del progetto e la camera avanza al suo interno. Next mantiene route, avanti e indietro; qualità Bassa e movimento ridotto usano navigazione diretta. Il timer di uscita non dipende dalla fluidità di GSAP. Il passaggio ha una destinazione fullscreen nello stesso renderer anche quando la demo del case study è fuori schermo; Escape annulla prima della navigazione e un link consente l’apertura immediata.
- **Memoria visiva**: solo una lista bianca in `sessionStorage`, chiave `one-man-universe-v1`: intro vista/completata, progetti, Reality Control, portali, mappa, forme provate, stanza 07 e finale. Nessun dato personale, nessun invio in rete. Piccole emissioni e nodi visitati cambiano aspetto. Il funzionamento continua in memoria volatile se lo storage è negato. “Azzera la memoria visiva” cancella le tracce della scheda. L’intro già vista viene saltata al ritorno; `?intro=1` e replay la riaprono.
- **Finale IL NUCLEO**: tre categorie di interazione, indicate nella checklist, sbloccano la stanza. Tre passaggi volontari ricompongono l’architettura, il nucleo e 60 elementi istanziati aggiuntivi. Nessun limite di tempo per leggere. Replay, uscita immediata e CTA reale ai contatti. La stanza 07 originale rimane separatamente disponibile.
- **Versione essenziale**: illustrazioni SVG statiche delle cinque forme, navigazione HTML e finale testuale completo. Non vengono presentate come rendering WebGL.

Il registro di implementazione e verifica di ogni milestone è in `docs/LIVING-UNIVERSE.md`.

## Qualità, risorse e accessibilità

| Qualità | DPR massimo | Ambiente iniziale | Frammenti del campo |
| ------- | ----------- | ------------------- | ------------------- |
| Alta    | 1,5         | 128 px              | 324                 |
| Media   | 1,15        | 64 px               | 196                 |
| Bassa   | 1           | 32 px               | 100                 |

La selezione automatica parte da Media su schermi stretti/hardware con pochi processori logici, altrimenti Alta. Dopo due finestre consecutive di quattro secondi con durata media dei fotogrammi superiore a 40 ms, riduce di un livello. Non risale automaticamente per evitare oscillazioni. È possibile scegliere manualmente Alta, Media o Bassa. Reduced motion prevale e mantiene il livello Bassa con scene statiche.

Canvas caricati dinamicamente; demo caricate vicino al viewport; rendering sospeso fuori vista e dietro la stanza segreta. Le geometrie ripetute usano InstancedMesh. Il passaggio di qualità conserva il Canvas. RAF, listener, controlli GSAP, shader, geometrie, composer, pass, voci audio e contesti vengono ripuliti. I listener di perdita WebGL vengono rimossi prima dello smontaggio, così il normale cleanup non viene interpretato come un errore.

Fallback per WebGL assente o perso, reduced motion e touch. Focus visibile, menu mobile e stanza segreta modali, Escape, controlli nativi con nomi comprensibili, dettagli annunciati, testi alternativi e percorsi equivalenti da tastiera. Il controllo di gravità automatica è disabilitato in reduced motion. I controlli delle demo 3D vengono sostituiti da una spiegazione quando la scena è statica.

## Modificare i contenuti

**`lib/portfolio-data.ts`** contiene:

- `identity.email`: indirizzo personale valido. Con stringa vuota compare “Recapiti in preparazione”; non viene simulato alcun invio.
- `identity.socials`: elementi `{ label: 'Nome', url: 'https://…' }`. Solo URL HTTPS; apertura in una nuova scheda annunciata.
- `identity.bio`, `identity.approach`, `identity.collaboration`: testi personali.
- `projects`: slug, titolo, categoria, descrizione, sfida, soluzione, immagini e alternative, tecnologie, ambiente e demo opzionale.
- `skills`: descrizioni, strumenti e coordinate del diagramma desktop.

Email e social sono volutamente vuoti, come richiesto dall’utente nelle fasi precedenti. Il comando di copia si attiva quando è configurata un’email valida; un eventuale rifiuto degli appunti mostra l’indirizzo da copiare manualmente. Non è presente un form finto.

**`lib/site-data.ts`** contiene nome, slogan, descrizione SEO, lingua, URL canonico e frase della stanza segreta. L’URL può essere sovrascritto con `NEXT_PUBLIC_SITE_URL` prima della build. Dopo modifiche ai dati, agli slug o al dominio, rigenerare la build.

## SEO e pubblicazione

HTML italiano, titoli e descrizioni per pagina, canonical, Open Graph, Twitter Card, immagine PNG locale, favicon SVG, icona Apple, `sitemap.xml`, `robots.txt` e JSON-LD `WebSite`/`CreativeWork`. I dati strutturati descrivono il sito e gli esperimenti; non attribuiscono identità o incarichi inesistenti.

La configurazione Sites è in `.openai/hosting.json`, con `static.directory: out`. L’indirizzo riservato è:

https://one-man-realta-7f26.one-man13.chatgpt.site

La visibilità iniziale Sites è privata: per aprire il collegamento da telefono usare lo stesso account ChatGPT proprietario. La pubblicazione non modifica automaticamente il pubblico autorizzato. Per pubblicarlo ad altri visitatori, impostare consapevolmente la visibilità nella gestione dell’hosting.

Per aggiornamenti Sites: eseguire i controlli e `npm run build:static`, sincronizzare il sorgente esatto nel repository Sites e pubblicare l’archivio della cartella `out/` insieme a `.openai/hosting.json`, associandolo allo stesso commit. `scripts/push-site.mjs` accetta credenziali temporanee soltanto su stdin nascosto e non le memorizza; è riservato al flusso di pubblicazione con il connettore Sites. Non inserire token in file, URL Git o comandi della shell.

Alternative: Vercel può usare il normale `npm run build`; un hosting statico può servire `out/`, risolvendo `/percorso` verso `/percorso.html` e mantenendo la pagina 404. Per il dominio definitivo aggiornare `NEXT_PUBLIC_SITE_URL`, ricostruire e configurare HTTPS. Nessuna variabile segreta è necessaria al sito attuale.

## Verifiche

```sh
npm run typecheck
npm run lint
npm run build
npx playwright install chromium
npm run test:e2e
npm run build:static
npm run test:static
```

TypeScript, lint senza warning e build server/statica superati. I **27 scenari** comprendono le 15 regressioni delle fasi precedenti e i nuovi percorsi del motore vivente: 26 superati nella suite sull’export e il caso camera M3 superato nella riesecuzione isolata con primi fotogrammi attesi, qualità Bassa e misure visive esplicite. Ultima regressione sulla build Next: **9/9**; ultimo affinamento della tipografia: **2/2**. Gli audit axe inclusi non riportano violazioni nei percorsi verificati. Dettagli e limiti nel registro `docs/LIVING-UNIVERSE.md`.

I test usano Chromium con WebGL software e touch emulato; comprendono intro, navigazione, case study, menu, nodi, fallback, Reality Control, audio su consenso, qualità, risorse GPU, metadati, link e audit axe per WCAG 2 A/AA e 2.1 AA. Le schermate sono in `test-results/`. La cadenza rallentata del test della qualità automatica è simulata; non è un benchmark su GPU fisiche.

## Struttura completa del sorgente

```text
app/
  layout.tsx                       Metadati, JSON-LD e runtime condiviso
  page.tsx                         Ingresso nell’esperienza
  not-found.tsx                    Pagina 404 italiana
  globals.css                      Stili originali dell’intro
  icon.svg                         Favicon
  robots.ts                        Regole crawler
  sitemap.ts                       Mappa delle pagine
  progetti/[slug]/page.tsx          Case study statici e JSON-LD
components/
  Experience.tsx                   Intro, fallback, homepage e replay
  Universe.tsx                     Sei scene originali dell’intro
  portfolio/
    Portfolio.tsx                  Homepage e ScrollTrigger
    Navigation.tsx                 Navigazione desktop/mobile
    SceneLayer.tsx                 Lazy loading e fallback
    WorldScene.tsx                 Ambienti del portfolio e shader
    SceneBoundary.tsx              Recupero da errori 3D
    PortalLink.tsx                 Transizioni fra pagine
    CaseStudy.tsx                  Pagine progetto e demo
    SkillSystem.tsx                Nodi e dettagli accessibili
    ContactPanel.tsx               Email, copia e social
    portfolio.css                 Design system del portfolio
  universe/
    UniversalRenderer.tsx           Canvas condiviso e coordinatore
    SceneSlot.tsx                   Destinazioni DOM del renderer
    ImpossibleArchitecture.tsx      Stanze e strutture istanziate
    CinematicCamera.tsx             Spline, orbite e portali
    CinematicLights.tsx             Key light e rim light
    LivingMatter.tsx                Shader delle cinque forme
    LivingControls.tsx              Laboratorio accessibile
    StaticMatter.tsx                Forme SVG essenziali
    MapRooms.tsx                    Mesh selezionabili e raycasting
    UniverseOverlay.tsx             Mappa/finale, gesti e focus
    PortalStage.tsx                Destinazione a schermo intero per i passaggi
    ProjectGate.tsx                 Porta dimensionale 3D
    VisualMemoryRuntime.tsx         Eventi di sessione
    MemoryTraces.tsx                Checklist e azzeramento
    FinaleStructure.tsx             Monumento istanziato
    FinalePanel.tsx                 Finale e CTA
    universe.css                   Interfaccia del motore
  reality/
    Runtime.tsx                    Motore fisico e qualità automatica
    RealityControl.tsx             Pannello, reset e audio
    Cursor.tsx                     Indicatore desktop
    WordFragments.tsx              Tipografia a geometrie istanziate
    SecretRoom.tsx                 Dialogo segreto accessibile
    SecretScene.tsx                Scultura 3D originale e shader
    GpuDiagnostics.tsx             Ciclo di vita e contatori GPU
    reality.css                    Interfaccia e fallback del controllo
lib/
  universe-config.ts               Stanze, traiettorie e nomi delle forme
  renderer-registry.ts             Registrazione e priorità delle scene
  interaction-orchestrator.ts      Proprietario del gesto corrente
  living-geometry.ts               Tessellazione e attributi del nucleo
  visual-memory.ts                 Memoria validata e sblocco
  intro-store.ts                   Macchina a stati dell’intro
  portfolio-store.ts               Stato di camera e ambienti
  reality-store.ts                 Stato centrale Reality Control
  performance-store.ts             Livelli e preferenze
  audio.ts                         Sintesi audio su consenso
  monolith.ts                      Geometria condivisa
  portfolio-data.ts                Progetti, biografia e recapiti
  site-data.ts                     Identità, dominio e SEO
public/
  progetti/*.svg                   Sei illustrazioni originali
  og.png                           Anteprima social
  apple-touch-icon.png             Icona telefono
scripts/
  serve-static.mjs                 Anteprima statica senza dipendenze
  push-site.mjs                    Sincronizzazione sorgente Sites
tests/
  universe.spec.ts                 Verifiche delle milestone M2–M9
  living-quality.spec.ts           Mobile, fallback, accessibilità e GPU
  experience.spec.ts               Regressioni Fase 1
  portfolio.spec.ts                Navigazione e Fase 2
  reality.spec.ts                  Controlli, accessibilità e SEO
docs/LIVING-UNIVERSE.md             Analisi e risultati delle milestone
.openai/hosting.json                Identità e destinazione Sites
next.config.ts                     Build Next.js o export statico
eslint.config.mjs                  Lint Next.js/TypeScript
playwright.config.ts               Browser test server/statici
postcss.config.mjs                 Tailwind CSS
tsconfig.json                      TypeScript
package.json / package-lock.json   Dipendenze e comandi
AGENTS.md                          Istruzioni Next.js dell’ambiente
```

## Limiti dichiarati

Safari e telefoni fisici richiedono ancora collaudo; il touch è emulato in Chromium. Gli audit automatici non sostituiscono una valutazione completa con screen reader. I controlli GPU verificano il ciclo di vita e contatori del renderer, non certificano l’assenza di ogni perdita di memoria del driver. Nessuna garanzia di 60 fps su qualsiasi dispositivo.

Frattura e gravità sono simulazioni controllate, non dinamica rigida completa. Il passaggio intro/homepage usa un raccordo ottico, non una trasformazione geometrica della pagina HTML. Le immagini dei case study sono illustrazioni originali, non prove di lavori per clienti. I contatti attendono i dati personali reali. Il nucleo liquido usa deformazione procedurale e normali della superficie tessellata, non una simulazione di fluidi. L’intro conserva il proprio shader e i propri gesti: condivide renderer e geometria sorgente con il portfolio; il mesh LivingMatter persiste fra sezioni e finale. Il caricamento delle route e la compilazione degli shader possono introdurre attese, specialmente nel rendering software.


Il renderer condiviso evita MSAA e usa il DPR controllato per contenere il costo su mobile. La risoluzione dell’ambiente riflettente del portfolio resta quella iniziale durante la permanenza nella scena: evita di rigenerare le mappe durante una discesa di qualità. Geometrie, particelle, DPR e ombre continuano ad adattarsi. Il livello Basso usa illuminazione Phong e cornici non illuminate per nucleo e architettura, conservando lo shader delle trasformazioni; i materiali PBR restano nei livelli Medio e Alto. Le rivelazioni HTML rispettano il tempo reale anche durante una compilazione GPU.

## Personalizzare il motore

Modificare `lib/universe-config.ts` per nomi, posizioni e traiettorie delle stanze; ogni `id` deve corrispondere a una sezione reale di `Portfolio.tsx`. `lib/portfolio-data.ts` centralizza biografia, progetti, email e social: i recapiti restano vuoti fino alla configurazione, senza form o contatti finti. `lib/site-data.ts` contiene slogan, dominio e metadati. Le soglie di qualità sono in `lib/performance-store.ts` e nel runtime; il criterio di sblocco del finale è `finaleUnlocked` in `lib/visual-memory.ts`. Shader e geometrie del nucleo sono rispettivamente in `LivingMatter.tsx` e `living-geometry.ts`. Dopo una modifica eseguire TypeScript, lint, build e i test interessati; per Sites ricostruire anche l’export statico.
