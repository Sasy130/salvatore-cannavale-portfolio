# Fotografie di prova della galleria

Queste tre fotografie servono a valutare composizione, ritaglio e resa delle immagini nella galleria ONE MAN. **Non rappresentano lavori, clienti o progetti personali dell'autore del portfolio.** Vanno sostituite con i propri materiali quando si configurano i progetti.

Scaricate il 7 novembre 2026 da Unsplash e conservate localmente: la galleria non deve richiedere immagini esterne durante la visita. Tutti i file sono JPEG progressivi, con lato lungo di 1200 pixel, e sono stati ispezionati visivamente.

| File pubblico | Contenuto fotografico | Dimensioni | Peso |
| --- | --- | --- | --- |
| `/anteprime/01.jpg` | Architettura chiara con un volume geometrico sospeso e una facciata vetrata inclinata. | 1200 × 800 px | 133.617 byte |
| `/anteprime/02.jpg` | Pigmenti liquidi rossi, arancioni e azzurri su fondo scuro. | 1200 × 800 px | 187.708 byte |
| `/anteprime/03.jpg` | Dettaglio di foglie verdi con nervature visibili e ombre profonde. | 675 × 1200 px | 158.552 byte |

## Fonti esatte

1. Architettura: <https://images.unsplash.com/photo-1487958449943-2429e8be8625?auto=format&fit=max&w=1200&h=1200&q=78&fm=jpg>
2. Pigmenti: <https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=max&w=1200&q=78&fm=jpg>
3. Foglie: <https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=max&w=1200&h=1200&q=78&fm=jpg>

Le fotografie provengono da Unsplash e sono utilizzate secondo la [licenza Unsplash](https://unsplash.com/license). La licenza consente il download, la modifica e l'uso gratuito, anche commerciale, alle condizioni indicate nella pagina ufficiale. I nomi dei fotografi non sono stati verificati in questa sessione; non vengono attribuiti nomi presunti. Gli identificativi originali delle immagini restano disponibili nei collegamenti sopra.

## Sostituzione

Sostituire i file nella cartella `public/anteprime/` oppure modificare `galleryPreviews` in `lib/gallery-data.ts`. Inserendo i propri lavori in `galleryProjects`, le fotografie dimostrative vengono sostituite automaticamente. Usare immagini di cui si possiedono i diritti e aggiornare i testi alternativi in base ai contenuti reali. Per un caricamento leggero, mantenere il lato lungo intorno a 1200 pixel e comprimere i JPEG prima di pubblicarli.

## Verifiche del 7 novembre 2026

- TypeScript e lint superati; export statico di produzione riuscito.
- Tre JPEG decodificati e verificati con dimensioni corrispondenti ai metadati; copie nell’export identiche ai file sorgenti. Peso complessivo circa 469 KiB.
- `galleryProjects` resta vuoto e i tre elementi espongono solo `preview`; nessun lavoro reale o cliente aggiunto.
- Le immagini vengono usate in cornici 3D, deformazione anamorfica, vista HTML e dettaglio; l’introduzione e le miniature geometriche restano nel renderer esistente.
- Suite Playwright aggiornata per immagini caricate, ordine delle foto e indicazione dimostrativa. **Test browser non eseguiti per questo aggiornamento.** I precedenti esiti del 6 novembre rimangono storici.
- L’ambiente gestito `ccarenv_b64_Y2NhcmVudl9iZTI1N2MwYjg3Y2M4MTkxYjM2ZDJmOTc2Y2RjNjlhNQ` è in esecuzione. Desktop dichiarato abilitato, stato osservato `unknown`; il tool `cua_repl.js` non è disponibile. Nessun server o browser alternativo è stato avviato per aggirare il limite dell’anteprima gestita.
