# Fase 4 — Registro delle milestone

## M1 — Analisi completata

Baseline: commit `c0d399c`, sito Sites versione 1. TypeScript e lint eseguiti e superati prima delle modifiche.

Componenti preservati e riutilizzati: macchina a stati `intro-store`, scene e shader di `Universe`, ambienti di `WorldScene`, `SecretScene`, sistema `RealityControl`, `WordFragments`, `PortalLink`, controlli delle demo, quality tiers e diagnostica GPU. Nessuna migrazione di framework o nuova dipendenza richiesta.

Estensione scelta: estrarre i contenuti R3F dai Canvas esistenti, conservarne i wrapper compatibili e affidare la loro presentazione a un solo Canvas persistente. Un host DOM stabile si sposta tra intro, portfolio, demo e dialogo segreto; il renderer non viene ricreato. La camera e le risorse vengono quindi coordinate dal motore esistente, esteso tramite `portfolio-store`. Le geometrie restano reali; il raccordo ottico dell’intro originale viene conservato.

La mappa e il nuovo finale useranno lo stesso renderer del portfolio. Le finestre HTML mantengono focus e navigazione alternativa; nessun nuovo Canvas per una miniatura. Gli stati di sessione saranno una lista bianca locale, senza coordinate del puntatore o dati personali.

Milestone successive da completare e verificare in ordine: M2 renderer condiviso; M3 architettura e camera; M4 materia; M5 mappa; M6 portali; M7 tipografia; M8 memoria; M9 finale; M10 regressioni, mobile e pubblicazione.

## M2 — Completata e verificata

Un solo Canvas persistente; contenuti R3F estratti senza eliminare i wrapper o le scene originali. Host DOM spostato fra i contenitori, camera e DPR coordinati, fallback conservato. Build, TypeScript e lint superati. Tre test browser passati: percorso completo dell’intro, risorse/focus della stanza segreta, identità dello stesso nodo Canvas attraverso intro → homepage → stanza segreta → homepage.

## M3 — Completata e verificata

Cinque stanze collegate a sezioni reali, pavimenti/pareti/cornici instanziati e ponti disposti su assi differenti. Le superfici si articolano all’avvicinamento alla stanza. Camera a spline, target interpolato, dolly, prospettiva e roll limitati, illuminazione PBR con ombre selettive nel livello Alto. La proiezione della tipografia esistente è stata adattata alla camera orientata. Build e test di navigazione/camera sulle cinque sezioni superati; nessun errore runtime nel percorso verificato.

## M4 — Completata
La superficie originale è tessellata in triangoli e dotata di attributi per faccia. Un solo shader interpola monolite, deformazione liquida, frammenti, particelle e campionamento geometrico delle lettere ONE MAN. Controlli HTML nel laboratorio, sincronizzazione automatica con le sezioni e Reality Control. Test browser delle cinque forme, ripristino e intercettazione degli errori GLSL superato. Risolto un blocco durante la ricostruzione dell’ambiente al cambio qualità isolando la sospensione nel contenuto del canvas.

## M5 — Completata e verificata
La mappa riusa le sei stanze del mondo e il renderer persistente. Camera orbitale limitata, drag, pinch, ruota, zoom e reset; selezione di sei mesh con raycasting. Lista HTML equivalente, Escape, contenuti sottostanti inerti, focus ripristinato e hash reali. Test browser superato: rotazione/zoom, click su una mesh proiettata, navigazione alternativa ai contatti e identità del canvas conservata.

## M6 — Completata e verificata
L’espansione originale della card resta, seguita da cinque cornici tridimensionali, variazione della prospettiva e dolly attraverso la porta. Colori dalle configurazioni dei progetti. Navigazione Next con URL reali e percorso immediato nei fallback/qualità Bassa. Il timer della navigazione è indipendente dal completamento GSAP. Test browser superato per geometria, avanzamento della camera, case study e cronologia avanti/indietro; il budget del test è 15 secondi per il renderer software.

## M7 — Completata e verificata
Il sistema esistente di cubi istanziati campiona il titolo e opera nello spazio della camera orientata. Aggiunta reazione in profondità al puntatore e attivazione diretta del comando della hero. Nessuna sostituzione del titolo semantico. Test browser superato: geometrie presenti, interazione, ritorno automatico, nuova attivazione e ripristino immediato.

## M8 — Completata e verificata
Memoria Zustand con lista bianca validata e sessionStorage facoltativo: nessun timestamp, coordinata o dato personale. Tracce: intro vista/completata, progetti, controllo, forme, mappa, portali e segreto. Emissioni sul nucleo e sui nodi visitati; checklist esplicita e azzeramento. Test superati per persistenza, schema, shader influenzato dalla memoria, replay e storage negato. Nessuna nuova dipendenza.

## M9 — Completata e verificata
Il finale si sblocca con tre categorie di interazione su sei, indicate nella checklist. Riusa nucleo e architettura del portfolio; 60 elementi istanziati costruiscono il monumento aggiuntivo. Tre passaggi manuali trasformano geometrie e camera senza imporre tempi di lettura. Test superato per sblocco reale, shader, struttura, tre testi, replay, focus, Escape e CTA ai contatti.

## M10 — Completata
Regressioni, mobile, accessibilità, risorse GPU e produzione verificati nei percorsi descritti sotto. La continuità intro/portfolio conserva i gesti e lo shader originali dell’intro e condivide renderer e sorgente della geometria; il mesh persistente LivingMatter collega le sezioni e il finale. La materia è procedurale, non una simulazione fluidodinamica. I riflessi usano un ambiente sintetico locale senza HDR scaricati.


### Ottimizzazioni e correzioni finali

- Event manager del canvas centralizzato: coordinate rispetto al suo rettangolo reale e sorgente esterna per la mappa. Il raycasting continua dopo un cambio di qualità.
- Il canvas resta montato e sospende i fotogrammi quando la scheda è nascosta. Perdita del contesto o errore shader attivano la versione essenziale; contenuti e link restano accessibili.
- Ambiente riflettente del portfolio fissato alla risoluzione iniziale della scena, per evitare rigenerazioni durante una discesa di qualità. DPR, geometrie, particelle e ombre continuano ad adattarsi. MSAA disabilitato nel renderer condiviso; il DPR Alto offre supersampling controllato.
- Livello Basso: nucleo e pareti usano Phong e cornici semplici; Medio/Alto mantengono PBR. È un compromesso dichiarato per il costo degli shader, senza eliminare le trasformazioni geometriche.
- Collegamenti alle sezioni nativi; transizioni Next per le pagine. Nessun intercettore dello scroll. Le rivelazioni GSAP rispettano il tempo reale dopo un rallentamento.
- Portali fullscreen nello stesso renderer anche quando la demo di un case study è fuori schermo. Escape annulla prima della navigazione; link diretto disponibile durante il caricamento. Focus isolato durante il passaggio.
- Ripristino dei gesti su annullamento, perdita del focus e cambio scheda. Overlay usabili anche su schermi bassi, navigazione alternativa e diagrammi SVG delle forme.
- Nebbia e sfondo originali dell’intro preservati. Rimozione esplicita dell’host del renderer al suo smontaggio.
- La revisione dei fotogrammi ha corretto un’occlusione nel finale e la distribuzione dei triangoli tipografici: i vertici si ricompongono in ONE MAN leggibile, senza sostituire il modello con testo HTML o una dissolvenza.

### Risultati realmente eseguiti

| Verifica | Esito |
| --- | --- |
| TypeScript | Superato |
| ESLint, zero warning | Superato |
| Build Next.js di produzione | Superata |
| Build statica di produzione | Superata |
| Suite completa sull’export | 26 scenari superati; il caso camera M3 è stato corretto e rieseguito separatamente |
| M3 isolato sull’export | 1/1 superato: qualità Bassa, attesa dei primi fotogrammi, rettangoli delle sezioni e cinque fotogrammi della camera |
| Regressione finale sulla build Next | 9/9 superati: intro desktop/touch, essenziale, raycasting, renderer condiviso, perdita WebGL, portali e finale |
| Ultimo affinamento della tipografia | 2/2 superati: cinque forme, ricomposizione e finale; fotogramma finale esaminato |
| Audit axe inclusi | Nessuna violazione nei percorsi verificati, inclusi mappa e finale essenziali |

I 27 scenari della suite hanno un esito positivo dopo le correzioni e le riesecuzioni mirate. Le esecuzioni intermedie hanno individuato errori GLSL, un attributo ARIA e problemi di sincronizzazione; non vengono considerate verifiche superate. Il test camera è separato dall’adattamento automatico della qualità, verificato in un altro test. La misura di visibilità del caso M3 usa rettangoli e fotogrammi: nel browser software IntersectionObserver restituiva zero anche per sezioni già nel viewport.

Browser: Chromium con SwiftShader e touch emulato a 390×844. Verificati drag e pinch reali tramite eventi touch del browser, skip/replay, tutti gli stati dell’intro, memoria con e senza storage, cronologia, link locali, metadati, audio su consenso, qualità manuale/automatica e fallback. La pausa della scheda e la cadenza lenta sono simulate; la perdita WebGL è provocata tramite WEBGL_lose_context. I contatori GPU verificano il ciclo di vita, non certificano ogni comportamento del driver.

### Limiti e personalizzazione

Safari, screen reader e telefoni fisici richiedono ancora collaudo dedicato. Nessuna promessa di prestazioni identiche sui dispositivi. Le immagini dei case study sono illustrazioni di ricerche personali implementate; nessun cliente o risultato inventato. Email e social restano da configurare come concordato.

Struttura, comandi, configurazione di contenuti/scene e pubblicazione sono in README.md. Le risorse pubblicate provengono da out/ e mantengono l’identità Sites e il pubblico privato esistenti.
