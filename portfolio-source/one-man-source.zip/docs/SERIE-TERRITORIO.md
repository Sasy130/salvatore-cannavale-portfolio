# Dalla mappa al sito

La homepage presenta la serie personale «Dalla mappa al sito» subito dopo i progetti. Il racconto parte dalla zona del creatore su Maps e si amplia attraverso proposte indipendenti per le attività incontrate. È una serie pensata per Instagram: non sono dichiarati episodi pubblicati o collaborazioni con le aziende.

Prime proposte: A&J Rent Car e Rent Car Station. I due lavori sono spostati dall'indice editoriale alla sezione dedicata; restano disponibili tutti i tredici progetti complessivi. Copertine, demo, collegamenti e dialoghi progetto sono riutilizzati. Nessuna mappa finta, nessun indirizzo o coordinata inventati, nessuna API o dipendenza aggiunta.

Configurazione in `lib/local-series.ts`: titolo, descrizione, `projectSlugs` ordinati e `instagramProfileUrl` (vuoto fino a quando sarà disponibile). Per aggiungere una proposta, inserire il progetto in `lib/restored-projects.ts` e il suo slug nell'array della serie. Sarà automaticamente separato dai progetti personali. Se si imposta il profilo Instagram, appare il link reale; altrimenti il fondo invita a suggerire un'attività tramite i contatti.

Componente `components/vice/LocalRedesignSeries.tsx`, stile `local-redesign-series.css`, ancora pubblica `#dalla-mappa-al-sito`, menu «La serie». Le due proposte usano gli stessi dialoghi e anteprime interattive già esistenti. Senza JavaScript i collegamenti portano ai siti. Reduced motion, focus e dispositivi touch restano supportati.
