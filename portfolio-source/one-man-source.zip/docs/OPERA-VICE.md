# Archivio — sfondo a nastri precedente

Sostituito nella hero da `components/vice/TypographicBackdrop.tsx`. Questo asset resta soltanto in archivio; vedere `SFONDO-TIPOGRAFICO.md`.

# Sfondo originale ONE MAN

`public/assets/one-man-vice-art.webp` è un’opera generata appositamente per questa revisione con image_gen: texture pittorica, nastri magenta/corallo, riflessi turchesi, viola scuro e ombre tropicali. Nessun testo, fotografia di luogo reale o materiale del videogioco. È un’immagine di sfondo, non una simulazione di fluidi.

L’originale PNG generato è conservato nella cartella generated_images della workspace. Per il sito è stato codificato in WebP qualità 84, senza modifiche alla composizione: 210860 byte. Il precedente asset fotografico resta in archivio e non è utilizzato nella hero o nell’introduzione attiva.
