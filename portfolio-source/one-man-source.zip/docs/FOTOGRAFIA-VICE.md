# Fotografia della nuova apertura

Autori: Luise and Nic. Fonte: https://unsplash.com/photos/art-deco-building-with-palm-tree-and-sky-QfW9ESNpdiI/

La pagina fonte indica l’uso gratuito sotto Unsplash License: https://unsplash.com/license. La fotografia è materiale di direzione artistica, non un progetto o luogo di lavoro attribuito a Salvatore. Credito anche nel footer del sito. Copia locale ottimizzata servita da public/assets/vice-portrait.webp, scaricata dal CDN ufficiale con larghezza 1600 e qualità 78. Nessun collegamento al gioco o uso di suoi materiali.
