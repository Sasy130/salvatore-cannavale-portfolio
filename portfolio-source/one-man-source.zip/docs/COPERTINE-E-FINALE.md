# Copertine dei siti e finale tipografico

La sezione progetti dichiara «I miei progetti» e «Ideati, disegnati e sviluppati da me», come richiesto dal titolare. I progetti restano personali o redesign indipendenti, con descrizioni che identificano le funzionalità dimostrative. Nessuna attribuzione di clienti o risultati.

Le nuove copertine in `public/assets/project-covers/` sono schermate delle pagine pubbliche dei progetti esistenti sul dominio. Dodici sono nuove catture; per VELMORA si conserva la schermata integrale già disponibile, ricodificata in WebP, perché il nuovo rendering nella macchina di cattura non garantisce una vista affidabile. Nessuna copertina generica aggiunta. La resa usa object-fit:contain e il rapporto della cattura per conservare i contenuti della pagina. Le vecchie copertine restano in archivio. Dati e percorsi attivi in `lib/restored-projects.ts`.

La sezione Metodo è rimossa dalla homepage e dal suo menu. Il componente precedente resta conservato nel sorgente come archivio. L'ancora #indice conduce alla sezione progetti per compatibilità.

`components/vice/FinalContact.tsx` realizza il nuovo finale «Facciamo il prossimo segno»: segno S vettoriale, titolo editoriale, firma ONE MAN, email reale, copia, replay e ritorno all'inizio. Stile in `final-contact.css`; movimento limitato di segno e titolo coordinato con ScrollTrigger nella homepage. Reduced motion mantiene la composizione statica. L'indirizzo viene da `lib/portfolio-data.ts`, nessun form finto, nessuna dipendenza aggiunta.
