# Sfondo tipografico della hero

Lo sfondo attivo è `components/vice/TypographicBackdrop.tsx`: forme vettoriali originali ricavate da O, N e M, ritagliate sul viewport. Il vecchio WebP a nastri è conservato ma non è caricato dalla homepage.

Tre livelli si muovono con profondità diverse tramite variabili CSS. Gli eventi pointer passivi sulla hero supportano mouse e touch senza cattura dei gesti. Al rilascio del dito, uscita del mouse o annullamento del gesto, la composizione torna al centro. Il ciclo requestAnimationFrame termina a movimento assestato e si arresta fuori dalla hero. Reduced motion disabilita il movimento anche se la preferenza cambia durante la visita. Nessun canvas, WebGL, libreria o immagine esterna aggiunta.

Colori, opacità e maschera di contrasto si modificano in fondo a `components/vice/vice.css`; i tracciati e l'ampiezza del movimento nel componente. Le forme sono decorative (`aria-hidden`); nome e informazioni restano nell'HTML. L'apertura SC esistente rivela lo stesso sfondo della homepage. Menu, progetti e sezioni successive sono preservati.
