# Archivio — sezione rimossa dalla homepage

Il titolare ha richiesto la rimozione di questa sezione. Vedere `COPERTINE-E-FINALE.md` per la revisione attiva.

# Metodo creativo al posto dell'indice duplicato

Il blocco «Scegli dove entrare» ripeteva i tredici lavori già presenti nella sezione progetti. È sostituito da `components/vice/CreativeMethod.tsx`: titolo «Prima l'idea. Poi il segno.», tre passaggi — Identità, Interazione e Sviluppo — e un collegamento reale ai contatti.

Il menu della homepage mostra Metodo e punta a #metodo; #indice rimane un'ancora compatibile con i vecchi collegamenti. Il componente Navigation mantiene la voce storica nelle versioni archiviate tramite una proprietà opzionale. La sezione progetti e le sue anteprime restano invariate, così come intro, hero e sezioni successive.

CSS in creative-method.css. Su desktop un segno vettoriale ruota leggermente con lo scroll; su telefono è omesso per dare spazio ai testi. Il titolo ha una traslazione orizzontale di 18px legata allo scroll. Reduced motion disattiva queste animazioni. Tutti i contenuti sono leggibili senza JavaScript; nessuna nuova dipendenza, canvas o immagine.
