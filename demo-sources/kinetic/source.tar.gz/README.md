# KÍNETIC — Cinematic rebuild V2

Live Site: https://kinetic-art-of-movement-demo.one-man13.chatgpt.site (owner-private; same ChatGPT account).

## Latest media-only patch

The approved V2 design and master choreography are unchanged. Media now uses a short interpolated playhead, directional prefetch, safe last-valid-frame presentation and source-rate portrait samples. See [the audit, profile and tests](docs/VIDEO-SCROLL-FIX.md).

## Run

```sh
cd /workspace/sites/kinetic-demo
npm ci
npm run dev
```

Node 20.9+ required. Production/static preview: `npm run build` then `npm start` (port 3000; `PORT` overrides it). Next.js uses static export to `out/`, including every commercial route. The original V1 project in `/workspace/kinetic` is retained as a historical working copy; make updates in this hosted checkout.

## Verify

```sh
npm run lint
npm run typecheck
npm run build
npx playwright install chromium
npm test
```

In the current managed environment Chromium is already installed: `PLAYWRIGHT_BROWSERS_PATH=/tmp/kinetic-browsers npm test`. The suite starts a local static test server on port 4173 when needed. Test screenshots are saved to ignored `artifacts/`.

## Main files

- `components/film/Experience.tsx`: persistent stage, six acts, keyboard discipline tabs, profiles, events and working CTAs.
- `components/film/Director.tsx`: one GSAP timeline for all six acts; native scroll, precise scrubbing, scene visibility/focus, shared progress and cleanup.
- `components/film/FramePlayer.tsx`, `lib/playhead.ts`, `lib/sequence.ts`: real decoded frame playback, priority prefetch, obsolete-request cancellation, bounded bitmap cache, mobile variants and photographic fallback.
- `components/film/Scene3D.tsx`: scroll-driven folded red surface, camera approach and collapsing geometry. Demand rendering, capped DPR, no autoplay animation loop.
- `components/film/Scenography.tsx`: optional WebGL gating and failure boundary.
- `components/film/Silence.tsx`: 2.1-second light-slit intro; skippable and dismissed by scrolling or keyboard input.
- `lib/film.ts`: chapter registry, reading poses, observed footage cues and shared animation signals.
- `app/film.css`: visual direction, dedicated mobile composition, static/reduced-motion fallback.
- `components/Header.tsx`, `Footer.tsx`: direct navigation, accessible fullscreen menu, shared visual identity.
- `app/[section]/page.tsx`, `app/courses/[slug]/page.tsx`, `JoinForm.tsx`: preserved commercial routes and honest demo form.
- `docs/REBUILD-V2.md`: audit, actual changes, cue timings, test evidence and limits.
- `ASSETS.md`: local media provenance and licenses.

## Demo scope

KÍNETIC is a fictional academy. Faculty, programs and events are illustrative. Photos are dance studies and do not depict or endorse the invented instructor identities. The form validates in the browser and explicitly reports that nothing was sent or booked. No personal data is stored or transmitted by the JavaScript demo form.

The film uses licensed 2D footage, not an alpha-masked dancer or a rotatable 3D person. The WebGL cloth is a procedural surface and the floor is a scenic overlay, not a physical reconstruction of the filmed theatre. Mobile uses a portrait crop of the actual footage. Physical Safari/iOS/Android testing and Core Web Vitals measurement remain production validation tasks.
