import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests",
  timeout: 45000,
  reporter: "list",
  use: {
    baseURL: "http://127.0.0.1:4173",
    headless: true,
    viewport: { width: 1440, height: 900 },
    launchOptions: { args: ["--enable-unsafe-swiftshader"] },
  },
  webServer: {
    command:
      "python -m http.server 4173 --directory out --bind 0.0.0.0 2>/tmp/kinetic-v2-http.log",
    url: "http://127.0.0.1:4173",
    reuseExistingServer: true,
  },
});
