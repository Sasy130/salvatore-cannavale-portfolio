/** A short, time-based filter for the media only. Scene/GSAP targets are untouched. */
export class MediaPlayhead {
  target: number;
  visual: number;
  private updatedAt: number;
  private previousAt: number;
  constructor(progress: number, now: number) {
    this.target = this.visual = progress;
    this.updatedAt = this.previousAt = now;
  }
  setTarget(progress: number, now: number) {
    const next = Math.max(0, Math.min(1, progress));
    if (Math.abs(next - this.target) > 1e-9) {
      if (this.visual === this.target) this.previousAt = now;
      this.target = next;
      this.updatedAt = now;
    }
  }
  advance(now: number, frameCount: number) {
    const dt = Math.max(0, Math.min(50, now - this.previousAt));
    this.previousAt = now;
    const delta = this.target - this.visual;
    // Smaller wheel pulses are distributed across paints. Large seeks catch up faster.
    const responseMs = Math.abs(delta) > 0.08 ? 30 : 45;
    this.visual += delta * -Math.expm1(-dt / responseMs);
    // Exact rest: no endless easing or residual drift once the gesture stops.
    if (
      now - this.updatedAt >= 140 ||
      Math.abs(this.target - this.visual) * (frameCount - 1) < 0.12
    ) {
      this.visual = this.target;
    }
    return { progress: this.visual, settled: this.visual === this.target };
  }
}

/** Never show a future sample and then jump backwards when an older fetch finishes. */
export function playbackFrame(
  available: Iterable<number>,
  desired: number,
  previous: number,
): number {
  const frames = [...available];
  if (frames.includes(desired)) return desired;
  if (previous < 0) return -1; // Keep the poster until the requested starting sample exists.
  const forward = desired > previous;
  const candidates = frames.filter((index) =>
    forward
      ? index > previous && index < desired
      : index < previous && index > desired,
  );
  if (!candidates.length) return previous;
  return forward ? Math.max(...candidates) : Math.min(...candidates);
}
