export const FILM_SECONDS = 12;
export const chapters = [
  { id: "awakening", number: "I", name: "The awakening", at: 0, end: 0.205 },
  { id: "body", number: "II", name: "The body", at: 0.245, end: 0.365 },
  {
    id: "disciplines",
    number: "III",
    name: "The disciplines",
    at: 0.415,
    end: 0.58,
  },
  { id: "people", number: "IV", name: "The people", at: 0.635, end: 0.735 },
  { id: "stage", number: "V", name: "The stage", at: 0.77, end: 0.88 },
  { id: "your-move", number: "VI", name: "Your move", at: 0.945, end: 1 },
] as const;
// Manually observed in the actual Pexels footage. Times are clip-relative.
// No skeleton tracking, alpha footage, or invented jump is implied.
export const footageCues = [
  { time: 0, name: "chest lifted, skirt extended" },
  { time: 2, name: "turn, back toward camera" },
  { time: 4, name: "forward fold and descent" },
  { time: 6, name: "low reach across the floor" },
  { time: 7, name: "rise from the floor" },
  { time: 10, name: "arm arcs above the shoulder" },
  { time: 11, name: "arms extend outwards" },
];
export const film = {
  progress: 0,
  media: 0,
  frame: 0,
  desiredFrame: 0,
  cache: 0,
  pending: 0,
  errors: 0,
  chapter: 0,
  discipline: 1,
  reduced: false,
  fps: 0,
};
const listeners = new Set<() => void>();
export function subscribeFilm(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}
export function emitFilm() {
  listeners.forEach((listener) => listener());
}
export function seekChapter(index: number) {
  const reel = document.querySelector<HTMLElement>(".film-reel");
  if (!reel) return;
  const chapter = chapters[index];
  if (film.reduced) {
    document.getElementById(chapter.id)?.scrollIntoView({ behavior: "auto" });
    return;
  }
  const top = reel.getBoundingClientRect().top + scrollY;
  const travel = reel.offsetHeight - innerHeight;
  window.scrollTo({
    top:
      top + travel * Math.min(0.99, [0, 0.29, 0.47, 0.685, 0.82, 0.99][index]),
    behavior: "instant",
  });
}
export function pulse(value: number, start: number, peak: number, end: number) {
  return Math.max(
    0,
    Math.min((value - start) / (peak - start), (end - value) / (end - peak), 1),
  );
}
