export const courses = [
  {
    slug: "classical",
    name: "Classical",
    tag: "Precision becomes poetry.",
    description:
      "Build your foundation. Discover alignment, musicality and the freedom that comes from technique.",
    level: "Foundation / Intermediate",
    time: "Mon & Wed · 18:00–19:30",
    teacher: "Elena Moreau",
    image: "/demos/kinetic/images/dance.jpg",
  },
  {
    slug: "contemporary",
    name: "Contemporary",
    tag: "Let the body speak.",
    description:
      "Explore weight, breath and space. An expressive practice rooted in floorwork and creative exploration.",
    level: "All levels",
    time: "Tue & Thu · 19:00–20:30",
    teacher: "Luca Ferri",
    image: "/demos/kinetic/images/contemporary.jpg",
  },
  {
    slug: "urban",
    name: "Urban",
    tag: "Your rhythm. Your rules.",
    description:
      "Find your groove through musicality, freestyle and choreography. Bring your energy. Make it yours.",
    level: "Open / Advanced",
    time: "Wed & Fri · 20:00–21:30",
    teacher: "Alex Rivers",
    image: "/demos/kinetic/images/urban.jpg",
  },
];
export const artists = [
  {
    name: "Elena Moreau",
    discipline: "Classical",
    bio: "A practice shaped by precision and curiosity. Elena connects the discipline of ballet with each dancer’s individual expression.",
  },
  {
    name: "Luca Ferri",
    discipline: "Contemporary",
    bio: "Luca explores the space between instinct and intention through floorwork, improvisation and collaborative creation.",
  },
  {
    name: "Alex Rivers",
    discipline: "Urban",
    bio: "Rooted in freestyle culture, Alex brings musicality, connection and an unmistakable energy to the studio.",
  },
];
export const scenes = [
  "First breath",
  "Movement",
  "Beyond the body",
  "Find your movement",
  "Break the rules",
  "The artists",
  "We become one",
  "Your move",
];
