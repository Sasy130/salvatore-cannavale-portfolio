export const MAX_FRAMES = 20;
export const SOURCE_FRAME_COUNT = 288;
type Entry = { controller: AbortController };
/** Bounded decode window around the displayed playhead, with the latest GSAP target protected. */
export class FrameSequence {
  readonly cache = new Map<number, ImageBitmap>();
  readonly pending = new Map<number, Entry>();
  readonly failed = new Set<number>();
  readonly count = SOURCE_FRAME_COUNT;
  private disposed = false;
  private position = 0;
  private target = 0;
  private direction = 0;
  constructor(
    readonly mobile: boolean,
    private onChange: () => void,
  ) {}
  request(position: number, target = position) {
    const clamp = (value: number) =>
      Math.max(0, Math.min(this.count - 1, Math.round(value)));
    const next = clamp(position);
    const goal = clamp(target);
    this.direction =
      Math.sign(goal - next) ||
      Math.sign(next - this.position) ||
      this.direction;
    this.position = next;
    this.target = goal;
    // Protect the destination fetch even when a fast seek outruns intermediate decoding.
    for (const [index, entry] of this.pending) {
      if (Math.abs(index - next) > 14 && Math.abs(index - goal) > 1) {
        entry.controller.abort();
        this.pending.delete(index);
      }
    }
    this.pump();
  }
  private queue() {
    const direction = this.direction || 1;
    const ahead = this.mobile ? 6 : 10;
    const behind = this.mobile ? 4 : 6;
    const queue = [this.position, this.position + direction, this.target];
    for (let offset = 1; offset <= Math.max(ahead, behind); offset++) {
      if (offset <= ahead) queue.push(this.position + direction * offset);
      if (offset <= behind) queue.push(this.position - direction * offset);
    }
    return [...new Set(queue)].filter(
      (index) => index >= 0 && index < this.count,
    );
  }
  private pump() {
    if (this.disposed) return;
    for (const index of this.queue()) {
      if (this.pending.size >= (this.mobile ? 3 : 4)) break;
      if (
        this.cache.has(index) ||
        this.pending.has(index) ||
        this.failed.has(index)
      )
        continue;
      this.load(index);
    }
  }
  private load(index: number) {
    const controller = new AbortController();
    this.pending.set(index, { controller });
    const src = `/demos/kinetic/media/${this.mobile ? "film-mobile-24" : "film-hd"}/${String(index + 1).padStart(3, "0")}.webp`;
    fetch(src, { signal: controller.signal, cache: "force-cache" })
      .then((response) => {
        if (!response.ok) throw new Error("Frame unavailable");
        return response.blob();
      })
      .then((blob) => createImageBitmap(blob))
      .then((bitmap) => {
        if (this.disposed || controller.signal.aborted) {
          bitmap.close();
          return;
        }
        this.cache.set(index, bitmap);
        while (this.cache.size > (this.mobile ? 12 : MAX_FRAMES)) {
          // Keep both the displayed neighbourhood and the exact destination hot.
          const distance = (frame: number) =>
            Math.min(
              Math.abs(frame - this.position),
              Math.abs(frame - this.target) + 2,
            );
          const farthest = [...this.cache.keys()].sort(
            (a, b) => distance(b) - distance(a),
          )[0];
          this.cache.get(farthest)?.close();
          this.cache.delete(farthest);
        }
      })
      .catch((error) => {
        if (error.name !== "AbortError" && !this.disposed)
          this.failed.add(index);
      })
      .finally(() => {
        if (this.pending.get(index)?.controller === controller)
          this.pending.delete(index);
        if (!this.disposed) {
          this.onChange();
          this.pump();
        }
      });
  }
  nearest(target: number) {
    return [...this.cache.keys()].reduce(
      (best, index) =>
        Math.abs(index - target) < Math.abs(best - target) ? index : best,
      -10000,
    );
  }
  dispose() {
    this.disposed = true;
    this.pending.forEach((entry) => entry.controller.abort());
    this.pending.clear();
    this.cache.forEach((bitmap) => bitmap.close());
    this.cache.clear();
  }
}
