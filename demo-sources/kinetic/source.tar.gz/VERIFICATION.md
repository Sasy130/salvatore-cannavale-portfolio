# Latest update — media-only scroll smoothing

Lint, TypeScript and production export passed. **14 tests passed in 35.4 seconds**. The paired wheel profile recorded 27 displayed pose changes versus 10 before, with the same exact final frame. See `docs/VIDEO-SCROLL-FIX.md` for causes, files, measurements and device/source limits. The following report is the earlier V2 rebuild verification.

# KÍNETIC V2 — verification, 2026-11-14

Final source checks:

- ESLint: passed, no errors or warnings.
- TypeScript `tsc --noEmit`: passed.
- Next.js production/static-export build: passed.
- Chromium suite: **8 tests passed in 23.6 seconds**.
- Separate all-act console audit: **no JavaScript or console errors**, with **one active WebGL canvas** in the desktop browser.
- Asset/export audit: 288 HD frames + 144 portrait mobile frames, SSR opening light reveal, every commercial route exported.

## Actual browser coverage

1. Intro skip, forward frame progress, frozen frame/pixels while stopped, exact same canvas pixel data after reverse return to the same scroll position.
2. All five named transition windows, a single persistent sticky stage, fast bidirectional seeks, decoded cache and request bounds.
3. Six chapter jumps, discipline environment selection, arrow-key tabs, trial course preselection, native fullscreen menu Escape/focus restoration, final booking CTA.
4. Mobile composition, horizontal overflow, midpoint reload, resize into desktop resolution, bounded cache.
5. Reduced-motion visibility of every act and usable poster/navigation when all frame requests fail.
6. All commercial routes at 390px, native invalid-form prevention, honest local demo feedback after valid input.
7. Deliberately delayed frame responses, convergence to the target, no frame drift after stopping, navigable menu while media loads.
8. Deliberately unavailable WebGL, CSS fabric fallback, complete film navigation and final CTA.

Visual inspection covered the desktop opening, body, disciplines, faculty, stage, final invitation, fabric/collapse/echo/light transition windows and six mobile positions. Screenshots are local under `artifacts/` and are not bundled into production.

Performance work is verified through decoded-cache limits (20 HD / 12 mobile), request limits (4 / 3), cancellation, progressive fetching, DPR cap, reduced-motion/mobile WebGL gating and demand rendering restricted to the active 3D transition interval. This is not a Core Web Vitals score or a real-device FPS guarantee. Optional debug `?debug=1` measures rAF cadence only while enabled.

WebGL was exercised in headless Chromium, with a separate forced-failure fallback case. Physical iOS/Android, Safari/Firefox and field performance remain unverified. No production booking delivery is claimed.
