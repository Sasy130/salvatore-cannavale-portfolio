"use client";
import { useEffect, useRef, useState } from "react";
export default function JoinForm() {
  const [message, setMessage] = useState("");
  const select = useRef<HTMLSelectElement>(null);
  useEffect(() => {
    const value = new URLSearchParams(location.search).get("course");
    if (
      value &&
      ["classical", "contemporary", "urban"].includes(value) &&
      select.current
    )
      select.current.value = value[0].toUpperCase() + value.slice(1);
  }, []);
  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        setMessage(
          `Thanks, ${data.get("name")}. Your ${data.get("course")} trial request has been validated for this demo. Nothing has been sent or booked.`,
        );
      }}
    >
      <p className="eyebrow">MAKE THE FIRST MOVE</p>
      <label>
        Your name
        <input
          name="name"
          required
          autoComplete="name"
          placeholder="First and last name"
          maxLength={100}
        />
      </label>
      <label>
        Email address
        <input
          name="email"
          type="email"
          required
          autoComplete="email"
          placeholder="you@example.com"
        />
      </label>
      <label>
        Your discipline
        <select ref={select} name="course" required defaultValue="Contemporary">
          <option>Classical</option>
          <option>Contemporary</option>
          <option>Urban</option>
        </select>
      </label>
      <label>
        A little about you
        <textarea
          name="message"
          placeholder="Your experience, your questions, your ambitions."
          rows={3}
          maxLength={2000}
        />
      </label>
      <label className="consent">
        <input type="checkbox" required />I understand this is a demonstration
        and no booking will be made.
      </label>
      <button className="pill dark" type="submit">
        Preview my trial request <span>↗</span>
      </button>
      <p role="status" className="form-status">
        {message}
      </p>
      <small>Demo only. No personal data is transmitted or stored.</small>
    </form>
  );
}
