"use client";
import Link from "next/link";
import { useState } from "react";
import Image from "next/image";
import { courses } from "@/lib/data";
export default function CourseList() {
  const [filter, setFilter] = useState("All");
  return (
    <>
      <div className="filter-row" aria-label="Filter courses">
        {["All", "Foundation", "Open"].map((value) => (
          <button
            key={value}
            aria-pressed={filter === value}
            onClick={() => setFilter(value)}
          >
            {value === "All"
              ? "All levels"
              : value === "Foundation"
                ? "Foundation"
                : "Open level"}
          </button>
        ))}
      </div>
      <div className="course-list">
        {courses
          .filter(
            (c) =>
              filter === "All" ||
              (filter === "Foundation"
                ? c.slug === "classical"
                : c.slug !== "classical"),
          )
          .map((course) => (
            <article key={course.slug}>
              <Link className="list-image" href={"/courses/" + course.slug}>
                <Image
                  src={course.image}
                  alt={course.name + " dance study"}
                  fill
                  sizes="(max-width:700px) 90vw, 30vw"
                />
              </Link>
              <h2>{course.name}</h2>
              <p>{course.description}</p>
              <dl>
                <div>
                  <dt>LEVEL</dt>
                  <dd>{course.level}</dd>
                </div>
              </dl>
              <Link className="text-link" href={"/courses/" + course.slug}>
                Discover the program ↗
              </Link>
            </article>
          ))}
      </div>
    </>
  );
}
