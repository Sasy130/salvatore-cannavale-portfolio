import Link from "next/link";
export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-top">
        <p>
          Independent minds.
          <br />
          Moving together.
        </p>
        <div>
          <Link href="/academy">The academy ↗</Link>
          <Link href="/courses">Find your class ↗</Link>
          <Link href="/contact">Get in touch ↗</Link>
        </div>
      </div>
      <div className="footer-bottom">
        <span>THE ART OF MOVEMENT / CLASSICAL · CONTEMPORARY · URBAN</span>
        <span>
          © {new Date().getFullYear()} KÍNETIC · A concept academy. All programs
          are illustrative.
        </span>
      </div>
      <Link className="footer-wordmark" href="/" aria-label="Kinetic home">
        KÍNETIC
      </Link>
    </footer>
  );
}
