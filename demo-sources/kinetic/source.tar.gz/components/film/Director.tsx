"use client";
import { useLayoutEffect, type RefObject } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  chapters,
  film,
  emitFilm,
  FILM_SECONDS,
  footageCues,
} from "@/lib/film";
export default function useFilmDirector(
  root: RefObject<HTMLDivElement | null>,
) {
  useLayoutEffect(() => {
    const reel = root.current;
    if (!reel) return;
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia(reel);
    const panels = [...reel.querySelectorAll<HTMLElement>("[data-act]")];
    const nav = [
      ...reel.querySelectorAll<HTMLButtonElement>(".film-chapter-nav button"),
    ];
    const debug = reel.querySelector<HTMLOutputElement>(".film-debug");
    if (debug)
      debug.hidden =
        process.env.NODE_ENV !== "development" &&
        !new URLSearchParams(location.search).has("debug");
    const disposePanels = () => {
      panels.forEach((panel) => {
        panel.inert = false;
        panel.removeAttribute("aria-hidden");
      });
      document.body.classList.remove("film-is-playing", "film-is-light");
      reel.classList.remove("is-directed");
      reel.style.removeProperty("--film-progress");
    };
    media.add("(prefers-reduced-motion: no-preference)", () => {
      film.reduced = false;
      film.progress = 0;
      film.media = 0;
      reel.classList.add("is-directed");
      document.body.classList.add("film-is-playing");
      let active = -1;
      let debugRaf = 0;
      let debugFrames = 0;
      let debugStart = performance.now();
      const master = gsap.timeline({
        defaults: { ease: "none" },
        onUpdate: () => {
          const p = master.progress();
          film.progress = p;
          film.media = Math.min(1, p / 0.92);
          const chapter = Math.max(
            0,
            chapters.findLastIndex((c) => p >= c.at),
          );
          film.chapter = chapter;
          reel.dataset.progress = p.toFixed(5);
          reel.dataset.chapter = chapters[chapter].id;
          reel.style.setProperty("--film-progress", String(p));
          reel.style.setProperty(
            "--film-ui",
            p > 0.925 ? "#101014" : "#e9e5dc",
          );
          document.body.classList.toggle("film-is-light", p > 0.925);
          if (active !== chapter) {
            active = chapter;
            panels.forEach((panel, i) => {
              panel.inert = i !== chapter;
              panel.setAttribute("aria-hidden", String(i !== chapter));
            });
            nav.forEach((button, i) => {
              if (i === chapter) button.setAttribute("aria-current", "step");
              else button.removeAttribute("aria-current");
            });
            const label = reel.querySelector(".film-live-chapter");
            if (label)
              label.textContent = `${chapters[chapter].number} / ${chapters[chapter].name.toUpperCase()}`;
          }
          emitFilm();
        },
        scrollTrigger: {
          trigger: reel,
          start: "top top",
          end: "bottom bottom",
          scrub: true,
          invalidateOnRefresh: true,
          onRefresh: () => emitFilm(),
        },
      });
      master.to({}, { duration: 1 }, 0);
      gsap.set(".film-panel:not(.act-awakening)", { autoAlpha: 0 });
      // 01 — Body to typography: the real opening turn drives separated letter planes.
      master
        .to(
          ".wordmark-letter",
          {
            x: (i: number) => (i - 3) * 95,
            y: (i: number) => (i % 2 ? -110 : 75),
            rotation: (i: number) => (i - 3) * 5,
            scale: 1.2,
            stagger: { amount: 0.022 },
            duration: 0.115,
          },
          0.032,
        )
        .to(".film-wordmark", { opacity: 0, duration: 0.035 }, 0.133)
        .fromTo(
          ".giant-echo",
          { clipPath: "inset(0 100% 0 0)", xPercent: -5 },
          { clipPath: "inset(0 0% 0 0)", xPercent: 0, duration: 0.09 },
          0.065,
        )
        .to(
          ".giant-echo",
          { xPercent: 20, scale: 1.13, opacity: 0, duration: 0.04 },
          0.155,
        )
        .to(".awaken-claim", { yPercent: -30, duration: 0.11 }, 0.055)
        .to(
          ".awakening-note,.awakening-disciplines",
          { opacity: 0, duration: 0.035 },
          0.14,
        )
        .to(
          ".film-dancer",
          { scale: 1.38, xPercent: 8, yPercent: 3, duration: 0.17 },
          0,
        )
        .to(
          ".stage-reticle",
          { rotation: 70, scale: 1.7, opacity: 0, duration: 0.13 },
          0.08,
        );
      // 02 — Fabric portal: skirt/turn cue, complete red occlusion, then manifesto reveal.
      master
        .set(".fabric-portal", { visibility: "visible" }, 0.16)
        .fromTo(
          ".fabric-portal",
          { xPercent: 125, rotation: -18, scale: 1.6 },
          { xPercent: -125, rotation: 16, scale: 1.5, duration: 0.125 },
          0.16,
        )
        .set(".act-awakening", { autoAlpha: 0 }, 0.22)
        .set(".act-body", { autoAlpha: 1 }, 0.225)
        .fromTo(
          ".act-body h2",
          { y: 90, clipPath: "inset(100% 0 0 0)" },
          { y: 0, clipPath: "inset(0% 0 0 0)", duration: 0.055 },
          0.225,
        )
        .fromTo(".body-manifesto", { x: 60 }, { x: 0, duration: 0.06 }, 0.23)
        .to(
          ".film-dancer",
          {
            scale: 1.22,
            xPercent: -25,
            yPercent: 0,
            opacity: 0.5,
            duration: 0.07,
          },
          0.22,
        )
        .set(".fabric-portal", { visibility: "hidden" }, 0.286);
      // 03 — Stage collapse: geometric floor breaks as the real dancer descends.
      master
        .fromTo(
          ".stage-floor",
          { autoAlpha: 0 },
          { autoAlpha: 0.8, duration: 0.025 },
          0.3,
        )
        .to(
          ".stage-floor i",
          {
            yPercent: (i: number) => 160 + (i % 3) * 75,
            xPercent: (i: number) => (i % 2 ? 150 : -150),
            rotationX: 75,
            rotationZ: (i: number) => (i - 6) * 12,
            z: 180,
            stagger: { amount: 0.018 },
            duration: 0.065,
          },
          0.336,
        )
        .to(".stage-floor", { autoAlpha: 0, duration: 0.025 }, 0.397)
        .to(
          ".act-body h2",
          { yPercent: -30, clipPath: "inset(0 0 100% 0)", duration: 0.045 },
          0.34,
        )
        .set(".act-body", { autoAlpha: 0 }, 0.385)
        .set(".act-disciplines", { autoAlpha: 1 }, 0.395)
        .fromTo(
          ".act-disciplines h2",
          { xPercent: -25, clipPath: "inset(0 100% 0 0)" },
          { xPercent: 0, clipPath: "inset(0 0% 0 0)", duration: 0.06 },
          0.392,
        )
        .fromTo(
          ".discipline-visual",
          { clipPath: "polygon(50% 0,50% 0,50% 100%,50% 100%)", rotation: 9 },
          {
            clipPath: "polygon(0 0,100% 0,100% 100%,0 100%)",
            rotation: 0,
            duration: 0.065,
          },
          0.394,
        )
        .fromTo(
          ".film-discipline-tabs",
          { y: 80 },
          { y: 0, duration: 0.05 },
          0.398,
        )
        .to(
          ".film-dancer",
          { xPercent: -20, scale: 1.05, opacity: 0.4, duration: 0.07 },
          0.38,
        );
      // 04 — Motion echo: actual neighbouring frames become photographic windows.
      master
        .to(
          ".film-dancer",
          { xPercent: 0, scale: 1.18, opacity: 0.85, duration: 0.045 },
          0.535,
        )
        .fromTo(
          ".echo-one",
          { autoAlpha: 0, xPercent: -110, rotation: -18, scale: 0.65 },
          {
            autoAlpha: 0.85,
            xPercent: -30,
            rotation: -9,
            scale: 1,
            duration: 0.055,
          },
          0.535,
        )
        .fromTo(
          ".echo-two",
          { autoAlpha: 0, xPercent: 110, rotation: 18, scale: 0.65 },
          {
            autoAlpha: 0.85,
            xPercent: 30,
            rotation: 8,
            scale: 1,
            duration: 0.055,
          },
          0.548,
        )
        .to(
          ".act-disciplines h2,.film-discipline-tabs,.film-course-copy",
          { y: -70, clipPath: "inset(0 0 100% 0)", duration: 0.045 },
          0.565,
        )
        .to(
          ".discipline-visual",
          {
            scale: 0.8,
            rotation: -8,
            xPercent: 80,
            autoAlpha: 0,
            duration: 0.05,
          },
          0.568,
        )
        .set(".act-disciplines", { autoAlpha: 0 }, 0.617)
        .to(
          ".echo-one",
          {
            xPercent: -160,
            scale: 0.8,
            rotation: 0,
            autoAlpha: 0,
            duration: 0.05,
          },
          0.59,
        )
        .to(
          ".echo-two",
          {
            xPercent: 155,
            scale: 0.8,
            rotation: 0,
            autoAlpha: 0,
            duration: 0.05,
          },
          0.6,
        )
        .set(".act-people", { autoAlpha: 1 }, 0.615)
        .fromTo(
          ".act-people h2",
          { yPercent: 70, clipPath: "inset(100% 0 0 0)" },
          { yPercent: 0, clipPath: "inset(0% 0 0 0)", duration: 0.05 },
          0.615,
        )
        .fromTo(
          ".film-artist",
          { yPercent: 145, rotation: (i: number) => (i - 1) * 12 },
          {
            yPercent: 0,
            rotation: 0,
            stagger: { amount: 0.018 },
            duration: 0.055,
          },
          0.601,
        )
        .to(
          ".film-dancer",
          { scale: 1.06, opacity: 0.2, duration: 0.045 },
          0.62,
        );
      // Shared image aperture joins the faculty scenography to the collective stage.
      master
        .to(
          ".film-artist",
          {
            yPercent: -25,
            rotationY: (i: number) => (i - 1) * 35,
            scale: 0.86,
            stagger: { amount: 0.012 },
            duration: 0.045,
          },
          0.724,
        )
        .fromTo(
          ".stage-photograph",
          {
            clipPath: "polygon(45% 0,55% 0,55% 100%,45% 100%)",
            scale: 1.3,
            autoAlpha: 0,
          },
          {
            clipPath: "polygon(0% 0,100% 0,100% 100%,0% 100%)",
            scale: 1,
            autoAlpha: 1,
            duration: 0.07,
          },
          0.724,
        )
        .to(
          ".act-people h2",
          { yPercent: -70, clipPath: "inset(0 0 100% 0)", duration: 0.035 },
          0.724,
        )
        .set(".act-people", { autoAlpha: 0 }, 0.767)
        .set(".act-stage", { autoAlpha: 1 }, 0.748)
        .fromTo(
          ".act-stage h2",
          { xPercent: -30, clipPath: "inset(0 100% 0 0)" },
          { xPercent: 0, clipPath: "inset(0 0% 0 0)", duration: 0.06 },
          0.748,
        )
        .fromTo(
          ".film-events",
          { xPercent: 40 },
          { xPercent: 0, duration: 0.055 },
          0.756,
        )
        .to(".film-dancer", { opacity: 0, duration: 0.03 }, 0.738)
        .to(".stage-photograph", { scale: 1.08, duration: 0.12 }, 0.785)
        .to(
          ".film-dancer",
          { opacity: 0.58, scale: 1.22, xPercent: 0, duration: 0.035 },
          0.861,
        );
      // 05 — Light explosion: the actual final arm opening carries the ivory reveal.
      master
        .fromTo(
          ".light-explosion",
          { scale: 0, opacity: 1 },
          { scale: 1.2, duration: 0.075 },
          0.868,
        )
        .to(
          ".act-stage h2",
          { scale: 1.15, yPercent: -10, duration: 0.055 },
          0.872,
        )
        .set(".act-stage", { autoAlpha: 0 }, 0.925)
        .set(".act-your-move", { autoAlpha: 1 }, 0.929)
        .fromTo(
          ".act-your-move h2",
          { yPercent: 40, clipPath: "inset(100% 0 0 0)" },
          { yPercent: 0, clipPath: "inset(0% 0 0 0)", duration: 0.045 },
          0.929,
        )
        .fromTo(
          ".final-invitation",
          { y: 70 },
          { y: 0, duration: 0.035 },
          0.948,
        )
        .to(".film-dancer", { opacity: 0, duration: 0.025 }, 0.92);
      master.progress(
        ScrollTrigger.getAll().find((t) => t.vars.trigger === reel)?.progress ||
          0,
      );
      emitFilm();
      if (debug && !debug.hidden) {
        const measure = (now: number) => {
          debugFrames++;
          if (now - debugStart >= 500) {
            film.fps = Math.round((debugFrames * 1000) / (now - debugStart));
            debugFrames = 0;
            debugStart = now;
            const cue = footageCues.findLast(
              (c) => c.time <= film.media * FILM_SECONDS,
            );
            debug.textContent = `${chapters[film.chapter].id} · p ${film.progress.toFixed(3)} · frame ${film.frame}/${film.desiredFrame} · cache ${film.cache}/${innerWidth < 700 ? 12 : 20} · pending ${film.pending} · ${film.fps} rAF fps · errors ${film.errors} · cue ${cue?.name}`;
          }
          debugRaf = requestAnimationFrame(measure);
        };
        debugRaf = requestAnimationFrame(measure);
      }
      const refresh = () => ScrollTrigger.refresh();
      document.fonts.ready.then(() => {
        if (reel.isConnected) refresh();
      });
      window.addEventListener("load", refresh);
      return () => {
        window.removeEventListener("load", refresh);
        cancelAnimationFrame(debugRaf);
        master.scrollTrigger?.kill();
        master.revert();
        disposePanels();
      };
    });
    media.add("(prefers-reduced-motion: reduce)", () => {
      film.reduced = true;
      film.media = 0;
      disposePanels();
      emitFilm();
      return () => {
        film.reduced = false;
      };
    });
    return () => {
      media.revert();
      disposePanels();
    };
  }, [root]);
  return null;
}
