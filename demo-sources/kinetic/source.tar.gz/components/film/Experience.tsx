"use client";
import Link from "next/link";
import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { artists, courses } from "@/lib/data";
import { chapters, film, emitFilm, seekChapter } from "@/lib/film";
import FramePlayer from "./FramePlayer";
import useFilmDirector from "./Director";
import Silence from "./Silence";
import Scenography from "./Scenography";
export default function Experience() {
  const root = useRef<HTMLDivElement>(null);
  useFilmDirector(root);
  const [discipline, setDiscipline] = useState(1);
  const course = courses[discipline];
  useEffect(() => {
    film.discipline = discipline;
    emitFilm();
  }, [discipline]);
  return (
    <div ref={root} className="film-reel" data-discipline={course.slug}>
      <Silence />
      <div className="film-stage">
        <div className="film-backdrop" aria-hidden="true" />
        <div className="film-spotlight" aria-hidden="true" />
        <FramePlayer />
        <div className="film-grain" aria-hidden="true" />
        <div className="fabric-portal" aria-hidden="true">
          <i />
          <i />
          <i />
        </div>
        <Scenography />
        <div className="stage-floor" aria-hidden="true">
          {Array.from({ length: 12 }, (_, i) => (
            <i key={i} />
          ))}
        </div>
        <div className="echo-window echo-one" aria-hidden="true">
          <Image src="/demos/kinetic/images/contemporary.jpg" alt="" fill sizes="35vw" />
        </div>
        <div className="echo-window echo-two" aria-hidden="true">
          <Image src="/demos/kinetic/images/urban.jpg" alt="" fill sizes="35vw" />
        </div>
        <div className="stage-photograph" aria-hidden="true">
          <Image src="/demos/kinetic/images/ensemble.jpg" alt="" fill sizes="100vw" />
        </div>
        <div className="light-explosion" aria-hidden="true" />
        <div className="stage-reticle" aria-hidden="true">
          <i />
          <span>THE BODY KNOWS.</span>
        </div>

        <section
          className="film-panel act-awakening"
          id="awakening"
          data-act="0"
          aria-label="Act I — The awakening"
        >
          <div className="act-eyebrow">
            <span>I / THE AWAKENING</span>
            <span>AN ACADEMY. AN ATTITUDE.</span>
          </div>
          <h1 className="film-wordmark" aria-label="KÍNETIC">
            <span aria-hidden="true">
              {"KÍNETIC".split("").map((letter, i) => (
                <b className="wordmark-letter" key={i}>
                  {letter}
                </b>
              ))}
            </span>
            <sup>®</sup>
          </h1>
          <div className="awaken-claim">
            <span>DON’T JUST WATCH.</span>
            <em>FEEL THE MOVEMENT.</em>
          </div>
          <p className="awakening-note">
            Classical roots. Contemporary minds.
            <br />
            Uncompromising urban energy.
          </p>
          <div className="awakening-disciplines">
            CLASSICAL
            <br />
            CONTEMPORARY
            <br />
            URBAN
          </div>
          <span className="giant-echo" aria-hidden="true">
            MOVE.
          </span>
        </section>

        <section
          className="film-panel act-body"
          id="body"
          data-act="1"
          aria-label="Act II — The body"
        >
          <div className="act-eyebrow">
            <span>II / THE BODY</span>
            <span>LESS THINKING. MORE FEELING.</span>
          </div>
          <span className="body-coordinate" aria-hidden="true">
            BEYOND
            <br />
            THE BODY.
          </span>
          <h2>
            NOT STEPS.
            <br />
            <em>Instinct.</em>
          </h2>
          <div className="body-manifesto">
            <svg
              className="editorial-cross"
              viewBox="0 0 100 100"
              aria-hidden="true"
            >
              <path
                d="M50 0v100M0 50h100M15 15l70 70M15 85l70-70"
                stroke="currentColor"
                strokeWidth="8"
              />
            </svg>
            <div>
              <p>
                Before the first step, there is a feeling.
                <br />
                We give it room to become something.
              </p>
              <p>
                Technique is our foundation. Expression is our language. This is
                a space to move beyond what you know — and into who you are.
              </p>
              <Link className="film-text-link" href="/academy">
                This is KÍNETIC <span>↗</span>
              </Link>
            </div>
          </div>
        </section>

        <section
          className="film-panel act-disciplines"
          id="disciplines"
          data-act="2"
          aria-label="Act III — The disciplines"
        >
          <div className="act-eyebrow">
            <span>III / THE DISCIPLINES</span>
            <span>THREE WORLDS. ONE OBSESSION.</span>
          </div>
          <h2>
            FIND YOUR
            <br />
            <em>movement.</em>
          </h2>
          <div className="discipline-visual">
            <Image
              key={course.slug}
              src={course.image}
              alt={course.name + " dance study"}
              fill
              loading="eager"
              sizes="(max-width:700px) 55vw, 37vw"
            />
            <span>
              {course.slug === "classical"
                ? "01"
                : course.slug === "contemporary"
                  ? "02"
                  : "03"}
              <small>{course.name.toUpperCase()}</small>
            </span>
          </div>
          <div
            className="film-discipline-tabs"
            role="tablist"
            aria-label="Choose a discipline"
          >
            {courses.map((c, i) => (
              <button
                role="tab"
                aria-selected={discipline === i}
                tabIndex={discipline === i ? 0 : -1}
                aria-controls="film-course-panel"
                id={"film-tab-" + i}
                key={c.slug}
                onClick={() => setDiscipline(i)}
                onKeyDown={(event) => {
                  if (
                    ![
                      "ArrowLeft",
                      "ArrowRight",
                      "ArrowUp",
                      "ArrowDown",
                      "Home",
                      "End",
                    ].includes(event.key)
                  )
                    return;
                  event.preventDefault();
                  const index =
                    event.key === "Home"
                      ? 0
                      : event.key === "End"
                        ? 2
                        : (i +
                            (["ArrowRight", "ArrowDown"].includes(event.key)
                              ? 1
                              : 2)) %
                          3;
                  setDiscipline(index);
                  document.getElementById("film-tab-" + index)?.focus();
                }}
              >
                <span>0{i + 1}</span>
                {c.name}
                <b>↗</b>
              </button>
            ))}
          </div>
          <div
            className="film-course-copy"
            id="film-course-panel"
            role="tabpanel"
            aria-labelledby={"film-tab-" + discipline}
          >
            <h3>{course.tag}</h3>
            <p>{course.description}</p>
            <span className="film-course-meta">
              {course.level} / {course.time}
            </span>
            <div>
              <Link className="film-text-link" href={"/courses/" + course.slug}>
                Enter this world ↗
              </Link>
              <Link
                className="film-text-link"
                href={"/join?course=" + course.slug}
              >
                Book a trial ↗
              </Link>
            </div>
          </div>
        </section>

        <section
          className="film-panel act-people"
          id="people"
          data-act="3"
          aria-label="Act IV — The people"
        >
          <div className="act-eyebrow">
            <span>IV / THE PEOPLE</span>
            <span>FIND YOUR PEOPLE. FEEL YOUR POTENTIAL.</span>
          </div>
          <h2>
            THE ONES WHO
            <br />
            <em>move you.</em>
          </h2>
          <div className="film-artists">
            {artists.map((artist, i) => (
              <Link
                key={artist.name}
                className={"film-artist artist-" + i}
                href={"/artists#artist-" + i}
              >
                <div className="film-artist-image">
                  <Image
                    src={
                      i === 0
                        ? "/demos/kinetic/images/dance.jpg"
                        : i === 1
                          ? "/demos/kinetic/images/contemporary.jpg"
                          : "/demos/kinetic/images/urban.jpg"
                    }
                    alt={artist.discipline + " dance study"}
                    fill
                    loading="eager"
                    sizes="(max-width:700px) 35vw, 24vw"
                  />
                  <span>↗</span>
                </div>
                <div className="film-artist-name">
                  <h3>{artist.name}</h3>
                  <span>{artist.discipline}</span>
                </div>
              </Link>
            ))}
          </div>
          <p className="film-demo-note">
            Illustrative faculty. Photography depicts dance studies.
          </p>
          <Link className="film-text-link people-link" href="/artists">
            Meet the creative faculty ↗
          </Link>
        </section>

        <section
          className="film-panel act-stage"
          id="stage"
          data-act="4"
          aria-label="Act V — The stage"
        >
          <div className="act-eyebrow">
            <span>V / THE STAGE</span>
            <span>EVERY REHEARSAL LEADS TO SOMETHING.</span>
          </div>
          <h2>
            WE
            <br />
            <em>BECOME</em>
            <br />
            ONE.
          </h2>
          <div className="film-events">
            <p>
              Individual voices.
              <br />
              One unforgettable feeling.
            </p>
            <Link href="/events">
              <span>
                12.12.26<small>CONTEMPORARY SHOWCASE</small>
              </span>
              <strong>Between the lines</strong>
              <b>↗</b>
            </Link>
            <Link href="/events">
              <span>
                23.01.27<small>URBAN / OPEN FLOOR</small>
              </span>
              <strong>Open floor</strong>
              <b>↗</b>
            </Link>
            <span className="film-demo-note">
              A demonstration season. Discover the full program.
            </span>
          </div>
        </section>

        <section
          className="film-panel act-your-move"
          id="your-move"
          data-act="5"
          aria-label="Act VI — Your move"
        >
          <div className="act-eyebrow">
            <span>VI / YOUR MOVE</span>
            <span>EVERY BODY. EVERY BEGINNING.</span>
          </div>
          <h2>
            YOUR MOVE
            <br />
            STARTS <em>HERE.</em>
          </h2>
          <div className="final-invitation">
            <p>
              No perfect moment.
              <br />
              Just you, and the courage to begin.
            </p>
            <Link className="film-book" href="/join">
              <span>
                BOOK YOUR
                <br />
                FIRST CLASS.
              </span>
              <b>↗</b>
            </Link>
            <Link className="film-text-link" href="/courses">
              Explore all disciplines ↗
            </Link>
          </div>
          <p className="film-demo-note">
            A concept academy. A real invitation to imagine more.
          </p>
        </section>

        <nav className="film-chapter-nav" aria-label="Film chapters">
          {chapters.map((chapter, i) => (
            <button
              key={chapter.id}
              onClick={() => seekChapter(i)}
              aria-label={"Act " + chapter.number + " — " + chapter.name}
              aria-current={i === 0 ? "step" : undefined}
            >
              <i />
              <span>{chapter.name}</span>
            </button>
          ))}
        </nav>
        <div className="film-bottom-bar">
          <button
            className="film-scroll-prompt"
            onClick={() => seekChapter(Math.min(5, film.chapter + 1))}
          >
            <span>SCROLL TO CHOREOGRAPH</span>
            <b>↓</b>
          </button>
          <span className="film-live-chapter" aria-hidden="true">
            I / THE AWAKENING
          </span>
          <Link href="/courses" className="film-bypass">
            Explore without the film ↗
          </Link>
          <div className="film-progress-track" aria-hidden="true">
            <i />
          </div>
        </div>
        <output className="film-debug" hidden aria-hidden="true" />
      </div>
    </div>
  );
}
