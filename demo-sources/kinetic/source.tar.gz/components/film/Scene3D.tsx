"use client";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import { Group, ShaderMaterial } from "three";
import { film, subscribeFilm, pulse } from "@/lib/film";
function Scenography() {
  const material = useRef<ShaderMaterial>(null);
  const tiles = useRef<Group>(null);
  const { invalidate } = useThree();
  const uniforms = useMemo(
    () => ({ uProgress: { value: 0 }, uReveal: { value: 0 } }),
    [],
  );
  useEffect(() => {
    let wasActive = film.progress > 0.15 && film.progress < 0.43;
    return subscribeFilm(() => {
      const active = film.progress > 0.15 && film.progress < 0.43;
      if (active || wasActive) invalidate();
      wasActive = active;
    });
  }, [invalidate]);
  useFrame(({ camera }) => {
    const p = film.progress;
    const portal = pulse(p, 0.163, 0.215, 0.28);
    if (material.current) {
      material.current.uniforms.uProgress.value = p;
      material.current.uniforms.uReveal.value = portal;
    }
    camera.position.z = 6 - portal * 3.2;
    camera.lookAt(0, 0, 0);
    if (tiles.current) {
      const collapse = Math.max(0, Math.min(1, (p - 0.335) / 0.072));
      tiles.current.visible = p > 0.3 && p < 0.425;
      tiles.current.children.forEach((tile, i) => {
        const side = i % 2 ? 1 : -1;
        tile.position.set(
          (i - 5.5) * 0.78 + side * collapse * 3,
          -2.6 - collapse * (i % 3) * 1.5,
          -1 - collapse * 2,
        );
        tile.rotation.set(
          -Math.PI / 2 + collapse * (i % 2 ? 1 : -1),
          0,
          side * collapse * 0.9,
        );
        tile.scale.setScalar(1 + collapse * 0.25);
      });
    }
  });
  return (
    <>
      <mesh position={[0, 0, 0.1]}>
        <planeGeometry args={[24, 18, 100, 70]} />
        <shaderMaterial
          ref={material}
          uniforms={uniforms}
          transparent
          depthWrite={false}
          side={2}
          vertexShader={`uniform float uProgress;uniform float uReveal;varying float vFold;varying vec2 vUv;void main(){vUv=uv;vec3 p=position;float phase=p.x*.85+p.y*.35+uProgress*35.;float fold=sin(phase)*1.1+sin(phase*2.05)*.28;p.z+=fold*uReveal;vFold=fold;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`}
          fragmentShader={`uniform float uReveal;varying float vFold;varying vec2 vUv;void main(){float light=.55+vFold*.28;vec3 red=vec3(.71,.065,.16);float sheen=pow(max(0.,vFold*.7),5.)*.25;gl_FragColor=vec4(red*light+vec3(sheen),smoothstep(0.,.4,uReveal));}`}
        />
      </mesh>
      <group ref={tiles}>
        {Array.from({ length: 12 }, (_, i) => (
          <mesh key={i}>
            <boxGeometry args={[0.73, 3.4, 0.04]} />
            <meshBasicMaterial
              color={i % 3 === 0 ? "#b51e32" : "#474247"}
              wireframe={i % 3 !== 0}
            />
          </mesh>
        ))}
      </group>
    </>
  );
}
export default function Scene3D() {
  return (
    <Canvas
      className="film-canvas-3d"
      frameloop="demand"
      dpr={[1, 1.25]}
      camera={{ position: [0, 0, 6], fov: 50 }}
      gl={{ alpha: true, antialias: false, powerPreference: "low-power" }}
      fallback={<span />}
    >
      <Scenography />
    </Canvas>
  );
}
