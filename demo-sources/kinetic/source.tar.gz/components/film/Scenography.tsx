"use client";
import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import WebGLBoundary from "@/components/WebGLBoundary";
const Scene = dynamic(() => import("./Scene3D"), { ssr: false });
export default function Scenography() {
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    const query = matchMedia(
      "(min-width: 900px) and (prefers-reduced-motion: no-preference)",
    );
    const check = () => {
      if (!query.matches) {
        setEnabled(false);
        return;
      }
      try {
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("webgl2", {
          failIfMajorPerformanceCaveat: true,
        });
        setEnabled(!!context);
        context?.getExtension("WEBGL_lose_context")?.loseContext();
      } catch {
        setEnabled(false);
      }
    };
    check();
    query.addEventListener("change", check);
    return () => query.removeEventListener("change", check);
  }, []);
  return (
    <div className="film-scenography" aria-hidden="true">
      {enabled && (
        <WebGLBoundary>
          <Scene />
        </WebGLBoundary>
      )}
    </div>
  );
}
