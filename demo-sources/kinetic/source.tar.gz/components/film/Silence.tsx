"use client";
import { useLayoutEffect, useRef } from "react";
export default function Silence() {
  const element = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const node = element.current;
    if (!node) return;
    let seen = false;
    try {
      seen = sessionStorage.getItem("kinetic-v2-intro") === "seen";
      sessionStorage.setItem("kinetic-v2-intro", "seen");
    } catch {}
    const dismiss = () => node.removeAttribute("data-open");
    if (seen || matchMedia("(prefers-reduced-motion: reduce)").matches) {
      dismiss();
      return;
    }
    node.setAttribute("data-open", "true");
    const timer = setTimeout(dismiss, 2100);
    window.addEventListener("wheel", dismiss, { once: true, passive: true });
    window.addEventListener("touchmove", dismiss, {
      once: true,
      passive: true,
    });
    window.addEventListener("keydown", dismiss, { once: true });
    return () => {
      clearTimeout(timer);
      window.removeEventListener("wheel", dismiss);
      window.removeEventListener("touchmove", dismiss);
      window.removeEventListener("keydown", dismiss);
    };
  }, []);
  return (
    <div
      className="silence"
      data-open="true"
      ref={element}
      aria-label="Opening light reveal"
    >
      <div className="silence-shutter left" />
      <div className="silence-shutter right" />
      <span className="silence-line" />
      <span className="silence-caption">EVERY MOVEMENT BEGINS IN SILENCE.</span>
      <button onClick={() => element.current?.removeAttribute("data-open")}>
        Skip intro ↗
      </button>
    </div>
  );
}
