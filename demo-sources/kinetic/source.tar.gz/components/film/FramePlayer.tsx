"use client";
import Image from "next/image";
import { useEffect, useRef } from "react";
import { film, subscribeFilm, pulse } from "@/lib/film";
import { FrameSequence } from "@/lib/sequence";
import { MediaPlayhead, playbackFrame } from "@/lib/playhead";
export default function FramePlayer() {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const node = canvas.current;
    const ctx = node?.getContext("2d", { alpha: false });
    if (!node || !ctx) return;
    let sequence: FrameSequence | undefined;
    let playhead = new MediaPlayhead(film.media, performance.now());
    let scheduled = 0;
    let lastSignature = "";
    let rendered = -1;
    let mobile = innerWidth < 700;
    let disposed = false;
    const preference = matchMedia("(prefers-reduced-motion: reduce)");
    const schedule = () => {
      if (!scheduled && !disposed) scheduled = requestAnimationFrame(draw);
    };
    const draw = (now: number) => {
      scheduled = 0;
      if (!sequence || disposed) return;
      playhead.setTarget(film.media, now);
      const state = playhead.advance(now, sequence.count);
      const desired = Math.round(state.progress * (sequence.count - 1));
      const target = Math.round(playhead.target * (sequence.count - 1));
      sequence.request(desired, target);
      film.desiredFrame = target;
      film.cache = sequence.cache.size;
      film.pending = sequence.pending.size;
      film.errors = sequence.failed.size;
      node.dataset.targetFrame = String(target);
      node.dataset.targetProgress = playhead.target.toFixed(8);
      node.dataset.visualProgress = state.progress.toFixed(8);
      node.dataset.visualFrame = String(desired);
      node.dataset.cached = String(sequence.cache.size);
      node.dataset.pending = String(sequence.pending.size);
      node.dataset.settled = String(state.settled);
      const selected = playbackFrame(sequence.cache.keys(), desired, rendered);
      const bitmap = sequence.cache.get(selected);
      // A cache miss never clears the surface or chooses an unrelated future sample.
      if (bitmap) {
        const echo = pulse(film.progress, 0.525, 0.572, 0.625);
        const signature = `${selected}:${echo.toFixed(2)}`;
        if (signature !== lastSignature) {
          // Resize only when a replacement frame is ready, in the same paint as drawImage.
          if (node.width !== bitmap.width || node.height !== bitmap.height) {
            node.width = bitmap.width;
            node.height = bitmap.height;
          }
          ctx.globalAlpha = 1;
          ctx.globalCompositeOperation = "source-over";
          ctx.drawImage(bitmap, 0, 0, node.width, node.height);
          if (echo > 0.01) {
            ctx.globalCompositeOperation = "screen";
            [-1, 1].forEach((direction, i) => {
              const trail = sequence!.cache.get(
                sequence!.nearest(selected - (i + 1) * 4),
              );
              if (trail) {
                ctx.globalAlpha = echo * 0.2;
                ctx.drawImage(
                  trail,
                  direction * node.width * 0.065 * (i + 1),
                  0,
                  node.width,
                  node.height,
                );
              }
            });
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = "source-over";
          }
          node.style.opacity = "1";
          node.dataset.frameIndex = String(selected);
          node.dataset.ready = "true";
          film.frame = selected;
          rendered = selected;
          lastSignature = signature;
        }
      }
      // Exactly one RAF chain while converging; loading callbacks wake it when necessary.
      if (!state.settled) schedule();
    };
    const start = () => {
      sequence?.dispose();
      rendered = -1;
      lastSignature = "";
      if (preference.matches) {
        sequence = undefined;
        node.style.opacity = "0";
        return;
      }
      mobile = innerWidth < 700;
      playhead = new MediaPlayhead(film.media, performance.now());
      sequence = new FrameSequence(mobile, schedule);
      schedule();
    };
    start();
    const unsubscribe = subscribeFilm(schedule);
    const resize = () => {
      if (mobile !== innerWidth < 700) start();
    };
    window.addEventListener("resize", resize);
    preference.addEventListener("change", start);
    return () => {
      disposed = true;
      unsubscribe();
      cancelAnimationFrame(scheduled);
      sequence?.dispose();
      window.removeEventListener("resize", resize);
      preference.removeEventListener("change", start);
    };
  }, []);
  return (
    <div className="film-dancer">
      <picture>
        <source
          media="(max-width: 699px)"
          srcSet="/demos/kinetic/images/film-poster-mobile.webp"
        />
        <Image
          src="/demos/kinetic/images/film-poster.webp"
          alt="A ballerina in ivory, caught in a breath of movement on a dark stage"
          fill
          priority
          sizes="100vw"
        />
      </picture>
      <canvas
        ref={canvas}
        aria-hidden="true"
        data-frame-index="-1"
        data-target-frame="0"
      />
    </div>
  );
}
