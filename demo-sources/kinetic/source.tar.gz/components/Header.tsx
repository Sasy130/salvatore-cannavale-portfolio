"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
const links = [
  ["Academy", "academy"],
  ["Courses", "courses"],
  ["Artists", "artists"],
  ["Events", "events"],
  ["Contact / Join", "join"],
];
export default function Header() {
  const pathname = usePathname().replace(/\/$/, "") || "/";
  const [open, setOpen] = useState(false);
  const panel = useRef<HTMLDialogElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (open) panel.current?.showModal();
    else panel.current?.close();
  }, [open]);
  return (
    <>
      <header
        className={
          pathname === "/join" || pathname === "/contact"
            ? "on-ivory"
            : pathname === "/"
              ? "home-header"
              : ""
        }
      >
        <Link className="logo" href="/" aria-label="Kinetic home">
          KÍNETIC<span>®</span>
        </Link>
        <nav aria-label="Main navigation">
          {links.slice(0, 4).map(([label, url]) => (
            <Link href={"/" + url} key={url}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="header-right">
          <Link className="book-link" href="/join">
            Book a class <span>↗</span>
          </Link>
          <button
            ref={toggle}
            className="menu-toggle"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
            aria-expanded={open}
          >
            <i />
            <i />
          </button>
        </div>
      </header>
      <dialog
        ref={panel}
        className="menu"
        onCancel={() => setOpen(false)}
        onClose={() => {
          setOpen(false);
          toggle.current?.focus();
        }}
      >
        <button className="close" onClick={() => setOpen(false)} autoFocus>
          Close ×
        </button>
        <p className="eyebrow">FIND YOUR OWN EXPRESSION</p>
        {links.map(([label, url], i) => (
          <Link key={url} href={"/" + url} onClick={() => setOpen(false)}>
            <small>0{i + 1}</small>
            {label}
            <span>↗</span>
          </Link>
        ))}
        <p>Movement belongs to everyone.</p>
      </dialog>
    </>
  );
}
