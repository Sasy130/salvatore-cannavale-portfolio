export const dynamicParams = false;
import Link from "next/link";
import { notFound } from "next/navigation";
import Image from "next/image";
import { courses } from "@/lib/data";
export function generateStaticParams() {
  return courses.map((c) => ({ slug: c.slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  return {
    title: `${courses.find((c) => c.slug === slug)?.name || "Course"} — KÍNETIC`,
  };
}
export default async function Detail({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const c = courses.find((c) => c.slug === slug);
  if (!c) notFound();
  return (
    <main id="main" className="inner-page">
      <p className="eyebrow">
        <Link href="/courses">COURSES</Link> / {c.name.toUpperCase()}
      </p>
      <h1>
        {c.name}
        <br />
        <em>{c.tag}</em>
      </h1>
      <div className="content-grid">
        <div className="content-image">
          <Image
            src={c.image}
            alt={c.name + " dance study"}
            fill
            priority
            sizes="(max-width:700px) 90vw, 45vw"
          />
        </div>
        <div className="body-copy">
          <h2>A practice to make your own.</h2>
          <p>{c.description}</p>
          <dl>
            <div>
              <dt>LEVEL</dt>
              <dd>{c.level}</dd>
            </div>
            <div>
              <dt>SAMPLE TIMETABLE</dt>
              <dd>{c.time}</dd>
            </div>
          </dl>
          <dl>
            <div>
              <dt>FACULTY</dt>
              <dd>{c.teacher}</dd>
            </div>
            <div>
              <dt>DURATION / AGE</dt>
              <dd>90 minutes / Adults 18+</dd>
            </div>
          </dl>
          <h3>Inside the class</h3>
          <p>
            {c.slug === "classical"
              ? "A progressive barre warm-up leads into centre practice, balance and travelling combinations. Explore posture, coordination and musical phrasing."
              : c.slug === "contemporary"
                ? "Begin with breath and mobility, explore floorwork and weight transfer, then develop a short movement phrase through guided improvisation."
                : "Build warmth through grooves and rhythm drills before exploring freestyle prompts and a choreographed combination. Close with a shared practice and cool-down."}
          </p>
          <h3>Before you arrive</h3>
          <p>
            Wear comfortable clothing that allows you to move freely. Bring
            water. For classical classes, soft ballet shoes are suggested;
            contemporary is practised barefoot; urban uses clean indoor
            trainers.
          </p>
          <Link className="pill" href={"/join?course=" + c.slug}>
            Book your first class <span>↗</span>
          </Link>
          <p className="demo-note">
            Demonstration program and timetable. No real booking is made.
          </p>
        </div>
      </div>
    </main>
  );
}
