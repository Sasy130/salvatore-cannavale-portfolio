export const dynamicParams = false;
import Link from "next/link";
import { notFound } from "next/navigation";
import Image from "next/image";
import JoinForm from "@/components/JoinForm";
import CourseList from "@/components/CourseList";
import { artists } from "@/lib/data";
const titles: Record<string, string> = {
  academy: "Inside the academy.",
  courses: "Find your movement.",
  artists: "The ones who move you.",
  events: "Made for the stage.",
  join: "Your move starts here.",
  contact: "Let’s move together.",
};
export function generateStaticParams() {
  return Object.keys(titles).map((section) => ({ section }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  return { title: `${titles[section] || "Not found"} — KÍNETIC` };
}
export default async function Section({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  if (!titles[section]) notFound();
  const join = section === "join" || section === "contact";
  return (
    <main id="main" className={"inner-page " + (join ? "join-page" : "")}>
      <p className="eyebrow">KÍNETIC / {section.toUpperCase()}</p>
      <h1>{titles[section]}</h1>
      {section === "academy" && (
        <>
          <p className="inner-intro">
            A place to begin. A space to become. An academy built around the
            belief that movement belongs to everyone.
          </p>
          <div className="content-grid">
            <div className="content-image">
              <Image
                src="/demos/kinetic/images/dance.jpg"
                alt="Classical dancers rehearsing in a light-filled studio"
                fill
                sizes="(max-width:700px) 90vw, 45vw"
              />
            </div>
            <div className="body-copy">
              <h2>
                Technique gives you tools.
                <br />
                <em>Expression makes them yours.</em>
              </h2>
              <p>
                We bring classical foundations, contemporary exploration and
                urban energy into one creative home. Each practice is distinct.
                All share a commitment to curiosity, care and the joy of moving
                together.
              </p>
              <h3>Room to explore</h3>
              <p>
                Our imagined academy includes two light-filled rehearsal
                studios, a dedicated floorwork space and an intimate performance
                stage. Small classes create room for thoughtful feedback and
                individual development.
              </p>
              <h3>A practice for every body</h3>
              <p>
                Start with an open class or build a regular practice. Our sample
                programs welcome adult beginners and experienced movers alike.
                Let us know about access needs before your first visit so we can
                discuss a suitable class.
              </p>
              <Link href="/courses" className="pill">
                Explore our disciplines ↗
              </Link>
            </div>
          </div>
        </>
      )}
      {section === "courses" && (
        <>
          <p className="inner-intro">
            Find a foundation. Follow a feeling. Make space for a new way of
            moving.
          </p>
          <CourseList />
        </>
      )}
      {section === "artists" && (
        <>
          <p className="inner-intro">
            Three perspectives. A shared belief in your potential. Meet our
            illustrative creative faculty.
          </p>
          {artists.map((a, i) => (
            <article
              className="profile content-grid"
              key={a.name}
              id={"artist-" + i}
            >
              <div className="content-image">
                <Image
                  src={
                    i === 1
                      ? "/demos/kinetic/images/contemporary.jpg"
                      : i === 2
                        ? "/demos/kinetic/images/urban.jpg"
                        : "/demos/kinetic/images/dance.jpg"
                  }
                  alt={a.discipline + " dance study"}
                  fill
                  sizes="(max-width:700px) 90vw, 45vw"
                />
              </div>
              <div className="body-copy">
                <p className="eyebrow">
                  0{i + 1} / {a.discipline.toUpperCase()}
                </p>
                <h2>{a.name}</h2>
                <p>{a.bio}</p>
                <p>
                  Classes combine guided technique, creative tasks and time to
                  reflect. Expect a welcoming studio, thoughtful challenges and
                  permission to find your own voice.
                </p>
                <Link
                  className="text-link"
                  href={"/courses/" + a.discipline.toLowerCase()}
                >
                  Explore associated classes ↗
                </Link>
              </div>
            </article>
          ))}
        </>
      )}
      {section === "events" && (
        <>
          <p className="inner-intro">
            From studio experiments to shared stages. Discover a demonstration
            season of live movement.
          </p>
          <div
            className="content-image"
            style={{ height: 450, marginBottom: 55 }}
          >
            <Image
              src="/demos/kinetic/images/hero.jpg"
              alt="Ballet on a dark theatre stage"
              fill
              sizes="90vw"
            />
          </div>
          {[
            {
              day: "12",
              month: "DEC 2026",
              title: "Between the lines",
              text: "An intimate contemporary showcase exploring the spaces we share. Studio stage · 19:30 · 60 minutes.",
            },
            {
              day: "23",
              month: "JAN 2027",
              title: "Open floor",
              text: "An evening of urban freestyle, shared rhythm and creative exchange. Main studio · 18:00 · 90 minutes.",
            },
            {
              day: "20",
              month: "MAR 2027",
              title: "Becoming",
              text: "Classical and contemporary dancers meet in a collective end-of-term performance. Theatre stage · 20:00 · 75 minutes.",
            },
          ].map((e) => (
            <article className="event-row" key={e.title}>
              <div className="event-date">
                {e.day}
                <small>{e.month}</small>
              </div>
              <div>
                <h2>{e.title}</h2>
                <p>{e.text}</p>
              </div>
              <Link className="text-link" href="/contact">
                Ask about this event ↗
              </Link>
            </article>
          ))}
        </>
      )}
      {join && (
        <div className="content-grid">
          <div>
            <p className="inner-intro">
              You don’t have to know all the steps. You only have to take the
              first one.
            </p>
            <p style={{ lineHeight: 1.9, maxWidth: 400 }}>
              Explore a discipline, tell us what brings you here and preview
              your first class request. New to dance? Our foundation and open
              classes are a welcoming place to start.
            </p>
            <p className="demo-note">
              KÍNETIC is a fictional academy created as a design demonstration.
              There is no physical studio, live timetable or booking service.
            </p>
          </div>
          <JoinForm />
        </div>
      )}
      <p className="demo-note">
        KÍNETIC is a concept academy. Faculty, facilities, dates and programs
        are illustrative. Stock photography does not imply endorsement.
      </p>
    </main>
  );
}
