import Experience from "@/components/film/Experience";
export default function Home() {
  return (
    <main id="main" className="cinematic-home">
      <noscript>
        <style>{`.silence{display:none!important}`}</style>
      </noscript>
      <Experience />
    </main>
  );
}
