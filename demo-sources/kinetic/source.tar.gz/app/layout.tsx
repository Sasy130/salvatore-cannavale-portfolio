import Link from "next/link";
import type { Metadata } from "next";
import "./globals.css";
import "./film.css";
import Footer from "@/components/Footer";
import Header from "@/components/Header";
export const metadata: Metadata = {
  title: "KÍNETIC — The Art of Movement",
  description:
    "A new language of movement. Classical, contemporary and urban dance. Discover the KÍNETIC academy.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Link className="skip-link" href="#main">
          Skip to content
        </Link>
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
