import Link from "next/link";
export default function NotFound() {
  return (
    <main id="main" className="inner-page">
      <p className="eyebrow">404 / A STEP OUT OF PLACE</p>
      <h1>
        Find your way
        <br />
        <em>back to movement.</em>
      </h1>
      <Link className="pill" href="/">
        Return to the experience ↗
      </Link>
    </main>
  );
}
