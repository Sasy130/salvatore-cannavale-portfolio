import type { NextConfig } from 'next';
const config: NextConfig = { output: 'export', basePath: '/demos/kinetic', images: { unoptimized: true }, trailingSlash: true };
export default config;
