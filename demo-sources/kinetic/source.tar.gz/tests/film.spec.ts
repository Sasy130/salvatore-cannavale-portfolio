import { test, expect, type Page } from "@playwright/test";
const canvas = ".film-dancer canvas";
async function open(page: Page) {
  await page.goto("/");
  await expect(page.locator(".film-reel")).toHaveClass(/is-directed/);
  const skip = page.getByRole("button", { name: "Skip intro" });
  if (await skip.isVisible()) await skip.click();
  await expect(page.locator(canvas)).toHaveAttribute("data-ready", "true");
}
async function seek(page: Page, p: number) {
  await page.evaluate((value) => {
    const reel = document.querySelector<HTMLElement>(".film-reel")!;
    scrollTo({
      top: reel.offsetTop + (reel.offsetHeight - innerHeight) * value,
      behavior: "instant",
    });
  }, p);
  await expect
    .poll(
      async () =>
        Number(await page.locator(".film-reel").getAttribute("data-progress")),
      { timeout: 10000 },
    )
    .toBeCloseTo(p, 2);
  await expect
    .poll(
      async () => {
        const node = page.locator(canvas);
        return (
          (await node.getAttribute("data-frame-index")) ===
          (await node.getAttribute("data-target-frame"))
        );
      },
      { timeout: 10000 },
    )
    .toBe(true);
}
test("intro is skippable; exact frame advances, freezes, and reverses", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await open(page);
  await seek(page, 0.025);
  const first = await page.locator(canvas).getAttribute("data-frame-index");
  const pixels = await page
    .locator(canvas)
    .evaluate((c: HTMLCanvasElement) => c.toDataURL());
  await page.screenshot({ path: "artifacts/v2-awakening.png" });
  await seek(page, 0.115);
  expect(
    Number(await page.locator(canvas).getAttribute("data-frame-index")),
  ).toBeGreaterThan(Number(first));
  const frozen = await page.locator(canvas).getAttribute("data-frame-index");
  const stopped = await page
    .locator(canvas)
    .evaluate((c: HTMLCanvasElement) => c.toDataURL());
  await page.waitForTimeout(500);
  expect(await page.locator(canvas).getAttribute("data-frame-index")).toBe(
    frozen,
  );
  expect(
    await page
      .locator(canvas)
      .evaluate((c: HTMLCanvasElement) => c.toDataURL()),
  ).toBe(stopped);
  await seek(page, 0.025);
  expect(await page.locator(canvas).getAttribute("data-frame-index")).toBe(
    first,
  );
  expect(
    await page
      .locator(canvas)
      .evaluate((c: HTMLCanvasElement) => c.toDataURL()),
  ).toBe(pixels);
  expect(errors).toEqual([]);
});
test("five transitions occupy one persistent stage and survive rapid scroll", async ({
  page,
}) => {
  await open(page);
  const stages = await page.locator(".film-stage").count();
  expect(stages).toBe(1);
  for (const [name, p] of [
    ["body-to-type", 0.105],
    ["fabric", 0.22],
    ["collapse", 0.365],
    ["echo", 0.575],
    ["light", 0.905],
  ] as const) {
    await seek(page, p);
    await page.screenshot({ path: `artifacts/v2-${name}.png` });
    expect(
      await page
        .locator(".film-stage")
        .evaluate((e) => Math.abs(e.getBoundingClientRect().top)),
    ).toBeLessThan(2);
  }
  for (const p of [0.04, 0.7, 0.18, 0.84, 0.055])
    await page.evaluate((value) => {
      const r = document.querySelector<HTMLElement>(".film-reel")!;
      scrollTo({
        top: (r.offsetHeight - innerHeight) * value,
        behavior: "instant",
      });
    }, p);
  await seek(page, 0.055);
  expect(
    Number(await page.locator(canvas).getAttribute("data-cached")),
  ).toBeLessThanOrEqual(20);
  expect(
    Number(await page.locator(canvas).getAttribute("data-pending")),
  ).toBeLessThanOrEqual(4);
});
test("six acts, course environments, keyboard tabs, menu and final CTA", async ({
  page,
}) => {
  await open(page);
  for (const [label, id] of [
    ["II", "body"],
    ["III", "disciplines"],
    ["IV", "people"],
    ["V", "stage"],
    ["VI", "your-move"],
  ]) {
    await page
      .getByRole("button", { name: new RegExp("Act " + label + " —") })
      .click();
    await expect(page.locator(".film-reel")).toHaveAttribute(
      "data-chapter",
      id,
    );
    await expect(page.locator("#" + id)).toHaveAttribute(
      "aria-hidden",
      "false",
    );
    await page.screenshot({ path: `artifacts/v2-act-${id}.png` });
  }
  await page
    .getByRole("button", { name: "Act III — The disciplines", exact: true })
    .click();
  const tab = page.getByRole("tab", { name: /Contemporary/ });
  await tab.focus();
  await page.keyboard.press("ArrowRight");
  await expect(page.getByRole("tab", { name: /Urban/ })).toHaveAttribute(
    "aria-selected",
    "true",
  );
  await expect(page.getByRole("tabpanel")).toContainText(
    "Your rhythm. Your rules.",
  );
  await page.getByRole("link", { name: "Book a trial" }).click();
  await expect(page).toHaveURL(/join\/?\?course=urban/);
  await expect(page.getByLabel("Your discipline")).toHaveValue("Urban");
  await page.getByRole("button", { name: "Open menu" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("button", { name: "Open menu" })).toBeFocused();
  await page.goto("/");
  await page
    .getByRole("button", { name: "Act VI — Your move", exact: true })
    .click();
  await page.getByRole("link", { name: /BOOK YOUR FIRST CLASS/ }).click();
  await expect(page).toHaveURL(/join/);
});
test("mobile director, resize, refresh and bounded sequence cache", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await open(page);
  for (const p of [0.03, 0.28, 0.445, 0.66, 0.8, 0.98]) {
    await seek(page, p);
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await page.screenshot({ path: `artifacts/v2-mobile-${p}.png` });
  }
  await seek(page, 0.445);
  await page.reload();
  await expect(page.locator(".film-reel")).toHaveClass(/is-directed/);
  await page.setViewportSize({ width: 1280, height: 720 });
  await seek(page, 0.1);
  expect(
    Number(await page.locator(canvas).getAttribute("data-frame-index")),
  ).toBeGreaterThan(20);
  expect(
    Number(await page.locator(canvas).getAttribute("data-cached")),
  ).toBeLessThanOrEqual(20);
});
test("reduced motion exposes every act; missing assets retain poster and navigation", async ({
  browser,
}) => {
  const context = await browser.newContext({
    reducedMotion: "reduce",
    viewport: { width: 390, height: 844 },
  });
  const page = await context.newPage();
  await page.goto("http://127.0.0.1:4173/");
  await expect(page.locator(".film-reel")).not.toHaveClass(/is-directed/);
  for (const id of [
    "awakening",
    "body",
    "disciplines",
    "people",
    "stage",
    "your-move",
  ])
    await expect(page.locator("#" + id)).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await context.close();
  const normal = await browser.newPage();
  await normal.route("**/demos/kinetic/media/film-*/**", (route) => route.abort());
  await normal.goto("http://127.0.0.1:4173/");
  await normal.waitForTimeout(2300);
  await expect(normal.locator(".film-dancer img")).toBeVisible();
  expect(
    await normal
      .locator(".film-dancer img")
      .evaluate((img: HTMLImageElement) => img.naturalWidth > 0),
  ).toBe(true);
  await normal.getByRole("link", { name: "Explore without the film" }).click();
  await expect(normal).toHaveURL(/courses/);
  await normal.close();
});
test("commercial pages, validation, and narrow layout remain intact", async ({
  page,
}) => {
  await page.setViewportSize({ width: 390, height: 844 });
  for (const route of [
    "/academy/",
    "/courses/",
    "/courses/classical/",
    "/courses/contemporary/",
    "/courses/urban/",
    "/artists/",
    "/events/",
    "/contact/",
  ]) {
    const response = await page.goto(route);
    expect(response?.status()).toBe(200);
    await expect(page.locator("h1")).toBeVisible();
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      route,
    ).toBe(true);
  }
  await page.goto("/join/");
  await page.getByRole("button", { name: "Preview my trial request" }).click();
  await expect(page.getByRole("status")).toBeEmpty();
  await page.getByLabel("Your name").fill("Demo Dancer");
  await page.getByLabel("Email address").fill("demo@example.com");
  await page.getByRole("checkbox").check();
  await page.getByRole("button", { name: "Preview my trial request" }).click();
  await expect(page.getByRole("status")).toContainText(
    "Nothing has been sent or booked.",
  );
});

test("slow frame delivery converges to the requested frame without blocking navigation", async ({
  page,
}) => {
  await page.route("**/demos/kinetic/media/film-*/**", async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 100));
    await route.continue();
  });
  await open(page);
  await seek(page, 0.125);
  const stopped = await page.locator(canvas).getAttribute("data-frame-index");
  await page.waitForTimeout(300);
  expect(await page.locator(canvas).getAttribute("data-frame-index")).toBe(
    stopped,
  );
  await page.getByRole("button", { name: "Open menu" }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
});
test("WebGL failure retains CSS transitions and the complete film controls", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (
      this: HTMLCanvasElement,
      type: string,
      ...args: unknown[]
    ) {
      if (type.includes("webgl")) return null;
      return original.apply(this, [type, ...args] as Parameters<
        typeof original
      >);
    } as typeof original;
  });
  await open(page);
  await seek(page, 0.22);
  await expect(page.locator(".fabric-portal")).toBeVisible();
  await page
    .getByRole("button", { name: "Act VI — Your move", exact: true })
    .click();
  await expect(
    page.getByRole("link", { name: /BOOK YOUR FIRST CLASS/ }),
  ).toBeVisible();
});
