import { test, expect, type Page } from "@playwright/test";
import { MediaPlayhead, playbackFrame } from "../lib/playhead";
const selector = ".film-dancer canvas";
async function ready(page: Page) {
  await page.goto("/");
  await expect(page.locator(selector)).toHaveAttribute("data-ready", "true");
  const skip = page.getByRole("button", { name: "Skip intro" });
  if (await skip.isVisible()) await skip.click();
  await page.waitForTimeout(200);
}
async function settled(page: Page) {
  await expect
    .poll(async () =>
      page
        .locator(selector)
        .evaluate(
          (node) =>
            node.getAttribute("data-frame-index") ===
              node.getAttribute("data-target-frame") &&
            node.getAttribute("data-settled") === "true",
        ),
    )
    .toBe(true);
}
test("media filter is time-based, does not overshoot and reaches exact rest within 140ms", () => {
  const p = new MediaPlayhead(0, 0);
  p.setTarget(0.02, 1000);
  expect(p.advance(1000, 288).progress).toBe(0);
  let previous = 0;
  for (let t = 1016; t < 1140; t += 16) {
    const value = p.advance(t, 288).progress;
    expect(value).toBeGreaterThanOrEqual(previous);
    expect(value).toBeLessThanOrEqual(0.02);
    previous = value;
  }
  expect(p.advance(1140, 288)).toEqual({ progress: 0.02, settled: true });
  p.setTarget(0, 1200);
  let last = 0.02;
  for (let t = 1200; t < 1340; t += 16) {
    const value = p.advance(t, 288).progress;
    expect(value).toBeLessThanOrEqual(last);
    expect(value).toBeGreaterThanOrEqual(0);
    last = value;
  }
  expect(p.advance(1340, 288).progress).toBe(0);
});
test("late/future decode cannot cause reverse bounces or blank frames", () => {
  expect(playbackFrame([10, 14], 12, 10)).toBe(10);
  expect(playbackFrame([10, 11, 14], 12, 10)).toBe(11);
  expect(playbackFrame([10, 11, 12, 14], 12, 11)).toBe(12);
  expect(playbackFrame([10, 12, 14], 11, 12)).toBe(12);
  expect(playbackFrame([10, 11, 12, 14], 11, 12)).toBe(11);
  expect(playbackFrame([14], 12, -1)).toBe(-1);
});
test("one wheel pulse paints intermediate real frames and then sleeps at exact target", async ({
  page,
}) => {
  await ready(page);
  const c = page.locator(selector);
  const initial = Number(await c.getAttribute("data-frame-index"));
  await page.evaluate(() => {
    (window as unknown as { scrubFrames: number[] }).scrubFrames = [];
    const frames = (window as unknown as { scrubFrames: number[] }).scrubFrames;
    const started = performance.now();
    const sample = () => {
      frames.push(
        Number(
          document
            .querySelector(".film-dancer canvas")
            ?.getAttribute("data-frame-index"),
        ),
      );
      if (performance.now() - started < 400) requestAnimationFrame(sample);
    };
    requestAnimationFrame(sample);
  });
  await page.mouse.wheel(0, 120);
  await page.waitForTimeout(450);
  await settled(page);
  const values = await page.evaluate(
    () => (window as unknown as { scrubFrames: number[] }).scrubFrames,
  );
  const changed = [...new Set(values)].filter((value) => value > initial);
  expect(changed.length).toBeGreaterThanOrEqual(2);
  expect(changed.at(-1)).toBe(
    Number(await c.getAttribute("data-target-frame")),
  );
  const stable = await c.evaluate((node: HTMLCanvasElement) =>
    node.toDataURL(),
  );
  await page.waitForTimeout(250);
  expect(await c.evaluate((node: HTMLCanvasElement) => node.toDataURL())).toBe(
    stable,
  );
});
test("small trackpad-like inputs and repeated reverse wheel motion remain directional", async ({
  page,
}) => {
  await ready(page);
  await page.evaluate(() => {
    (window as unknown as { frames: number[] }).frames = [];
    const values = (window as unknown as { frames: number[] }).frames;
    const start = performance.now();
    const sample = () => {
      values.push(
        Number(
          document
            .querySelector(".film-dancer canvas")
            ?.getAttribute("data-frame-index"),
        ),
      );
      if (performance.now() - start < 1300) requestAnimationFrame(sample);
    };
    requestAnimationFrame(sample);
  });
  for (let i = 0; i < 24; i++) {
    await page.mouse.wheel(0, 6);
    await page.waitForTimeout(10);
  }
  await settled(page);
  await page.waitForTimeout(150);
  const forward = await page.evaluate(
    () => (window as unknown as { frames: number[] }).frames,
  );
  for (let i = 1; i < forward.length; i++)
    expect(forward[i]).toBeGreaterThanOrEqual(forward[i - 1]);
  const high = Number(
    await page.locator(selector).getAttribute("data-frame-index"),
  );
  for (let repeat = 0; repeat < 3; repeat++) {
    await page.mouse.wheel(0, -120);
    await page.waitForTimeout(200);
    await settled(page);
    await page.mouse.wheel(0, 120);
    await page.waitForTimeout(200);
    await settled(page);
  }
  expect(
    Number(await page.locator(selector).getAttribute("data-frame-index")),
  ).toBeGreaterThanOrEqual(high - 1);
});
test("delayed missing sample holds the last valid image rather than jumping to future cache entries", async ({
  page,
}) => {
  await page.route("**/film-hd/013.webp", (route) => route.abort());
  await ready(page);
  await page.evaluate(() => {
    const r = document.querySelector<HTMLElement>(".film-reel")!;
    scrollTo({
      top: (r.offsetHeight - innerHeight) * ((0.92 * 12) / 287),
      behavior: "instant",
    });
  });
  await expect(page.locator(selector)).toHaveAttribute(
    "data-target-frame",
    "12",
  );
  await page.waitForTimeout(450);
  const rendered = Number(
    await page.locator(selector).getAttribute("data-frame-index"),
  );
  expect(rendered).toBeGreaterThanOrEqual(0);
  expect(rendered).toBeLessThan(12);
  await expect(page.locator(selector)).toHaveCSS("opacity", "1");
  const pixels = await page
    .locator(selector)
    .evaluate((node: HTMLCanvasElement) => node.toDataURL());
  await page.waitForTimeout(150);
  expect(
    await page
      .locator(selector)
      .evaluate((node: HTMLCanvasElement) => node.toDataURL()),
  ).toBe(pixels);
});
test("mobile uses source-rate portrait samples and native touch scrubs in both directions", async ({
  browser,
}) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    hasTouch: true,
    isMobile: true,
  });
  const page = await context.newPage();
  await page.goto("http://127.0.0.1:4173/");
  await expect(page.locator(selector)).toHaveAttribute("data-ready", "true");
  const client = await context.newCDPSession(page);
  await client.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 200, y: 700 }],
  });
  for (let y = 650; y >= 250; y -= 50) {
    await client.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: 200, y }],
    });
    await page.waitForTimeout(20);
  }
  await client.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await page.waitForTimeout(400);
  await settled(page);
  const forward = Number(
    await page.locator(selector).getAttribute("data-frame-index"),
  );
  expect(forward).toBeGreaterThan(5);
  expect(
    await page
      .locator(selector)
      .evaluate((c: HTMLCanvasElement) => [c.width, c.height]),
  ).toEqual([540, 960]);
  await client.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 200, y: 250 }],
  });
  for (let y = 300; y <= 700; y += 50) {
    await client.send("Input.dispatchTouchEvent", {
      type: "touchMove",
      touchPoints: [{ x: 200, y }],
    });
    await page.waitForTimeout(20);
  }
  await client.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await page.waitForTimeout(400);
  await settled(page);
  expect(
    Number(await page.locator(selector).getAttribute("data-frame-index")),
  ).toBeLessThan(forward);
  expect(
    Number(await page.locator(selector).getAttribute("data-cached")),
  ).toBeLessThanOrEqual(12);
  await context.close();
});
