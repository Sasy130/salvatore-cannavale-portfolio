import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import vm from "node:vm";
import ts from "typescript";
function load(file) {
  const module = { exports: {} };
  const compiled = ts.transpileModule(fs.readFileSync(file, "utf8"), {
    compilerOptions: {
      module: ts.ModuleKind.CommonJS,
      target: ts.ScriptTarget.ES2020,
    },
  }).outputText;
  vm.runInNewContext(
    compiled,
    { exports: module.exports, module, Intl, URL, URLSearchParams },
    { filename: file },
  );
  return module.exports;
}
const { properties } = load("lib/properties.ts");
const { filterProperties, blankFilters, filtersToQuery, filtersFromQuery } =
  load("lib/search.ts");
const result = (f) => filterProperties(properties, { ...blankFilters, ...f });
assert.equal(properties.length, 8);
assert.equal(new Set(properties.map((p) => p.id)).size, 8);
assert.equal(new Set(properties.map((p) => p.slug)).size, 8);
for (const p of properties) {
  assert.ok(p.baths > 0 && p.beds > 0 && p.price > 0 && p.size > 0);
  assert.ok(p.lat >= 40 && p.lat <= 47 && p.lng >= 8 && p.lng <= 12);
  for (const img of new Set([p.image, ...p.gallery]))
    assert.ok(fs.existsSync(`public/images/${img}.jpg`), `${p.id}: ${img}`);
}
assert.equal(result({}).length, 8);
assert.equal(result({ contract: "Affitto" }).length, 2);
assert.equal(result({ city: "Como" }).length, 2);
assert.equal(
  result({ city: "Milano", type: "Attico", contract: "Vendita" })
    .map((p) => p.id)
    .join(","),
  "VR-002",
);
assert.equal(
  result({ features: ["Piscina", "Vista mare"] })
    .map((p) => p.id)
    .join(","),
  "VR-003",
);
assert.equal(
  result({ q: "brERA" })
    .map((p) => p.id)
    .join(","),
  "VR-002",
);
assert.equal(
  result({ price: "5000", contract: "Affitto" })
    .map((p) => p.id)
    .join(","),
  "VR-007",
);
assert.equal(result({ priceMin: "3000000", size: "400", beds: "5" }).length, 3);
assert.equal(result({ area: "Oltrarno", city: "Milano" }).length, 0);
assert.equal(result({ q: "nessun immobile esiste" }).length, 0);
const original = {
  ...blankFilters,
  city: "Como",
  priceMin: "1000000",
  features: ["Piscina", "Terrazza"],
};
const restored = filtersFromQuery(
  new URLSearchParams(filtersToQuery(original)),
);
assert.equal(JSON.stringify(restored), JSON.stringify(original));
assert.equal(
  filtersFromQuery(new URLSearchParams("citta=Milano&contratto=Affitto")).city,
  "Milano",
);
const root = path.resolve("out");
assert.ok(
  fs.existsSync(path.join(root, "index.html")),
  "Run npm run build before npm test",
);
let pages = 0,
  links = 0,
  images = 0;
const visit = (dir) => {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name !== "_next") visit(file);
    } else if (file.endsWith(".html")) {
      pages++;
      const html = fs.readFileSync(file, "utf8");
      assert.match(html, /<html lang="it"/);
      assert.match(html, /<title>[^<]+<\/title>/);
      assert.match(html, /name="viewport"/);
      for (const match of html.matchAll(/(?:href|src)="([^"#]+)"/g)) {
        const raw = match[1].replaceAll("&amp;", "&");
        if (!raw.startsWith("/") || raw.startsWith("//")) continue;
        const url = raw.split(/[?#]/)[0];
        const target = path.join(root, decodeURIComponent(url));
        assert.ok(
          fs.existsSync(target) || fs.existsSync(`${target}.html`),
          `Broken local link in ${file}: ${raw}`,
        );
        links++;
        if (raw.startsWith("/images/")) images++;
      }
    }
  }
};
visit(root);
assert.ok(pages >= 20);
console.log(
  `✓ 8 immobili validi; filtri combinati, stato vuoto e query URL verificati`,
);
console.log(
  `✓ ${pages} pagine, ${links} riferimenti locali e ${images} riferimenti fotografici verificati`,
);

const { cinematicDestination } = load("lib/navigation.ts");
const current = "https://vera.example/proprieta/";
assert.equal(
  cinematicDestination(
    "/proprieta/villa-orizzonte/?visita=1#richiesta",
    current,
  ),
  "/proprieta/villa-orizzonte/?visita=1#richiesta",
);
for (const href of [
  "#contenuto",
  "?citta=Como",
  "/proprieta",
  "/proprieta/",
  "mailto:info@example.com",
  "tel:+39000",
  "https://altro.example/mappa/",
]) {
  assert.equal(
    cinematicDestination(href, current),
    null,
    `Must preserve native navigation for ${href}`,
  );
}
console.log(
  "✓ Navigazione: route interne, anchor, filtri, link esterni e contatti verificati",
);
