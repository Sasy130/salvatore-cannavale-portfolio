# VÉRA — Luxury Real Estate

Demo immobiliare italiana realizzata con Next.js App Router, TypeScript, React, GSAP/ScrollTrigger, Lenis, Leaflet e Lucide. Esportazione statica: nessun backend, chiave API o servizio a pagamento.

## Avvio

```sh
npm install
npm run dev
```

Aprire http://localhost:3000. Per la build statica: `npm run build`; l'output è in `out/`. La cartella può essere pubblicata su un hosting statico che supporti directory index e `404.html`. `npm run typecheck` controlla i tipi; `npm test` verifica filtri, integrità dati e navigazione generata.

## Architettura

- `app/`: homepage, collezione, ricerca avanzata, mappa, 8 dettagli generati staticamente, preferiti, chi siamo, servizi, valutazione, contatti, journal, privacy e 404.
- `lib/properties.ts`: unica fonte degli immobili dimostrativi; tipi e dati sostituibili con un adapter CMS.
- `lib/search.ts`: ricerca pura, filtri combinati e serializzazione query URL.
- `components/Shell.tsx`: navigazione, menu con focus contenuto, preferiti, smooth scrolling e reveal.
- `components/Home.tsx`: introduzione salt modale non bloccante, hero, ricerca rapida e sezioni editoriali.
- `components/PropertyDetail.tsx`: galleria nativa dialog, controlli tastiera e swipe, scheda tecnica, planimetria illustrativa e form.
- `components/PropertyMap.tsx`: mappa caricata solo lato client, tile CARTO/OpenStreetMap, marker e risultati sincronizzati alla zona visibile.
- `components/Forms.tsx`: validazione browser e conferma esplicita della simulazione senza invii.
- `public/images/`, `public/fonts/`: fotografie e font locali, senza dipendenze da CDN per i contenuti editoriali.

## Design e accessibilità

Carbone `#111111`, avorio `#F5F1E9`, champagne `#C6A77B`, bianco caldo `#FAF9F6`, pietra `#85827D`. Cormorant Garamond per i titoli, Manrope per l'interfaccia. CSS dedicato per il layout editoriale, breakpoint mobile e desktop. Motion rispettoso di `prefers-reduced-motion`, intro breve saltabile, skip link, focus visibile, menu fullscreen con Escape/focus trap, form etichettati e dialog galleria nativo. Gli effetti hover sono limitati a puntatori compatibili.

## Funzionalità demo e limiti

Gli annunci sono di fantasia. Le fotografie Unsplash sono ispirazioni e non rappresentano immobili offerti realmente. I marker non identificano indirizzi esatti. Nessun tour 360 è presentato in assenza di contenuti autentici. Le planimetrie sono dichiarate illustrative, non in scala. I form non inviano e non memorizzano dati personali; non viene calcolata una valutazione economica reale. I preferiti persistono nel browser (`vera-favorites`); l'intro si esegue una volta per sessione (`vera-intro`).

Le mappe richiedono connettività per le tessere CARTO. In caso di errore la lista degli immobili resta disponibile. La demo è impostata `noindex`: prima dell'uso commerciale vanno sostituiti dati, testi legali, fotografie pertinenti, metadata e policy SEO e integrato un servizio effettivo di gestione richieste.

## Font e immagini

Cormorant Garamond e Manrope: Google Fonts, SIL Open Font License. Copie locali ridotte al set latino. Fotografie: Unsplash, licenza Unsplash; riferimenti originali in `public/images/credits.json`.

## Verifiche

Build di produzione e TypeScript eseguiti nell'ambiente di lavoro. Test automatici sui dati e collegamenti statici. La verifica visiva/interattiva in browser non è stata eseguita: l'ambiente non espone `cua_repl.js`, lo strumento previsto dal flusso di hosting. Una revisione finale su dispositivi reali resta da effettuare.

## Edizione cinematografica

La homepage include una scena hero con camera su scroll, un manifesto tipografico a illuminazione progressiva, una collezione fotografica orizzontale e una scena a portale che si apre a schermo intero. I pin e lo scorrimento laterale guidato sono riservati a desktop da 1000px; su tablet e smartphone la collezione usa lo scorrimento orizzontale nativo con scroll snap. Con movimento ridotto le scene restano statiche e tutti i link accessibili.

`components/ImmersiveScenes.tsx` gestisce i tre racconti visivi; `components/CinematicMotion.tsx` gestisce il sipario tra route, la navigazione per capitoli, l’indicatore di lettura e i pulsanti magnetici. Le transizioni non intercettano anchor della pagina corrente, filtri via query, collegamenti esterni, download o click con tasti modificatori. Un timeout di ripristino riapre sempre il sipario quando una route è lenta. Ogni contesto GSAP viene ripristinato su cambio pagina o breakpoint. `app/cinematic.css` contiene il nuovo livello visivo senza sostituire il design system esistente.
