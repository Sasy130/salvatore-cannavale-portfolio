import type { Property } from "./properties";
export type Filters = {
  q: string;
  city: string;
  area: string;
  contract: string;
  type: string;
  price: string;
  priceMin: string;
  size: string;
  beds: string;
  features: string[];
};
export const blankFilters: Filters = {
  q: "",
  city: "",
  area: "",
  contract: "",
  type: "",
  price: "",
  priceMin: "",
  size: "",
  beds: "",
  features: [],
};
export function filterProperties(items: Property[], f: Filters) {
  return items.filter(
    (p) =>
      (!f.q ||
        `${p.name} ${p.city} ${p.area} ${p.region} ${p.id}`
          .toLowerCase()
          .includes(f.q.toLowerCase())) &&
      (!f.city || p.city === f.city) &&
      (!f.area || p.area === f.area) &&
      (!f.contract || p.contract === f.contract) &&
      (!f.type || p.type === f.type) &&
      (!f.priceMin || p.price >= Number(f.priceMin)) &&
      (!f.price || p.price <= Number(f.price)) &&
      (!f.size || p.size >= Number(f.size)) &&
      (!f.beds || p.beds >= Number(f.beds)) &&
      f.features.every((feature) => p.features.includes(feature)),
  );
}

export function filtersToQuery(f: Filters) {
  const q = new URLSearchParams();
  for (const [key, value] of Object.entries(f)) {
    if (Array.isArray(value)) {
      if (value.length) q.set(key, value.join(","));
    } else if (value) q.set(key, value);
  }
  return q.toString();
}
export function filtersFromQuery(query: URLSearchParams): Filters {
  const result = { ...blankFilters, features: [] as string[] };
  for (const key of Object.keys(result) as (keyof Filters)[]) {
    if (key === "features")
      result.features = (query.get(key) || "").split(",").filter(Boolean);
    else result[key] = query.get(key) || "";
  }
  result.city = query.get("citta") || result.city;
  result.type = query.get("tipo") || result.type;
  result.contract = query.get("contratto") || result.contract;
  return result;
}
