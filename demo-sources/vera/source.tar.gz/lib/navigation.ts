/** Only real, same-origin route changes receive the cinematic shutter. */
export function cinematicDestination(
  href: string,
  currentHref: string,
): string | null {
  try {
    const current = new URL(currentHref);
    const target = new URL(href, current);
    if (
      !["http:", "https:"].includes(target.protocol) ||
      target.origin !== current.origin
    )
      return null;
    const normalize = (path: string) => path.replace(/\/+$/, "");
    if (normalize(target.pathname) === normalize(current.pathname)) return null;
    return target.pathname + target.search + target.hash;
  } catch {
    return null;
  }
}
