export type Property = {
  id: string;
  slug: string;
  name: string;
  city: string;
  area: string;
  region: string;
  price: number;
  size: number;
  beds: number;
  baths: number;
  type: string;
  contract: "Vendita" | "Affitto";
  image: string;
  gallery: string[];
  features: string[];
  description: string;
  lat: number;
  lng: number;
  status: string;
  floorplan: boolean;
};
export const properties: Property[] = [
  {
    id: "VR-001",
    slug: "villa-orizzonte",
    name: "Villa Orizzonte",
    city: "Como",
    area: "Cernobbio",
    region: "Lago di Como",
    price: 4800000,
    size: 420,
    beds: 5,
    baths: 6,
    type: "Villa",
    contract: "Vendita",
    image: "villa",
    gallery: ["villa", "hero", "room"],
    features: ["Piscina", "Vista lago", "Giardino", "Terrazza"],
    description:
      "Un dialogo silenzioso tra architettura e paesaggio. Grandi vetrate dissolvono il confine tra gli interni e un giardino privato, mentre la luce accompagna ogni momento della giornata. Materiali naturali, volumi essenziali e una piscina disegnata sull’orizzonte raccontano un modo diverso di abitare.",
    lat: 45.843,
    lng: 9.074,
    status: "Selezione esclusiva",
    floorplan: true,
  },
  {
    id: "VR-002",
    slug: "attico-brera",
    name: "L’Attico di Brera",
    city: "Milano",
    area: "Brera",
    region: "Lombardia",
    price: 2650000,
    size: 240,
    beds: 3,
    baths: 3,
    type: "Attico",
    contract: "Vendita",
    image: "penthouse",
    gallery: ["penthouse", "milan", "interior"],
    features: ["Terrazza", "Ascensore", "Domotica"],
    description:
      "Sopra i tetti di Brera, una dimora dall’anima contemporanea. La zona giorno si apre su una terrazza raccolta; pietra, legno e dettagli su misura compongono un equilibrio di eleganza e intimità.",
    lat: 45.473,
    lng: 9.186,
    status: "Nuova selezione",
    floorplan: true,
  },
  {
    id: "VR-003",
    slug: "dimora-mediterranea",
    name: "Dimora Mediterranea",
    city: "Porto Cervo",
    area: "Costa Smeralda",
    region: "Sardegna",
    price: 6200000,
    size: 580,
    beds: 6,
    baths: 7,
    type: "Villa",
    contract: "Vendita",
    image: "coast",
    gallery: ["coast", "garden", "room"],
    features: ["Piscina", "Vista mare", "Giardino", "Terrazza"],
    description:
      "La luce del Mediterraneo entra in ogni ambiente. Una residenza pensata per vivere all’aperto, con spazi conviviali, un giardino generoso e ambienti che custodiscono la calma dell’isola.",
    lat: 41.135,
    lng: 9.532,
    status: "Selezione esclusiva",
    floorplan: false,
  },
  {
    id: "VR-004",
    slug: "residenza-luce",
    name: "Residenza Luce",
    city: "Firenze",
    area: "Oltrarno",
    region: "Toscana",
    price: 1250000,
    size: 185,
    beds: 3,
    baths: 2,
    type: "Appartamento",
    contract: "Vendita",
    image: "interior",
    gallery: ["interior", "room", "milan"],
    features: ["Ascensore", "Domotica"],
    description:
      "Nel cuore creativo di Firenze, una casa che custodisce la memoria del luogo e accoglie la semplicità del presente. Altezze generose, luce diffusa e un progetto d’interni misurato.",
    lat: 43.764,
    lng: 11.246,
    status: "Nuova selezione",
    floorplan: false,
  },
  {
    id: "VR-005",
    slug: "casa-delle-colline",
    name: "Casa delle Colline",
    city: "Siena",
    area: "Val d’Orcia",
    region: "Toscana",
    price: 3100000,
    size: 460,
    beds: 5,
    baths: 5,
    type: "Casale",
    contract: "Vendita",
    image: "tuscany",
    gallery: ["tuscany", "garden", "interior"],
    features: ["Piscina", "Giardino", "Terrazza"],
    description:
      "Una pausa tra le colline toscane. Il carattere della tradizione incontra il comfort contemporaneo, tra spazi dedicati alla convivialità e angoli raccolti per ritrovare il proprio tempo.",
    lat: 43.057,
    lng: 11.614,
    status: "Selezione esclusiva",
    floorplan: true,
  },
  {
    id: "VR-006",
    slug: "suite-sul-lago",
    name: "Suite sul Lago",
    city: "Como",
    area: "Blevio",
    region: "Lago di Como",
    price: 6500,
    size: 160,
    beds: 2,
    baths: 2,
    type: "Appartamento",
    contract: "Affitto",
    image: "lake",
    gallery: ["lake", "room", "architecture"],
    features: ["Vista lago", "Terrazza", "Ascensore"],
    description:
      "Una prospettiva privata sul lago. Ambienti ariosi, una terrazza dedicata alle prime ore del mattino e materiali che restituiscono una sensazione di naturale benessere.",
    lat: 45.842,
    lng: 9.106,
    status: "Locazione demo",
    floorplan: false,
  },
  {
    id: "VR-007",
    slug: "loft-materia",
    name: "Loft Materia",
    city: "Milano",
    area: "Porta Venezia",
    region: "Lombardia",
    price: 4800,
    size: 175,
    beds: 2,
    baths: 2,
    type: "Loft",
    contract: "Affitto",
    image: "milan",
    gallery: ["milan", "interior", "penthouse"],
    features: ["Domotica", "Terrazza"],
    description:
      "Un rifugio urbano dal carattere deciso. Geometrie aperte, superfici materiche e arredi essenziali danno forma a una nuova idea di abitare la città.",
    lat: 45.476,
    lng: 9.205,
    status: "Locazione demo",
    floorplan: false,
  },
  {
    id: "VR-008",
    slug: "villa-essenza",
    name: "Villa Essenza",
    city: "Lucca",
    area: "Colline lucchesi",
    region: "Toscana",
    price: 2250000,
    size: 350,
    beds: 4,
    baths: 4,
    type: "Villa",
    contract: "Vendita",
    image: "garden",
    gallery: ["garden", "architecture", "room"],
    features: ["Piscina", "Giardino", "Domotica"],
    description:
      "Immersa nel verde, una dimora che lascia parlare la natura. Le aperture incorniciano il paesaggio e collegano gli interni a una sequenza di giardini e spazi per il relax.",
    lat: 43.879,
    lng: 10.501,
    status: "Selezione esclusiva",
    floorplan: true,
  },
];
export const money = (price: number) =>
  new Intl.NumberFormat("it-IT", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(price);
export const image = (name: string) => `/demos/vera/images/${name}.jpg`;
