"use client";
import { useEffect, useRef, useState } from "react";
import type { Map as LeafletMap } from "leaflet";
import { Property, money } from "@/lib/properties";
import "leaflet/dist/leaflet.css";
export default function PropertyMap({
  items,
  onAreaChange,
}: {
  items: Property[];
  onAreaChange?: (ids: string[]) => void;
}) {
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<LeafletMap | null>(null);
  const [error, setError] = useState(false);
  const [ready, setReady] = useState(false);
  const callback = useRef(onAreaChange);
  callback.current = onAreaChange;
  useEffect(() => {
    let cancelled = false;
    import("leaflet")
      .then((L) => {
        if (cancelled || !container.current) return;
        map.current = L.map(container.current, {
          scrollWheelZoom: false,
          zoomControl: false,
        }).setView([43.6, 10.2], 6);
        L.control
          .zoom({ zoomInTitle: "Ingrandisci", zoomOutTitle: "Riduci" })
          .addTo(map.current);
        L.tileLayer(
          "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
          {
            attribution:
              '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
            maxZoom: 18,
          },
        )
          .on("tileerror", () => setError(true))
          .on("tileload", () => setError(false))
          .addTo(map.current);
        setReady(true);
        setTimeout(() => map.current?.invalidateSize(), 100);
      })
      .catch(() => setError(true));
    return () => {
      cancelled = true;
      map.current?.remove();
      map.current = null;
    };
  }, []);
  useEffect(() => {
    if (!ready || !map.current) return;
    let cleanup = () => {};
    let cancelled = false;
    import("leaflet").then((L) => {
      if (cancelled || !map.current) return;
      const group = L.layerGroup().addTo(map.current);
      items.forEach((p) => {
        const icon = L.divIcon({
          className: "price-marker",
          html: `<span>${p.price >= 1000000 ? (p.price / 1000000).toLocaleString("it-IT") + " M €" : money(p.price)}</span>`,
          iconSize: [90, 34],
          iconAnchor: [45, 17],
        });
        const marker = L.marker([p.lat, p.lng], {
          icon,
          keyboard: true,
          title: p.name,
        }).addTo(group);
        const box = document.createElement("div");
        const title = document.createElement("strong");
        title.textContent = p.name;
        const location = document.createElement("p");
        location.textContent = `${p.area}, ${p.city} · ${p.size} m²`;
        const link = document.createElement("a");
        link.href = `/proprieta/${p.slug}/`;
        link.textContent = "Scopri la proprietà ↗";
        box.append(title, location, link);
        const close = document.createElement("button");
        close.type = "button";
        close.textContent = "Chiudi anteprima";
        close.className = "popup-close";
        close.addEventListener("click", () => marker.closePopup());
        box.append(close);
        marker.bindPopup(box, { closeButton: false });
      });
      if (items.length)
        map.current.fitBounds(
          L.latLngBounds(items.map((p) => [p.lat, p.lng])),
          { padding: [60, 60], maxZoom: 12, animate: false },
        );
      const moved = () => {
        if (map.current)
          callback.current?.(
            items
              .filter((p) => map.current!.getBounds().contains([p.lat, p.lng]))
              .map((p) => p.id),
          );
      };
      map.current.on("moveend", moved);
      cleanup = () => {
        map.current?.off("moveend", moved);
        group.remove();
      };
    });
    return () => {
      cancelled = true;
      cleanup();
    };
  }, [items, ready]);
  return (
    <div className="map-wrap" data-lenis-prevent>
      <div
        ref={container}
        className="leaflet-canvas"
        role="region"
        aria-label="Mappa interattiva delle posizioni indicative degli immobili"
      />
      {error && (
        <div className="map-error">
          La cartografia non è disponibile. Puoi esplorare tutti gli immobili
          nell’elenco.
        </div>
      )}
      <button
        className="map-reset"
        onClick={() => {
          if (items.length && map.current) {
            import("leaflet").then((L) =>
              map.current?.fitBounds(
                L.latLngBounds(items.map((p) => [p.lat, p.lng])),
                { padding: [60, 60], maxZoom: 12 },
              ),
            );
            callback.current?.(items.map((p) => p.id));
          }
        }}
      >
        Mostra tutte le proprietà
      </button>
    </div>
  );
}
