"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowUpRight, ArrowRight, MapPin } from "lucide-react";
import { image, money, properties } from "@/lib/properties";
import { FavoriteButton, TextLink } from "./Shell";

export function ImmersiveCollection() {
  const section = useRef<HTMLElement>(null);
  const rail = useRef<HTMLDivElement>(null);
  const progress = useRef<HTMLSpanElement>(null);
  const scene = useRef<ScrollTrigger | null>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add(
      "(min-width: 1000px) and (prefers-reduced-motion: no-preference)",
      () => {
        if (!rail.current || !section.current) return;
        const distance = () =>
          Math.max(0, rail.current!.scrollWidth - section.current!.clientWidth);
        const animation = gsap.to(rail.current, {
          x: () => -distance(),
          ease: "none",
          scrollTrigger: {
            trigger: section.current,
            start: "top 84px",
            end: () => `+=${distance()}`,
            pin: true,
            scrub: 0.8,
            invalidateOnRefresh: true,
            anticipatePin: 1,
            onUpdate: (self) => {
              if (progress.current)
                progress.current.style.transform = `scaleX(${self.progress})`;
            },
          },
        });
        scene.current = animation.scrollTrigger!;
        return () => {
          scene.current = null;
        };
      },
    );
    return () => mm.revert();
  }, []);
  return (
    <section
      className="collection-scene"
      ref={section}
      aria-label="Selezione di proprietà"
      onFocusCapture={(e) => {
        if (
          !scene.current ||
          !rail.current ||
          !e.target.matches(":focus-visible")
        )
          return;
        const card = e.target.closest<HTMLElement>(".collection-residence");
        if (!card) return;
        const distance =
          rail.current.scrollWidth - (section.current?.clientWidth || 0);
        const offset = Math.max(0, card.offsetLeft - 80);
        const y =
          scene.current.start +
          Math.min(1, offset / Math.max(1, distance)) *
            (scene.current.end - scene.current.start);
        window.scrollTo({ top: y, behavior: "instant" });
      }}
    >
      <div className="collection-topline">
        <span className="eyebrow">LA COLLEZIONE / EDIZIONE 01</span>
        <span className="eyebrow">
          SCORRI PER ESPLORARE <ArrowRight size={14} />
        </span>
      </div>
      <div className="collection-rail" ref={rail}>
        {properties.slice(0, 4).map((p, i) => (
          <article className="collection-residence" key={p.id}>
            <div className="collection-photograph">
              <Link
                href={`/proprieta/${p.slug}/`}
                aria-label={`Scopri ${p.name}`}
              >
                <img
                  src={image(p.image)}
                  alt={`${p.name}, fotografia illustrativa`}
                  width="1400"
                  height="1000"
                  loading="lazy"
                />
                <span className="collection-discover">
                  Entra <ArrowUpRight size={24} />
                </span>
              </Link>
              <span className="collection-index">
                0{i + 1}
                <sup>/ 04</sup>
              </span>
              <FavoriteButton id={p.id} />
              <div className="collection-photo-caption">
                <MapPin size={12} />
                {p.area}, {p.city}
                <span>SELEZIONE DEMO</span>
              </div>
            </div>
            <div className="collection-caption">
              <div>
                <span className="eyebrow">
                  {p.type} · {p.size} M² · {p.beds} CAMERE
                </span>
                <Link href={`/proprieta/${p.slug}/`}>
                  <h3>{p.name}</h3>
                </Link>
              </div>
              <div>
                <span>{money(p.price)}</span>
                <Link
                  href={`/proprieta/${p.slug}/`}
                  className="collection-arrow"
                  aria-label={`Esplora ${p.name}`}
                >
                  <ArrowUpRight size={28} />
                </Link>
              </div>
            </div>
          </article>
        ))}
        <div className="collection-finale">
          <span className="eyebrow">OGNI LUOGO, UNA POSSIBILITÀ.</span>
          <h3>
            La prossima
            <br />
            storia è <em>tua.</em>
          </h3>
          <TextLink href="/proprieta/">Tutta la collezione</TextLink>
        </div>
      </div>
      <div className="collection-meter">
        <span ref={progress} />
      </div>
    </section>
  );
}

export function PortalScene() {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add(
      "(min-width: 1000px) and (prefers-reduced-motion: no-preference)",
      () => {
        const ctx = gsap.context(() => {
          const tl = gsap.timeline({
            scrollTrigger: {
              trigger: root.current,
              start: "top top",
              end: "+=140%",
              pin: true,
              scrub: 0.9,
              anticipatePin: 1,
            },
          });
          tl.set(".portal-prologue", { autoAlpha: 1 })
            .fromTo(
              ".portal-frame",
              { clipPath: "inset(23% 35% 7% 35% round 48% 48% 0% 0%)" },
              {
                clipPath: "inset(0% 0% 0% 0% round 0% 0% 0% 0%)",
                duration: 1,
                ease: "power2.inOut",
              },
              0,
            )
            .fromTo(
              ".portal-frame img",
              { scale: 1.35 },
              { scale: 1, duration: 1.2, ease: "none" },
              0,
            )
            .to(
              ".portal-prologue",
              { scale: 1.3, autoAlpha: 0, duration: 0.55 },
              0.1,
            )
            .fromTo(
              ".portal-final",
              { y: 90, autoAlpha: 0 },
              { y: 0, autoAlpha: 1, duration: 0.5 },
              0.75,
            )
            .fromTo(
              ".portal-final h2",
              { clipPath: "inset(0 0 100% 0)" },
              { clipPath: "inset(0 0 0% 0)", duration: 0.45 },
              0.8,
            );
        }, root);
        return () => ctx.revert();
      },
    );
    return () => mm.revert();
  }, []);
  return (
    <section ref={root} className="portal-scene" id="experience">
      <div className="portal-prologue" aria-hidden="true">
        <p className="eyebrow">03 — CAMBIA PROSPETTIVA</p>
        <span>
          Oltre
          <br />
          <em>l’ordinario.</em>
        </span>
        <span className="portal-coordinate">
          45°50′ N &nbsp; 09°04′ E<br />
          UN ALTRO MODO DI ABITARE
        </span>
      </div>
      <div className="portal-frame">
        <img
          src={image("architecture")}
          alt="Una residenza contemporanea immersa nel giardino"
          width="1800"
          height="1200"
          loading="lazy"
        />
        <div className="portal-shade" />
      </div>
      <div className="portal-final">
        <p className="eyebrow">THE ART OF LIVING / IL JOURNAL VÉRA</p>
        <h2>
          La vita,
          <br />
          <em>in un altro modo.</em>
        </h2>
        <div>
          <p>
            La luce che cambia una stanza.
            <br />
            Il silenzio che diventa un privilegio.
            <br />
            La bellezza delle cose essenziali.
          </p>
          <TextLink href="/experience/" light>
            Entra nel nostro universo
          </TextLink>
        </div>
      </div>
      <span className="portal-side">ARCHITETTURA / EMOZIONE / VITA</span>
    </section>
  );
}

export function LivingStatement() {
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      const ctx = gsap.context(() => {
        const words = gsap.utils.toArray<HTMLElement>(".statement-word");
        gsap.fromTo(
          words,
          { color: "#5b564e" },
          {
            color: "#f5f1e9",
            stagger: 0.12,
            ease: "none",
            scrollTrigger: {
              trigger: root.current,
              start: "top 65%",
              end: "bottom 80%",
              scrub: 0.4,
            },
          },
        );
        gsap.fromTo(
          ".statement-orbit",
          { rotation: -35 },
          {
            rotation: 35,
            ease: "none",
            scrollTrigger: {
              trigger: root.current,
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          },
        );
      }, root);
      return () => ctx.revert();
    });
    return () => mm.revert();
  }, []);
  const text = "Ci sono case che si guardano. E luoghi che si sentono.";
  return (
    <section ref={root} className="living-statement">
      <div className="statement-orbit" aria-hidden="true" />
      <div className="statement-kicker">
        <span className="eyebrow">VÉRA / UNA QUESTIONE DI PERCEZIONE</span>
        <span>01 — 04</span>
      </div>
      <h2 aria-label={text}>
        {text.split(" ").map((word, i) => (
          <span
            className={`statement-word ${i > 6 ? "statement-italic" : ""}`}
            aria-hidden="true"
            key={i}
          >
            {word}{" "}
          </span>
        ))}
      </h2>
      <div className="statement-end">
        <span className="eyebrow">
          NON È DOVE VIVI.
          <br />È COME TI FA SENTIRE.
        </span>
        <Link
          href="#selezione"
          className="statement-next"
          aria-label="Scopri la collezione"
        >
          <ArrowRight size={28} />
        </Link>
      </div>
    </section>
  );
}
