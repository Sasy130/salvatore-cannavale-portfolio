"use client";
import { createContext, useContext, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight, Heart, Menu, X, ArrowRight } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Lenis from "lenis";
import { CinematicNavigation, MotionAtmosphere } from "./CinematicMotion";
const FavoritesContext = createContext<{
  favorites: string[];
  toggle: (id: string) => void;
}>({ favorites: [], toggle: () => {} });
export const useFavorites = () => useContext(FavoritesContext);
const links = [
  ["Proprietà", "/proprieta/"],
  ["Il mondo VÉRA", "/chi-siamo/"],
  ["Servizi", "/servizi/"],
  ["Contatti", "/contatti/"],
];
export function Shell({ children }: { children: React.ReactNode }) {
  const [favorites, setFavorites] = useState<string[]>([]);
  const [ready, setReady] = useState(false);
  const [menu, setMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const path = usePathname();
  const menuRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const opener = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    try {
      const raw = JSON.parse(localStorage.getItem("vera-favorites") || "[]");
      if (Array.isArray(raw))
        setFavorites(raw.filter((x) => typeof x === "string"));
    } catch {}
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready)
      try {
        localStorage.setItem("vera-favorites", JSON.stringify(favorites));
      } catch {}
  }, [favorites, ready]);
  useEffect(() => {
    setMenu(false);
    const update = () => setScrolled(window.scrollY > 30);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, [path]);
  useEffect(() => {
    if (!menu) return;
    closeRef.current?.focus();
    const old = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenu(false);
      if (e.key === "Tab") {
        const els = menuRef.current?.querySelectorAll<HTMLElement>("a,button");
        if (!els?.length) return;
        const first = els[0],
          last = els[els.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = old;
      document.removeEventListener("keydown", key);
      opener.current?.focus();
    };
  }, [menu]);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const lenis = new Lenis({
      duration: 1.05,
      smoothWheel: true,
      anchors: true,
    });
    lenis.on("scroll", ScrollTrigger.update);
    const stop = () => lenis.stop();
    const resume = () => {
      lenis.scrollTo(window.scrollY, { immediate: true, force: true });
      lenis.start();
    };
    window.addEventListener("vera:navigation-start", stop);
    window.addEventListener("vera:navigation-end", resume);
    const tick = (time: number) => lenis.raf(time * 1000);
    gsap.ticker.add(tick);
    return () => {
      window.removeEventListener("vera:navigation-start", stop);
      window.removeEventListener("vera:navigation-end", resume);
      gsap.ticker.remove(tick);
      lenis.destroy();
    };
  }, []);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((el) => {
        gsap.fromTo(
          el,
          { y: 50, opacity: 0, clipPath: "inset(0% 0% 16% 0%)" },
          {
            y: 0,
            opacity: 1,
            clipPath: "inset(0% 0% 0% 0%)",
            duration: 1,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 94%", once: true },
          },
        );
      });
      gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((el) => {
        gsap.to(el, {
          yPercent: 7,
          ease: "none",
          scrollTrigger: {
            trigger: el.parentElement,
            start: "top top",
            end: "bottom top",
            scrub: true,
          },
        });
      });
    });
    const timer = setTimeout(() => ScrollTrigger.refresh(), 350);
    return () => {
      clearTimeout(timer);
      ctx.revert();
    };
  }, [path]);
  const toggle = (id: string) =>
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  const isHero = path === "/" || /^\/proprieta\/[^/]+/.test(path);
  return (
    <FavoritesContext.Provider value={{ favorites, toggle }}>
      <CinematicNavigation />
      <MotionAtmosphere />
      <a href="#contenuto" className="skip-link">
        Vai al contenuto
      </a>
      <header className={`header ${scrolled || !isHero ? "solid" : ""}`}>
        <Link href="/" className="brand" aria-label="VÉRA, homepage">
          VÉRA<span>LUXURY REAL ESTATE</span>
        </Link>
        <nav aria-label="Navigazione principale">
          {links.map(([name, url]) => (
            <Link
              key={url}
              href={url}
              aria-current={path === url ? "page" : undefined}
            >
              {name}
            </Link>
          ))}
        </nav>
        <div className="header-actions">
          <Link
            href="/preferiti/"
            className="icon-button"
            aria-label={`Preferiti, ${favorites.length} immobili`}
          >
            <Heart size={18} />
            {favorites.length > 0 && (
              <span className="count">{favorites.length}</span>
            )}
          </Link>
          <Link className="header-contact" href="/valutazione/">
            Valuta il tuo immobile <ArrowUpRight size={15} />
          </Link>
          <button
            ref={opener}
            className="icon-button menu-trigger"
            aria-label="Apri menu"
            aria-expanded={menu}
            onClick={() => setMenu(true)}
          >
            <Menu size={23} />
          </button>
        </div>
      </header>
      {menu && (
        <div
          data-lenis-prevent
          ref={menuRef}
          className="full-menu"
          role="dialog"
          aria-modal="true"
          aria-label="Menu di navigazione"
        >
          <div className="menu-top">
            <Link className="brand" href="/">
              VÉRA<span>LUXURY REAL ESTATE</span>
            </Link>
            <button
              ref={closeRef}
              onClick={() => setMenu(false)}
              className="icon-button"
              aria-label="Chiudi menu"
            >
              <X />
            </button>
          </div>
          <div className="menu-links">
            {[
              ...links,
              ["Esplora sulla mappa", "/mappa/"],
              ["Preferiti", "/preferiti/"],
              ["Valuta il tuo immobile", "/valutazione/"],
            ].map(([name, url], i) => (
              <Link
                style={{ animationDelay: `${i * 45}ms` }}
                href={url}
                key={url}
              >
                <sup>0{i + 1}</sup>
                {name}
                <ArrowUpRight />
              </Link>
            ))}
          </div>
          <p className="eyebrow">Luoghi straordinari. Storie da abitare.</p>
        </div>
      )}
      <main id="contenuto" tabIndex={-1} key={path} className="page-enter">
        {children}
      </main>
      <footer>
        <div className="footer-call">
          <span className="eyebrow">LA TUA PROSSIMA STORIA</span>
          <Link href="/contatti/">
            Inizia con un incontro.
            <ArrowUpRight />
          </Link>
        </div>
        <div className="footer-grid">
          <Link className="brand footer-brand" href="/">
            VÉRA<span>LUXURY REAL ESTATE</span>
          </Link>
          <p>
            Un nuovo sguardo sull’abitare.
            <br />
            Una selezione di luoghi straordinari,
            <br />
            pensati per la tua storia.
          </p>
          <div>
            {links.map(([name, url]) => (
              <Link href={url} key={url}>
                {name}
              </Link>
            ))}
          </div>
          <div>
            <Link href="/mappa/">Esplora sulla mappa</Link>
            <Link href="/valutazione/">Valuta il tuo immobile</Link>
            <Link href="/preferiti/">I tuoi preferiti</Link>
            <Link href="/privacy/">Privacy e demo</Link>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} VÉRA — Progetto dimostrativo</span>
          <span>Fotografie illustrative · Immobili e prezzi demo</span>
          <a href="#contenuto">Torna in alto ↑</a>
        </div>
      </footer>
      <div className="demo-tag">Esperienza dimostrativa</div>
    </FavoritesContext.Provider>
  );
}
export function TextLink({
  href,
  children,
  light = false,
}: {
  href: string;
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <Link href={href} className={`text-link ${light ? "light" : ""}`}>
      {children}
      <ArrowUpRight size={18} />
    </Link>
  );
}
export function ButtonLink({
  href,
  children,
  outline = false,
}: {
  href: string;
  children: React.ReactNode;
  outline?: boolean;
}) {
  return (
    <Link href={href} className={`button ${outline ? "outline" : ""}`}>
      {children}
      <ArrowRight size={18} />
    </Link>
  );
}
export function FavoriteButton({ id }: { id: string }) {
  const { favorites, toggle } = useFavorites();
  const active = favorites.includes(id);
  return (
    <button
      type="button"
      className={`favorite ${active ? "active" : ""}`}
      onClick={() => toggle(id)}
      aria-label={active ? "Rimuovi dai preferiti" : "Salva nei preferiti"}
      aria-pressed={active}
    >
      <Heart size={19} fill={active ? "currentColor" : "none"} />
    </button>
  );
}
