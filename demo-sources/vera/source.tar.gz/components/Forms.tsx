"use client";
import { useEffect, useState } from "react";
import { ArrowUpRight, Check, RotateCcw } from "lucide-react";
export function DemoForm({
  kind = "contact",
  property,
}: {
  kind?: "contact" | "visit" | "valuation";
  property?: string;
}) {
  const [success, setSuccess] = useState(false);
  const [mode, setMode] = useState(kind === "visit" ? "visit" : "info");
  const [today, setToday] = useState("");
  useEffect(() => {
    const now = new Date();
    setToday(
      `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`,
    );
  }, []);
  if (success)
    return (
      <div className="form-success" role="status">
        <span>
          <Check size={28} />
        </span>
        <p className="eyebrow">SIMULAZIONE COMPLETATA</p>
        <h2>
          {kind === "valuation"
            ? "Il primo passo è fatto."
            : mode === "visit"
              ? "Un incontro da immaginare."
              : "Il dialogo inizia qui."}
        </h2>
        <p>
          I dati sono stati validati solo nel tuo browser. Nessun messaggio è
          stato inviato, nessun appuntamento è stato prenotato e nessun dato è
          stato salvato sui nostri server.
        </p>
        <button className="text-link" onClick={() => setSuccess(false)}>
          Prova di nuovo <RotateCcw size={16} />
        </button>
      </div>
    );
  return (
    <form
      className="demo-form"
      onSubmit={(e) => {
        e.preventDefault();
        if (e.currentTarget.reportValidity()) setSuccess(true);
      }}
    >
      {property && (
        <>
          <p className="form-property">
            La tua richiesta per <strong>{property}</strong>
          </p>
          <div className="form-tabs">
            <button
              type="button"
              aria-pressed={mode === "info"}
              onClick={() => setMode("info")}
            >
              Richiedi informazioni
            </button>
            <button
              type="button"
              aria-pressed={mode === "visit"}
              onClick={() => setMode("visit")}
            >
              Prenota una visita demo
            </button>
          </div>
        </>
      )}
      <div className="form-row">
        <label>
          Nome e cognome *
          <input
            name="name"
            autoComplete="name"
            placeholder="Come ti chiami?"
            required
            minLength={3}
          />
        </label>
        <label>
          Email *
          <input
            name="email"
            type="email"
            autoComplete="email"
            placeholder="La tua email"
            required
          />
        </label>
      </div>
      <div className="form-row">
        <label>
          Telefono
          <input
            name="phone"
            type="tel"
            autoComplete="tel"
            placeholder="Il tuo numero (facoltativo)"
            pattern="[+0-9 ()-]{6,22}"
          />
        </label>
        {kind === "valuation" ? (
          <label>
            Località dell’immobile *
            <input name="city" placeholder="Città o zona" required />
          </label>
        ) : (
          <label>
            Come preferisci essere contattato?
            <select name="preferred">
              <option>Email</option>
              <option>Telefono</option>
            </select>
          </label>
        )}
      </div>
      {kind === "valuation" && (
        <>
          <div className="form-row">
            <label>
              Tipologia *
              <select name="type" required>
                <option value="">Seleziona</option>
                <option>Villa</option>
                <option>Attico</option>
                <option>Appartamento</option>
                <option>Casale</option>
                <option>Loft</option>
              </select>
            </label>
            <label>
              Superficie (m²) *
              <input
                type="number"
                name="size"
                min="15"
                max="10000"
                placeholder="Es. 240"
                required
              />
            </label>
          </div>
          <label>
            Il tuo obiettivo
            <select name="goal">
              <option>Desidero vendere</option>
              <option>Desidero affittare</option>
              <option>Voglio conoscere il valore</option>
            </select>
          </label>
        </>
      )}
      {mode === "visit" && (
        <div className="form-row">
          <label>
            Giorno desiderato *
            <input type="date" name="date" min={today} required />
          </label>
          <label>
            Fascia oraria *
            <select name="time" required>
              <option value="">Scegli un orario</option>
              <option>Mattina · 09:00–12:00</option>
              <option>Pomeriggio · 14:00–18:00</option>
            </select>
          </label>
        </div>
      )}
      <label>
        {kind === "valuation"
          ? "Raccontaci il tuo immobile"
          : "Il tuo messaggio"}
        <textarea
          name="message"
          rows={4}
          placeholder={
            kind === "valuation"
              ? "Le caratteristiche che lo rendono speciale…"
              : "Cosa possiamo aiutarti a trovare?"
          }
          maxLength={2000}
        />
      </label>
      <label className="consent">
        <input type="checkbox" name="consent" required />
        <span>
          Ho letto l’<a href="/demos/vera/privacy/">informativa sulla demo</a> e comprendo
          che questa è una simulazione senza invio dei dati. *
        </span>
      </label>
      <button className="button" type="submit">
        {kind === "valuation"
          ? "Simula la richiesta di valutazione"
          : mode === "visit"
            ? "Simula la prenotazione"
            : "Simula l’invio della richiesta"}
        <ArrowUpRight size={18} />
      </button>
      <p className="form-notice">
        Demo senza backend: nessun invio reale, pagamento o prenotazione. I
        campi con * sono obbligatori.
      </p>
    </form>
  );
}
