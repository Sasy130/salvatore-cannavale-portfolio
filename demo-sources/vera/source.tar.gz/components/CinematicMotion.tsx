"use client";
import { useEffect, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { cinematicDestination } from "@/lib/navigation";

/** A short shutter between real routes. Links retain native behavior without JS. */
export function CinematicNavigation() {
  const root = useRef<HTMLDivElement>(null);
  const active = useRef(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const router = useRouter();
  const path = usePathname();
  const reveal = useRef(() => {});
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    const panels = element.querySelectorAll(".route-panel");
    const brand = element.querySelector(".route-brand");
    const finish = () => {
      active.current = false;
      element.classList.remove("is-active");
      window.dispatchEvent(new Event("vera:navigation-end"));
    };
    reveal.current = () => {
      if (!active.current) return;
      if (timer.current) clearTimeout(timer.current);
      gsap
        .timeline({ onComplete: finish })
        .to(brand, { opacity: 0, duration: 0.15 })
        .to(
          panels,
          {
            scaleY: 0,
            transformOrigin: "50% 0%",
            duration: 0.6,
            stagger: 0.055,
            ease: "power4.inOut",
          },
          0.05,
        );
    };
    const click = (event: MouseEvent) => {
      if (
        event.defaultPrevented ||
        event.button !== 0 ||
        event.metaKey ||
        event.ctrlKey ||
        event.shiftKey ||
        event.altKey ||
        matchMedia("(prefers-reduced-motion: reduce)").matches
      )
        return;
      const anchor = (event.target as Element).closest<HTMLAnchorElement>(
        "a[href]",
      );
      if (
        !anchor ||
        anchor.target === "_blank" ||
        anchor.hasAttribute("download") ||
        anchor.closest(".leaflet-container")
      )
        return;
      const destination = cinematicDestination(anchor.href, location.href);
      if (!destination) return;
      event.preventDefault();
      if (active.current) return;
      active.current = true;
      element.classList.add("is-active");
      window.dispatchEvent(new Event("vera:navigation-start"));
      router.prefetch(destination.split(/[?#]/)[0]);
      gsap.killTweensOf([panels, brand]);
      gsap.set(panels, { scaleY: 0, transformOrigin: "50% 100%" });
      gsap.set(brand, { opacity: 0 });
      gsap
        .timeline()
        .to(panels, {
          scaleY: 1,
          duration: 0.48,
          stagger: 0.045,
          ease: "power4.inOut",
        })
        .to(brand, { opacity: 1, duration: 0.2 }, 0.3)
        .call(() => {
          router.push(destination);
          timer.current = setTimeout(() => reveal.current(), 2200);
        });
    };
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("click", click, true);
      if (timer.current) clearTimeout(timer.current);
      gsap.killTweensOf([panels, brand]);
    };
  }, [router]);
  useEffect(() => {
    if (!active.current) return;
    reveal.current();
    document.getElementById("contenuto")?.focus({ preventScroll: true });
  }, [path]);
  return (
    <div ref={root} className="route-shutter" aria-hidden="true">
      <span className="route-panel" />
      <span className="route-panel" />
      <span className="route-panel" />
      <div className="route-brand">
        VÉRA<span>IL PROSSIMO CAPITOLO</span>
      </div>
    </div>
  );
}

/** Low-cost pointer transforms; touch and reduced motion get the static design. */
export function MotionAtmosphere() {
  const path = usePathname();
  const progress = useRef<HTMLDivElement>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      gsap.fromTo(
        progress.current,
        { scaleX: 0 },
        {
          scaleX: 1,
          ease: "none",
          scrollTrigger: { start: 0, end: "max", scrub: 0.1 },
        },
      );
    });
    mm.add(
      "(min-width: 1000px) and (hover: hover) and (pointer: fine) and (prefers-reduced-motion: no-preference)",
      () => {
        const elements = Array.from(
          document.querySelectorAll<HTMLElement>(
            ".button, .collection-arrow, .statement-next, .hero-about",
          ),
        );
        const cleanups = elements.map((el) => {
          const x = gsap.quickTo(el, "x", {
              duration: 0.35,
              ease: "power3.out",
            }),
            y = gsap.quickTo(el, "y", { duration: 0.35, ease: "power3.out" });
          const move = (e: PointerEvent) => {
            const r = el.getBoundingClientRect();
            x((e.clientX - r.left - r.width / 2) * 0.13);
            y((e.clientY - r.top - r.height / 2) * 0.18);
          };
          const leave = () => {
            x(0);
            y(0);
          };
          el.addEventListener("pointermove", move);
          el.addEventListener("pointerleave", leave);
          return () => {
            el.removeEventListener("pointermove", move);
            el.removeEventListener("pointerleave", leave);
            x.tween.kill();
            y.tween.kill();
            gsap.set(el, { clearProps: "transform" });
          };
        });
        return () => cleanups.forEach((clean) => clean());
      },
    );
    const loaded = () => ScrollTrigger.refresh();
    window.addEventListener("load", loaded);
    return () => {
      window.removeEventListener("load", loaded);
      mm.revert();
    };
  }, [path]);
  return (
    <>
      <div className="reading-progress" ref={progress} aria-hidden="true" />
      <div className="film-texture" aria-hidden="true" />
    </>
  );
}

export function ChapterNavigation() {
  const root = useRef<HTMLElement>(null);
  const chapters = [
    ["opening", "Apertura"],
    ["selezione", "La collezione"],
    ["essenza", "L’essenza"],
    ["experience", "L’esperienza"],
    ["destinazioni", "I luoghi"],
  ];
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const ctx = gsap.context(() => {
      chapters.forEach(([id], i) => {
        const el = document.getElementById(id);
        if (!el) return;
        ScrollTrigger.create({
          trigger: el,
          start: "top 45%",
          end: "bottom 45%",
          onToggle: (self) => {
            root.current?.querySelectorAll("a").forEach((a, index) => {
              if (self.isActive && i === index)
                a.setAttribute("aria-current", "location");
              else if (self.isActive) a.removeAttribute("aria-current");
            });
          },
        });
      });
    });
    return () => ctx.revert();
    // The chapter list is static for the lifetime of the home page.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <nav
      ref={root}
      className="chapter-nav"
      aria-label="Capitoli della homepage"
    >
      {chapters.map(([id, label], i) => (
        <a href={`#${id}`} key={id}>
          <span>{String(i + 1).padStart(2, "0")}</span>
          <i />
          <b>{label}</b>
        </a>
      ))}
    </nav>
  );
}
