"use client";
import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import Link from "next/link";
import dynamic from "next/dynamic";
import {
  ArrowDown,
  ArrowUpRight,
  ArrowLeft,
  ArrowRight,
  X,
  Images,
  MapPin,
  Maximize,
  BedDouble,
  Bath,
  Check,
  Share2,
} from "lucide-react";
import { Property, properties, image, money } from "@/lib/properties";
import { FavoriteButton, TextLink } from "./Shell";
import { PropertyCard } from "./Properties";
import { DemoForm } from "./Forms";
const PropertyMap = dynamic(() => import("./PropertyMap"), {
  ssr: false,
  loading: () => <div className="map-loading">Caricamento della mappa…</div>,
});
export function PropertyDetail({ property: p }: { property: Property }) {
  const [photo, setPhoto] = useState<number | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const [shared, setShared] = useState("");
  const start = useRef(0);
  const mapItems = useRef([p]);
  const motionRoot = useRef<HTMLDivElement>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add(
      "(min-width: 1000px) and (prefers-reduced-motion: no-preference)",
      () => {
        const ctx = gsap.context(() => {
          gsap.from(".detail-hero h1", {
            y: 70,
            clipPath: "inset(0 0 100% 0)",
            duration: 1.3,
            ease: "power4.out",
            delay: 0.2,
          });
          gsap.to(".detail-hero-content", {
            yPercent: -25,
            ease: "none",
            scrollTrigger: {
              trigger: ".detail-hero",
              start: "top top",
              end: "bottom top",
              scrub: 1,
            },
          });
          gsap.utils
            .toArray<HTMLElement>(".gallery-strip>button")
            .forEach((el) => {
              gsap.fromTo(
                el,
                { clipPath: "inset(10% 6% 10% 6%)" },
                {
                  clipPath: "inset(0% 0% 0% 0%)",
                  ease: "none",
                  scrollTrigger: {
                    trigger: el,
                    start: "top 90%",
                    end: "top 40%",
                    scrub: 0.7,
                  },
                },
              );
            });
        }, motionRoot);
        return () => ctx.revert();
      },
    );
    return () => mm.revert();
  }, []);
  useEffect(() => {
    if (photo !== null && !dialog.current?.open) dialog.current?.showModal();
    if (photo === null && dialog.current?.open) dialog.current.close();
  }, [photo]);
  const next = (delta: number) =>
    setPhoto((n) => ((n ?? 0) + delta + p.gallery.length) % p.gallery.length);
  async function share() {
    try {
      await navigator.clipboard.writeText(location.href);
      setShared("Link copiato");
    } catch {
      setShared("Copia il link dalla barra degli indirizzi");
    }
    setTimeout(() => setShared(""), 4000);
  }
  return (
    <div ref={motionRoot} className="cinematic-detail">
      <section className="detail-hero">
        <img
          src={image(p.image)}
          alt={`${p.name}, immagine illustrativa`}
          fetchPriority="high"
          width="1800"
          height="1200"
          data-parallax
        />
        <div className="detail-shade" />
        <div className="detail-hero-content">
          <Link href="/proprieta/" className="back-link">
            <ArrowLeft size={15} />
            La collezione
          </Link>
          <p className="eyebrow">
            {p.region} — {p.area}
          </p>
          <h1>{p.name}</h1>
          <p>Un altro modo di sentirsi a casa.</p>
        </div>
        <div className="detail-hero-bottom">
          <a href="#dimora" className="scroll-cue">
            <ArrowDown size={17} />
            SCOPRI LA DIMORA
          </a>
          <button className="gallery-open" onClick={() => setPhoto(0)}>
            <Images size={18} />
            Esplora la galleria · {p.gallery.length} foto
          </button>
        </div>
        <span className="detail-demo-label">
          Fotografia illustrativa · Proprietà demo
        </span>
      </section>
      <section className="detail-summary section" id="dimora">
        <div>
          <p className="eyebrow">
            {p.id} · {p.contract.toUpperCase()} · {p.status.toUpperCase()}
          </p>
          <h2>
            {money(p.price)}
            {p.contract === "Affitto" && <small> / mese</small>}
          </h2>
          <p>
            <MapPin size={15} />
            {p.area}, {p.city} · Posizione indicativa
          </p>
        </div>
        <div className="detail-stats">
          <span>
            <Maximize size={21} />
            <strong>
              {p.size} <small>m²</small>
            </strong>
            SUPERFICIE
          </span>
          <span>
            <BedDouble size={23} />
            <strong>{p.beds}</strong>CAMERE
          </span>
          <span>
            <Bath size={23} />
            <strong>{p.baths}</strong>BAGNI
          </span>
        </div>
        <div className="detail-actions">
          <FavoriteButton id={p.id} />
          <button
            className="icon-button"
            onClick={share}
            aria-label="Copia link della proprietà"
          >
            <Share2 size={20} />
          </button>
          <span role="status">{shared}</span>
        </div>
      </section>
      <section className="detail-editorial section">
        <div data-reveal>
          <p className="eyebrow">L’ANIMA DI QUESTA CASA</p>
          <h2>
            Spazio alla luce.
            <br />
            <em>Spazio alla vita.</em>
          </h2>
        </div>
        <div data-reveal>
          <p className="lead">{p.description}</p>
          <p>
            Un progetto abitativo da immaginare attraverso atmosfere, materiali
            e proporzioni. Questa scheda fa parte della collezione demo VÉRA: le
            fotografie sono riferimenti visivi e non documentano una proprietà
            realmente disponibile.
          </p>
          <div className="feature-list">
            {p.features.map((f) => (
              <span key={f}>
                <Check size={15} />
                {f}
              </span>
            ))}
          </div>
          <a href="#richiesta" className="text-link">
            Immagina il tuo prossimo capitolo <ArrowUpRight size={18} />
          </a>
        </div>
      </section>
      <section className="detail-gallery section">
        <div
          className="gallery-strip"
          onTouchStart={(e) => (start.current = e.touches[0].clientX)}
          onTouchEnd={(e) => {
            if (Math.abs(start.current - e.changedTouches[0].clientX) > 50)
              e.currentTarget.scrollBy({
                left: start.current > e.changedTouches[0].clientX ? 300 : -300,
                behavior: "smooth",
              });
          }}
        >
          {p.gallery.map((img, i) => (
            <button
              onClick={() => setPhoto(i)}
              key={i}
              aria-label={`Apri fotografia ${i + 1} di ${p.gallery.length}`}
            >
              <img
                src={image(img)}
                alt={`${p.name}, ispirazione architettonica ${i + 1}`}
                loading="lazy"
                width="1200"
                height="900"
              />
              <span>
                0{i + 1} / 0{p.gallery.length}
                <Maximize size={17} />
              </span>
            </button>
          ))}
        </div>
        <p className="photo-note">
          Fotografie di ispirazione · Scorri per esplorare, tocca per ingrandire
        </p>
      </section>
      <section className="technical section">
        <div>
          <p className="eyebrow">I DETTAGLI CHE CONTANO</p>
          <h2>
            Ogni elemento,
            <br />
            <em>al suo posto.</em>
          </h2>
        </div>
        <dl>
          {[
            ["Riferimento", p.id],
            ["Tipologia", p.type],
            ["Contratto", p.contract],
            ["Superficie", p.size + " m²"],
            ["Camere", String(p.beds)],
            ["Bagni", String(p.baths)],
            ["Classe energetica", "Non disponibile · demo"],
            ["Disponibilità", "Annuncio dimostrativo"],
          ].map(([key, val]) => (
            <div key={key}>
              <dt>{key}</dt>
              <dd>{val}</dd>
            </div>
          ))}
        </dl>
        {p.floorplan && (
          <details className="floorplan">
            <summary>
              Esplora la planimetria dimostrativa <ArrowUpRight size={18} />
            </summary>
            <svg
              viewBox="0 0 600 360"
              role="img"
              aria-label="Schema di distribuzione illustrativo: soggiorno, cucina, terrazza e zona notte"
            >
              <rect
                x="20"
                y="20"
                width="560"
                height="320"
                fill="#eae5dc"
                stroke="#85827D"
                strokeWidth="3"
              />
              <path
                d="M340 20V340 M20 220H340 M340 150H580 M450 150V340 M150 220V340"
                fill="none"
                stroke="#85827D"
                strokeWidth="3"
              />
              <g
                textAnchor="middle"
                fill="#555"
                fontSize="14"
                fontFamily="sans-serif"
              >
                <text x="180" y="120">
                  SOGGIORNO
                </text>
                <text x="85" y="285">
                  CUCINA
                </text>
                <text x="250" y="285">
                  TERRAZZA
                </text>
                <text x="460" y="90">
                  ZONA NOTTE
                </text>
                <text x="395" y="250">
                  BAGNO
                </text>
                <text x="515" y="250">
                  CAMERA
                </text>
              </g>
            </svg>
            <p>
              Schema illustrativo non in scala. Non rappresenta la distribuzione
              reale dell’immobile.
            </p>
          </details>
        )}
      </section>
      <section className="detail-position section">
        <div className="section-top">
          <div>
            <p className="eyebrow">IL CONTESTO, PARTE DELLA STORIA</p>
            <h2>
              {p.area}.<br />
              <em>Il tuo orizzonte.</em>
            </h2>
          </div>
          <p className="section-aside">
            {p.city}, {p.region}. Un luogo da esplorare con uno sguardo nuovo.
            Il marker indica soltanto una zona dimostrativa e non un indirizzo
            reale.
          </p>
        </div>
        <div className="detail-map">
          <PropertyMap items={mapItems.current} />
        </div>
      </section>
      <section className="contact-section section" id="richiesta">
        <div data-reveal>
          <p className="eyebrow">PARLIAMONE INSIEME</p>
          <h2>
            Ogni storia inizia
            <br />
            <em>con un incontro.</em>
          </h2>
          <p>
            Un’informazione in più, una visita da immaginare.
            <br />
            Esplora il percorso di contatto della nostra demo.
          </p>
          <div className="contact-demo-note">
            SIMULAZIONE · Nessuna richiesta sarà inviata.
          </div>
        </div>
        <DemoForm property={p.name} />
      </section>
      <section className="section similar">
        <div className="section-top">
          <div>
            <p className="eyebrow">ALTRE STORIE DA ABITARE</p>
            <h2>
              Potresti <em>innamorarti.</em>
            </h2>
          </div>
          <TextLink href="/proprieta/">Tutta la collezione</TextLink>
        </div>
        <div className="results-grid">
          {properties
            .filter((item) => item.id !== p.id)
            .sort(
              (a, b) => Number(b.type === p.type) - Number(a.type === p.type),
            )
            .slice(0, 3)
            .map((item) => (
              <PropertyCard key={item.id} property={item} />
            ))}
        </div>
      </section>
      <dialog
        data-lenis-prevent
        ref={dialog}
        className="lightbox"
        onCancel={() => setPhoto(null)}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") next(1);
          if (e.key === "ArrowLeft") next(-1);
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget) setPhoto(null);
        }}
      >
        <button
          autoFocus
          className="lightbox-close icon-button"
          onClick={() => setPhoto(null)}
          aria-label="Chiudi galleria"
        >
          <X />
        </button>
        {photo !== null && (
          <>
            <img
              key={photo}
              src={image(p.gallery[photo])}
              alt={`Fotografia illustrativa ${photo + 1} di ${p.gallery.length}`}
              onTouchStart={(e) => (start.current = e.touches[0].clientX)}
              onTouchEnd={(e) => {
                const delta = start.current - e.changedTouches[0].clientX;
                if (Math.abs(delta) > 40) next(delta > 0 ? 1 : -1);
              }}
            />
            <div className="lightbox-controls">
              <button
                className="icon-button"
                onClick={() => next(-1)}
                aria-label="Fotografia precedente"
              >
                <ArrowLeft />
              </button>
              <span aria-live="polite">
                {photo + 1} / {p.gallery.length} — Fotografia illustrativa
              </span>
              <button
                className="icon-button"
                onClick={() => next(1)}
                aria-label="Fotografia successiva"
              >
                <ArrowRight />
              </button>
            </div>
          </>
        )}
      </dialog>
    </div>
  );
}
