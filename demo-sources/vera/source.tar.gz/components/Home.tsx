"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowDown,
  ArrowUpRight,
  ArrowLeft,
  ArrowRight,
  Search,
  MapPin,
  ChevronDown,
} from "lucide-react";
import gsap from "gsap";
import { properties, image } from "@/lib/properties";
import { ButtonLink, TextLink } from "./Shell";
import {
  ImmersiveCollection,
  PortalScene,
  LivingStatement,
} from "./ImmersiveScenes";
import { ChapterNavigation } from "./CinematicMotion";
import { ScrollTrigger } from "gsap/ScrollTrigger";
export function Home() {
  const root = useRef<HTMLDivElement>(null);
  const intro = useRef<HTMLDivElement>(null);
  const timeline = useRef<gsap.core.Timeline | null>(null);
  const [introDone, setIntroDone] = useState(false);
  const [slide, setSlide] = useState(0);
  const [city, setCity] = useState("");
  const [type, setType] = useState("");
  const [contract, setContract] = useState("Vendita");
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add(
      "(min-width: 1000px) and (prefers-reduced-motion: no-preference)",
      () => {
        const ctx = gsap.context(() => {
          gsap
            .timeline({
              scrollTrigger: {
                trigger: ".hero",
                start: "top top",
                end: "+=65%",
                pin: true,
                scrub: 0.8,
                anticipatePin: 1,
              },
            })
            .to(".hero-content", { yPercent: -65, opacity: 0, ease: "none" }, 0)
            .to(".hero-camera", { scale: 1.15, ease: "none" }, 0)
            .to(
              ".hero-watermark",
              { yPercent: 15, opacity: 0.35, ease: "none" },
              0,
            );
          gsap.fromTo(
            ".manifesto-photo",
            { clipPath: "inset(15% 8% 15% 8%)" },
            {
              clipPath: "inset(0% 0% 0% 0%)",
              ease: "none",
              scrollTrigger: {
                trigger: ".manifesto",
                start: "top 80%",
                end: "top 20%",
                scrub: 1,
              },
            },
          );
          gsap.to(".manifesto-photo img", {
            yPercent: -8,
            scale: 1.08,
            ease: "none",
            scrollTrigger: {
              trigger: ".manifesto",
              start: "top bottom",
              end: "bottom top",
              scrub: 1,
            },
          });
          gsap.fromTo(
            ".destination",
            { y: 100 },
            {
              y: 0,
              stagger: 0.12,
              ease: "none",
              scrollTrigger: {
                trigger: ".destination-grid",
                start: "top 95%",
                end: "top 35%",
                scrub: 1,
              },
            },
          );
        }, root);
        return () => ctx.revert();
      },
    );
    return () => mm.revert();
  }, []);
  useEffect(() => {
    if (!root.current) return;
    let seen = false;
    try {
      seen = !!sessionStorage.getItem("vera-intro");
    } catch {}
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const ctx = gsap.context(() => {
      if (seen || reduced) {
        gsap.set(intro.current, { display: "none" });
        setIntroDone(true);
        return;
      }
      const tl = gsap.timeline({
        onComplete: () => {
          setIntroDone(true);
          try {
            sessionStorage.setItem("vera-intro", "1");
          } catch {}
        },
      });
      timeline.current = tl;
      tl.fromTo(
        ".intro-logo",
        { opacity: 0, y: 12 },
        { opacity: 1, y: 0, duration: 0.65 },
      )
        .fromTo(
          ".intro-line",
          { scaleX: 0 },
          { scaleX: 1, duration: 0.65, ease: "power3.inOut" },
          0.35,
        )
        .to(".intro-logo", { opacity: 0, duration: 0.35 }, 0.95)
        .to(
          intro.current,
          { clipPath: "inset(0 0 100% 0)", duration: 1, ease: "power4.inOut" },
          1.1,
        )
        .fromTo(
          ".hero-photo",
          { scale: 1.15, clipPath: "inset(12% 15% 12% 15%)" },
          {
            scale: 1,
            clipPath: "inset(0% 0% 0% 0%)",
            duration: 1.65,
            ease: "power3.inOut",
          },
          0.7,
        )
        .fromTo(
          ".hero-title .letter",
          { y: "105%", opacity: 0 },
          {
            y: "0%",
            opacity: 1,
            stagger: 0.012,
            duration: 0.7,
            ease: "power3.out",
          },
          1.55,
        )
        .fromTo(
          ".hero .hero-copy, .hero .hero-bottom",
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.1 },
          2.1,
        )
        .set(intro.current, { display: "none" });
    }, root);
    return () => ctx.revert();
  }, []);
  const skip = () => {
    timeline.current?.progress(1);
    setIntroDone(true);
  };
  const slides = [
    {
      img: "villa",
      name: "Villa Orizzonte",
      location: "Cernobbio, Lago di Como",
      url: "/proprieta/villa-orizzonte/",
    },
    {
      img: "penthouse",
      name: "L’Attico di Brera",
      location: "Brera, Milano",
      url: "/proprieta/attico-brera/",
    },
    {
      img: "coast",
      name: "Dimora Mediterranea",
      location: "Porto Cervo, Sardegna",
      url: "/proprieta/dimora-mediterranea/",
    },
  ];
  const phrase = (text: string) =>
    Array.from(text).map((char, i) => (
      <span className="letter" aria-hidden="true" key={i}>
        {char === " " ? "\u00a0" : char}
      </span>
    ));
  return (
    <div ref={root} className="cinematic-home">
      <ChapterNavigation />
      <div
        className={`intro ${introDone ? "done" : ""}`}
        ref={intro}
        aria-hidden={introDone}
      >
        <div className="intro-logo">
          VÉRA<span>LUXURY REAL ESTATE</span>
        </div>
        <div className="intro-line" />
        <button
          className="skip-intro"
          onClick={skip}
          tabIndex={introDone ? -1 : 0}
        >
          Salta introduzione <ArrowRight size={14} />
        </button>
      </div>
      <section className="hero" id="opening">
        <div className="hero-photo">
          <div className="hero-camera">
            <img
              key={slide}
              src={image(slides[slide].img)}
              alt={`${slides[slide].name} — fotografia architettonica illustrativa`}
              fetchPriority="high"
              width="2200"
              height="1467"
            />
          </div>
        </div>
        <div className="hero-shade" />
        <span className="hero-watermark" aria-hidden="true">
          VÉRA
        </span>
        <div className="hero-edition" aria-hidden="true">
          <span>ABITARE L’ECCEZIONE</span>
          <span>ITALIA / EDIZIONE 01</span>
        </div>
        <div className="hero-content">
          <p className="eyebrow hero-copy">
            <span className="small-line" /> PROPRIETÀ STRAORDINARIE. VITE
            AUTENTICHE.
          </p>
          <h1
            className="hero-title"
            aria-label="Non cerchiamo semplicemente case. Troviamo luoghi da vivere."
          >
            <span className="hero-line">{phrase("Non cerchiamo")}</span>
            <span className="hero-line">{phrase("semplicemente case.")}</span>
            <span className="hero-line italic">
              {phrase("Troviamo luoghi da vivere.")}
            </span>
          </h1>
          <div className="hero-copy">
            <p className="hero-subtitle">Una nuova prospettiva sull’abitare.</p>
            <div className="hero-buttons">
              <Link href="/proprieta/" className="button champagne">
                Esplora le proprietà <ArrowUpRight size={17} />
              </Link>
              <Link href="/chi-siamo/" className="hero-about">
                Scopri VÉRA <ArrowUpRight size={16} />
              </Link>
            </div>
          </div>
        </div>
        <div className="hero-bottom">
          <a className="scroll-cue" href="#selezione">
            <span className="scroll-line" />
            <span>SCOPRI L’ESSENZA</span>
            <ArrowDown size={13} />
          </a>
          <Link href={slides[slide].url} className="hero-location">
            <MapPin size={14} />
            <span>
              {slides[slide].location}
              <small>
                {slides[slide].name} · Scopri la proprietà{" "}
                <ArrowUpRight size={12} />
              </small>
            </span>
          </Link>
          <div className="slide-control">
            <button
              aria-label="Fotografia precedente"
              onClick={() => setSlide((slide + 2) % 3)}
            >
              <ArrowLeft size={15} />
            </button>
            <span>
              0{slide + 1}
              <i> / 03</i>
            </span>
            <button
              aria-label="Fotografia successiva"
              onClick={() => setSlide((slide + 1) % 3)}
            >
              <ArrowRight size={15} />
            </button>
          </div>
        </div>
      </section>
      <section className="quick-search">
        <span className="search-intro">
          Il tuo prossimo
          <br />
          <em>luogo nel mondo.</em>
        </span>
        <label>
          LOCALITÀ
          <select value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="">Dove desideri vivere?</option>
            {[...new Set(properties.map((p) => p.city))].map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <label>
          TIPOLOGIA
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">Tutte le proprietà</option>
            {[...new Set(properties.map((p) => p.type))].map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <label>
          CONTRATTO
          <select
            value={contract}
            onChange={(e) => setContract(e.target.value)}
          >
            <option>Vendita</option>
            <option>Affitto</option>
          </select>
        </label>
        <Link
          className="search-submit"
          href={`/ricerca/?citta=${encodeURIComponent(city)}&tipo=${encodeURIComponent(type)}&contratto=${contract}`}
        >
          <Search size={18} />
          <span>Cerca proprietà</span>
          <ArrowUpRight size={16} />
        </Link>
      </section>
      <LivingStatement />
      <section className="section selected" id="selezione">
        <div className="section-top" data-reveal>
          <div>
            <p className="eyebrow">01 — LA NOSTRA SELEZIONE</p>
            <h2>
              Indirizzi unici.
              <br />
              <em>Possibilità infinite.</em>
            </h2>
          </div>
          <div className="section-aside">
            <p>
              Non solo immobili, ma espressioni di un modo di vivere. Una
              selezione curata, un’emozione che resta.
            </p>
            <TextLink href="/proprieta/">
              Tutte le proprietà <span className="link-count">08</span>
            </TextLink>
          </div>
        </div>
        <ImmersiveCollection />
        <div className="selection-bottom">
          <span className="eyebrow">SCELTE CON CURA. PENSATE PER TE.</span>
          <TextLink href="/mappa/">
            Lasciati guidare dai luoghi <MapPin size={15} />
          </TextLink>
        </div>
      </section>
      <section className="manifesto section" id="essenza">
        <div className="manifesto-photo">
          <img
            src={image("hero")}
            alt="Architettura contemporanea, materiali naturali e luce"
            loading="lazy"
            width="1100"
            height="1400"
          />
          <span className="photo-caption">
            LA BELLEZZA È NEL MODO IN CUI TI SENTI.
          </span>
        </div>
        <div className="manifesto-copy" data-reveal>
          <p className="eyebrow">02 — L’ESSENZA DI VÉRA</p>
          <h2>
            Il vero lusso
            <br />è sentirsi
            <br />
            <em>nel posto giusto.</em>
          </h2>
          <p>
            Ci sono luoghi che non si possono spiegare.
            <br />
            Si riconoscono, semplicemente.
          </p>
          <p>
            VÉRA nasce da questa intuizione: una casa è molto più di uno spazio.
            È il riflesso di chi sei, la cornice di ciò che diventerai. Per
            questo guardiamo oltre i metri quadrati, per trovare ciò che conta
            davvero.
          </p>
          <TextLink href="/chi-siamo/">Il nostro modo di vedere</TextLink>
          <span className="manifesto-signature">Véra.</span>
        </div>
      </section>
      <PortalScene />
      <section className="destinations section" id="destinazioni">
        <div className="section-top" data-reveal>
          <div>
            <p className="eyebrow">04 — GEOGRAFIE DEL DESIDERIO</p>
            <h2>
              A ogni luogo,
              <br />
              <em>la sua anima.</em>
            </h2>
          </div>
          <div className="section-aside">
            <p>
              Dall’energia della città alla quiete del lago.
              <br />
              Trova il paesaggio che ti assomiglia.
            </p>
            <TextLink href="/mappa/">Esplora la mappa</TextLink>
          </div>
        </div>
        <div className="destination-grid">
          {[
            {
              name: "Lago di Como",
              img: "lake",
              city: "Como",
              sub: "Eleganza senza tempo",
            },
            {
              name: "Milano",
              img: "milan",
              city: "Milano",
              sub: "Il ritmo del contemporaneo",
            },
            {
              name: "Toscana",
              img: "tuscany",
              city: "Siena",
              sub: "La bellezza di rallentare",
            },
          ].map((d, i) => (
            <Link
              href={`/ricerca/?citta=${d.city}`}
              className="destination"
              key={d.name}
            >
              <img
                src={image(d.img)}
                alt={`Ispirazione abitativa: ${d.name}`}
                loading="lazy"
                width="600"
                height="800"
              />
              <div>
                <span className="eyebrow">0{i + 1} / ITALIA</span>
                <h3>{d.name}</h3>
                <p>
                  {d.sub}
                  <ArrowUpRight size={20} />
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>
      <section className="valuation-banner">
        <div data-reveal>
          <p className="eyebrow">UN PATRIMONIO, UNA NUOVA PROSPETTIVA</p>
          <h2>
            Ogni casa ha un valore.
            <br />
            <em>La tua, una storia.</em>
          </h2>
        </div>
        <div data-reveal>
          <p>
            Scopri come potremmo valorizzare il tuo immobile, con sensibilità,
            visione e un’attenzione personale.
          </p>
          <ButtonLink href="/valutazione/">Valuta il tuo immobile</ButtonLink>
        </div>
      </section>
    </div>
  );
}
