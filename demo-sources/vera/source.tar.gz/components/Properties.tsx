"use client";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import dynamic from "next/dynamic";
import {
  ArrowUpRight,
  MapPin,
  SlidersHorizontal,
  Search,
  Grid2X2,
  List,
  X,
  Heart,
  RotateCcw,
  BedDouble,
  Bath,
  Maximize,
} from "lucide-react";
import { properties, Property, image, money } from "@/lib/properties";
import {
  blankFilters,
  filterProperties,
  filtersToQuery,
  filtersFromQuery,
  type Filters,
} from "@/lib/search";
import { FavoriteButton, useFavorites, ButtonLink } from "./Shell";
const PropertyMap = dynamic(() => import("./PropertyMap"), {
  ssr: false,
  loading: () => <div className="map-loading">Caricamento della mappa…</div>,
});
export function PropertyCard({
  property: p,
  editorial = false,
  index = 0,
}: {
  property: Property;
  editorial?: boolean;
  index?: number;
}) {
  return (
    <article
      className={`property-card ${editorial ? "editorial" : ""}`}
      data-reveal={editorial ? "" : undefined}
    >
      <div className="property-visual">
        <Link
          href={`/proprieta/${p.slug}/`}
          className="property-image"
          onPointerMove={(e) => {
            if (e.pointerType !== "mouse") return;
            const r = e.currentTarget.getBoundingClientRect();
            e.currentTarget.style.setProperty(
              "--cursor-x",
              `${e.clientX - r.left}px`,
            );
            e.currentTarget.style.setProperty(
              "--cursor-y",
              `${e.clientY - r.top}px`,
            );
          }}
          aria-label={`Scopri ${p.name}`}
        >
          <img
            src={image(p.image)}
            alt={`${p.name} — fotografia architettonica illustrativa`}
            width="900"
            height="660"
            loading="lazy"
          />
          <span className="card-view">
            Scopri
            <ArrowUpRight size={20} />
          </span>
        </Link>
        <span className="property-label">{p.status}</span>
        <FavoriteButton id={p.id} />
        <span className="property-number">
          {String(index + 1).padStart(2, "0")}
        </span>
      </div>
      <div className="property-info">
        <p className="eyebrow">
          <MapPin size={11} />
          {p.area}, {p.city}
        </p>
        <Link className="property-title" href={`/proprieta/${p.slug}/`}>
          <h3>{p.name}</h3>
          <ArrowUpRight size={22} />
        </Link>
        <div className="property-meta">
          <span>
            {p.size} m² <i>·</i> {p.beds} camere <i>·</i> {p.baths} bagni
          </span>
          <strong>
            {money(p.price)}
            {p.contract === "Affitto" && <small> / mese</small>}
          </strong>
        </div>
      </div>
    </article>
  );
}
export function PropertyExplorer({
  mode = "grid",
}: {
  mode?: "grid" | "map" | "favorites" | "advanced";
}) {
  const [filters, setFilters] = useState<Filters>(blankFilters);
  const [view, setView] = useState("grid");
  const [sort, setSort] = useState("selection");
  const [expanded, setExpanded] = useState(mode === "advanced");
  const [mapIds, setMapIds] = useState<string[] | null>(null);
  const { favorites } = useFavorites();
  useEffect(() => {
    const url = new URLSearchParams(location.search);
    setFilters(filtersFromQuery(url));
  }, []);
  const set = (key: keyof Filters, value: string) => {
    setFilters((f) => ({
      ...f,
      [key]: value,
      ...(key === "city" ? { area: "" } : {}),
    }));
    setMapIds(null);
  };
  useEffect(() => setMapIds(null), [filters]);
  const base = useMemo(
    () =>
      mode === "favorites"
        ? properties.filter((p) => favorites.includes(p.id))
        : properties,
    [mode, favorites],
  );
  const filtered = useMemo(() => {
    const result = filterProperties(base, filters);
    return result.sort((a, b) =>
      sort === "price-up"
        ? a.price - b.price
        : sort === "price-down"
          ? b.price - a.price
          : sort === "size"
            ? b.size - a.size
            : a.id.localeCompare(b.id),
    );
  }, [base, filters, sort]);
  const visible = mapIds
    ? filtered.filter((p) => mapIds.includes(p.id))
    : filtered;
  const active = Object.entries(filters).filter(([, value]) =>
    Array.isArray(value) ? value.length : !!value,
  ).length;
  const reset = () => {
    setFilters({ ...blankFilters });
    setMapIds(null);
    history.replaceState(null, "", location.pathname);
  };
  return (
    <>
      <section className="listing-heading section">
        <p className="eyebrow">
          {mode === "favorites"
            ? "LA TUA SELEZIONE PERSONALE"
            : mode === "map"
              ? "GEOGRAFIE DELL’ABITARE"
              : "LA COLLEZIONE VÉRA"}
        </p>
        <h1>
          {mode === "favorites" ? (
            <>
              Luoghi da <em>ricordare.</em>
            </>
          ) : mode === "map" ? (
            <>
              Segui la tua <em>ispirazione.</em>
            </>
          ) : (
            <>
              Il tuo prossimo <em>capitolo.</em>
            </>
          )}
        </h1>
        <div className="listing-intro">
          <p>
            {mode === "favorites"
              ? "Le dimore che hanno catturato il tuo sguardo, custodite su questo dispositivo."
              : mode === "map"
                ? "Esplora le nostre residenze, un luogo alla volta. Le posizioni sono indicative."
                : "Una collezione di dimore fuori dall’ordinario. Trova quella che parla di te."}
          </p>
          <span className="eyebrow">
            {String(base.length).padStart(2, "0")} PROPRIETÀ DEMO
          </span>
        </div>
      </section>
      <section className="explorer section">
        <div className="filter-main">
          <label className="search-field">
            <Search size={17} />
            <input
              placeholder="Cerca un luogo, un nome…"
              aria-label="Ricerca testuale immobili"
              value={filters.q}
              onChange={(e) => set("q", e.target.value)}
            />
          </label>
          <label className="filter-select">
            <span className="sr-only">Contratto</span>
            <select
              value={filters.contract}
              onChange={(e) => set("contract", e.target.value)}
            >
              <option value="">Vendita e affitto</option>
              <option>Vendita</option>
              <option>Affitto</option>
            </select>
          </label>
          <label className="filter-select">
            <span className="sr-only">Città</span>
            <select
              value={filters.city}
              onChange={(e) => set("city", e.target.value)}
            >
              <option value="">Tutte le località</option>
              {[...new Set(properties.map((p) => p.city))].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
          <button
            className={`filter-toggle ${expanded ? "selected" : ""}`}
            onClick={() => setExpanded(!expanded)}
            aria-expanded={expanded}
          >
            <SlidersHorizontal size={16} />
            Filtri {active > 0 && <span>{active}</span>}
          </button>
        </div>
        {expanded && (
          <div className="filter-expanded">
            <label>
              Quartiere
              <select
                value={filters.area}
                onChange={(e) => set("area", e.target.value)}
              >
                <option value="">Tutti i quartieri</option>
                {properties
                  .filter((p) => !filters.city || p.city === filters.city)
                  .map((p) => (
                    <option key={p.id}>{p.area}</option>
                  ))}
              </select>
            </label>
            <label>
              Tipologia
              <select
                value={filters.type}
                onChange={(e) => set("type", e.target.value)}
              >
                <option value="">Tutte le tipologie</option>
                {[...new Set(properties.map((p) => p.type))].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </select>
            </label>
            <label>
              Prezzo minimo (€)
              <input
                type="number"
                min="0"
                placeholder="Nessun minimo"
                value={filters.priceMin}
                onChange={(e) => set("priceMin", e.target.value)}
              />
            </label>
            <label>
              Prezzo massimo (€)
              <input
                type="number"
                min="0"
                placeholder="Nessun limite"
                value={filters.price}
                onChange={(e) => set("price", e.target.value)}
              />
            </label>
            <label>
              Superficie minima (m²)
              <input
                type="number"
                min="0"
                placeholder="Qualsiasi superficie"
                value={filters.size}
                onChange={(e) => set("size", e.target.value)}
              />
            </label>
            <label>
              Camere
              <select
                value={filters.beds}
                onChange={(e) => set("beds", e.target.value)}
              >
                <option value="">Qualsiasi numero</option>
                {[2, 3, 4, 5, 6].map((n) => (
                  <option value={n} key={n}>
                    {n} o più camere
                  </option>
                ))}
              </select>
            </label>
            <fieldset>
              <legend>Ciò che fa la differenza</legend>
              <div className="feature-filters">
                {[
                  "Piscina",
                  "Giardino",
                  "Terrazza",
                  "Vista lago",
                  "Vista mare",
                  "Domotica",
                  "Ascensore",
                ].map((feature) => (
                  <label className="check-chip" key={feature}>
                    <input
                      type="checkbox"
                      checked={filters.features.includes(feature)}
                      onChange={() =>
                        setFilters((f) => ({
                          ...f,
                          features: f.features.includes(feature)
                            ? f.features.filter((v) => v !== feature)
                            : [...f.features, feature],
                        }))
                      }
                    />
                    {feature}
                  </label>
                ))}
              </div>
            </fieldset>
            <button className="reset-filters" onClick={reset}>
              <RotateCcw size={14} />
              Azzera i filtri
            </button>
          </div>
        )}
        <div className="results-toolbar">
          <p aria-live="polite">
            {visible.length}{" "}
            {visible.length === 1 ? "proprietà trovata" : "proprietà trovate"}{" "}
            {active > 0 && (
              <button onClick={reset} className="reset-inline">
                Azzera <X size={12} />
              </button>
            )}
          </p>
          <div>
            <label className="sort-label">
              <span className="sr-only">Ordina risultati</span>
              <select value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="selection">La selezione VÉRA</option>
                <option value="price-up">Prezzo crescente</option>
                <option value="price-down">Prezzo decrescente</option>
                <option value="size">Superficie maggiore</option>
              </select>
            </label>
            {mode !== "map" && (
              <div className="view-switch">
                <button
                  onClick={() => setView("grid")}
                  aria-label="Visualizzazione a griglia"
                  aria-pressed={view === "grid"}
                >
                  <Grid2X2 size={17} />
                </button>
                <button
                  onClick={() => setView("list")}
                  aria-label="Visualizzazione a lista"
                  aria-pressed={view === "list"}
                >
                  <List size={19} />
                </button>
                <Link
                  href={`/mappa/?${filtersToQuery(filters)}`}
                  aria-label="Esplora sulla mappa"
                >
                  <MapPin size={18} />
                </Link>
              </div>
            )}
          </div>
        </div>
        {mode === "map" ? (
          <div className="map-explorer">
            <div className="map-results">
              {visible.map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
              {visible.length === 0 && (
                <p className="empty-mini">
                  Nessuna proprietà in quest’area. Allarga la mappa o modifica i
                  filtri.
                </p>
              )}
            </div>
            <div className="map-panel">
              <PropertyMap items={filtered} onAreaChange={setMapIds} />
              <p className="map-note">
                Posizioni approssimative · Nessun indirizzo reale
              </p>
            </div>
          </div>
        ) : visible.length ? (
          <div className={`results-grid ${view === "list" ? "list-view" : ""}`}>
            {visible.map((p, i) => (
              <PropertyCard key={p.id} property={p} index={i} />
            ))}
          </div>
        ) : (
          <div className="empty-state">
            {mode === "favorites" ? (
              <Heart size={34} strokeWidth={1} />
            ) : (
              <Search size={34} strokeWidth={1} />
            )}
            <h2>
              {mode === "favorites" && !active
                ? "Una storia ancora da scrivere."
                : "Il luogo giusto merita una ricerca."}
            </h2>
            <p>
              {mode === "favorites" && !active
                ? "Tocca il cuore su una proprietà per ritrovarla qui."
                : "Nessuna dimora corrisponde ai criteri. Prova ad ampliare le tue preferenze."}
            </p>
            {mode === "favorites" && !active ? (
              <ButtonLink href="/proprieta/">Esplora la collezione</ButtonLink>
            ) : (
              <button className="button" onClick={reset}>
                Azzera i filtri <RotateCcw size={16} />
              </button>
            )}
          </div>
        )}
        <p className="listing-disclaimer">
          Una collezione dimostrativa: immobili, descrizioni e prezzi sono di
          fantasia. Le fotografie sono illustrative e non rappresentano annunci
          reali.
        </p>
      </section>
    </>
  );
}
