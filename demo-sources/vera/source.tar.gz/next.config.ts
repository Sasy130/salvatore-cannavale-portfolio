import type { NextConfig } from "next";
const config: NextConfig = {
  output: "export", basePath: "/demos/vera",
  trailingSlash: true,
  images: { unoptimized: true },
  poweredByHeader: false,
};
export default config;
