export const metadata = { title: "Privacy e informazioni sulla demo" };
export default function Page() {
  return (
    <article className="legal-page section">
      <p className="eyebrow">TRASPARENZA, PRIMA DI TUTTO</p>
      <h1>
        Una demo.
        <br />
        <em>Tutto alla luce.</em>
      </h1>
      <h2>Natura del progetto</h2>
      <p>
        VÉRA è un concept dimostrativo di sito immobiliare. Il brand, gli
        immobili, i prezzi, le descrizioni e le disponibilità sono elementi di
        fantasia e non costituiscono offerte di vendita o locazione. Non sono
        attivi servizi di intermediazione o consulenza.
      </p>
      <h2>Moduli e dati personali</h2>
      <p>
        I moduli validano i campi esclusivamente nel browser. Non inviano email,
        non prenotano visite e non trasmettono i dati inseriti a un backend. Non
        inserire dati sensibili. Il messaggio di conferma segnala soltanto il
        completamento della simulazione.
      </p>
      <h2>Memoria locale</h2>
      <p>
        I preferiti sono salvati nel localStorage del browser con la chiave
        vera-favorites. La preferenza sull’introduzione è conservata nella
        sessionStorage con la chiave vera-intro. Puoi cancellare queste
        informazioni dalle impostazioni del browser. Non utilizziamo strumenti
        di analisi o cookie pubblicitari nell’applicazione.
      </p>
      <h2>Fotografie e cartografia</h2>
      <p>
        Le fotografie provengono da Unsplash e sono riferimenti di architettura
        e interni. Non documentano gli immobili descritti. Le mappe utilizzano
        Leaflet e le tessere CARTO basate su OpenStreetMap: il caricamento della
        cartografia comporta richieste verso questi servizi esterni. I marker
        indicano zone approssimative, senza indirizzi precisi.
      </p>
      <h2>Accesso e hosting</h2>
      <p>
        Il sito è ospitato con Sites. Eventuali controlli di accesso e registri
        tecnici dell’hosting sono gestiti dalla piattaforma. Questa pagina
        descrive il comportamento della demo e dovrà essere sostituita con
        un’informativa adeguata prima di un impiego commerciale reale.
      </p>
    </article>
  );
}
