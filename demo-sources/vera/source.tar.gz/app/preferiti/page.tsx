import { PropertyExplorer } from "@/components/Properties";
export const metadata = { title: "I tuoi preferiti" };
export default function Page() {
  return <PropertyExplorer mode="favorites" />;
}
