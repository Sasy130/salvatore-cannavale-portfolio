import type { Metadata, Viewport } from "next";
import "./fonts.css";
import "lenis/dist/lenis.css";
import "./globals.css";
import "./cinematic.css";
import { Shell } from "@/components/Shell";
export const metadata: Metadata = {
  metadataBase: new URL("https://vera-luxury-residenze.one-man13.chatgpt.site"),
  title: {
    default: "VÉRA — Luoghi straordinari. Storie da abitare.",
    template: "%s | VÉRA Luxury Real Estate",
  },
  description:
    "Una nuova prospettiva sull’abitare. Esplora la collezione dimostrativa VÉRA: ville, attici e residenze di prestigio nei luoghi più suggestivi d’Italia.",
  openGraph: {
    title: "VÉRA — Luxury Real Estate",
    description: "Non cerchiamo semplicemente case. Troviamo luoghi da vivere.",
    locale: "it_IT",
    type: "website",
    images: [{ url: "/demos/vera/images/villa.jpg", width: 1400, height: 933 }],
  },
  robots: { index: false, follow: false },
};
export const viewport: Viewport = {
  themeColor: "#111111",
  width: "device-width",
  initialScale: 1,
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="it">
      <body>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
