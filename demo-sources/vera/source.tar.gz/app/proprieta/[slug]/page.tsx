import { notFound } from "next/navigation";
import { properties } from "@/lib/properties";
import { PropertyDetail } from "@/components/PropertyDetail";
export function generateStaticParams() {
  return properties.map((p) => ({ slug: p.slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const p = properties.find((p) => p.slug === slug);
  return {
    title: p ? `${p.name} — ${p.city}` : "Proprietà non trovata",
    description: p?.description,
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const p = properties.find((p) => p.slug === slug);
  if (!p) notFound();
  return <PropertyDetail property={p} />;
}
