import { PropertyExplorer } from "@/components/Properties";
export const metadata = { title: "La collezione — Proprietà esclusive" };
export default function Page() {
  return <PropertyExplorer />;
}
