import { DemoForm } from "@/components/Forms";
import { TextLink } from "@/components/Shell";
export const metadata = { title: "Contatti — Iniziamo una conversazione" };
export default function Page() {
  return (
    <>
      <section className="editorial-heading section">
        <p className="eyebrow">IL PRIMO PASSO</p>
        <h1>
          Le belle storie iniziano
          <br />
          <em>con una conversazione.</em>
        </h1>
        <p>Raccontaci il luogo che immagini. Cominciamo da qui.</p>
      </section>
      <section className="contact-section section contact-page">
        <div>
          <p className="eyebrow">UNO SPAZIO PER ASCOLTARTI</p>
          <h2>
            Il tuo tempo.
            <br />
            <em>La nostra attenzione.</em>
          </h2>
          <p>
            Esplora il percorso di contatto VÉRA. Puoi provare il modulo e il
            suo feedback di conferma, senza inviare alcuna informazione.
          </p>
          <div className="contact-info">
            <span>VÉRA — Luxury Real Estate</span>
            <p>
              Concept digitale · Italia
              <br />
              Nessuna sede fisica o assistenza attiva in questa demo.
            </p>
          </div>
          <TextLink href="/proprieta/">
            Preferisci partire dalle proprietà?
          </TextLink>
          <div className="contact-demo-note">
            DEMO · I dati restano nel tuo browser e non vengono conservati dopo
            aver lasciato il modulo.
          </div>
        </div>
        <DemoForm />
      </section>
    </>
  );
}
