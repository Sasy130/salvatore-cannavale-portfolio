import { ButtonLink } from "@/components/Shell";
export default function NotFound() {
  return (
    <section className="not-found section">
      <p className="eyebrow">404 — UN PICCOLO FUORI PERCORSO</p>
      <h1>
        Alcuni luoghi
        <br />
        restano <em>da trovare.</em>
      </h1>
      <p>
        La pagina che cerchi non è qui. Il prossimo luogo da vivere, forse sì.
      </p>
      <ButtonLink href="/proprieta/">Ritrova la tua ispirazione</ButtonLink>
    </section>
  );
}
