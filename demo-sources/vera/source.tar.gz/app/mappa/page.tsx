import { PropertyExplorer } from "@/components/Properties";
export const metadata = { title: "Esplora sulla mappa" };
export default function Page() {
  return <PropertyExplorer mode="map" />;
}
