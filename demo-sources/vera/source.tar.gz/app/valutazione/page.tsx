import { DemoForm } from "@/components/Forms";
import { image } from "@/lib/properties";
export const metadata = { title: "Valuta il tuo immobile" };
export default function Page() {
  return (
    <>
      <section className="editorial-heading section">
        <p className="eyebrow">IL VALORE DI UNA STORIA</p>
        <h1>
          La tua casa merita
          <br />
          <em>il giusto sguardo.</em>
        </h1>
        <p>
          Ogni immobile racchiude un potenziale. Iniziamo a immaginarlo insieme.
        </p>
      </section>
      <section className="valuation-layout section">
        <div className="valuation-story">
          <img
            src={image("architecture")}
            alt="Architettura e dettagli di una residenza contemporanea"
            width="1000"
            height="1100"
          />
          <h2>
            Oltre il prezzo.
            <br />
            <em>Il suo vero valore.</em>
          </h2>
          <p>
            La valutazione proposta dal concept VÉRA considera contesto,
            architettura, stato dell’immobile e caratteristiche distintive.
          </p>
          <ol>
            <li>
              <span>01</span>Raccontaci il tuo immobile
            </li>
            <li>
              <span>02</span>Immagina un confronto dedicato
            </li>
            <li>
              <span>03</span>Definisci il tuo prossimo passo
            </li>
          </ol>
          <p className="form-notice">
            Questa demo non calcola una stima economica e non offre consulenza
            immobiliare. Nessun dato sarà inviato.
          </p>
        </div>
        <div>
          <p className="eyebrow">RACCONTACI IL TUO IMMOBILE</p>
          <DemoForm kind="valuation" />
        </div>
      </section>
    </>
  );
}
