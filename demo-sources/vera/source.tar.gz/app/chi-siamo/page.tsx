import { image } from "@/lib/properties";
import { TextLink, ButtonLink } from "@/components/Shell";
export const metadata = { title: "Il mondo VÉRA" };
export default function Page() {
  return (
    <>
      <section className="editorial-heading section">
        <p className="eyebrow">IL MONDO VÉRA</p>
        <h1>
          Uno sguardo diverso.
          <br />
          <em>Una bellezza autentica.</em>
        </h1>
        <p>Crediamo nei luoghi che ci fanno sentire noi stessi.</p>
      </section>
      <div className="wide-photo">
        <img
          src={image("hero")}
          width="2000"
          height="1200"
          alt="Interni contemporanei attraversati dalla luce"
          fetchPriority="high"
        />
      </div>
      <section className="story-section section">
        <p className="eyebrow">IL NOSTRO MANIFESTO</p>
        <div data-reveal>
          <h2>
            Non vendiamo sogni.
            <br />
            <em>Diamo spazio alla vita.</em>
          </h2>
          <p className="lead">
            VÉRA è un concept di agenzia immobiliare nato per esplorare una
            relazione più sensibile tra persone, architettura e paesaggio.
          </p>
          <p>
            In questa esperienza dimostrativa, immaginiamo un percorso che parte
            dall’ascolto e arriva a una scelta consapevole. Una selezione
            ragionata, informazioni leggibili e il tempo necessario per
            riconoscere il proprio luogo.
          </p>
          <p>
            Per noi il prestigio non è una formula. È la qualità di una luce,
            l’intelligenza di una distribuzione, il rapporto con ciò che ci
            circonda. È poter dire: qui, sto bene.
          </p>
          <TextLink href="/proprieta/">Esplora la nostra visione</TextLink>
        </div>
      </section>
      <section className="values-section section">
        <p className="eyebrow">TRE PRINCIPI. UN SOLO MODO DI ESSERE.</p>
        {[
          [
            "01",
            "Sensibilità",
            "Guardare oltre la superficie. Comprendere le persone e ciò che rende una casa davvero speciale.",
          ],
          [
            "02",
            "Trasparenza",
            "Informazioni chiare, aspettative condivise e una relazione costruita sulla fiducia. Anche in una demo.",
          ],
          [
            "03",
            "Visione",
            "Connettere l’architettura alle nuove esigenze dell’abitare, con uno sguardo aperto al futuro.",
          ],
        ].map(([n, title, text]) => (
          <div key={n} className="value-row" data-reveal>
            <span>{n}</span>
            <h2>{title}</h2>
            <p>{text}</p>
          </div>
        ))}
      </section>
      <section className="quote-section">
        <p className="eyebrow">LA NOSTRA IDEA DI LUSSO</p>
        <blockquote>
          «Non ciò che si mostra.
          <br />
          <em>Ciò che si sente.»</em>
        </blockquote>
        <ButtonLink href="/contatti/">Conosciamoci</ButtonLink>
      </section>
    </>
  );
}
