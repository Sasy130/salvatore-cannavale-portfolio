import { image } from "@/lib/properties";
import { TextLink } from "@/components/Shell";
export const metadata = {
  title: "The Art of Living — Architettura, design, ispirazione",
};
export default function Page() {
  return (
    <>
      <section className="editorial-heading section experience-heading">
        <p className="eyebrow">IL JOURNAL VÉRA · VOLUME 01</p>
        <h1>
          The Art
          <br />
          of <em>Living.</em>
        </h1>
        <p>Appunti sulla bellezza di abitare.</p>
      </section>
      <div className="wide-photo">
        <img
          src={image("architecture")}
          alt="Proporzioni, luce e materiali di una dimora contemporanea"
          width="2000"
          height="1200"
          fetchPriority="high"
        />
      </div>
      <section className="story-section section">
        <p className="eyebrow">01 — LA LUCE COME MATERIA</p>
        <div data-reveal>
          <h2>
            L’architettura inizia
            <br />
            <em>dove entra la luce.</em>
          </h2>
          <p className="lead">
            Al mattino disegna geometrie sul pavimento. Al tramonto ammorbidisce
            i contorni. La luce non arreda soltanto uno spazio: gli dà un ritmo.
          </p>
          <p>
            Una finestra orientata con cura, una parete lasciata libera, il
            riflesso su una superficie naturale. Sono gesti semplici, capaci di
            trasformare il modo in cui viviamo ogni giorno la nostra casa.
          </p>
        </div>
      </section>
      <section className="journal-duo section">
        <img
          src={image("interior")}
          alt="Materiali naturali e arredi essenziali"
          loading="lazy"
          width="1000"
          height="1200"
          data-reveal
        />
        <div data-reveal>
          <p className="eyebrow">02 — IL PRIVILEGIO DELL’ESSENZIALE</p>
          <h2>
            Meno rumore.
            <br />
            <em>Più significato.</em>
          </h2>
          <p>
            Legno che racconta il tempo. Pietra che conserva una temperatura.
            Tessuti che invitano a fermarsi. La materia autentica non ha bisogno
            di imporsi: si lascia riconoscere.
          </p>
          <p>
            L’abitare contemporaneo ritrova il valore della misura. Non
            accumulare, ma scegliere. Non riempire, ma lasciare spazio a ciò che
            conta.
          </p>
        </div>
      </section>
      <div className="journal-landscape">
        <img
          src={image("garden")}
          alt="Giardino e architettura in dialogo"
          width="1800"
          height="1100"
          loading="lazy"
        />
        <div>
          <p className="eyebrow">03 — IL PAESAGGIO DENTRO</p>
          <h2>
            Aprire una porta.
            <br />
            <em>Ritrovare il mondo.</em>
          </h2>
        </div>
      </div>
      <section className="quote-section">
        <p className="eyebrow">DALL’ISPIRAZIONE A UN NUOVO INIZIO</p>
        <h2>
          Quale luogo
          <br />
          <em>ti assomiglia?</em>
        </h2>
        <TextLink href="/proprieta/">Esplora la collezione VÉRA</TextLink>
      </section>
    </>
  );
}
