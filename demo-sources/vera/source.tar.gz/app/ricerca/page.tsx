import { PropertyExplorer } from "@/components/Properties";
export const metadata = { title: "Ricerca avanzata" };
export default function Page() {
  return <PropertyExplorer mode="advanced" />;
}
