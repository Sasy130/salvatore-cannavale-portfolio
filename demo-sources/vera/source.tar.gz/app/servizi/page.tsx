import { TextLink, ButtonLink } from "@/components/Shell";
import { image } from "@/lib/properties";
export const metadata = { title: "Servizi — Un percorso su misura" };
export default function Page() {
  return (
    <>
      <section className="editorial-heading section">
        <p className="eyebrow">IL NOSTRO APPROCCIO</p>
        <h1>
          Ogni esigenza è unica.
          <br />
          <em>Così il suo percorso.</em>
        </h1>
        <p>
          Dalla prima intuizione alla prossima casa. Un servizio da immaginare
          intorno a te.
        </p>
      </section>
      <section className="services-list section">
        {[
          {
            n: "01",
            title: "Trovare il tuo luogo",
            sub: "RICERCA & ACQUISTO",
            text: "Un ascolto attento delle tue priorità, una selezione coerente con il tuo stile di vita. Esplora le dimore demo, confronta le caratteristiche e custodisci i tuoi preferiti.",
            link: "/ricerca/",
            cta: "Inizia la tua ricerca",
            img: "lake",
          },
          {
            n: "02",
            title: "Dare valore alla tua storia",
            sub: "VALUTAZIONE & VENDITA",
            text: "Una presentazione che rispetta l’identità dell’immobile. Il percorso proposto comprende analisi del contesto, racconto fotografico e una strategia di valorizzazione dedicata.",
            link: "/valutazione/",
            cta: "Esplora la valutazione demo",
            img: "interior",
          },
          {
            n: "03",
            title: "Abitare, con libertà",
            sub: "LOCAZIONI",
            text: "Dimore per una nuova stagione della vita. Una selezione di appartamenti in locazione, con canoni e caratteristiche consultabili nella nostra collezione dimostrativa.",
            link: "/ricerca/?contratto=Affitto",
            cta: "Scopri le locazioni",
            img: "milan",
          },
        ].map((s) => (
          <article className="service-row" key={s.n} data-reveal>
            <div className="service-img">
              <img
                src={image(s.img)}
                alt={s.title}
                loading="lazy"
                width="1000"
                height="850"
              />
            </div>
            <div>
              <p className="eyebrow">
                {s.n} — {s.sub}
              </p>
              <h2>{s.title}</h2>
              <p>{s.text}</p>
              <TextLink href={s.link}>{s.cta}</TextLink>
            </div>
          </article>
        ))}
      </section>
      <section className="quote-section">
        <p className="eyebrow">UN PROGETTO DIMOSTRATIVO</p>
        <h2>
          Un servizio personale.
          <br />
          <em>Fin dal primo gesto.</em>
        </h2>
        <p>
          I servizi descrivono il concept VÉRA e non costituiscono un’offerta
          professionale attiva.
        </p>
        <ButtonLink href="/contatti/">Esplora il contatto demo</ButtonLink>
      </section>
    </>
  );
}
