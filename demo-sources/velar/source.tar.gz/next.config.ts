import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export", basePath: "/demos/velar",
  trailingSlash: true,
  images: {
    loader: "custom",
    loaderFile: "./src/lib/static-image-loader.ts",
    deviceSizes: [360, 480, 768, 960, 1280, 1600],
    imageSizes: [96, 160, 320],
  },
};

export default nextConfig;
