# VELAR — Exotic Car Rental · Fase 3

La Fase 3 completa pagine, richiesta dimostrativa e preparazione HTTPS, conservando la regia delle Fasi 1–2. Consegna, file e limiti: [docs/phase3-delivery.md](docs/phase3-delivery.md). Audit precedente: [docs/phase2-audit.md](docs/phase2-audit.md).

Esperienza automotive responsive realizzata in Next.js App Router, React, TypeScript, CSS e GSAP/ScrollTrigger. Nessun backend, pagamento o prenotazione reale.

## Avvio

Richiede Node.js 20.9 o superiore.

```bash
cd /workspace/velar
npm install
npm run dev -- --hostname 0.0.0.0
```

Aprire http://localhost:3000. Produzione statica: `npm run build`, poi `npm start` (porta 3000). Per QA su un’altra porta: `PORT=3002 npm start`. L’output distribuibile è `out/`.

## Funzioni operative

- Intro GSAP di 5 secondi sulla stessa scena DOM del Key Vault. La prima chiave resta al centro dell’inquadratura iniziale; la camera 2.5D arretra e rivela le altre. Il pulsante ha un impulso luminoso. Nessun video o schermata nera usati per coprire il raccordo.
- Al termine il tavolo passa da fixed al flusso della pagina e la posizione di scroll viene allineata nello stesso aggiornamento. La Home fotografica resta raggiungibile sopra il vault.
- Skip Intro, Escape e replay. Prima visita per sessione (`sessionStorage`, chiave `velar-intro`). Le pagine secondarie non riproducono l’intro. Intro automatica disabilitata con reduced motion, hardwareConcurrency ≤2 o viewport di altezza inferiore a 650 px.
- Sei ricostruzioni fotorealistiche AI, con sagome e materiali differenti, etichette accessibili, selezione esclusiva, hover e risposta touch/tastiera. **Immagini ricostruite dichiarate, non fotografie autentiche né riproduzioni ufficiali certificate.**
- ScrollTrigger reversibile per parallasse hero e movimento del tavolo. Lo scroll resta nativo.
- Reveal della vettura con chiave condivisa: parte dalla posizione effettiva della chiave, espande una maschera fotografica e accompagna la chiave nell’angolo. Chiusura dalla posa attuale verso la chiave selezionata, anche durante l’apertura. Cambio vettura interno senza rimontare la scena. Sotto il reveal il vault resta montato.
- Catalogo da archivio strutturato, filtri per categoria, sei URL dedicati `/collection/[slug]`, schede tecniche e CTA collegate alla vettura scelta.
- Navigazione fissa, sfondo adattivo allo scroll, indicatore di sezione e menu mobile.
- Modulo locale con tutti i campi richiesti, validazione HTML e controllo date/telefono, consenso esplicito alla simulazione. Riepilogo scaricabile `.txt`. Nessuna trasmissione o memorizzazione persistente dei dati del modulo.
- Dialog con focus, Escape e contenimento Tab; reduced motion; immagini responsive Next Image, lazy loading, fallback di errore e WebP locale; preload della fotografia hero.

## Architettura

- `src/components/SiteShell.tsx`: navigazione, footer, accesso globale al modulo.
- `src/components/ExperienceContext.tsx`: stati INTRO, VAULT_IDLE, VAULT_SCROLL, KEY_SELECTED, CAR_TRANSITION, CAR_EXPLORE, BOOKING e selezione/ritorno persistenti durante la navigazione.
- `src/components/HomeExperience.tsx`: composizione Home, vault, fleet, servizi, about, contact.
- `src/components/AnimationController.ts`: timeline intro, ScrollTrigger e cleanup.
- `src/components/KeyArt.tsx`: asset fotorealistici riutilizzabili, con fallback SVG.
- `src/components/CarReveal.tsx`: transizione chiave/vettura e inversione.
- `src/components/CarImage.tsx`: asset ottimizzati e fallback.
- `src/components/DetailExperience.tsx`: scheda tecnica e galleria.
- `src/components/Booking.tsx`: modulo dimostrativo locale.
- `src/data/cars.ts`: archivio delle sei vetture e fonti tecniche.
- `public/cars/credits.json` e `/credits`: autori, fonti, licenze e modifiche alle fotografie.

## Asset e limiti dichiarati

Le sei fotografie esterne sono del modello indicato. La hero mostra la Lamborghini Revuelto Opera Unica; la scheda Revuelto usa una fotografia di serie. Sono disponibili anche gli interni della Revuelto e viste parziali dell’abitacolo Cullinan. Le fotografie sono ospitate localmente e attribuite in `/credits` (CC BY-SA 4.0 oppure CC0). Gli originali JPG sono conservati insieme alle versioni WebP. Eventuali usi delle versioni derivate devono mantenere l’attribuzione e le condizioni della licenza indicata.

Restano da completare:

1. Per una corrispondenza OEM certificata servono fotografie autorizzate delle chiavi esatte. La fase attuale usa ricostruzioni fotorealistiche AI dichiarate e una regia 2.5D.
2. Interni di 296 GTB, 750S, 911 GT3 RS e G 63 e fotografie di dettaglio; i pannelli mancanti sono dichiarati, senza sostituirli con altri modelli.
3. Shooting fotografico uniforme da studio: le fotografie documentarie attuali sono autentiche ma non costituiscono un set coordinato commissionato a VELAR.
4. Backend di richiesta, contatti e WhatsApp aziendali, informativa privacy definitiva, condizioni di noleggio, assicurazione, deposito e disponibilità effettiva. Nulla di questo è simulato come operativo.
5. Collaudo su dispositivi fisici e GPU differenti. Non viene garantito un framerate di 60 FPS. Non è presente una scena WebGL, poiché non sono disponibili modelli accurati; nessun Lenis né rallentamento artificiale dello scroll.

Le tariffe sono dimostrative e non includono condizioni commerciali definite. Le specifiche si riferiscono alle versioni di serie documentate, con G 63 versione 2018 e Cullinan prima serie.

## Verifiche

```bash
npm run lint
npx tsc --noEmit
npm run build
# Con il server avviato su :3000 e Chromium disponibile:
npm run test:browser
# QA cinematico completo sulle sette viewport:
npm run test:cinematic
# Profilo sintetico (default server :3001):
npm run profile:motion
```

Il test browser usa Playwright con `/usr/bin/chromium`. Copre durata intro, sei selezioni, reveal e inversione, filtri, date non valide, richiesta dimostrativa, navigazione dettaglio/Home, layout mobile 390 px, menu, assenza di overflow orizzontale, immagini e page errors. Screenshot generati in `artifacts/`. Il test confronta anche la geometria della prima chiave nell’ultimo fotogramma dell’intro e nel primo della Home; verifica skip/replay, chiusura anticipata ripetuta del reveal, scroll rapido/inverso e ridimensionamento. Non misura gli FPS.

Per ripristinare la prima visita nella console del browser: `sessionStorage.removeItem('velar-intro')`.

## Verifica della Fase 2

Avviare un server di produzione con `npm run build` e `PORT=3001 npm start`, poi `BASE_URL=http://localhost:3001 npm run test:cinematic`. Per verificare anche il modulo della Fase 1: `BASE_URL=http://localhost:3001 npm run test:browser`. I risultati della suite cinematografica sono in `artifacts/phase2/results.json`, gli screenshot in `artifacts/phase2/`. ViewTransition è un miglioramento progressivo, con prefetch completo delle schede; nei browser senza supporto la navigazione resta disponibile.

Motion tokens e camera planare sono in `src/lib/motion.ts` e `src/lib/camera.ts`; configurazioni delle sei vetture in `src/data/cinematics.ts`; politiche di interruzione in `src/lib/motion-state.ts`.

Il controllo aggiuntivo di stati conservati e fallback progressivi è disponibile con `BASE_URL=http://localhost:3001 npm run test:state`.

## Fase 3 — export e richiesta completa

La stessa app Next.js viene prerenderizzata con `output: export`. Loader immagini statico, font locali, nessun backend o segreto runtime. Configurazioni Vercel e Sites incluse.

```bash
npm run lint
npx tsc --noEmit
npm run build
PORT=3002 npm start
# In un altro terminale:
BASE_URL=http://localhost:3002 npm run test:final
BASE_URL=http://localhost:3002 npm run test:cinematic
```

Tutte le pagine commerciali sono autonome e raggiungibili dalla navbar/footer. Il modulo ha orari e località distinti, riepilogo modificabile e download; nessun invio è simulato come riuscito. La pubblicazione è verificata separatamente dalla build locale.

## Sito pubblico

https://velar-exotic-rental.one-man13.chatgpt.site — Sites, versione 1, accesso pubblico HTTPS verificato. Dettagli di consegna e limiti in `docs/phase3-delivery.md`.
