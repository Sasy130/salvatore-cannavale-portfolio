import { chromium } from "playwright";
import assert from "node:assert/strict";
import { writeFile, mkdir } from "node:fs/promises";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const base = process.env.BASE_URL || "http://localhost:3001";
const result = { checks: [], errors: [] };
await mkdir("artifacts/phase2", { recursive: true });
try {
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  page.on("pageerror", (e) => result.errors.push(e.message));
  await page.addInitScript(() => sessionStorage.setItem("velar-intro", "seen"));
  await page.goto(base);
  await page.locator('[data-key="296-gtb"]').click();
  await page.locator(".vault-action button").click();
  await page.locator(".car-reveal[data-reveal-phase=settled]").waitFor();
  await page.locator(".reveal-actions a").click();
  await page.locator(".detail-hero:not(.detail-loading):visible").waitFor();
  await page.getByRole("link", { name: "← BACK TO COLLECTION" }).click();
  await page.locator(".car-reveal[data-reveal-phase=settled]").waitFor();
  await page.waitForTimeout(180);
  assert.equal(
    await page.locator("header").getAttribute("data-experience-state"),
    "CAR_EXPLORE",
  );
  await page
    .getByRole("button", { name: "RICHIEDI NOLEGGIO", exact: true })
    .click();
  assert.equal(
    await page.locator("header").getAttribute("data-experience-state"),
    "BOOKING",
  );
  await page.keyboard.press("Escape");
  assert.equal(
    await page.locator("header").getAttribute("data-experience-state"),
    "CAR_EXPLORE",
  );
  await page.keyboard.press("Escape");
  await page.locator(".car-reveal").waitFor({ state: "detached" });
  assert.equal(
    await page.locator("header").getAttribute("data-experience-state"),
    "VAULT_IDLE",
  );
  result.checks.push(
    "retained reveal state, booking and restoration, then idle",
  );
  const fallback = await browser.newPage({
    viewport: { width: 390, height: 844 },
    hasTouch: true,
    isMobile: true,
  });
  fallback.on("pageerror", (e) => result.errors.push(e.message));
  await fallback.addInitScript(() => {
    Object.defineProperty(navigator, "hardwareConcurrency", { get: () => 2 });
    document.startViewTransition = undefined;
  });
  await fallback.goto(base);
  await fallback.waitForTimeout(300);
  assert.equal(await fallback.locator(".is-intro").count(), 0);
  await fallback.locator("#card-cullinan .card-photo").click();
  await fallback.locator(".detail-hero:not(.detail-loading):visible").waitFor();
  assert.match(fallback.url(), /cullinan/);
  await fallback
    .getByRole("button", { name: "RICHIEDI QUESTA VETTURA" })
    .click();
  assert.equal(await fallback.locator("[name=car]").inputValue(), "cullinan");
  await fallback.keyboard.press("Escape");
  result.checks.push(
    "low-power intro fallback and working navigation/booking without ViewTransition API",
  );
  assert.deepEqual(result.errors, []);
  console.log("PASS focused state and progressive fallback tests");
} catch (error) {
  result.errors.push(error.stack);
  console.error(error);
  process.exitCode = 1;
} finally {
  await writeFile(
    "artifacts/phase2/state-fallback.json",
    JSON.stringify(result, null, 2),
  );
  await browser.close();
}
