import { chromium } from "playwright";
import assert from "node:assert/strict";
import { mkdir, writeFile } from "node:fs/promises";
const base = process.env.BASE_URL || "http://localhost:3000";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const failures = [],
  results = [],
  consoleErrors = [];
const slugs = ["revuelto", "296-gtb", "cullinan", "750s", "911-gt3-rs", "g63"];
function observe(page) {
  page.on("pageerror", (e) => consoleErrors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error" || /Invalid scope/.test(m.text()))
      consoleErrors.push(m.text());
  });
}
async function waitSettled(page) {
  await page
    .locator('.car-reveal[data-reveal-phase="settled"][aria-busy="false"]')
    .waitFor({ timeout: 12000 });
}
async function noOverflow(page) {
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth + 1,
    ),
    "horizontal overflow",
  );
}
async function closeReveal(page) {
  await page.keyboard.press("Escape");
  await page.locator(".car-reveal").waitFor({ state: "detached" });
  assert.notEqual(
    await page.evaluate(() => document.body.style.overflow),
    "hidden",
  );
}
try {
  await mkdir("artifacts/phase2", { recursive: true });
  for (const width of [360, 390, 430, 768, 1366, 1440, 1920]) {
    const height = width <= 430 ? 844 : width === 768 ? 1024 : 1000;
    const page = await browser.newPage({
      viewport: { width, height },
      isMobile: width <= 768,
      hasTouch: width <= 768,
    });
    observe(page);
    await page.goto(base, { waitUntil: "domcontentloaded" });
    await page.locator(".is-intro").waitFor();
    const continuity = await page.evaluate(
      () =>
        new Promise((resolve) => {
          const started = performance.now();
          let last;
          function sample() {
            const r = document
              .querySelector(".key-art")
              .getBoundingClientRect();
            const rect = { x: r.x, y: r.y, w: r.width, h: r.height };
            if (document.querySelector(".is-intro")) {
              last = rect;
              requestAnimationFrame(sample);
            } else
              resolve({
                before: last,
                after: rect,
                observedMs: performance.now() - started,
              });
          }
          sample();
        }),
    );
    const delta = Math.max(
      ...["x", "y", "w", "h"].map((k) =>
        Math.abs(continuity.before[k] - continuity.after[k]),
      ),
    );
    assert.ok(delta < 2, `intro geometry ${width}: ${delta}`);
    assert.ok(
      continuity.observedMs > 3900 && continuity.observedMs < 6500,
      `intro duration ${width}`,
    );
    assert.equal(await page.locator(".key-choice").count(), 6);
    assert.equal(await page.locator(".is-intro").count(), 0);
    await noOverflow(page);
    const duplicateIds = await page.locator("svg [id]").evaluateAll((nodes) => {
      const ids = nodes.map((n) => n.id);
      return ids.length - new Set(ids).size;
    });
    assert.equal(duplicateIds, 0);
    // Small deltas approximate a trackpad stream; large wheel deltas and reverse must also settle.
    if (width > 768) {
      for (const deltaY of [15, 25, 30, 400, -500])
        await page.mouse.wheel(0, deltaY);
      await page.waitForTimeout(450);
    } else {
      const cdp = await page.context().newCDPSession(page);
      await cdp.send("Input.dispatchTouchEvent", {
        type: "touchStart",
        touchPoints: [{ x: width / 2, y: height * 0.8 }],
      });
      for (let i = 1; i <= 7; i++) {
        await cdp.send("Input.dispatchTouchEvent", {
          type: "touchMove",
          touchPoints: [{ x: width / 2, y: height * 0.8 - i * 35 }],
        });
        await page.waitForTimeout(20);
      }
      await cdp.send("Input.dispatchTouchEvent", {
        type: "touchEnd",
        touchPoints: [],
      });
      await cdp.detach();
    }
    assert.ok(
      await page
        .locator(".vault-camera")
        .evaluate((n) => !getComputedStyle(n).transform.includes("NaN")),
    );
    await page.locator("#vault").scrollIntoViewIfNeeded();
    await page.screenshot({ path: `artifacts/phase2/vault-${width}.png` });
    if (width <= 768) {
      await page.setViewportSize({ width: height, height: width });
      await noOverflow(page);
      await page.setViewportSize({ width, height });
      await noOverflow(page);
    }
    await page.getByRole("button", { name: "REPLAY THE INTRO" }).click();
    await page.getByRole("button", { name: "SKIP INTRO" }).click();
    await page.locator(".is-intro").waitFor({ state: "detached" });
    const settled = await page.locator(".key-art").first().boundingBox();
    await page.waitForTimeout(220);
    const after = await page.locator(".key-art").first().boundingBox();
    assert.ok(Math.abs(settled.y - after.y) < 1, "no residual intro movement");
    results.push({
      viewport: width,
      introMs: Math.round(continuity.observedMs),
      introGeometryDelta: delta,
      scrollInput:
        width <= 768
          ? "synthetic touch"
          : "synthetic wheel small/large/reverse",
      orientation: width <= 768 ? "checked" : "not applicable",
    });
    console.log("PASS viewport", width, "intro delta", delta);
    await page.close();
  }
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  observe(page);
  await page.addInitScript(() => {
    sessionStorage.setItem("velar-intro", "seen");
    window.__viewTransitions = 0;
    const original = document.startViewTransition?.bind(document);
    if (original)
      document.startViewTransition = (...args) => {
        window.__viewTransitions++;
        return original(...args);
      };
  });
  await page.goto(base, { waitUntil: "domcontentloaded" });
  for (const slug of slugs) {
    await page.locator(`[data-key="${slug}"]`).click();
    await page.locator(".vault-action button").click();
    await waitSettled(page);
    assert.equal(
      await page.locator(".car-reveal").getAttribute("data-photo-active"),
      slug,
    );
    assert.match(
      await page.locator(".reveal-actions a").getAttribute("href"),
      new RegExp(slug),
    );
    await page.screenshot({ path: `artifacts/phase2/reveal-${slug}.png` });
    await closeReveal(page);
    console.log("PASS key/reveal", slug);
  }
  // Interrupt selection: no forced completion, no new scene mount, and the latest requested photo wins.
  await page.locator(".key-choice").evaluateAll((nodes) => {
    nodes[1].click();
    nodes[0].click();
    nodes[5].click();
  });
  assert.equal(
    await page
      .locator(".key-choice[aria-pressed=true]")
      .getAttribute("data-key"),
    "g63",
  );
  await page.locator(".vault-action button").click();
  await page.waitForTimeout(110);
  await closeReveal(page);
  await page.locator(".vault-action button").click();
  await waitSettled(page);
  const identity = await page.locator(".reveal-key").evaluate((n) => {
    n.dataset.identity = "persisted";
    return n.dataset.identity;
  });
  await page.locator(".reveal-switcher").evaluate((n) => {
    n.querySelector('[data-car-index="1"]').click();
    n.querySelector('[data-car-index="0"]').click();
    n.querySelector('[data-car-index="3"]').click();
  });
  await waitSettled(page);
  assert.equal(
    await page.locator(".car-reveal").getAttribute("data-photo-active"),
    "750s",
  );
  assert.equal(
    await page.locator(".reveal-key").getAttribute("data-identity"),
    identity,
  );
  await page.setViewportSize({ width: 1024, height: 768 });
  await noOverflow(page);
  await waitSettled(page);
  await page
    .getByRole("button", { name: "RICHIEDI NOLEGGIO", exact: true })
    .click();
  await page.locator(".dialog").waitFor();
  assert.equal(await page.locator("[name=car]").inputValue(), "750s");
  await page.keyboard.press("Escape");
  assert.equal(await page.locator(".car-reveal").count(), 1);
  await closeReveal(page);
  await page.setViewportSize({ width: 1440, height: 1000 });
  // Shared fleet/detail reference, filter/selection/position restoration and browser back.
  await page.getByRole("button", { name: "Luxury SUVs", exact: true }).click();
  await page.locator("#card-g63 .card-photo").scrollIntoViewIfNeeded();
  const y = await page.evaluate(() => scrollY);
  await page.locator("#card-g63 .card-photo").click();
  await page.locator(".detail-hero:not(.detail-loading):visible").waitFor();
  await page.waitForTimeout(450);
  assert.match(page.url(), /collection\/g63/);
  assert.ok(
    await page.evaluate(() => window.__viewTransitions > 0),
    "native ViewTransition invoked",
  );
  await page.getByRole("link", { name: "← BACK TO COLLECTION" }).click();
  await page.locator("#collection").waitFor();
  await page.waitForTimeout(500);
  assert.equal(await page.locator(".car-card").count(), 2);
  assert.equal(
    await page
      .locator(".key-choice[aria-pressed=true]")
      .getAttribute("data-key"),
    "g63",
  );
  assert.ok(
    Math.abs((await page.evaluate(() => scrollY)) - y) < 5,
    "return scroll restored",
  );
  assert.equal(await page.locator(".is-intro").count(), 0);
  await page.locator("#card-cullinan .card-photo").click();
  await page.locator(".detail-hero:not(.detail-loading):visible").waitFor();
  await page.goBack();
  await page.locator("#collection").waitFor();
  await page.waitForTimeout(350);
  assert.equal(await page.locator(".car-card").count(), 2);
  await page
    .getByRole("button", { name: "All vehicles (06)", exact: true })
    .click();
  await page.locator('[data-key="296-gtb"]').click();
  await page.locator(".vault-action button").click();
  await waitSettled(page);
  await page.locator(".reveal-actions a").click();
  await page.locator(".detail-hero:not(.detail-loading):visible").waitFor();
  assert.match(page.url(), /296-gtb/);
  assert.notEqual(
    await page.evaluate(() => document.body.style.overflow),
    "hidden",
  );
  await page.getByRole("link", { name: "← BACK TO COLLECTION" }).click();
  await page.locator("#vault").waitFor();
  assert.equal(
    await page
      .locator(".key-choice[aria-pressed=true]")
      .getAttribute("data-key"),
    "296-gtb",
  );
  await waitSettled(page);
  assert.equal(
    await page.locator(".car-reveal").getAttribute("data-photo-active"),
    "296-gtb",
  );
  await closeReveal(page);
  results.push({
    desktopInteractions:
      "six reveals, rapid selection, early close, in-place switching, booking over reveal, resize, shared page navigation, return position/filter/selection and browser back passed",
  });
  const reduced = await browser.newPage({
    viewport: { width: 390, height: 844 },
    reducedMotion: "reduce",
    hasTouch: true,
    isMobile: true,
  });
  observe(reduced);
  await reduced.goto(base);
  await reduced.waitForTimeout(300);
  assert.equal(await reduced.locator(".is-intro").count(), 0);
  await reduced.locator('[data-key="cullinan"]').focus();
  await reduced.keyboard.press("Enter");
  assert.equal(
    await reduced
      .locator(".key-choice[aria-pressed=true]")
      .getAttribute("data-key"),
    "cullinan",
  );
  await reduced.locator(".vault-action button").focus();
  await reduced.keyboard.press("Enter");
  await waitSettled(reduced);
  await reduced.keyboard.press("Tab");
  assert.ok(
    await reduced.evaluate(() =>
      document.querySelector(".car-reveal").contains(document.activeElement),
    ),
  );
  await reduced.keyboard.press("Shift+Tab");
  assert.ok(
    await reduced.evaluate(() =>
      document.querySelector(".car-reveal").contains(document.activeElement),
    ),
  );
  await closeReveal(reduced);
  await reduced.getByRole("button", { name: "BOOK NOW" }).click();
  await reduced.locator(".dialog").waitFor();
  assert.equal(await reduced.locator("[name=car]").inputValue(), "cullinan");
  await reduced.keyboard.press("Escape");
  await reduced.getByRole("button", { name: "Apri menu" }).click();
  await reduced.getByRole("link", { name: "Services", exact: true }).click();
  await reduced.waitForTimeout(200);
  assert.equal(
    await reduced
      .getByRole("button", { name: "Apri menu" })
      .getAttribute("aria-expanded"),
    "false",
  );
  results.push({
    accessibility:
      "reduced motion, keyboard selection, visible focus CSS, modal Tab containment, Escape and mobile menu checked; no screen-reader or physical-device certification",
  });
  assert.deepEqual(consoleErrors, [], "browser console/page errors");
  console.log("PASS phase 2 full suite");
} catch (e) {
  failures.push(e.stack || e.message);
  console.error(e);
  process.exitCode = 1;
} finally {
  await writeFile(
    "artifacts/phase2/results.json",
    JSON.stringify({ base, results, failures, consoleErrors }, null, 2),
  );
  await browser.close();
}
