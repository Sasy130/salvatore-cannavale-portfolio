import { chromium } from "playwright";
import { writeFile, mkdir } from "node:fs/promises";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
try {
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  await page.addInitScript(() => sessionStorage.setItem("velar-intro", "seen"));
  await page.goto(process.env.BASE_URL || "http://localhost:3001");
  await page.locator("#vault").scrollIntoViewIfNeeded();
  await page.waitForTimeout(1000);
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("Performance.enable");
  const before = (await cdp.send("Performance.getMetrics")).metrics;
  if (process.env.MODE === "reveal")
    await page
      .getByRole("button", { name: "DISCOVER Revuelto", exact: true })
      .click();
  const frames = await page.evaluate(
    () =>
      new Promise((resolve) => {
        const times = [];
        let last = performance.now(),
          start = last;
        function frame(now) {
          times.push(now - last);
          last = now;
          const t = (now - start) / 2600;
          if (!document.querySelector(".car-reveal"))
            window.scrollTo({
              top:
                document.querySelector(".vault-anchor").offsetTop +
                Math.sin(t * Math.PI * 2) * 220,
              behavior: "instant",
            });
          if (t < 1) requestAnimationFrame(frame);
          else resolve(times.slice(2));
        }
        requestAnimationFrame(frame);
      }),
  );
  const after = (await cdp.send("Performance.getMetrics")).metrics;
  const values = Object.fromEntries(after.map((v) => [v.name, v.value]));
  const prev = Object.fromEntries(before.map((v) => [v.name, v.value]));
  const sorted = [...frames].sort((a, b) => a - b);
  const result = {
    mode: process.env.MODE || "scroll",
    environment:
      "Headless Chromium, Linux, 1440x1000; synthetic scroll, not physical hardware certification",
    samples: frames.length,
    medianFrameMs: sorted[Math.floor(sorted.length * 0.5)],
    p95FrameMs: sorted[Math.floor(sorted.length * 0.95)],
    framesOver34ms: frames.filter((t) => t > 34).length,
    layoutCount: values.LayoutCount - prev.LayoutCount,
    recalcStyleCount: values.RecalcStyleCount - prev.RecalcStyleCount,
    scriptDurationMs: (values.ScriptDuration - prev.ScriptDuration) * 1000,
    taskDurationMs: (values.TaskDuration - prev.TaskDuration) * 1000,
    heapUsedMB: values.JSHeapUsedSize / 1048576,
  };
  await mkdir("artifacts", { recursive: true });
  await writeFile(
    `artifacts/${process.env.PROFILE_NAME || "motion-profile"}.json`,
    JSON.stringify(result, null, 2),
  );
  console.log(result);
} finally {
  await browser.close();
}
