import json,subprocess,urllib.parse
from pathlib import Path
root=Path('public/cars');credits=json.loads((root/'credits.json').read_text())
files=[('750s-rear','2023 McLaren 750S 2.jpg'),('cullinan-interior-2','Rolls-Royce Cullinan 2018 (31569773828).jpg')]
for slug,file in files:
 if any(c['slug']==slug for c in credits):continue
 try:
  params=dict(action='query',titles='File:'+file,prop='imageinfo',iiprop='url|extmetadata',iiurlwidth=1600,format='json')
  data=json.loads(subprocess.check_output(['curl','-fsSL','--retry','2','--max-time','30','https://en.wikipedia.org/w/api.php?'+urllib.parse.urlencode(params)]))
  info=next(iter(data['query']['pages'].values()))['imageinfo'][0]
  subprocess.run(['curl','-fsSL','--max-time','45',info.get('thumburl',info['url']),'-o',str(root/(slug+'.jpg'))],check=True)
  credits.append(dict(slug=slug,file=file,url=info['descriptionurl'],metadata=info.get('extmetadata',{})));print(slug,info.get('extmetadata',{}).get('ImageDescription',{}).get('value','')[:200],flush=True)
 except Exception as e:print(slug,str(e),flush=True)
(root/'credits.json').write_text(json.dumps(credits,indent=2))
