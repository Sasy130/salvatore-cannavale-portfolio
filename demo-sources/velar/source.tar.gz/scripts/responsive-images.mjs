import sharp from "sharp";
import { readdir } from "node:fs/promises";
for (const file of await readdir("public/cars")) {
  if (!file.endsWith(".webp") || /-w\d+\.webp$/.test(file)) continue;
  for (const width of [480, 960, 1600])
    await sharp("public/cars/" + file)
      .resize({ width, withoutEnlargement: true })
      .webp({ quality: 80 })
      .toFile("public/cars/" + file.replace(".webp", `-w${width}.webp`));
}
