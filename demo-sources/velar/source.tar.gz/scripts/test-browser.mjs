import { chromium } from "playwright";
import assert from "node:assert/strict";
import { mkdir } from "node:fs/promises";
const base = process.env.BASE_URL || "http://localhost:3000";
(async () => {
  await mkdir("artifacts", { recursive: true });
  const browser = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  const errors = [];
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(base);
  await page.locator(".is-intro").waitFor();
  const continuity = page.evaluate(
    () =>
      new Promise((resolve) => {
        let last = null;
        const tick = () => {
          const active = !!document.querySelector(".is-intro");
          const key = document.querySelector(".key-art");
          const r = key?.getBoundingClientRect();
          const box = r ? { x: r.x, y: r.y, w: r.width, h: r.height } : null;
          if (active) {
            last = box;
            requestAnimationFrame(tick);
          } else {
            resolve({ before: last, after: box });
          }
        };
        requestAnimationFrame(tick);
      }),
  );
  const start = Date.now();
  await page.locator(".is-intro").waitFor({ state: "detached", timeout: 8000 });
  console.log("Intro completed after", Date.now() - start, "ms");
  const raccordo = await continuity;
  console.log("Intro continuity", raccordo);
  assert.ok(
    Math.abs(raccordo.before.x - raccordo.after.x) < 3 &&
      Math.abs(raccordo.before.y - raccordo.after.y) < 3,
    "intro/Home geometry must remain continuous",
  );
  assert.equal(await page.locator(".key-choice").count(), 6);
  for (const b of await page.locator(".key-choice").all()) await b.click();
  assert.equal(
    await page.locator('.key-choice[aria-pressed="true"] small').textContent(),
    "G 63 · 06",
  );
  await page.getByRole("button", { name: "DISCOVER G 63" }).click();
  await page.locator(".car-reveal").waitFor();
  await page.waitForTimeout(1800);
  await page.getByRole("button", { name: "Torna alle chiavi" }).click();
  await page.locator(".car-reveal").waitFor({ state: "detached" });
  for (let i = 0; i < 3; i++) {
    await page.getByRole("button", { name: "DISCOVER G 63" }).click();
    await page.waitForTimeout(180);
    await page.keyboard.press("Escape");
    await page.locator(".car-reveal").waitFor({ state: "detached" });
  }
  await page.getByRole("button", { name: "REPLAY THE INTRO" }).click();
  await page.getByRole("button", { name: "SKIP INTRO" }).click();
  await page.locator(".is-intro").waitFor({ state: "detached" });
  await page.locator("#collection").scrollIntoViewIfNeeded();
  await page.getByRole("button", { name: "Luxury SUVs", exact: true }).click();
  assert.equal(await page.locator(".car-card").count(), 2);
  await page
    .getByRole("button", { name: "All vehicles (06)", exact: true })
    .click();
  assert.equal(await page.locator(".car-card").count(), 6);
  await page.locator("#card-g63 button").click();
  await page.locator(".dialog").waitFor();
  await page.locator("[name=location]").fill("Milano");
  await page.locator("[name=name]").fill("Test VELAR");
  await page.locator("[name=email]").fill("test@example.com");
  await page.locator("[name=phone]").fill("+39 333 1234567");
  await page.locator("[name=pickup]").fill("2027-02-12");
  await page.locator("[name=return]").fill("2027-02-12");
  await page.locator("input[type=checkbox]").check();
  await page.getByRole("button", { name: "Prepara richiesta demo" }).click();
  await page.locator(".dialog [role=alert]").waitFor();
  await page.locator("[name=return]").fill("2027-02-15");
  await page.getByRole("button", { name: "Prepara richiesta demo" }).click();
  await page.getByRole("status").waitFor();
  assert.match(
    await page.getByRole("status").textContent(),
    /non è stato trasmesso|Nessun dato è stato trasmesso/,
  );
  await page.keyboard.press("Escape");
  await page.goto(base + "/collection/911-gt3-rs");
  await page.getByRole("heading", { name: "Porsche 911 GT3 RS" }).waitFor();
  assert.equal(await page.locator(".is-intro").count(), 0);
  await page.getByRole("link", { name: "← BACK TO COLLECTION" }).click();
  await page.waitForTimeout(500);
  await page.evaluate(() => scrollTo({ top: 0, behavior: "instant" }));
  for (const y of [4000, 1000, 6000, 300, 2100, 0]) {
    await page.evaluate((v) => scrollTo({ top: v, behavior: "instant" }), y);
    await page.waitForTimeout(60);
  }
  await page.setViewportSize({ width: 1024, height: 768 });
  assert.ok(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  );
  await page.setViewportSize({ width: 1440, height: 1000 });
  await page.screenshot({ path: "artifacts/desktop-hero.png" });
  const mobile = await browser.newPage({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
    reducedMotion: "reduce",
  });
  mobile.on("pageerror", (e) => errors.push(e.message));
  await mobile.goto(base);
  await mobile.waitForTimeout(600);
  assert.equal(await mobile.locator(".is-intro").count(), 0);
  assert.ok(
    await mobile.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  );
  await mobile.getByRole("button", { name: "Apri menu" }).click();
  await mobile.getByRole("link", { name: "Collection", exact: true }).click();
  await mobile.waitForTimeout(800);
  assert.ok(!(await mobile.locator("nav").getAttribute("class")));
  await mobile.getByRole("button", { name: "BOOK NOW" }).click();
  await mobile.locator(".dialog").waitFor();
  await mobile.keyboard.press("Escape");
  for (const img of await mobile.locator(".car-card img").all()) {
    await img.scrollIntoViewIfNeeded();
    await img.evaluate((i) =>
      i.complete
        ? Promise.resolve()
        : new Promise((resolve) => {
            i.onload = resolve;
            i.onerror = resolve;
          }),
    );
  }
  await mobile.evaluate(() => scrollTo({ top: 0, behavior: "instant" }));
  await mobile.screenshot({
    path: "artifacts/mobile-full.png",
    fullPage: true,
  });
  for (const slug of [
    "revuelto",
    "296-gtb",
    "cullinan",
    "750s",
    "911-gt3-rs",
    "g63",
  ]) {
    const response = await page.request.get(base + "/collection/" + slug);
    assert.equal(response.status(), 200);
  }
  const broken = await mobile
    .locator("img")
    .evaluateAll(
      (imgs) => imgs.filter((i) => i.complete && i.naturalWidth === 0).length,
    );
  assert.equal(broken, 0);
  assert.deepEqual(errors, []);
  console.log(
    "PASS: intro, 6 keys, selection, filters, date validation, local request, details, mobile navigation, images, no page errors",
  );
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
