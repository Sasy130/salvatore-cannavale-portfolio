import { chromium, devices, request } from "playwright";
import assert from "node:assert/strict";
import { mkdir, writeFile, readFile } from "node:fs/promises";
const base = process.env.BASE_URL || "http://localhost:3002";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  headless: true,
  args: ["--no-sandbox"],
});
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
const api = await request.newContext({
  proxy:
    proxyUrl && !base.includes("localhost") ? { server: proxyUrl } : undefined,
});
const errors = [],
  checks = [],
  failedRequests = [];
const slugs = ["revuelto", "296-gtb", "cullinan", "750s", "911-gt3-rs", "g63"];
function watch(page) {
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
  });
  page.on("response", (r) => {
    if (r.status() >= 400 && !r.url().includes("missing-velar-page"))
      failedRequests.push({ url: r.url(), status: r.status() });
  });
}
async function visibleImages(page) {
  for (const img of await page.locator("main:visible img").all()) {
    await img.scrollIntoViewIfNeeded();
    await img.evaluate((i) =>
      i.complete
        ? Promise.resolve()
        : new Promise((resolve) => {
            i.onload = resolve;
            i.onerror = resolve;
          }),
    );
    assert.ok(await img.evaluate((i) => i.naturalWidth > 0), "loaded image");
  }
}
try {
  await mkdir("artifacts/phase3", { recursive: true });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1000 },
  });
  watch(page);
  await page.addInitScript(() => sessionStorage.setItem("velar-intro", "seen"));
  for (const route of [
    "/",
    "/collection/",
    "/services/",
    "/about/",
    "/contact/",
    "/booking/",
    "/privacy/",
    "/cookies/",
    "/credits/",
    ...slugs.map((s) => "/collection/" + s + "/"),
  ]) {
    const response = await page.goto(base + route);
    assert.equal(response.status(), 200, route);
    await page.waitForTimeout(120);
    assert.ok(await page.locator("main:visible").count());
    assert.ok((await page.title()).includes("VELAR"));
    assert.ok(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
      "overflow " + route,
    );
    if (route.startsWith("/collection/")) await visibleImages(page);
    checks.push("HTTP/page/images " + route);
  }
  const robots = await api.get(base + "/robots.txt");
  assert.equal(robots.status(), 200);
  const sitemap = await api.get(base + "/sitemap.xml");
  assert.equal(sitemap.status(), 200);
  assert.match(await sitemap.text(), /https:\/\/velar-exotic-rental/);
  const notFound = await api.get(base + "/missing-velar-page/");
  assert.equal(notFound.status(), 404);
  assert.match(await notFound.text(), /A different road/);
  checks.push("SEO files and custom 404");
  await page.goto(base + "/");
  for (const slug of slugs) {
    await page.locator(`.key-choice[data-key="${slug}"]`).click();
    await page.locator(".vault-action button").click();
    await page
      .locator(".car-reveal[data-reveal-phase=settled][aria-busy=false]")
      .waitFor();
    assert.equal(
      await page.locator(".car-reveal").getAttribute("data-photo-active"),
      slug,
    );
    await page.keyboard.press("Escape");
    await page.locator(".car-reveal").waitFor({ state: "detached" });
  }
  checks.push("six correct keys/reveals and return");
  await page.goto(base + "/collection/revuelto/");
  await page.getByRole("button", { name: /Ingrandisci:/ }).click();
  await page.locator(".gallery-lightbox").waitFor();
  await page.keyboard.press("ArrowRight");
  assert.match(
    await page.locator(".lightbox-controls p").innerText(),
    /posteriore/,
  );
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "INTERNI 01" }).click();
  await page.getByRole("button", { name: /Ingrandisci:/ }).click();
  await page.keyboard.press("Escape");
  await page.goto(base + "/collection/750s/");
  await page.getByRole("button", { name: "INTERNI 00" }).click();
  await page.locator(".gallery-empty").waitFor();
  checks.push(
    "gallery controls, lightbox keyboard, interior and declared fallback",
  );
  await page.goto(base + "/services/");
  assert.equal(await page.locator(".service-card").count(), 6);
  await page.locator(".service-card").nth(1).getByRole("link").click();
  await page.locator(".booking-page-panel form").waitFor();
  assert.match(
    await page.locator("[name=notes]").inputValue(),
    /Chauffeur Service/,
  );
  checks.push("six demo services and service brief");
  const form = page.locator(".booking-page-panel form");
  await form.locator("[name=car]").selectOption("296-gtb");
  await form.locator("[name=location]").fill("Milano aeroporto");
  await form.locator("[name=dropoffLocation]").fill("Milano hotel");
  await form.locator("[name=name]").fill("Test VELAR");
  await form.locator("[name=email]").fill("test@example.com");
  await form.locator("[name=phone]").fill("+39 333 1234567");
  const future = new Date(Date.now() + 86400000 * 7).toISOString().slice(0, 10);
  await form.locator("[name=pickup]").fill(future);
  await form.locator("[name=return]").fill(future);
  await form.locator("[name=pickupTime]").fill("10:00");
  await form.locator("[name=returnTime]").fill("09:00");
  await form.locator("input[type=checkbox]").check();
  let posted = 0;
  page.on("request", (r) => {
    if (r.method() === "POST") posted++;
  });
  await form
    .getByRole("button", { name: "PREPARA RICHIESTA DEMO", exact: true })
    .click();
  await form.locator("[role=alert]").waitFor();
  await form.locator("[name=returnTime]").fill("11:00");
  await form
    .getByRole("button", { name: "PREPARA RICHIESTA DEMO", exact: true })
    .click();
  const summary = page.locator(".request-summary");
  await summary.waitFor();
  assert.match(await summary.innerText(), /La richiesta non è stata inviata/);
  assert.match(await summary.innerText(), /Milano hotel/);
  assert.equal(posted, 0);
  const downloadPromise = page.waitForEvent("download");
  await summary.getByRole("button", { name: "SCARICA RIEPILOGO" }).click();
  const download = await downloadPromise;
  assert.match(await readFile(await download.path(), "utf8"), /296 GTB/);
  await summary.getByRole("button", { name: "MODIFICA" }).click();
  assert.equal(await form.locator("[name=name]").inputValue(), "Test VELAR");
  checks.push(
    "same-day time validation, separate locations, local review/download/edit, no POST",
  );
  await page.goto(base + "/collection/g63/");
  await page
    .getByRole("button", { name: "REQUEST BOOKING", exact: true })
    .click();
  await page.locator(".dialog").waitFor();
  assert.equal(await page.locator(".dialog [name=car]").inputValue(), "g63");
  await page.keyboard.press("Escape");
  checks.push("sticky car booking CTA and selected vehicle");
  for (const width of [360, 390, 430, 768]) {
    const mobile = await browser.newPage({
      viewport: { width, height: 844 },
      isMobile: true,
      hasTouch: true,
      reducedMotion: "reduce",
    });
    watch(mobile);
    await mobile.goto(base + "/");
    if (await mobile.getByRole("button", { name: "Apri menu" }).isVisible())
      await mobile.getByRole("button", { name: "Apri menu" }).click();
    await mobile.getByRole("link", { name: "Collection", exact: true }).click();
    await mobile.locator("#fleet-catalog").waitFor();
    assert.equal(await mobile.locator("#fleet-catalog .car-card").count(), 6);
    await mobile.locator("#catalog-revuelto .card-photo").click();
    await mobile.locator(".car-gallery").waitFor();
    await mobile.getByRole("button", { name: /Ingrandisci:/ }).click();
    await mobile.locator(".gallery-lightbox").waitFor();
    await mobile.getByRole("button", { name: "Chiudi fotografia" }).click();
    await mobile
      .getByRole("button", { name: "REQUEST BOOKING", exact: true })
      .click();
    await mobile.locator(".dialog").waitFor();
    assert.ok(
      await mobile.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
    );
    await mobile.screenshot({ path: `artifacts/phase3/booking-${width}.png` });
    await mobile.keyboard.press("Escape");
    await mobile.setViewportSize({ width: 844, height: width });
    assert.ok(
      await mobile.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth + 1,
      ),
    );
    await mobile.close();
    checks.push("mobile gallery/menu/form/orientation " + width);
  }
  const fresh = await browser.newContext({
    ...devices["iPhone 13"],
    recordVideo: undefined,
  });
  const phone = await fresh.newPage();
  watch(phone);
  await phone.goto(base + "/");
  await phone.locator(".is-intro").waitFor();
  await phone.getByRole("button", { name: "SKIP INTRO" }).click();
  await phone.locator(".is-intro").waitFor({ state: "detached" });
  await phone.locator('.key-choice[data-key="296-gtb"]').tap();
  await phone.locator(".vault-action button").tap();
  await phone.locator(".car-reveal[data-reveal-phase=settled]").waitFor();
  await phone.screenshot({ path: "artifacts/phase3/iphone-reveal.png" });
  await phone.keyboard.press("Escape");
  await fresh.close();
  checks.push("iPhone emulation: intro skip, touch key/reveal");
  assert.deepEqual(failedRequests, []);
  assert.deepEqual(errors, []);
  console.log("PASS phase 3:", checks.length, "checks");
} catch (error) {
  errors.push(error.stack || error.message);
  console.error(error);
  process.exitCode = 1;
} finally {
  await writeFile(
    "artifacts/phase3/results.json",
    JSON.stringify({ base, checks, errors, failedRequests }, null, 2),
  );
  await api.dispose();
  await browser.close();
}
