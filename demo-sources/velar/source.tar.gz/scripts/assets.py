import urllib.request,json,time,subprocess
from pathlib import Path
root=Path('/workspace/velar/public/cars'); credits=[]
for slug,title in [('revuelto','Lamborghini Revuelto'),('296-gtb','Ferrari 296'),('cullinan','Rolls-Royce Cullinan'),('750s','McLaren 750S'),('911-gt3-rs','Porsche 911 (992)'),('g63','Mercedes-Benz G-Class')]:
 try:
  def query(base,params):
   return json.loads(subprocess.check_output(['curl','-fsSL','--max-time','30',base+'?'+urllib.parse.urlencode(params)]))
  import urllib.parse
  d=query('https://en.wikipedia.org/w/api.php',dict(action='query',titles=title,prop='pageimages',format='json',pithumbsize=1600))
  p=next(iter(d['query']['pages'].values())); file=p['pageimage']
  m=query('https://en.wikipedia.org/w/api.php',dict(action='query',titles='File:'+file,prop='imageinfo',iiprop='url|extmetadata',iiurlwidth=1600,format='json'))
  info=next(iter(m['query']['pages'].values()))['imageinfo'][0]
  url=info.get('thumburl',info['url']); subprocess.run(['curl','-fsSL','--max-time','45',url,'-o',str(root/(slug+'.jpg'))],check=True)
  credits.append(dict(slug=slug,title=title,file=file,url=info['descriptionurl'],metadata=info.get('extmetadata',{})))
  print(slug,file,flush=True)
 except Exception as e: print(slug,str(e),flush=True)
(root/'credits.json').write_text(json.dumps(credits,indent=2))
