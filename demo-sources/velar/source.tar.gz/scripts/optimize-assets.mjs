import sharp from "sharp";
import { readdir } from "node:fs/promises";
for (const file of await readdir("public/cars")) {
  if (file.endsWith(".jpg"))
    await sharp("public/cars/" + file)
      .resize({ width: 1920, withoutEnlargement: true })
      .webp({ quality: 85 })
      .toFile("public/cars/" + file.replace(".jpg", ".webp"));
}
