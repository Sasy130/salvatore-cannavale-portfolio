"""Push the reviewed local source using a short-lived credential received only over hidden stdin."""
import getpass,json,os,subprocess,sys
from pathlib import Path
credential=json.loads(getpass.getpass('Site credential JSON (hidden): '))
repo=credential['remote_url'];token=credential.get('token','');branch=credential['branch'];env=os.environ.copy()
if token:
 header=token if token.startswith(('Bearer ','Basic ')) else 'Bearer '+token
 env.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='http.'+repo+'.extraHeader',GIT_CONFIG_VALUE_0='Authorization: '+header)
env.update(GIT_TERMINAL_PROMPT='0',GIT_TRACE='0',GIT_CURL_VERBOSE='0')
def run(args):
 p=subprocess.run(args,env=env,text=True,capture_output=True)
 if p.returncode:
  output=(p.stdout+p.stderr).replace(token,'[redacted]') if token else p.stdout+p.stderr
  print(output,file=sys.stderr);raise SystemExit(p.returncode)
 return p.stdout.strip()
# Never store credentialed remotes or headers in the checkout.
run(['git','add','--all'])
status=run(['git','status','--porcelain'])
if status:run(['git','-c','user.name=VELAR Development','-c','user.email=dev@velar.invalid','commit','-m','Complete VELAR luxury demo, static hosting and phase 3 QA'])
sha=run(['git','rev-parse','HEAD'])
run(['git','push',repo,'HEAD:refs/heads/'+branch])
remote=run(['git','ls-remote',repo,'refs/heads/'+branch]).split()[0]
if remote!=sha:raise SystemExit('Remote source verification failed')
print(json.dumps({'commit_sha':sha,'branch':branch,'source_verified':True}))
