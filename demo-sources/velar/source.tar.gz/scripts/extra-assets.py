exec(open('/workspace/velar/scripts/assets.py').read().split('for slug,title')[0])
credits=json.loads((root/'credits.json').read_text())
for slug,file in [('750s','2023 McLaren 750S 1.jpg'),('911-gt3-rs','Porsche 992 GT3 RS MYLE Festival 2025 DSC 9584 (cropped).jpg'),('g63','Mercedes-AMG G 63 Genf 2018.jpg')]:
 try:
  params=dict(action='query',titles='File:'+file,prop='imageinfo',iiprop='url|extmetadata',iiurlwidth=1600,format='json')
  data=json.loads(subprocess.check_output(['curl','-fsSL','--retry','2','--max-time','30','https://en.wikipedia.org/w/api.php?'+urllib.parse.urlencode(params)]))
  info=next(iter(data['query']['pages'].values()))['imageinfo'][0]
  subprocess.run(['curl','-fsSL','--retry','2','--max-time','45',info.get('thumburl',info['url']),'-o',str(root/(slug+'.jpg'))],check=True)
  credits.append(dict(slug=slug,file=file,url=info['descriptionurl'],metadata=info.get('extmetadata',{})))
  print(slug,flush=True)
 except Exception as e:print(e)
(root/'credits.json').write_text(json.dumps(credits,indent=2))
