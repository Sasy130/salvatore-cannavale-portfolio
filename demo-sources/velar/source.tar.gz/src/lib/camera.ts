import { gsap } from "gsap";
import { CameraPose, REST_CAMERA, MOTION } from "./motion";
/** A planar camera rig: table transforms only. Photographs are never skewed. */
export function createCameraRig(
  element: HTMLElement,
  initial: Partial<CameraPose> = {},
) {
  const pose = { ...REST_CAMERA, ...initial };
  const render = () =>
    gsap.set(element, {
      x: pose.truck,
      y: pose.pedestal,
      scale: pose.dolly,
      rotationX: pose.pitch,
      rotationY: pose.yaw,
      rotationZ: pose.roll,
      force3D: true,
    });
  render();
  return {
    pose,
    render,
    move(
      target: Partial<CameraPose>,
      duration: number = MOTION.duration.focus,
    ) {
      return gsap.to(pose, {
        ...target,
        duration,
        ease: MOTION.ease.camera,
        overwrite: "auto",
        onUpdate: render,
      });
    },
    stop() {
      gsap.killTweensOf(pose);
    },
  };
}

export type KeyFrame = {
  x: number;
  y: number;
  width: number;
  height: number;
  rotation: number;
};
export function measureKey(element: Element): KeyFrame {
  const rect = element.getBoundingClientRect();
  const matrix = new DOMMatrixReadOnly(getComputedStyle(element).transform);
  const rotation = (Math.atan2(matrix.b, matrix.a) * 180) / Math.PI;
  const angle = (Math.abs(rotation) * Math.PI) / 180,
    c = Math.cos(angle),
    s = Math.sin(angle),
    denominator = c * c - s * s;
  const width = (rect.width * c - rect.height * s) / denominator,
    height = (rect.height * c - rect.width * s) / denominator;
  return {
    x: rect.x + (rect.width - width) / 2,
    y: rect.y + (rect.height - height) / 2,
    width,
    height,
    rotation,
  };
}
