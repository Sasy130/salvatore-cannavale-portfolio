import type { ExperienceState } from "@/components/ExperienceContext";
import type { SetStateAction } from "react";
/** Ownership and interruption are scene-local; these guards reject late callbacks into another scene. */
export const TRANSITION_POLICY = {
  INTRO: {
    owner: "intro timeline",
    interrupt: "settle immediately on skip or resize",
    next: ["VAULT_IDLE"],
  },
  VAULT_IDLE: {
    owner: "native scroll",
    interrupt: "retarget focus from current pose",
    next: [
      "INTRO",
      "VAULT_SCROLL",
      "KEY_SELECTED",
      "CAR_EXPLORE",
      "CAR_TRANSITION",
      "BOOKING",
    ],
  },
  VAULT_SCROLL: {
    owner: "scrub timeline",
    interrupt: "focus uses a separate child rig",
    next: [
      "VAULT_IDLE",
      "INTRO",
      "KEY_SELECTED",
      "CAR_TRANSITION",
      "CAR_EXPLORE",
      "BOOKING",
    ],
  },
  KEY_SELECTED: {
    owner: "selection timeline",
    interrupt: "kill and retarget current values",
    next: [
      "CAR_EXPLORE",
      "INTRO",
      "VAULT_IDLE",
      "VAULT_SCROLL",
      "KEY_SELECTED",
      "CAR_TRANSITION",
      "BOOKING",
    ],
  },
  CAR_TRANSITION: {
    owner: "reveal timeline",
    interrupt: "close from current mask; latest decoded asset wins",
    next: ["CAR_EXPLORE", "CAR_TRANSITION", "VAULT_IDLE", "BOOKING"],
  },
  CAR_EXPLORE: {
    owner: "reveal panel",
    interrupt: "switch without remounting the scene",
    next: ["CAR_TRANSITION", "VAULT_IDLE", "BOOKING"],
  },
  BOOKING: {
    owner: "booking dialog",
    interrupt: "restore the previous scene; ignore late motion callbacks",
    next: [
      "CAR_EXPLORE",
      "INTRO",
      "VAULT_IDLE",
      "VAULT_SCROLL",
      "KEY_SELECTED",
      "CAR_TRANSITION",
    ],
  },
} satisfies Record<
  ExperienceState,
  { owner: string; interrupt: string; next: ExperienceState[] }
>;
export function reduceExperience(
  current: ExperienceState,
  action: SetStateAction<ExperienceState>,
): ExperienceState {
  const next = typeof action === "function" ? action(current) : action;
  return next === current ||
    (TRANSITION_POLICY[current].next as readonly string[]).includes(next)
    ? next
    : current;
}
