/** Screen-space 2.5D direction. No orbit of a photographed object is implied. */
export const MOTION = {
  duration: {
    intro: 5,
    feedback: 0.22,
    focus: 0.62,
    connection: 1.1,
    settle: 0.48,
    switch: 0.5,
    return: 0.65,
    route: 0.38,
  },
  ease: {
    camera: "power3.inOut",
    settle: "power3.out",
    feedback: "power2.out",
    light: "sine.inOut",
  },
  scroll: { scrub: 0.35, desktopTruck: 16, mobileTruck: 5, pedestal: 22 },
  camera: {
    desktopMacro: 8.4,
    mobileMacro: 6.8,
    focusScale: 1.055,
    mobileFocusScale: 1.025,
  },
} as const;
export const reducedMotion = () =>
  matchMedia("(prefers-reduced-motion: reduce)").matches;
export const compactMotion = () =>
  innerWidth <= 768 || (navigator.hardwareConcurrency || 8) <= 4;
export type CameraPose = {
  truck: number;
  pedestal: number;
  dolly: number;
  pitch: number;
  yaw: number;
  roll: number;
};
export const REST_CAMERA: CameraPose = {
  truck: 0,
  pedestal: 0,
  dolly: 1,
  pitch: 0,
  yaw: 0,
  roll: 0,
};
export function safeSession(key: string, value?: string) {
  try {
    if (value !== undefined) sessionStorage.setItem(key, value);
    return sessionStorage.getItem(key);
  } catch {
    return null;
  }
}
