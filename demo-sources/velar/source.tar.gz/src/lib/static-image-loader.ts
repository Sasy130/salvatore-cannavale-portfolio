import type { ImageLoaderProps } from "next/image";
/** Responsive local WebP variants; no image API or external runtime is required. */
export default function staticImageLoader({ src, width }: ImageLoaderProps) {
  if (!src.startsWith("/demos/velar/cars/") || !src.endsWith(".webp")) return src;
  const size = width <= 480 ? 480 : width <= 960 ? 960 : 1600;
  return src.replace(/\.webp$/, `-w${size}.webp`);
}
