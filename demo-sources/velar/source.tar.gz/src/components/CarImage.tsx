"use client";
import { useState } from "react";
import Image from "next/image";
import type { Car } from "@/data/cars";
export function CarImage({
  car,
  priority = false,
  sizes = "(max-width:600px) 90vw,(max-width:900px) 45vw,33vw",
}: {
  car: Car;
  priority?: boolean;
  sizes?: string;
}) {
  const [failed, setFailed] = useState(false);
  return car.image && !failed ? (
    <Image
      src={car.image}
      alt={`${car.brand} ${car.model} — fotografia esterna`}
      fill
      sizes={sizes}
      priority={priority}
      onError={() => setFailed(true)}
    />
  ) : (
    <div className="fallback-image">
      {car.brand} {car.model}
      <br />
      Fotografia verificata in preparazione
    </div>
  );
}
