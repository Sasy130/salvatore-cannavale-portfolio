"use client";
import Link from "next/link";
import { ViewTransition, useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MOTION } from "@/lib/motion";
import { cinematics } from "@/data/cinematics";
import { CarGallery } from "./CarGallery";
import { highlights } from "@/data/galleries";
import { ArrowUpRight } from "lucide-react";
import type { Car } from "@/data/cars";
import { useExperience } from "./ExperienceContext";
import { CarImage } from "./CarImage";
export function DetailExperience({ car }: { car: Car }) {
  const { book, homeSnapshot } = useExperience();
  const root = useRef<HTMLElement>(null);
  useEffect(() => {
    const element = root.current;
    if (!element) return;
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add("(prefers-reduced-motion: no-preference)", () => {
      const ctx = gsap.context(() => {
        gsap.fromTo(
          ".detail-hero img",
          { yPercent: -2, scale: 1.045 },
          {
            yPercent: 2,
            scale: 1.045,
            ease: "none",
            scrollTrigger: {
              trigger: ".detail-hero",
              start: "top bottom",
              end: "bottom top",
              scrub: MOTION.scroll.scrub,
            },
          },
        );
      }, element);
      return () => ctx.revert();
    });
    return () => mm.revert();
  }, []);
  return (
    <main className="section detail" ref={root}>
      <Link
        className="text-link"
        href={homeSnapshot?.path || (homeSnapshot ? "/" : "/collection")}
        scroll={!homeSnapshot}
        transitionTypes={["nav-back"]}
      >
        ← BACK TO COLLECTION
      </Link>
      <div className="eyebrow" style={{ marginTop: 35 }}>
        {car.category}
      </div>
      <h1>
        {car.brand}
        <br />
        <em>{car.model}</em>
      </h1>
      <ViewTransition
        name={
          (homeSnapshot?.source === "vault"
            ? "reveal-car-"
            : homeSnapshot?.path === "/collection"
              ? "collection-car-"
              : "fleet-car-") + car.slug
        }
        share="car-morph"
        default="none"
      >
        <div
          className="detail-hero"
          style={
            {
              "--detail-framing": cinematics[car.slug].target.join("% ") + "%",
            } as React.CSSProperties
          }
        >
          <CarImage car={car} priority sizes="90vw" />
        </div>
      </ViewTransition>
      <CarGallery car={car} />
      <div className="detail-content">
        <div>
          <div className="eyebrow">THE EXPERIENCE</div>
          <h2>
            Una presenza.
            <br />
            Infinite possibilità.
          </h2>
          <p>{car.description}</p>
          <ul className="car-highlights">
            {highlights[car.slug].map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p>
            Tariffa illustrativa da €{car.price.toLocaleString("it-IT")} al
            giorno. Non costituisce un’offerta commerciale. Disponibilità,
            deposito, assicurazione, chilometraggio e requisiti di guida non
            sono ancora configurati.
          </p>
          <button
            className="button"
            onClick={() => book(car.slug)}
            style={{ marginTop: 30 }}
          >
            RICHIEDI QUESTA VETTURA <ArrowUpRight size={16} />
          </button>
        </div>
        <div>
          <div className="spec-grid">
            {[
              ["Potenza", car.power],
              ["0–100 km/h", car.acceleration],
              ["Velocità massima", car.speed],
              ["Motore", car.engine],
            ].map(([label, value]) => (
              <div key={label}>
                <small>{label}</small>
                <strong>{value}</strong>
              </div>
            ))}
          </div>
          <div className="asset-note">
            Dati indicativi del modello di serie.{" "}
            <a href={car.source} target="_blank" rel="noreferrer">
              Fonte del costruttore ↗
            </a>
            <br />
            Le gallerie indicano gli asset effettivamente disponibili. Gli
            allestimenti fotografati possono differire. Nessuna immagine di
            altri modelli viene sostituita.
            <br />
            <Link href="/credits">Crediti fotografici e licenze →</Link>
          </div>
        </div>
      </div>
      <section className="rental-section">
        <div>
          <div className="eyebrow">RENTAL DETAILS</div>
          <h2>
            La trasparenza
            <br />
            fa parte del viaggio.
          </h2>
        </div>
        <dl className="rental-terms">
          <div>
            <dt>Tariffa giornaliera</dt>
            <dd>
              Da €{car.price.toLocaleString("it-IT")}/giorno, esclusivamente
              dimostrativi. Nessun totale commerciale calcolato.
            </dd>
          </div>
          <div>
            <dt>Deposito cauzionale</dt>
            <dd>
              Importo e modalità non configurati. Da definire in un’offerta
              reale.
            </dd>
          </div>
          <div>
            <dt>Chilometraggio incluso</dt>
            <dd>
              Da concordare. Nessuna promessa di chilometri illimitati; costi
              extra non definiti.
            </dd>
          </div>
          <div>
            <dt>Coperture e requisiti</dt>
            <dd>
              Assicurazione, franchigia, età minima, patente e disponibilità da
              verificare prima di qualsiasi noleggio reale.
            </dd>
          </div>
        </dl>
      </section>
      <div className="detail-booking-bar">
        <div>
          <small>PREZZO DIMOSTRATIVO</small>
          <strong>
            €{car.price.toLocaleString("it-IT")} <span>/ giorno</span>
          </strong>
        </div>
        <button className="button" onClick={() => book(car.slug)}>
          REQUEST BOOKING <ArrowUpRight size={15} />
        </button>
      </div>
    </main>
  );
}
