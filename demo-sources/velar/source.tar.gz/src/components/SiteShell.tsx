"use client";
import {
  useState,
  useEffect,
  useCallback,
  useRef,
  ReactNode,
  useReducer,
} from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { HomeSnapshot } from "./ExperienceContext";
import { reduceExperience } from "@/lib/motion-state";
import { safeSession } from "@/lib/motion";
import { ArrowUpRight, X, Menu } from "lucide-react";
import { cars } from "@/data/cars";
import { Context, ExperienceState } from "./ExperienceContext";
import { Booking } from "./Booking";
export function SiteShell({ children }: { children: ReactNode }) {
  const [state, setState] = useReducer(reduceExperience, "VAULT_IDLE");
  const pathname = usePathname();
  const previousPath = useRef(pathname);
  const [selectedSlug, setSelectedSlug] = useState("296-gtb");
  const [homeSnapshot, saveHomeSnapshot] = useState<HomeSnapshot | null>(null);
  const selectCar = useCallback((slug: string) => {
    if (cars.some((c) => c.slug === slug)) {
      setSelectedSlug(slug);
      safeSession("velar-selected", slug);
    }
  }, []);
  const [booking, setBooking] = useState<string | null>(null);
  const [menu, setMenu] = useState(false);
  const [active, setActive] = useState("home");
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 40);
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => window.removeEventListener("scroll", update);
  }, []);
  const beforeBooking = useRef<ExperienceState>("VAULT_IDLE");
  const book = useCallback(
    (slug?: string) => {
      beforeBooking.current = state;
      setBooking(slug || selectedSlug);
      setState("BOOKING");
    },
    [state, selectedSlug],
  );
  const closeBooking = useCallback(() => {
    setBooking(null);
    setState(beforeBooking.current);
  }, []);
  useEffect(() => {
    const sections = document.querySelectorAll("section[id]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-15% 0px -55% 0px" },
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, [pathname]);
  useEffect(() => {
    const changed = previousPath.current !== pathname;
    previousPath.current = pathname;
    const frame = requestAnimationFrame(() => {
      if (changed) setMenu(false);
      setState((current) => {
        if (current === "BOOKING" || current === "INTRO") return current;
        if (pathname.startsWith("/collection/")) return "CAR_EXPLORE";
        const reveal = Array.from(
          document.querySelectorAll<HTMLElement>(".car-reveal"),
        ).find((node) => node.getClientRects().length > 0);
        if (pathname === "/" && reveal)
          return reveal.dataset.revealPhase === "settled"
            ? "CAR_EXPLORE"
            : "CAR_TRANSITION";
        return "VAULT_IDLE";
      });
      const saved = safeSession("velar-selected");
      if (saved && cars.some((c) => c.slug === saved)) setSelectedSlug(saved);
    });
    return () => cancelAnimationFrame(frame);
  }, [pathname]);
  useEffect(() => {
    if (!menu) return;
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenu(false);
        document.querySelector<HTMLButtonElement>(".menu")?.focus();
      }
    };
    document.addEventListener("keydown", key);
    return () => document.removeEventListener("keydown", key);
  }, [menu]);
  return (
    <Context.Provider
      value={{
        book,
        state,
        setState,
        selectedSlug,
        selectCar,
        homeSnapshot,
        saveHomeSnapshot,
      }}
    >
      <header
        className={scrolled ? "scrolled" : ""}
        inert={state === "INTRO"}
        data-experience-state={state}
      >
        <Link href="/" className="logo" aria-label="VELAR Home">
          VELAR<small>EXOTIC CAR RENTAL</small>
        </Link>
        <nav className={menu ? "open" : ""} aria-label="Navigazione principale">
          {[
            ["Home", "/#home"],
            ["Collection", "/collection"],
            ["Services", "/services"],
            ["About", "/about"],
            ["Contact", "/contact"],
          ].map(([name, url]) => (
            <Link
              className={
                (
                  pathname === "/"
                    ? active === name.toLowerCase()
                    : pathname.startsWith(url)
                )
                  ? "active"
                  : ""
              }
              key={name}
              href={url}
              onClick={() => {
                setMenu(false);
                if (name === "Home") saveHomeSnapshot(null);
              }}
            >
              {name}
            </Link>
          ))}
        </nav>
        <button
          className="nav-book"
          onClick={() => {
            book();
            setMenu(false);
          }}
        >
          BOOK NOW <ArrowUpRight size={13} />
        </button>
        <button
          className="menu"
          aria-label={menu ? "Chiudi menu" : "Apri menu"}
          aria-expanded={menu}
          onClick={() => setMenu(!menu)}
        >
          {menu ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>
      {children}
      <footer>
        <div className="footer-top">
          <div>
            <Link href="/" className="logo">
              VELAR<small>EXOTIC CAR RENTAL</small>
            </Link>
            <p>
              Extraordinary cars. Unforgettable journeys.
              <br />
              Un nuovo modo di vivere la strada.
            </p>
          </div>
          <div className="footer-links">
            <Link href="/collection">The collection</Link>
            <Link href="/services">Our services</Link>
            <Link href="/contact">Contact</Link>
            <Link href="/booking">Request booking</Link>
            <Link href="/about">About VELAR</Link>
            <Link href="/privacy">Privacy · demo</Link>
            <Link href="/cookies">Cookies & storage</Link>
            <Link href="/credits">Asset & project notes</Link>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 VELAR · Concept di autonoleggio di lusso</span>
          <span>
            PREZZI E DISPONIBILITÀ DIMOSTRATIVI · NESSUNA PRENOTAZIONE REALE
          </span>
        </div>
      </footer>
      {booking && <Booking initial={booking} onClose={closeBooking} />}
    </Context.Provider>
  );
}
