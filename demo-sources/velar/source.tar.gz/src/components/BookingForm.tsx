"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, Check, Download, Edit3 } from "lucide-react";
import { cars } from "@/data/cars";
function localDate() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
export function BookingForm({
  initial = "revuelto",
  initialNote = "",
  onNavigate,
}: {
  initial?: string;
  initialNote?: string;
  onNavigate?: () => void;
}) {
  const [today, setToday] = useState("");
  const [pickup, setPickup] = useState("");
  const [stage, setStage] = useState<"editing" | "preparing" | "review">(
    "editing",
  );
  const [error, setError] = useState("");
  const [summary, setSummary] = useState("");
  const form = useRef<HTMLFormElement>(null);
  const summaryRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (stage === "review") summaryRef.current?.focus();
  }, [stage]);
  const frame = useRef<number | null>(null);
  useEffect(() => {
    const id = requestAnimationFrame(() => {
      const value = localDate();
      setToday(value);
      setPickup((p) => p || value);
    });
    return () => {
      cancelAnimationFrame(id);
      if (frame.current) cancelAnimationFrame(frame.current);
    };
  }, []);
  function download() {
    const blob = new Blob(
      [
        summary +
          "\n\nDEMO LOCALE — richiesta non inviata, prenotazione non confermata.\nNessun pagamento o disponibilità garantita.",
      ],
      { type: "text/plain;charset=utf-8" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "velar-richiesta-demo.txt";
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return (
    <div className="booking-form">
      <div className="demo-badge">DEMO LOCALE · INVIO NON ATTIVO</div>
      <p className="dialog-intro">
        Prepara la tua richiesta e controlla il riepilogo. I dati restano in
        questa pagina: non vengono trasmessi né salvati dopo la chiusura.
        Nessuna prenotazione o disponibilità viene confermata.
      </p>
      <form
        ref={form}
        hidden={stage === "review"}
        aria-busy={stage === "preparing"}
        onSubmit={(event) => {
          event.preventDefault();
          setError("");
          const f = new FormData(event.currentTarget);
          const name = String(f.get("name")).trim(),
            location = String(f.get("location")).trim(),
            dropoff = String(f.get("dropoffLocation")).trim();
          const car = cars.find((c) => c.slug === f.get("car"));
          if (!car) {
            setError("Seleziona una vettura della collezione.");
            return;
          }
          if (name.length < 2 || location.length < 2 || dropoff.length < 2) {
            setError(
              "Inserisci nome e località di ritiro e riconsegna validi.",
            );
            return;
          }
          const phone = String(f.get("phone")).trim();
          if (
            !/^[+\d\s().-]{7,25}$/.test(phone) ||
            phone.replace(/\D/g, "").length < 7 ||
            phone.replace(/\D/g, "").length > 15
          ) {
            setError(
              "Inserisci un numero di telefono valido, con prefisso internazionale.",
            );
            return;
          }
          const start =
              String(f.get("pickup")) + "T" + String(f.get("pickupTime")),
            end = String(f.get("return")) + "T" + String(f.get("returnTime"));
          const now = new Date();
          const current =
            localDate() +
            "T" +
            String(now.getHours()).padStart(2, "0") +
            ":" +
            String(now.getMinutes()).padStart(2, "0");
          if (!f.get("pickup") || !f.get("return") || start <= current) {
            setError(
              "Il ritiro deve essere successivo alla data e all’ora attuali.",
            );
            return;
          }
          if (end <= start) {
            setError(
              "La riconsegna deve essere successiva al ritiro, anche nell’orario.",
            );
            return;
          }
          setStage("preparing");
          frame.current = requestAnimationFrame(() => {
            setSummary(
              `${car.brand} ${car.model}\nRitiro: ${f.get("pickup")} alle ${f.get("pickupTime")}\nLuogo di ritiro: ${location}\nRiconsegna: ${f.get("return")} alle ${f.get("returnTime")}\nLuogo di riconsegna: ${dropoff}\n${name}\nEmail: ${f.get("email")}\nTelefono: ${phone}\nNote: ${String(f.get("notes")).trim() || "—"}\nTariffa indicativa demo: €${car.price.toLocaleString("it-IT")}/giorno. Totale, deposito, chilometri e coperture da definire.`,
            );
            setStage("review");
          });
        }}
      >
        <div className="form-grid">
          <label className="field full">
            Vettura
            <select name="car" defaultValue={initial} required>
              {cars.map((c) => (
                <option key={c.slug} value={c.slug}>
                  {c.brand} {c.model}
                </option>
              ))}
            </select>
          </label>
          <label className="field">
            Data ritiro
            <input
              type="date"
              name="pickup"
              value={pickup}
              onChange={(e) => setPickup(e.target.value)}
              min={today || undefined}
              required
            />
          </label>
          <label className="field">
            Ora ritiro
            <input
              type="time"
              name="pickupTime"
              defaultValue="10:00"
              required
            />
          </label>
          <label className="field">
            Data riconsegna
            <input
              type="date"
              name="return"
              min={pickup || today || undefined}
              required
            />
          </label>
          <label className="field">
            Ora riconsegna
            <input
              type="time"
              name="returnTime"
              defaultValue="10:00"
              required
            />
          </label>
          <label className="field">
            Località ritiro
            <input
              name="location"
              autoComplete="off"
              placeholder="Città, aeroporto o hotel"
              minLength={2}
              maxLength={120}
              required
            />
          </label>
          <label className="field">
            Località riconsegna
            <input
              name="dropoffLocation"
              autoComplete="off"
              placeholder="Città, aeroporto o hotel"
              minLength={2}
              maxLength={120}
              required
            />
          </label>
          <label className="field full">
            Nome e cognome
            <input
              name="name"
              autoComplete="name"
              minLength={2}
              maxLength={100}
              required
            />
          </label>
          <label className="field">
            Email
            <input
              name="email"
              type="email"
              autoComplete="email"
              maxLength={150}
              required
            />
          </label>
          <label className="field">
            Telefono
            <input
              name="phone"
              type="tel"
              autoComplete="tel"
              placeholder="+39"
              maxLength={25}
              required
            />
          </label>
          <label className="field full">
            Note aggiuntive
            <textarea
              name="notes"
              defaultValue={initialNote}
              maxLength={1500}
              placeholder="Occasione, itinerario e preferenze…"
            />
          </label>
        </div>
        <p className="form-hint">
          Orari locali indicativi. Fuso orario e condizioni saranno da
          confermare in un’offerta reale.
        </p>
        <label className="consent">
          <input type="checkbox" required /> Comprendo che questa è una
          simulazione locale: nessun dato sarà inviato e nessuna prenotazione
          sarà confermata.
        </label>
        <p className="form-hint">
          Leggi l’
          <Link href="/privacy" target="_blank" rel="noreferrer">
            informativa privacy dimostrativa
          </Link>
          . Non inserire documenti, carte o altri dati sensibili.
        </p>
        {error && (
          <p className="form-error" role="alert">
            {error}
          </p>
        )}
        <button
          className="button"
          type="submit"
          disabled={stage === "preparing"}
        >
          {stage === "preparing"
            ? "PREPARAZIONE LOCALE…"
            : "PREPARA RICHIESTA DEMO"}{" "}
          <ArrowRight size={14} />
        </button>
      </form>
      {stage === "review" && (
        <div
          className="status request-summary"
          role="status"
          ref={summaryRef}
          tabIndex={-1}
        >
          <Check size={24} />
          <h3>Riepilogo preparato nel browser.</h3>
          <p>{summary}</p>
          <p>
            <strong>La richiesta non è stata inviata.</strong> Conserva il
            riepilogo: contatti e disponibilità commerciali non sono ancora
            configurati.
          </p>
          <div className="summary-actions">
            <button className="button" onClick={download}>
              SCARICA RIEPILOGO <Download size={14} />
            </button>
            <button className="text-link" onClick={() => setStage("editing")}>
              <Edit3 size={14} /> MODIFICA
            </button>
            <Link className="text-link" href="/collection" onClick={onNavigate}>
              TORNA ALLA COLLEZIONE <ArrowRight size={14} />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
