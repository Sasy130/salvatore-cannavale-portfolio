"use client";
import { useEffect, RefObject, Dispatch, SetStateAction } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { createCameraRig } from "@/lib/camera";
import { MOTION, reducedMotion, compactMotion } from "@/lib/motion";
import type { ExperienceState } from "./ExperienceContext";
export function useIntroTimeline(
  intro: boolean,
  vault: RefObject<HTMLElement | null>,
  introTL: RefObject<gsap.core.Timeline | null>,
  finishIntro: () => void,
) {
  useEffect(() => {
    if (!intro || !vault.current) return;
    const scene = vault.current;
    const layer = scene.querySelector<HTMLElement>(".vault-camera")!;
    const keys = scene.querySelectorAll<HTMLElement>(".key-choice");
    const skip = scene.querySelector<HTMLButtonElement>(".skip");
    const compact = compactMotion();
    const previous = document.activeElement as HTMLElement;
    document.body.classList.add("intro-running");
    scene.setAttribute("data-camera-owner", "intro");
    skip?.focus({ preventScroll: true });
    const keyboard = (e: KeyboardEvent) => {
      if (e.key === "Escape") finishIntro();
      if (e.key === "Tab") {
        e.preventDefault();
        skip?.focus({ preventScroll: true });
      }
    };
    const resize = () => finishIntro();
    document.addEventListener("keydown", keyboard);
    window.addEventListener("resize", resize, { once: true });
    const ctx = gsap.context(() => {
      const heroKey = scene.querySelector<HTMLElement>('[data-key="296-gtb"]')!;
      const otherKeys = Array.from(keys).filter((key) => key !== heroKey);
      gsap.set(scene.querySelector(".vault-selection"), { x: 0, y: 0, scale: 1 });
      gsap.set(layer, { x: 0, y: 0, scale: 1, rotationX: 0, rotationY: 0, rotationZ: 0 });
      const first = heroKey.querySelector(".key-art")!.getBoundingClientRect();
      const stage = layer.getBoundingClientRect();
      const originX = first.x + first.width * 0.5 - stage.x;
      const originY = first.y + first.height * 0.5 - stage.y;
      gsap.set(layer, { transformOrigin: `${originX}px ${originY}px` });
      const camera = createCameraRig(layer, {
        truck: innerWidth * 0.5 - (first.x + first.width * 0.5),
        pedestal: innerHeight * 0.5 - (first.y + first.height * 0.5),
        dolly: Math.min(compact ? 2.3 : 2.8, innerHeight * 0.48 / first.height),
        pitch: 0,
        yaw: 0,
      });
      gsap.set(scene.querySelectorAll(".key-choice > span, .key-choice > small"), { opacity: 0 });
      const tl = gsap.timeline({ onComplete: finishIntro });
      tl.to(scene.querySelectorAll(".key-choice > span, .key-choice > small"), { opacity: 1, duration: 0.6 }, 3.5);
      introTL.current = tl;
      // One authoritative five-second sequence; position, orientation, focus and light have separate curves.
      tl.to(
        camera.pose,
        {
          truck: camera.pose.truck,
          duration: 1,
          ease: "sine.inOut",
          onUpdate: camera.render,
        },
        0,
      )
        .to(
          camera.pose,
          {
            truck: 0,
            pedestal: 0,
            dolly: 1,
            duration: 4,
            ease: MOTION.ease.camera,
            onUpdate: camera.render,
          },
          1,
        )
        .to(
          camera.pose,
          {
            pitch: 0,
            yaw: 0,
            duration: 3.6,
            ease: "sine.inOut",
            onUpdate: camera.render,
          },
          1.25,
        )
        .fromTo(
          heroKey,
          { opacity: 1 },
          { opacity: 1, duration: 2.35, ease: MOTION.ease.light },
          0,
        )
        .fromTo(
          heroKey.querySelector(".key-ground"),
          { opacity: 0, scale: 0.6 },
          {
            opacity: 0.7,
            scale: 1.1,
            duration: 0.7,
            yoyo: true,
            repeat: 1,
            ease: MOTION.ease.light,
          },
          2.5,
        )
        .fromTo(
          otherKeys,
          { opacity: 0 },
          {
            opacity: 1,
            duration: 1.35,
            stagger: 0.12,
            ease: MOTION.ease.light,
          },
          3.0,
        )
        .fromTo(
          ".vault-caption",
          { clipPath: "inset(0 0 100% 0)", y: 12 },
          {
            clipPath: "inset(0 0 0% 0)",
            y: 0,
            duration: 0.85,
            ease: MOTION.ease.settle,
          },
          4.0,
        )
        .fromTo(
          ".vault-action,.vault-top",
          { opacity: 0, y: 6 },
          { opacity: 1, y: 0, duration: 0.65 },
          4.35,
        )
        .fromTo(
          keys,
          { borderColor: "transparent" },
          { borderColor: "#ffffff15", duration: 0.65 },
          4.35,
        )
        .to(
          ".key-choice.selected",
          { borderColor: "#d5dac8", duration: 0.65 },
          4.35,
        )
        .fromTo(
          ".intro-progress",
          { scaleX: 0 },
          { scaleX: 1, duration: MOTION.duration.intro, ease: "none" },
          0,
        );
      if (reducedMotion()) tl.totalDuration(0.01);
    }, scene);
    return () => {
      ctx.revert();
      introTL.current = null;
      scene.setAttribute("data-camera-owner", "idle");
      document.body.classList.remove("intro-running");
      document.removeEventListener("keydown", keyboard);
      window.removeEventListener("resize", resize);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [intro, vault, introTL, finishIntro]);
}
export function useScrollMotion(
  root: RefObject<HTMLElement | null>,
  intro: boolean,
  setState: Dispatch<SetStateAction<ExperienceState>>,
) {
  useEffect(() => {
    if (!root.current || intro) return;
    gsap.registerPlugin(ScrollTrigger);
    const rootElement = root.current;
    const scene = rootElement.querySelector<HTMLElement>(".vault-section")!;
    const mm = gsap.matchMedia();
    mm.add(
      {
        motion: "(prefers-reduced-motion: no-preference)",
        compact: "(max-width: 768px)",
      },
      (context) => {
        if (!context.conditions?.motion) return;
        const compact = !!context.conditions.compact;
        const layer = scene.querySelector<HTMLElement>(".vault-camera")!;
        const ctx = gsap.context(() => {
          gsap.set(layer, { transformOrigin: "50% 50%" });
          const camera = createCameraRig(layer);
          gsap.to(".hero-photo", {
            yPercent: compact ? 4 : 9,
            scale: compact ? 1.035 : 1.07,
            ease: "none",
            scrollTrigger: {
              trigger: ".hero",
              start: "top top",
              end: "bottom top",
              scrub: MOTION.scroll.scrub,
            },
          });
          const idle = () => {
            scene.setAttribute("data-camera-owner", "idle");
            setState((s) => (s === "VAULT_SCROLL" ? "VAULT_IDLE" : s));
          };
          const tl = gsap.timeline({
            scrollTrigger: {
              trigger: ".vault-anchor",
              start: "top top",
              end: "bottom top",
              scrub: MOTION.scroll.scrub,
              invalidateOnRefresh: true,
              onEnter: () => {
                scene.setAttribute("data-camera-owner", "scroll");
                setState((s) => (s === "VAULT_IDLE" ? "VAULT_SCROLL" : s));
              },
              onLeaveBack: idle,
              onScrubComplete: idle,
            },
          });
          tl.to(
            camera.pose,
            {
              pedestal: -MOTION.scroll.pedestal * 0.4,
              dolly: 0.988,
              pitch: compact ? 0 : 1.2,
              duration: 0.4,
              ease: "sine.inOut",
              onUpdate: camera.render,
            },
            0,
          ).to(
            camera.pose,
            {
              truck: compact
                ? -MOTION.scroll.mobileTruck
                : -MOTION.scroll.desktopTruck,
              pedestal: -MOTION.scroll.pedestal,
              yaw: compact ? 0 : -0.65,
              duration: 0.6,
              ease: "sine.inOut",
              onUpdate: camera.render,
            },
            0.4,
          );
          const lights = scene.querySelectorAll(".key-light");
          lights.forEach((light, i) => {
            tl.fromTo(
              light,
              { opacity: 0.05 },
              { opacity: 0.4, duration: 0.16, ease: "sine.inOut" },
              i * 0.12,
            ).to(
              light,
              { opacity: 0.05, duration: 0.22, ease: "sine.inOut" },
              i * 0.12 + 0.16,
            );
          });
          tl.fromTo(
            ".vault-caption",
            { y: 0 },
            { y: -8, duration: 1, ease: "none" },
            0,
          );
        }, rootElement);
        return () => {
          ctx.revert();
          scene.setAttribute("data-camera-owner", "idle");
        };
      },
    );
    return () => mm.revert();
  }, [root, intro, setState]);
}
