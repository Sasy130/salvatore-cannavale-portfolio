"use client";
import type { KeyFrame } from "@/lib/camera";
import { createContext, useContext, Dispatch, SetStateAction } from "react";
export type ExperienceState =
  | "INTRO"
  | "VAULT_IDLE"
  | "VAULT_SCROLL"
  | "KEY_SELECTED"
  | "CAR_TRANSITION"
  | "CAR_EXPLORE"
  | "BOOKING";
export type HomeSnapshot = {
  y: number;
  filter: string;
  selected: string;
  source: "fleet" | "vault";
  path?: string;
  revealOrigin?: KeyFrame;
};
export type ExperienceContextValue = {
  book: (slug?: string) => void;
  state: ExperienceState;
  setState: Dispatch<SetStateAction<ExperienceState>>;
  selectedSlug: string;
  selectCar: (slug: string) => void;
  homeSnapshot: HomeSnapshot | null;
  saveHomeSnapshot: (snapshot: HomeSnapshot | null) => void;
};
export const Context = createContext<ExperienceContextValue | null>(null);
export function useExperience() {
  const context = useContext(Context);
  if (!context) throw new Error("VELAR Experience provider missing");
  return context;
}
