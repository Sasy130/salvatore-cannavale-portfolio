"use client";
import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import { BookingForm } from "./BookingForm";
export function Booking({
  initial,
  onClose,
}: {
  initial: string;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialog.current?.focus({ preventScroll: true });
    const handle = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
      if (e.key === "Tab") {
        const list = Array.from(
          dialog.current?.querySelectorAll<HTMLElement>(
            "button:not(:disabled),input,select,textarea,a[href]",
          ) || [],
        ).filter((n) => n.getClientRects().length);
        if (!list.length) return;
        const first = list[0],
          last = list[list.length - 1];
        if (
          e.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === dialog.current)
        ) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handle);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", handle);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [onClose]);
  return (
    <div
      className="overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="dialog"
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-title"
        tabIndex={-1}
      >
        <button
          className="close"
          onClick={onClose}
          aria-label="Chiudi richiesta"
        >
          <X size={20} />
        </button>
        <div className="eyebrow" style={{ color: "#68745a" }}>
          YOUR NEXT EXPERIENCE
        </div>
        <h2 id="booking-title">Il tuo viaggio, su misura.</h2>
        <BookingForm initial={initial} onNavigate={onClose} />
      </div>
    </div>
  );
}
