"use client";
import {
  useRef,
  useEffect,
  useLayoutEffect,
  useCallback,
  useState,
  ViewTransition,
} from "react";
import { gsap } from "gsap";
import { ArrowUpRight, X, ArrowLeft, ArrowRight } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { cars, Car } from "@/data/cars";
import { cinematics } from "@/data/cinematics";
import { MOTION, reducedMotion, compactMotion } from "@/lib/motion";
import { KeyArt } from "./KeyArt";
export type RevealOrigin = import("@/lib/camera").KeyFrame;
function insetFor(origin: RevealOrigin) {
  return `inset(${Math.max(0, origin.y)}px ${Math.max(0, innerWidth - origin.x - origin.width)}px ${Math.max(0, innerHeight - origin.y - origin.height)}px ${Math.max(0, origin.x)}px round 12px)`;
}
export function CarReveal({
  car,
  origin,
  onClose,
  onReady,
  onBook,
  onSelect,
  onNavigate,
  getOrigin,
  startSettled = false,
}: {
  car: Car;
  origin: RevealOrigin;
  onClose: () => void;
  onReady: () => void;
  onBook: () => void;
  onSelect: (car: Car) => void;
  onNavigate: () => void;
  getOrigin: () => RevealOrigin;
  startSettled?: boolean;
}) {
  const root = useRef<HTMLDivElement>(null);
  const opening = useRef<gsap.core.Timeline | null>(null);
  const resumeProgress = useRef<number | null>(startSettled ? 1 : null);
  const exit = useRef<gsap.core.Timeline | null>(null);
  const switching = useRef<gsap.core.Timeline | null>(null);
  const callbacks = useRef({ onClose, onReady, getOrigin });
  const [imageError, setImageError] = useState(false);
  const closingRef = useRef(false);
  const [closing, setClosing] = useState(false);
  const [ready, setReady] = useState(false);
  const [photo, setPhoto] = useState(car);
  const [layers, setLayers] = useState<Car[]>([car]);
  const photoRef = useRef(car);
  const request = useRef(0);
  const surface = useRef<HTMLDivElement>(null);
  const key = useRef<HTMLDivElement>(null);
  const [initialCar] = useState(car);
  const invalidateLoads = useCallback(() => {
    request.current++;
  }, []);
  useLayoutEffect(() => {
    callbacks.current = { onClose, onReady, getOrigin };
  }, [onClose, onReady, getOrigin]);
  const close = useCallback(() => {
    if (exit.current?.isActive()) return;
    closingRef.current = true;
    setClosing(true);
    setReady(false);
    request.current++;
    opening.current?.kill();
    switching.current?.kill();
    const target = callbacks.current.getOrigin();
    const reduced = reducedMotion();
    const duration = reduced ? 0 : MOTION.duration.return;
    const tl = gsap.timeline({ onComplete: () => callbacks.current.onClose() });
    exit.current = tl;
    tl.to(
      ".reveal-content,.reveal-switcher",
      { opacity: 0, y: 8, duration: duration * 0.4, overwrite: true },
      0,
    )
      .to(
        key.current,
        {
          x: target.x,
          y: target.y,
          scaleX: target.width / origin.width,
          scaleY: target.height / origin.height,
          duration,
          ease: MOTION.ease.camera,
          overwrite: "auto",
        },
        0,
      )
      .to(
        surface.current,
        {
          clipPath: insetFor(target),
          duration,
          ease: MOTION.ease.camera,
          overwrite: "auto",
        },
        0,
      );
  }, [origin]);
  useLayoutEffect(() => {
    const element = root.current!;
    const previous = document.activeElement as HTMLElement;
    const previousOverflow = document.body.style.overflow;
    const previousPadding = document.body.style.paddingRight;
    const gap = innerWidth - document.documentElement.clientWidth;
    document.body.style.overflow = "hidden";
    if (gap) document.body.style.paddingRight = `${gap}px`;
    element.focus({ preventScroll: true });
    const reduced = reducedMotion();
    const compact = compactMotion();
    const config = cinematics[initialCar.slug];
    const destination = () => ({
      x: innerWidth - (innerWidth < 600 ? 83 : 124),
      y: innerWidth < 600 ? 85 : 110,
    });
    let alive = true;
    const ctx = gsap.context(() => {
      gsap.set(key.current, {
        x: origin.x,
        y: origin.y,
        width: origin.width,
        height: origin.height,
        transformOrigin: "0 0",
      });
      gsap.set(surface.current, { clipPath: insetFor(origin) });
      const tl = gsap.timeline({
        paused: true,
        onComplete: () => {
          setReady(true);
          callbacks.current.onReady();
        },
      });
      opening.current = tl;
      tl.addLabel("focus", 0)
        .to(
          key.current,
          {
            scale: 1.12,
            duration: reduced ? 0 : 0.26,
            ease: MOTION.ease.feedback,
          },
          0,
        )
        .addLabel("connection", 0.18)
        .to(
          surface.current,
          {
            clipPath: "inset(0px 0px 0px 0px round 0px)",
            duration: reduced ? 0 : config.connection,
            ease: MOTION.ease.camera,
          },
          reduced ? 0 : 0.18,
        )
        .to(
          key.current,
          {
            ...destination(),
            scale: compact ? 0.68 : 0.75,
            duration: reduced ? 0 : config.connection,
            ease: MOTION.ease.camera,
          },
          reduced ? 0 : 0.18,
        )
        .fromTo(
          ".reveal-photo-motion",
          { x: compact ? 8 : 20, scale: 1.035 },
          {
            x: 0,
            scale: 1,
            duration: reduced ? 0 : config.connection + MOTION.duration.settle,
            ease: MOTION.ease.settle,
          },
          0,
        )
        .fromTo(
          ".reveal-content h2",
          { clipPath: "inset(0 0 100% 0)", y: 16 },
          {
            clipPath: "inset(0 0 0% 0)",
            y: 0,
            duration: reduced ? 0 : MOTION.duration.settle,
            ease: MOTION.ease.settle,
          },
          reduced ? 0 : 0.95,
        )
        .fromTo(
          ".reveal-content > :not(h2),.reveal-switcher",
          { opacity: 0, y: 10 },
          {
            opacity: 1,
            y: 0,
            duration: reduced ? 0 : MOTION.duration.settle,
            stagger: reduced ? 0 : 0.04,
            ease: MOTION.ease.settle,
          },
          reduced ? 0 : 1.12,
        );
      if (resumeProgress.current !== null) tl.progress(resumeProgress.current);
      const initialAsset = new window.Image();
      initialAsset.src = initialCar.image || "";
      initialAsset
        .decode()
        .catch(() => {
          if (alive) setImageError(true);
        })
        .then(() => {
          if (alive && !closingRef.current) tl.play();
        });
    }, element);
    const keyboard = (e: KeyboardEvent) => {
      if (!element.contains(document.activeElement)) return;
      if (e.key === "Escape") {
        e.preventDefault();
        close();
      }
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        e.preventDefault();
        const current = Number(element.dataset.carIndex || 0);
        const dir = e.key === "ArrowRight" ? 1 : -1;
        element
          .querySelector<HTMLButtonElement>(
            `[data-car-index="${(current + dir + cars.length) % cars.length}"]`,
          )
          ?.click();
      }
      if (e.key === "Tab") {
        const nodes = Array.from(
          element.querySelectorAll<HTMLElement>(
            "button:not(:disabled),a[href]",
          ),
        ).filter((n) => n.getClientRects().length);
        const firstNode = nodes[0],
          last = nodes[nodes.length - 1];
        if (
          e.shiftKey &&
          (document.activeElement === firstNode ||
            document.activeElement === element)
        ) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          firstNode?.focus();
        }
      }
    };
    const resize = () => {
      const dest = destination();
      gsap.to(key.current, {
        ...dest,
        duration: reducedMotion() ? 0 : MOTION.duration.feedback,
        overwrite: "auto",
      });
      if (opening.current?.isActive()) {
        opening.current.progress(1);
      }
      gsap.set(surface.current, {
        clipPath: "inset(0px 0px 0px 0px round 0px)",
      });
    };
    document.addEventListener("keydown", keyboard);
    window.addEventListener("resize", resize);
    return () => {
      alive = false;
      resumeProgress.current = opening.current?.progress() ?? null;
      invalidateLoads();
      ctx.revert();
      opening.current?.kill();
      exit.current?.kill();
      switching.current?.kill();
      document.body.style.overflow = previousOverflow;
      document.body.style.paddingRight = previousPadding;
      document.removeEventListener("keydown", keyboard);
      window.removeEventListener("resize", resize);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [origin, close, initialCar, invalidateLoads]);
  // Keep the current photograph while the requested asset decodes. A stale load never wins a later selection.
  useEffect(() => {
    if (car.slug === photoRef.current.slug) {
      if ((opening.current?.progress() || 0) >= 1) {
        const frame = requestAnimationFrame(() => {
          setReady(true);
          callbacks.current.onReady();
        });
        return () => cancelAnimationFrame(frame);
      }
      return;
    }
    const token = ++request.current;
    let cancelled = false;
    const image = new window.Image();
    image.src = car.image || "";
    const change = async () => {
      try {
        await image.decode();
      } catch {
        if (!image.naturalWidth) {
          if (!cancelled && request.current === token) {
            setImageError(true);
            setReady(true);
            callbacks.current.onReady();
          }
          return;
        }
      }
      if (cancelled || request.current !== token) return;
      setImageError(false);
      setLayers((previous) =>
        previous.some((c) => c.slug === car.slug)
          ? previous
          : [...previous, car],
      );
      setPhoto(car);
      photoRef.current = car;
    };
    void change();
    return () => {
      cancelled = true;
    };
  }, [car]);
  useLayoutEffect(() => {
    if (closing || (photo.slug === initialCar.slug && layers.length === 1))
      return;
    const panels = root.current?.querySelectorAll<HTMLElement>(
      ".reveal-photo-frame",
    );
    if (!panels) return;
    switching.current?.kill();
    const duration = reducedMotion() ? 0 : MOTION.duration.switch;
    const tl = gsap.timeline({
      onComplete: () => {
        if (!closing) {
          setReady(true);
          callbacks.current.onReady();
        }
      },
    });
    switching.current = tl;
    panels.forEach((panel) => {
      const active = panel.dataset.photo === photo.slug;
      tl.to(
        panel,
        {
          x: active ? 0 : compactMotion() ? -4 : -12,
          opacity: active ? 1 : 0,
          duration,
          ease: MOTION.ease.settle,
          overwrite: "auto",
        },
        0,
      );
    });
  }, [photo, layers, closing, initialCar]);

  function select(next: Car) {
    if (next.slug === car.slug || closing) return;
    setReady(false);
    onSelect(next);
  }
  const index = cars.findIndex((c) => c.slug === car.slug);
  return (
    <div
      className="car-reveal"
      ref={root}
      role="dialog"
      aria-modal="true"
      aria-labelledby="reveal-title"
      tabIndex={-1}
      data-car-index={index}
      data-photo-active={photo.slug}
      aria-busy={!ready}
      data-reveal-phase={closing ? "return" : ready ? "settled" : "transition"}
    >
      <div className="reveal-surface" ref={surface}>
        <div
          className="reveal-photo-motion"
          style={{ visibility: imageError ? "hidden" : undefined }}
        >
          {layers.map((layer) => {
            const framing = cinematics[layer.slug];
            return (
              <ViewTransition
                key={layer.slug}
                name={"reveal-car-" + layer.slug}
                share="car-morph"
                default="none"
              >
                <div
                  className="reveal-photo-frame"
                  data-photo={layer.slug}
                  style={
                    {
                      opacity: layer.slug === initialCar.slug ? 1 : 0,
                      "--photo-x": framing.target[0] + "%",
                      "--photo-y": framing.target[1] + "%",
                      "--photo-mobile-x": framing.mobileTarget[0] + "%",
                      "--photo-mobile-y": framing.mobileTarget[1] + "%",
                    } as React.CSSProperties
                  }
                >
                  <Image
                    src={layer.image!}
                    alt={layer.brand + " " + layer.model}
                    unoptimized
                    fill
                    sizes="100vw"
                    priority
                  />
                </div>
              </ViewTransition>
            );
          })}
        </div>
        {imageError && (
          <div className="reveal-image-fallback" role="status">
            Anteprima fotografica non disponibile per {car.brand} {car.model}.
          </div>
        )}
        <div className="reveal-shade" />
        <button
          className="close"
          aria-label="Torna alle chiavi"
          onClick={close}
        >
          <X size={22} />
        </button>
        <div className="reveal-content">
          <div className="eyebrow">YOUR KEY. YOUR EXPERIENCE.</div>
          <h2 id="reveal-title">
            {car.brand}
            <br />
            <em>{car.model}</em>
          </h2>
          <p>{car.description}</p>
          <div className="reveal-specs">
            <span>
              {car.power}
              <small>POTENZA</small>
            </span>
            <span>
              {car.acceleration}
              <small>0–100 KM/H</small>
            </span>
            <span>
              €{car.price.toLocaleString("it-IT")}
              <small>/ GIORNO · DEMO</small>
            </span>
          </div>
          <div className="reveal-actions">
            <Link
              href={"/collection/" + car.slug}
              className="button"
              onClick={(e) => {
                if (!ready || closing) {
                  e.preventDefault();
                  return;
                }
                onNavigate();
              }}
              aria-disabled={!ready || closing}
              tabIndex={ready && !closing ? 0 : -1}
            >
              ESPLORA LA VETTURA <ArrowUpRight size={14} />
            </Link>
            <button
              className="text-link"
              onClick={onBook}
              disabled={!ready || closing}
            >
              RICHIEDI NOLEGGIO <ArrowUpRight size={14} />
            </button>
          </div>
        </div>
        <div
          className="reveal-switcher"
          role="group"
          aria-label="Cambia esperienza"
        >
          <button
            className="reveal-step"
            aria-label="Vettura precedente"
            disabled={closing}
            onClick={() => select(cars[(index + 5) % 6])}
          >
            <ArrowLeft size={15} />
          </button>
          {cars.map((c, i) => (
            <button
              data-car-index={i}
              key={c.slug}
              aria-pressed={car.slug === c.slug}
              disabled={closing}
              onClick={() => select(c)}
            >
              <small>0{i + 1}</small>
              {c.model}
            </button>
          ))}
          <button
            className="reveal-step"
            aria-label="Vettura successiva"
            disabled={closing}
            onClick={() => select(cars[(index + 1) % 6])}
          >
            <ArrowRight size={15} />
          </button>
        </div>
      </div>
      <div
        className="reveal-key"
        ref={key}
        data-key={car.slug}
        style={
          { "--key-light": cinematics[car.slug].light } as React.CSSProperties
        }
      >
        <KeyArt car={car} />
      </div>
    </div>
  );
}
