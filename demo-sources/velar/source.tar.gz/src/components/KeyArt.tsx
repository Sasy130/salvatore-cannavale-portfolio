"use client";
import { useState } from "react";
import Image from "next/image";
import type { Car } from "@/data/cars";
import credits from "../../public/keys/credits.json";
export function KeyArt({ car }: { car: Car }) {
  const [failed, setFailed] = useState<string | null>(null);
  const asset = credits.assets.find((item) => item.slug === car.slug);
  return (
    <div className={`key-art key-cutout-frame key-photo-${car.slug}`}>
      {failed === car.slug || !asset ? (
        <div className="key-photo-unavailable" role="img" aria-label={`Foto della chiave ${car.brand} non disponibile`}>
          FOTO NON DISPONIBILE
        </div>
      ) : (
        <Image
          className="key-cutout"
          src={`/demos/velar/keys/${asset.file}`}
          width={600}
          height={800}
          alt={`Chiave realistica rielaborata da foto: ${car.brand} ${car.model}`}
          unoptimized
          loading="eager"
          onError={() => setFailed(car.slug)}
        />
      )}
    </div>
  );
}
