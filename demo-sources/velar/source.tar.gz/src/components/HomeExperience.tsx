"use client";
import {
  useState,
  useEffect,
  useRef,
  useCallback,
  useLayoutEffect,
  useEffectEvent,
} from "react";
import { flushSync } from "react-dom";
import { gsap } from "gsap";
import { useIntroTimeline, useScrollMotion } from "./AnimationController";
import { ArrowRight, ArrowUpRight, ChevronDown, Play } from "lucide-react";
import { cars, Car } from "@/data/cars";
import { useExperience } from "./ExperienceContext";
import { CarReveal, RevealOrigin } from "./CarReveal";
import { KeyArt } from "./KeyArt";
import { MOTION, reducedMotion, safeSession } from "@/lib/motion";
import { measureKey } from "@/lib/camera";
import { cinematics } from "@/data/cinematics";
import { Fleet } from "./Fleet";
export function HomeExperience() {
  const {
    book,
    setState,
    selectedSlug,
    selectCar,
    homeSnapshot: globalSnapshot,
    saveHomeSnapshot,
  } = useExperience();
  const homeSnapshot =
    globalSnapshot?.path && globalSnapshot.path !== "/" ? null : globalSnapshot;
  const selected = cars.find((c) => c.slug === selectedSlug) || cars[0];
  const [filter, setFilter] = useState(homeSnapshot?.filter || "All vehicles");
  const [intro, setIntro] = useState(false);
  const [restoring, setRestoring] = useState(homeSnapshot?.source === "vault");
  const [revealOrigin, setRevealOrigin] = useState<RevealOrigin | null>(
    homeSnapshot?.source === "vault" ? homeSnapshot.revealOrigin || null : null,
  );
  const root = useRef<HTMLElement>(null);
  const vault = useRef<HTMLElement>(null);
  const anchor = useRef<HTMLDivElement>(null);
  const introTL = useRef<gsap.core.Timeline | null>(null);
  const selectionTL = useRef<gsap.core.Timeline | null>(null);
  const finishIntro = useCallback(() => {
    introTL.current?.kill();
    const top = anchor.current?.offsetTop || 0;
    flushSync(() => {
      setIntro(false);
      setState("VAULT_IDLE");
    });
    window.scrollTo({ top, behavior: "instant" });
    safeSession("velar-intro", "seen");
    document.body.classList.remove("intro-running");
  }, [setState]);
  useEffect(() => {
    const reduced = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    const low = (navigator.hardwareConcurrency || 8) <= 2 || innerHeight < 650;
    if (!safeSession("velar-intro") && !homeSnapshot && !reduced && !low) {
      const frame = requestAnimationFrame(() => {
        setIntro(true);
        setState("INTRO");
      });
      return () => cancelAnimationFrame(frame);
    }
  }, [setState, homeSnapshot]);
  const restoreScroll = useEffectEvent(() => {
    const saved = homeSnapshot;
    if (saved) {
      window.scrollTo({ top: saved.y, behavior: "instant" });
      safeSession("velar-intro", "seen");
      const frame = requestAnimationFrame(() =>
        window.scrollTo({ top: saved.y, behavior: "instant" }),
      );
      return () => cancelAnimationFrame(frame);
    }
  });
  useLayoutEffect(() => restoreScroll(), []);
  useIntroTimeline(intro, vault, introTL, finishIntro);
  useScrollMotion(root, intro, setState);
  const restoreFocus = useEffectEvent(() => {
    const saved = homeSnapshot;
    if (saved?.source === "vault") {
      const config = cinematics[saved.selected];
      gsap.set(vault.current?.querySelector(".vault-selection") || [], {
        x: innerWidth < 768 ? config.truck * 0.2 : config.truck,
        y: config.pedestal,
        scale:
          innerWidth < 768
            ? MOTION.camera.mobileFocusScale
            : MOTION.camera.focusScale,
      });
      gsap.set(
        vault.current?.querySelector(
          `[data-key="${saved.selected}"] .key-lift`,
        ) || [],
        { y: -9, scale: 1.045 },
      );
    }
  });
  useLayoutEffect(() => restoreFocus(), []);
  useEffect(
    () => () => {
      selectionTL.current?.kill();
    },
    [],
  );
  function choose(car: Car) {
    selectCar(car.slug);
    setState(revealOrigin ? "CAR_TRANSITION" : "KEY_SELECTED");
    const stage = vault.current?.querySelector(".vault-selection");
    const keys = vault.current?.querySelectorAll<HTMLElement>(".key-choice");
    if (!keys || !stage) return;
    const config = cinematics[car.slug];
    selectionTL.current?.kill();
    const duration = reducedMotion() ? 0 : MOTION.duration.focus;
    const tl = gsap.timeline();
    selectionTL.current = tl;
    tl.to(
      stage,
      {
        x: innerWidth < 768 ? config.truck * 0.2 : config.truck,
        y: config.pedestal,
        scale:
          innerWidth < 768
            ? MOTION.camera.mobileFocusScale
            : MOTION.camera.focusScale,
        duration,
        ease: MOTION.ease.camera,
        overwrite: "auto",
      },
      0,
    );
    keys.forEach((node) => {
      const active = node.dataset.key === car.slug;
      tl.to(
        node.querySelector(".key-lift"),
        {
          y: active ? -9 : 0,
          scale: active ? 1.045 : 1,
          duration,
          ease: MOTION.ease.camera,
          overwrite: "auto",
        },
        0,
      ).to(
        node.querySelector(".key-focus-light"),
        {
          opacity: active ? 0.6 : 0,
          duration,
          ease: MOTION.ease.light,
          overwrite: "auto",
        },
        0,
      );
    });
  }
  function remember(source: "fleet" | "vault", slug = selected.slug) {
    saveHomeSnapshot({
      y: window.scrollY,
      filter,
      selected: slug,
      source,
      path: "/",
      revealOrigin: source === "vault" ? revealOrigin || undefined : undefined,
    });
    selectCar(slug);
    safeSession("velar-intro", "seen");
  }

  function reveal() {
    setRestoring(false);
    selectionTL.current?.kill();
    const node = vault.current?.querySelector(
      `[data-key="${selected.slug}"] .key-art`,
    );
    if (!node) return;
    setRevealOrigin(measureKey(node));
    setState("CAR_TRANSITION");
  }

  return (
    <main ref={root} className={revealOrigin ? "has-reveal" : ""}>
      <section className="hero" id="home">
        <div className="hero-photo" />
        <div className="hero-content">
          <div className="eyebrow">
            EXCEPTIONAL CARS. EXTRAORDINARY MOMENTS.
          </div>
          <h1>
            Some drive.
            <br />
            Others <em>experience.</em>
          </h1>
          <p className="hero-copy">
            Non è solo la destinazione.
            <br />È tutto ciò che senti lungo la strada.
            <br />
            Scegli l’eccezione. Scegli VELAR.
          </p>
          <a className="button" href="#vault">
            EXPLORE THE COLLECTION <ArrowUpRight size={16} />
          </a>
        </div>
        <div className="hero-bottom">
          <p>CURATED FOR THE EXTRAORDINARY</p>
          <div className="hero-model">
            <span>
              FEATURED
              <br />
              EXPERIENCE
            </span>
            <div>
              <strong>Lamborghini Revuelto</strong>
              <span>V12 HYBRID · 1,015 CV · 0–100 IN 2.5 S</span>
            </div>
          </div>
          <a href="#vault" className="hero-index">
            <b>01</b> / 06{" "}
            <ChevronDown
              size={13}
              style={{ marginLeft: 18, verticalAlign: "middle" }}
            />
          </a>
        </div>
      </section>
      <div className="brand-strip">
        <small>
          THE ART OF
          <br />
          EXCEPTIONAL DRIVING
        </small>
        <span>LAMBORGHINI</span>
        <span style={{ fontStyle: "italic" }}>Ferrari</span>
        <span>ROLLS-ROYCE</span>
        <span style={{ fontStyle: "italic" }}>McLaren</span>
        <span>PORSCHE</span>
        <span>AMG</span>
      </div>
      <div className="vault-anchor" ref={anchor}>
        <section
          className={"section vault-section " + (intro ? "is-intro" : "")}
          id="vault"
          ref={vault}
          role={intro ? "dialog" : undefined}
          aria-modal={intro ? true : undefined}
          aria-label={intro ? "Intro cinematografica VELAR" : undefined}
        >
          <div className="vault-top">
            <div className="eyebrow">01 / THE KEY VAULT</div>
            <button
              className="text-link"
              disabled={intro}
              onClick={() => {
                window.scrollTo({
                  top: anchor.current?.offsetTop || 0,
                  behavior: "instant",
                });
                selectCar("296-gtb");
                selectionTL.current?.kill();
                setIntro(true);
                setState("INTRO");
              }}
            >
              <Play size={11} /> REPLAY THE INTRO
            </button>
          </div>
          <div className="vault-caption">
            <h2>VELAR</h2>
            <p>SIX KEYS. SIX EXPERIENCES.</p>
            <small className="key-disclosure">Sagome realistiche · rielaborate da fotografie</small>
          </div>
          <div className="vault-camera">
            <div className="vault-selection">
              <div className="key-table">
                {cars.map((c, i) => (
                  <button
                    type="button"
                    tabIndex={intro ? -1 : 0}
                    data-key={c.slug}
                    style={
                      {
                        order: cinematics[c.slug].keyPosition,
                        "--key-light": cinematics[c.slug].light,
                      } as React.CSSProperties
                    }
                    className={
                      "key-choice " +
                      (selected.slug === c.slug ? "selected" : "")
                    }
                    aria-pressed={selected.slug === c.slug}
                    key={c.slug}
                    onClick={() => choose(c)}
                  >
                    <div className="key-ground" aria-hidden="true" />
                    <div className="key-light" aria-hidden="true" />
                    <div className="key-focus-light" aria-hidden="true" />
                    <div className="key-lift">
                      <KeyArt car={c} />
                    </div>
                    <span>{c.brand}</span>
                    <small>
                      {c.model.toUpperCase()} · 0{i + 1}
                    </small>
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="vault-action">
            <p>
              Una chiave, un mondo da scoprire.
              <br />
              Seleziona la tua prossima esperienza.
            </p>
            <button
              className="button outline"
              disabled={intro}
              onClick={reveal}
            >
              DISCOVER {selected.model} <ArrowUpRight size={14} />
            </button>
          </div>
          {intro && (
            <>
              <button className="skip" onClick={finishIntro}>
                SKIP INTRO <ArrowRight size={15} />
              </button>
              <div className="intro-progress" />
            </>
          )}
        </section>
      </div>
      <Fleet
        filter={filter}
        onFilter={setFilter}
        onNavigate={(slug) => remember("fleet", slug)}
      />
      <section className="section" id="services">
        <div className="section-head">
          <div>
            <div className="eyebrow">03 / BEYOND THE DRIVE</div>
            <h2>
              Every detail.
              <br />
              <em>Considered.</em>
            </h2>
          </div>
          <p>
            Il lusso è la libertà di godersi ogni istante.
            <br />
            Un servizio pensato intorno a te.
          </p>
        </div>
        <div className="services-grid">
          {[
            [
              "01",
              "Un’esperienza personale",
              "Scegli la vettura e raccontaci il tuo itinerario. Il percorso di richiesta raccoglie le tue preferenze in modo semplice e trasparente.",
            ],
            [
              "02",
              "Il tuo punto di partenza",
              "Indica aeroporto, hotel o città di ritiro. Luoghi e modalità di consegna saranno da verificare in una futura offerta reale.",
            ],
            [
              "03",
              "Occasioni straordinarie",
              "Un weekend speciale, un evento o un viaggio da ricordare. Condividi le tue esigenze per comporre un’esperienza su misura.",
            ],
          ].map(([n, t, p]) => (
            <div className="service" key={n}>
              <span>{n} /</span>
              <h3>{t}</h3>
              <p>{p}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="section about" id="about">
        <div>
          <div className="eyebrow">04 / THE VELAR PHILOSOPHY</div>
          <h2>
            For the love
            <br />
            of <em>the exceptional.</em>
          </h2>
        </div>
        <div>
          <p>
            Ci sono auto che si guidano. E auto che cambiano il modo di vivere
            un viaggio. VELAR nasce come progetto dedicato a questa differenza:
            una selezione essenziale, una cura autentica per il design, il
            desiderio di rendere ogni partenza speciale.
          </p>
          <p>
            VELAR è un progetto in sviluppo. La collezione e le tariffe sono
            dimostrative: disponibilità, coperture, requisiti del conducente e
            condizioni di noleggio saranno definiti prima dell’apertura
            commerciale.
          </p>
          <a href="#contact" className="text-link">
            LET’S CREATE YOUR EXPERIENCE <ArrowUpRight size={14} />
          </a>
        </div>
      </section>
      <section className="section contact" id="contact">
        <div>
          <div className="eyebrow">YOUR NEXT CHAPTER</div>
          <h2>Make it extraordinary.</h2>
          <p>La tua prossima esperienza inizia con una scelta.</p>
        </div>
        <button className="button" onClick={() => book()}>
          PLAN YOUR EXPERIENCE <ArrowUpRight size={16} />
        </button>
      </section>

      {revealOrigin && (
        <CarReveal
          car={selected}
          onSelect={choose}
          onNavigate={() => remember("vault")}
          getOrigin={() => {
            const node = vault.current?.querySelector<SVGSVGElement>(
              `[data-key="${selected.slug}"] .key-art`,
            );
            if (!node) return revealOrigin;
            selectionTL.current?.kill();
            return measureKey(node);
          }}
          origin={revealOrigin}
          startSettled={restoring}
          onClose={() => {
            setRevealOrigin(null);
            setRestoring(false);
            if (homeSnapshot?.source === "vault")
              saveHomeSnapshot({ ...homeSnapshot, revealOrigin: undefined });
            setState("VAULT_IDLE");
          }}
          onReady={() => setState("CAR_EXPLORE")}
          onBook={() => book(selected.slug)}
        />
      )}
    </main>
  );
}
