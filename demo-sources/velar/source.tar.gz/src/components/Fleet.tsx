"use client";
import { ViewTransition } from "react";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { cars } from "@/data/cars";
import { useExperience } from "./ExperienceContext";
import { CarImage } from "./CarImage";
const categories = [
  ["All vehicles", "Tutte le vetture"],
  ["Supercars", "Supercar"],
  ["Luxury SUVs", "Luxury SUV"],
  ["Sports cars", "Sportive"],
];
const ordered = [cars.find((c) => c.slug === "296-gtb")!, ...cars.filter((c) => c.slug !== "296-gtb")];
export function Fleet({ filter, onFilter, onNavigate, standalone = false }: {
  filter: string;
  onFilter: (filter: string) => void;
  onNavigate: (slug: string) => void;
  standalone?: boolean;
}) {
  const { book } = useExperience();
  const visible = ordered.filter((c) => filter === "All vehicles" || c.group === filter);
  return (
    <section className="section collection collection-editorial" id={standalone ? "fleet-catalog" : "collection"}>
      <div className="collection-kicker"><span>02 / THE VELAR COLLECTION</span><span>SELEZIONE PRIVATA · 06 ICONE</span></div>
      <div className="collection-heading">
        <h2>Un carattere.<br /><em>Per ogni viaggio.</em></h2>
        <div><p>Dall’emozione di una supercar al comfort di un grande SUV. Scegli la tua idea di straordinario.</p><span className="collection-signature">SIX CARS. ENDLESS POSSIBILITIES.</span></div>
      </div>
      <div className="collection-toolbar">
        <div className="filters" role="group" aria-label="Filtra collezione">
          {categories.map(([value, label]) => <button key={value} className={"filter " + (filter === value ? "selected" : "")} aria-pressed={filter === value} onClick={() => onFilter(value)}>{label}<sup>{value === "All vehicles" ? "06" : String(cars.filter((c) => c.group === value).length).padStart(2,"0")}</sup></button>)}
        </div>
        <span className="collection-count" aria-live="polite">{String(visible.length).padStart(2,"0")} vetture</span>
      </div>
      <div className="fleet-grid">
        {visible.map((c, index) => (
          <article className={"car-card " + (index === 0 || (filter === "All vehicles" && index === 5) ? "car-card-wide" : "")} id={(standalone ? "catalog-" : "card-") + c.slug} key={c.slug}>
            <Link href={"/collection/" + c.slug} className="card-photo" onClick={() => onNavigate(c.slug)} aria-label={"Scopri " + c.brand + " " + c.model}>
              <ViewTransition name={(standalone ? "collection-car-" : "fleet-car-") + c.slug} share="car-morph" default="none">
                <div className="card-image"><CarImage car={c} sizes="(max-width: 760px) 92vw, (max-width: 1100px) 48vw, 60vw" /></div>
              </ViewTransition>
              <span className="card-number">{String(ordered.indexOf(c) + 1).padStart(2,"0")} / {index === 0 ? "IN THE SPOTLIGHT" : "VELAR COLLECTION"}</span>
              <span className="card-arrow"><ArrowUpRight size={20} /></span>
            </Link>
            <div className="card-info">
              <div className="card-category">{c.category}</div>
              <h3><span>{c.brand}</span>{c.model}</h3>
              <p className="card-description">{c.description}</p>
              <dl className="card-specs"><div><dt>Potenza</dt><dd>{c.power}</dd></div><div><dt>0–100 km/h</dt><dd>{c.acceleration}</dd></div><div><dt>Motore</dt><dd>{c.engine.split(" · ")[0]}</dd></div></dl>
              <div className="card-price"><div><small>A PARTIRE DA</small><strong>€{c.price.toLocaleString("it-IT")}</strong><span> / giorno · demo</span></div><button onClick={() => book(c.slug)} aria-label={"Richiedi " + c.brand + " " + c.model}>RICHIEDI <ArrowUpRight size={15} /></button></div>
              <Link className="card-detail-link" href={"/collection/" + c.slug} onClick={() => onNavigate(c.slug)}>Esplora la vettura <ArrowUpRight size={14} /></Link>
            </div>
          </article>
        ))}
      </div>
      <div className="collection-endnote"><span>IL PROSSIMO VIAGGIO COMINCIA DA UNA SCELTA.</span><p>Collezione dimostrativa. Tariffe e disponibilità non costituiscono un’offerta di noleggio.</p></div>
    </section>
  );
}
