"use client";
import { useSearchParams } from "next/navigation";
import { BookingForm } from "./BookingForm";
import { useExperience } from "./ExperienceContext";
import { cars } from "@/data/cars";
export function BookingPageExperience() {
  const params = useSearchParams();
  const { selectedSlug } = useExperience();
  const query = params.get("car");
  const slug = cars.some((c) => c.slug === query) ? query! : selectedSlug;
  const service = params.get("service");
  return (
    <div className="booking-page-panel">
      <BookingForm
        initial={slug}
        initialNote={
          service ? "Informazioni sul servizio dimostrativo: " + service : ""
        }
      />
    </div>
  );
}
