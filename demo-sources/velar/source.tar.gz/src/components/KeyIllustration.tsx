import { useId } from "react";
import type { Car } from "@/data/cars";
export function KeyIllustration({ car }: { car: Car }) {
  const id = "key-" + useId().replace(/[^a-zA-Z0-9_-]/g, "");
  const paths = [
    "M28 5 L66 5 L83 25 L78 128 Q46 151 16 128 L11 25 Z",
    "M26 8 Q47 -2 68 8 L79 27 L74 125 Q48 149 22 125 L17 27 Z",
    "M22 4 H73 Q84 4 84 17 V126 Q84 140 70 140 H25 Q12 140 12 126 V17 Q12 4 22 4",
    "M30 4 L69 14 L82 56 L70 126 Q47 148 22 125 L12 58 Z",
    "M37 3 Q77 8 80 43 L72 129 Q45 145 20 126 L14 44 Q14 16 37 3",
    "M25 7 H72 L86 26 L79 128 L67 139 H28 L14 126 L9 27 Z",
  ];
  return (
    <svg
      className="key-art"
      viewBox="0 0 96 150"
      role="img"
      aria-label={"Illustrazione chiave " + car.brand}
    >
      <defs>
        <linearGradient id={id} x1="0" x2="1" y2=".6">
          <stop stopColor="#d3d4cd" />
          <stop offset=".18" stopColor="#595d56" />
          <stop offset=".42" stopColor="#181b18" />
          <stop offset=".8" stopColor="#777e71" />
          <stop offset="1" stopColor="#c9cdc0" />
        </linearGradient>
        <linearGradient id={id + "b"} x2=".8" y2="1">
          <stop stopColor={car.color} />
          <stop offset=".35" stopColor="#292d28" />
          <stop offset="1" stopColor="#10130f" />
        </linearGradient>
        <linearGradient id={id + "shine"}>
          <stop stopColor="white" stopOpacity="0" />
          <stop offset=".48" stopColor="#f4f3e9" stopOpacity=".8" />
          <stop offset=".52" stopColor="white" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
        <clipPath id={id + "clip"}>
          <path d={paths[car.shape]} />
        </clipPath>
      </defs>
      <path
        d={paths[car.shape]}
        fill={"url(#" + id + ")"}
        stroke="#919a85"
        strokeWidth=".8"
      />
      <path
        d={paths[car.shape]}
        fill={"url(#" + id + "b)"}
        transform="translate(8 9) scale(.83 .86)"
      />
      <path
        d="M29 20 Q47 12 65 23"
        fill="none"
        stroke="#dee4d1"
        strokeOpacity=".4"
      />
      <g clipPath={"url(#" + id + "clip)"}>
        <rect
          className="key-sheen"
          x="20"
          y="0"
          width="32"
          height="150"
          fill={"url(#" + id + "shine)"}
          opacity="0"
          transform="skewX(-18)"
        />
      </g>
      <path
        d="M23 27 L27 121 M25 28 L29 120 M27 29 L31 119"
        stroke="#eff0e1"
        strokeOpacity=".07"
        strokeWidth=".4"
      />
      <text
        x="48"
        y="48"
        textAnchor="middle"
        fill={car.color}
        fontSize={car.brand === "Rolls-Royce" ? 18 : 10}
        fontFamily="serif"
        fontWeight="bold"
      >
        {["L", "F", "RR", "M", "P", "✦"][car.shape]}
      </text>
      <rect
        className="key-unlock"
        x="29"
        y="65"
        width="38"
        height="23"
        rx={car.shape === 2 ? 0 : 6}
        fill="#252b22"
        stroke="#5b6552"
        strokeWidth=".5"
      />
      <path
        d="M44 75 v-4 a4 4 0 0 1 8 0 v4 M42 75 h12 v8 H42z"
        fill="none"
        stroke="#aeb7a2"
        strokeWidth="1.3"
      />
      <path d="M35 102 h26 M39 110 h18" stroke="#737d67" strokeWidth="1" />
      <ellipse cx="47" cy="129" rx="9" ry="3" fill="#070a07" stroke="#666e5b" />
    </svg>
  );
}
