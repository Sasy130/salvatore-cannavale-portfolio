"use client";
import { useState, useLayoutEffect, useEffectEvent } from "react";
import { Fleet } from "./Fleet";
import { useExperience } from "./ExperienceContext";
import { safeSession } from "@/lib/motion";
export function CollectionExperience() {
  const { homeSnapshot, saveHomeSnapshot, selectCar } = useExperience();
  const snapshot = homeSnapshot?.path === "/collection" ? homeSnapshot : null;
  const [filter, setFilter] = useState(snapshot?.filter || "All vehicles");
  const restore = useEffectEvent(() => {
    if (snapshot) {
      window.scrollTo({ top: snapshot.y, behavior: "instant" });
      const id = requestAnimationFrame(() =>
        window.scrollTo({ top: snapshot.y, behavior: "instant" }),
      );
      return () => cancelAnimationFrame(id);
    }
  });
  useLayoutEffect(() => restore(), []);
  return (
    <Fleet
      standalone
      filter={filter}
      onFilter={setFilter}
      onNavigate={(slug) => {
        saveHomeSnapshot({
          y: scrollY,
          filter,
          selected: slug,
          source: "fleet",
          path: "/collection",
        });
        selectCar(slug);
        safeSession("velar-intro", "seen");
      }}
    />
  );
}
