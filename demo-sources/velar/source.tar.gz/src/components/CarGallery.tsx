"use client";
import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight, Expand, X } from "lucide-react";
import type { Car } from "@/data/cars";
import { galleries } from "@/data/galleries";
export function CarGallery({ car }: { car: Car }) {
  const [group, setGroup] = useState<"exterior" | "interior">("exterior");
  const [index, setIndex] = useState(0);
  const [open, setOpen] = useState(false);
  const modal = useRef<HTMLDivElement>(null);
  const photos = galleries[car.slug][group];
  const active = photos[index];
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement,
      overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    modal.current?.focus();
    const keyboard = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
      if (e.key === "ArrowRight") setIndex((i) => (i + 1) % photos.length);
      if (e.key === "ArrowLeft")
        setIndex((i) => (i + photos.length - 1) % photos.length);
      if (e.key === "Tab") {
        const nodes = modal.current?.querySelectorAll<HTMLButtonElement>(
          "button:not(:disabled)",
        );
        if (!nodes?.length) return;
        const first = nodes[0],
          last = nodes[nodes.length - 1];
        if (
          e.shiftKey &&
          (document.activeElement === first ||
            document.activeElement === modal.current)
        ) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", keyboard);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", keyboard);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, [open, photos.length]);
  return (
    <section
      className="car-gallery"
      aria-label={"Galleria " + car.brand + " " + car.model}
    >
      <div className="section-head">
        <div>
          <div className="eyebrow">THE DETAILS</div>
          <h2>Explore the experience.</h2>
        </div>
        <div
          className="gallery-tabs"
          role="group"
          aria-label="Tipo di fotografie"
        >
          {(["exterior", "interior"] as const).map((value) => (
            <button
              key={value}
              className={group === value ? "selected" : ""}
              aria-pressed={group === value}
              onClick={() => {
                setGroup(value);
                setIndex(0);
              }}
            >
              {value === "exterior" ? "ESTERNI" : "INTERNI"}{" "}
              <span>
                {galleries[car.slug][value].length.toString().padStart(2, "0")}
              </span>
            </button>
          ))}
        </div>
      </div>
      {active ? (
        <>
          <button
            className="gallery-main"
            onClick={() => setOpen(true)}
            aria-label={"Ingrandisci: " + active.alt}
          >
            <Image
              key={active.src}
              src={active.src}
              alt={active.alt}
              fill
              sizes="90vw"
            />
            <span>
              <Expand size={16} /> ESPLORA A SCHERMO INTERO
            </span>
          </button>
          <div className="gallery-caption">
            <p>{active.caption}</p>
            <span>
              {index + 1} / {photos.length}
            </span>
          </div>
          <div className="gallery-thumbs">
            {photos.map((photo, i) => (
              <button
                key={photo.src}
                onClick={() => setIndex(i)}
                aria-pressed={i === index}
                aria-label={"Mostra foto " + (i + 1) + ": " + photo.caption}
              >
                <Image src={photo.src} alt="" fill sizes="120px" />
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className="gallery-empty">
          <span>INTERIOR EXPERIENCE</span>
          <h3>Uno spazio da scoprire.</h3>
          <p>
            Fotografie degli interni di {car.brand} {car.model} non disponibili
            in questa demo. Per la versione commerciale serve un set autorizzato
            e verificato di questo modello.
          </p>
          <Link href="/credits" className="text-link">
            FONTI E ASSET <ArrowRight size={14} />
          </Link>
        </div>
      )}
      {open && active && (
        <div
          className="gallery-lightbox"
          ref={modal}
          role="dialog"
          aria-modal="true"
          aria-label={"Fotografia " + (index + 1) + " di " + photos.length}
          tabIndex={-1}
        >
          <button
            className="close"
            aria-label="Chiudi fotografia"
            onClick={() => setOpen(false)}
          >
            <X size={24} />
          </button>
          <div className="lightbox-photo">
            <Image
              src={active.src}
              alt={active.alt}
              fill
              sizes="100vw"
              priority
            />
          </div>
          <div className="lightbox-controls">
            <button
              aria-label="Fotografia precedente"
              disabled={photos.length < 2}
              onClick={() =>
                setIndex((i) => (i + photos.length - 1) % photos.length)
              }
            >
              <ArrowLeft size={18} />
            </button>
            <p>
              {active.caption}
              <small>
                {index + 1} / {photos.length}
              </small>
            </p>
            <button
              aria-label="Fotografia successiva"
              disabled={photos.length < 2}
              onClick={() => setIndex((i) => (i + 1) % photos.length)}
            >
              <ArrowRight size={18} />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
