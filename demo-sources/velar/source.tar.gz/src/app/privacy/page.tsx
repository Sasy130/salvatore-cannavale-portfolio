import { PageIntro } from "@/components/PageIntro";
import Link from "next/link";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Privacy — VELAR",
  robots: { index: false, follow: true },
  description:
    "Informativa dimostrativa sul trattamento dei dati del progetto VELAR.",
};
export default function PrivacyPage() {
  return (
    <main>
      <PageIntro
        eyebrow="PRIVACY · DEMO"
        title="Your data. With clarity."
        description="Informativa dimostrativa riferita alle funzionalità effettive di questo progetto. Da completare e sottoporre a verifica prima di un uso commerciale."
      />
      <article className="section legal-copy">
        <h2>1. Ambito e titolare</h2>
        <p>
          VELAR è un concept di sito di autonoleggio. Titolare del trattamento,
          ragione sociale, indirizzo, recapiti e referente privacy non sono
          stati forniti: questa informativa non sostituisce l’informativa di
          un’attività reale.
        </p>
        <h2>2. Modulo dimostrativo</h2>
        <p>
          Il modulo utilizza vettura, date, orari, località, nome, email,
          telefono e note esclusivamente nella memoria della pagina per comporre
          un riepilogo locale. Non invia questi dati a un backend, non li salva
          in un database né nella sessionStorage. Alla chiusura del modulo o
          della pagina i dati non sono conservati dall’applicazione. Non
          inserire informazioni sensibili, documenti o dati di pagamento.
        </p>
        <h2>3. Riepilogo scaricabile</h2>
        <p>
          Se scegli di scaricare il riepilogo, viene generato un file sul tuo
          dispositivo. La sua conservazione e cancellazione dipendono da te e
          dalle impostazioni del dispositivo. Non è una richiesta inviata né una
          prenotazione confermata.
        </p>
        <h2>4. Preferenze di navigazione</h2>
        <p>
          La sessionStorage registra soltanto lo stato dell’intro e lo slug
          della vettura selezionata. Questi dati non identificano direttamente
          una persona, non vengono inviati dal progetto e normalmente scadono
          con la sessione della scheda. La pagina Cookies descrive questi
          strumenti.
        </p>
        <h2>5. Hosting e risorse</h2>
        <p>
          Font e fotografie sono serviti insieme al sito, senza richieste a
          Google Fonts, tracker, mappe o video incorporati. Il fornitore di
          hosting può trattare indirizzo IP, richieste HTTP e log tecnici per
          consegna, sicurezza e funzionamento del sito, secondo le proprie
          condizioni. Questa informativa dovrà indicare gestore, ruoli,
          localizzazione, tempi di conservazione e garanzie applicabili prima
          dell’uso commerciale.
        </p>
        <h2>6. Uso commerciale futuro</h2>
        <p>
          Prima di attivare un invio reale occorre definire titolare, finalità,
          base giuridica, destinatari e responsabili, tempi di conservazione,
          eventuali trasferimenti e modalità per esercitare accesso, rettifica,
          cancellazione, limitazione, opposizione e reclamo all’autorità
          competente. Nessun consenso marketing viene raccolto in questa demo.
        </p>
        <Link className="text-link" href="/cookies">
          COOKIE E MEMORIZZAZIONE LOCALE →
        </Link>
      </article>
    </main>
  );
}
