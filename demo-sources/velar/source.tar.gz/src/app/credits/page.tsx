import credits from "../../../public/cars/credits.json";
import Link from "next/link";
import keyCredits from "../../../public/keys/credits.json";
function plain(value: string) {
  return value
    .replace(/<[^>]*>/g, " ")
    .replace(/&[^;]+;/g, " ")
    .trim();
}
export default function Credits() {
  return (
    <main className="section detail">
      <Link href="/" className="text-link">
        ← HOME
      </Link>
      <div className="eyebrow" style={{ marginTop: 35 }}>
        PROJECT TRANSPARENCY
      </div>
      <h2>Asset, fonti e licenze.</h2>
      <p className="asset-note">
        VELAR è un concept funzionante. Le vetture non rappresentano una flotta
        effettivamente disponibile. Fotografie da Wikimedia Commons, mantenute
        localmente per affidabilità. Le fotografie sono state ridimensionate e
        compresse in WebP; nell’interfaccia possono essere ritagliate e
        desaturate tramite CSS. Loghi testuali e nomi dei costruttori
        identificano i modelli e non implicano affiliazione. Le sei chiavi sono immagini rielaborate con AI da fotografie di prodotto provenienti dalle fonti
        indicate qui sotto, isolate su fondo trasparente e uniformate nella luce. Non sono riproduzioni OEM certificate. Gli abbinamenti seguono le descrizioni dei venditori;
        finiture, pulsanti e versioni possono variare per anno e mercato.
        Le fotografie non documentano le chiavi di una flotta VELAR. Sono disponibili interni Revuelto
        e viste parziali dell’abitacolo Cullinan. Gli altri interni richiedono
        asset autorizzati.
      </p>
      <h3 style={{ marginTop: 35 }}>Riferimenti fotografici delle chiavi</h3>
      <ul className="asset-list">
        {keyCredits.assets.map((c) => (
          <li key={c.slug}><strong>{c.slug}</strong><br />{c.credit}<br />
            <a href={c.source} target="_blank" rel="noreferrer">Fonte della fotografia ↗</a>
          </li>
        ))}
      </ul>
      <h3 style={{ marginTop: 35 }}>Fotografie delle vetture</h3>
      <ul className="asset-list" style={{ marginTop: 35 }}>
        {credits.map((c) => (
          <li key={c.slug}>
            <strong>{c.file}</strong>
            <br />
            Autore: {plain(c.metadata.Artist?.value || "Vedi fonte originale")}
            <br />
            Licenza: {plain(
              c.metadata.LicenseShortName?.value || "Vedi fonte",
            )}{" "}
            ·{" "}
            <a
              href={c.metadata.LicenseUrl?.value || c.url}
              target="_blank"
              rel="noreferrer"
            >
              Condizioni ↗
            </a>
            <br />
            <a href={c.url} target="_blank" rel="noreferrer">
              Pagina originale e attribuzione completa ↗
            </a>
          </li>
        ))}
      </ul>
      <p className="asset-note">
        I dati tecnici si riferiscono ai modelli di serie: Revuelto, 296 GTB,
        Cullinan prima serie, 750S coupé, 911 GT3 RS (992), G 63 (2018). Fonti
        dei costruttori nelle schede. Le tariffe sono esempi editoriali, non
        preventivi. Contatti aziendali, WhatsApp, invio email, pagamenti e
        prenotazioni reali non sono configurati.
      </p>
      <div className="asset-note">
        Font serviti localmente: DM Sans e Manrope, distribuiti con SIL Open
        Font License 1.1. <a href="/demos/velar/fonts/dmsans-OFL.txt">Licenza DM Sans</a> ·{" "}
        <a href="/demos/velar/fonts/manrope-OFL.txt">Licenza Manrope</a>. Nessuna richiesta
        a Google Fonts durante la navigazione.
      </div>
    </main>
  );
}
