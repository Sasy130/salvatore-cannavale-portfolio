import { Suspense } from "react";
import { PageIntro } from "@/components/PageIntro";
import { BookingPageExperience } from "@/components/BookingPageExperience";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Request Booking — VELAR",
  description:
    "Prepara una richiesta dimostrativa VELAR con vettura, date, orari e località. Nessun invio o pagamento reale.",
};
export default function BookingPage() {
  return (
    <main>
      <PageIntro
        eyebrow="REQUEST BOOKING"
        title="Your next chapter."
        description="Un viaggio speciale inizia dai dettagli. Prepara una richiesta dimostrativa: nessun pagamento, nessuna disponibilità o prenotazione confermata."
      />
      <section className="section booking-page">
        <Suspense
          fallback={<div className="asset-note">Preparazione modulo…</div>}
        >
          <BookingPageExperience />
        </Suspense>
        <aside>
          <div className="eyebrow">BEFORE YOU BEGIN</div>
          <h2>
            Chiarezza,
            <br />
            in ogni dettaglio.
          </h2>
          <p>
            Questa demo non dispone di un servizio di invio. Il riepilogo viene
            elaborato nel browser e può essere scaricato o modificato.
          </p>
          <dl className="rental-terms">
            <div>
              <dt>Tariffe</dt>
              <dd>
                Dimostrative, per giorno. Totale da definire in un’offerta
                reale.
              </dd>
            </div>
            <div>
              <dt>Deposito e coperture</dt>
              <dd>Importi, franchigie e condizioni non configurati.</dd>
            </div>
            <div>
              <dt>Chilometraggio</dt>
              <dd>
                Inclusioni e costi extra da concordare. Nessun limite fittizio
                applicato.
              </dd>
            </div>
            <div>
              <dt>Dati personali</dt>
              <dd>
                Nessun documento o pagamento richiesto. I dati del modulo non
                sono trasmessi.
              </dd>
            </div>
          </dl>
        </aside>
      </section>
    </main>
  );
}
