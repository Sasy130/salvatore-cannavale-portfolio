import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { PageIntro } from "@/components/PageIntro";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "About — VELAR",
  description:
    "La filosofia VELAR: una selezione essenziale, design automotive e trasparenza. Progetto dimostrativo, senza affiliazioni con i costruttori.",
};
export default function AboutPage() {
  return (
    <main>
      <PageIntro
        eyebrow="THE VELAR PHILOSOPHY"
        title="For the exceptional."
        description="Ci sono auto che portano a destinazione. E auto che danno un significato diverso a ogni chilometro. VELAR esplora questa differenza."
      />
      <div className="about-editorial-image">
        <Image
          src="/demos/velar/cars/hero-exterior.webp"
          alt="Lamborghini Revuelto Opera Unica — carrozzeria e dettagli"
          fill
          sizes="100vw"
          priority
        />
        <span>SIX KEYS. SIX EXPERIENCES.</span>
      </div>
      <section className="section editorial-columns">
        <div>
          <div className="eyebrow">OUR POINT OF VIEW</div>
          <h2>
            Una selezione.
            <br />
            Un’intenzione.
          </h2>
        </div>
        <div>
          <p>
            Il progetto nasce intorno a sei vetture e a un gesto: scegliere una
            chiave. Un modo essenziale e personale di avvicinarsi al mondo delle
            supercar e dei SUV di lusso.
          </p>
          <p>
            La direzione è contemporanea: spazio, luce controllata, materiali
            scuri e un ritmo visivo che lascia respirare il contenuto.
            L’esperienza deve essere memorabile, ma anche chiara e utilizzabile.
          </p>
          <p>
            VELAR è una demo commerciale. Non vengono dichiarati una storia
            aziendale, una flotta disponibile, sedi, recensioni o collaborazioni
            che non siano state documentate. I nomi dei costruttori identificano
            i modelli; non implicano affiliazione.
          </p>
          <Link href="/collection" className="text-link">
            EXPLORE THE COLLECTION <ArrowUpRight size={15} />
          </Link>
        </div>
      </section>
      <section className="section principles">
        {[
          [
            "Selection",
            "Sei icone, scelte per carattere e identità. Una collezione essenziale, senza riempitivi.",
          ],
          [
            "Experience",
            "Una regia cinematografica al servizio della scoperta, con percorsi semplici verso ogni vettura.",
          ],
          [
            "Transparency",
            "Prezzi dimostrativi, asset attribuiti e condizioni da definire dichiarate in ogni richiesta.",
          ],
        ].map(([title, copy], i) => (
          <article key={title}>
            <small>0{i + 1}</small>
            <h3>{title}</h3>
            <p>{copy}</p>
          </article>
        ))}
      </section>
    </main>
  );
}
