import type { Metadata } from "next";
import "./globals.css";
import "./motion.css";
import "./phase3.css";
import site from "@/data/site.json";
import { MOTION } from "@/lib/motion";
import { SiteShell } from "@/components/Experience";
export const metadata: Metadata = {
  metadataBase: new URL(site.origin),
  title: "VELAR — Exotic Car Rental",
  openGraph: {
    title: "VELAR — Exotic Car Rental",
    description: "Six keys. Six experiences. Un concept automotive di lusso.",
    siteName: "VELAR",
    locale: "it_IT",
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "VELAR — Exotic Car Rental" },
  description:
    "Six keys. Six experiences. Scopri la collezione VELAR di supercar e SUV di lusso. Progetto dimostrativo.",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="it" data-scroll-behavior="smooth">
      <head>
        <link
          rel="preload"
          href="/demos/velar/fonts/dm-sans-latin.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <link
          rel="preload"
          href="/demos/velar/fonts/manrope-latin.woff2"
          as="font"
          type="font/woff2"
          crossOrigin="anonymous"
        />
        <link rel="preload" href="/demos/velar/cars/hero-exterior.webp" as="image" />
        <link rel="preload" href="/demos/velar/keys/revuelto-cutout.webp" as="image" />
      </head>
      <body
        style={
          {
            "--motion-route": MOTION.duration.route + "s",
          } as React.CSSProperties
        }
      >
        <SiteShell>{children}</SiteShell>
      </body>
    </html>
  );
}
