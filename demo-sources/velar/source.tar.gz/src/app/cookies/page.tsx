import { PageIntro } from "@/components/PageIntro";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Cookies — VELAR",
  robots: { index: false, follow: true },
  description:
    "Strumenti effettivi del progetto: preferenze di sessione, risorse locali e nessun tracker marketing.",
};
export default function CookiesPage() {
  return (
    <main>
      <PageIntro
        eyebrow="COOKIES & STORAGE"
        title="Only what is needed."
        description="Una descrizione concreta degli strumenti usati dalla demo. Nessun sistema di analisi, profilazione o marketing è integrato nel codice del progetto."
      />
      <article className="section legal-copy">
        <h2>Memorizzazione di sessione</h2>
        <p>
          Il progetto non imposta cookie applicativi. Utilizza sessionStorage,
          separata dai cookie, per due preferenze funzionali:
        </p>
        <div className="storage-table">
          <div>
            <strong>velar-intro</strong>
            <span>
              Ricorda che l’intro è già stata vista nella sessione della scheda.
            </span>
          </div>
          <div>
            <strong>velar-selected</strong>
            <span>
              Ricorda lo slug della vettura selezionata nella stessa sessione.
            </span>
          </div>
        </div>
        <p>
          I dati del modulo di richiesta non vengono memorizzati in questi
          strumenti. Filtri, posizione di scroll e scena sono mantenuti solo
          nello stato dell’interfaccia durante la navigazione.
        </p>
        <h2>Risorse e terze parti</h2>
        <p>
          Font e immagini sono ospitati localmente con il sito. Non sono
          integrati analytics, pixel pubblicitari, mappe, chat esterne, video o
          pagamenti. I collegamenti ai costruttori e alle fonti fotografiche
          aprono siti esterni solo quando li selezioni; le loro informative si
          applicano dopo l’apertura.
        </p>
        <h2>Gestire le preferenze</h2>
        <p>
          Puoi rivedere l’intro dal Key Vault e cambiare vettura in qualsiasi
          momento. La chiusura della sessione della scheda normalmente elimina
          la sessionStorage; puoi anche rimuovere i dati del sito dalle
          impostazioni del browser.
        </p>
        <h2>Hosting</h2>
        <p>
          Eventuali cookie o strumenti imposti dal fornitore di hosting per
          sicurezza o accesso devono essere valutati secondo la sua
          documentazione. Questa pagina descrive il codice applicativo VELAR;
          dovrà essere aggiornata se saranno aggiunti strumenti o servizi reali.
          Non viene mostrato un banner marketing privo di strumenti da gestire.
        </p>
      </article>
    </main>
  );
}
