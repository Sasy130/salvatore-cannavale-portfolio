export const dynamicParams = false;
import { Suspense } from "react";
import { cars } from "@/data/cars";
import { DetailExperience } from "@/components/Experience";
import site from "@/data/site.json";
import { notFound } from "next/navigation";
export function generateStaticParams() {
  return cars.map((c) => ({ slug: c.slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const c = cars.find((c) => c.slug === slug);
  return {
    title: c ? `${c.brand} ${c.model} — VELAR` : "Vettura non trovata — VELAR",
    description: c
      ? c.description + " Tariffa giornaliera esclusivamente dimostrativa."
      : undefined,
    alternates: {
      canonical: new URL("/collection/" + slug + "/", site.origin).href,
    },
    openGraph: c
      ? {
          title: `${c.brand} ${c.model} — VELAR`,
          description: c.description,
          images: [
            { url: "/demos/velar/cars/" + slug + ".jpg", alt: c.brand + " " + c.model },
          ],
        }
      : undefined,
  };
}
async function CarContent({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return <CachedCar slug={slug} />;
}
async function CachedCar({ slug }: { slug: string }) {
  const car = cars.find((c) => c.slug === slug);
  if (!car) notFound();
  return <DetailExperience car={car} />;
}

export default function CarPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  return (
    <Suspense
      fallback={
        <main
          className="section detail"
          aria-busy="true"
          aria-label="Caricamento vettura"
        >
          <div className="eyebrow">VELAR COLLECTION</div>
          <h1>
            Your next
            <br />
            experience.
          </h1>
          <div className="detail-hero detail-loading" />
        </main>
      }
    >
      <CarContent params={params} />
    </Suspense>
  );
}
