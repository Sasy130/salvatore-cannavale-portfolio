import { PageIntro } from "@/components/PageIntro";
import { CollectionExperience } from "@/components/CollectionExperience";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Collection — VELAR",
  description:
    "Sei icone automotive. Esplora supercar e SUV della collezione dimostrativa VELAR.",
};
export default function CollectionPage() {
  return (
    <main>
      <PageIntro
        eyebrow="THE COLLECTION"
        title="Choose your exception."
        description="Sei icone. Sei interpretazioni del viaggio. Fotografie autentiche, caratteristiche del modello e richieste dimostrative, in una collezione essenziale."
      />
      <CollectionExperience />
    </main>
  );
}
