import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { PageIntro } from "@/components/PageIntro";
import { services } from "@/data/services";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Services — VELAR",
  description:
    "Luxury rental, chauffeur, airport transfer, wedding, eventi e corporate: concept di servizi VELAR da confermare.",
};
export default function ServicesPage() {
  return (
    <main>
      <PageIntro
        eyebrow="BEYOND THE DRIVE"
        title="A finer way to travel."
        description="Sei concept di servizio, una sola attenzione al dettaglio. Tutte le esperienze illustrate sono dimostrative e non rappresentano servizi aziendali già disponibili."
      />
      <section className="section service-catalog">
        {services.map((service, i) => (
          <article className="service-card" key={service.slug}>
            <div className="service-image">
              <Image
                src={service.image}
                alt={service.alt}
                fill
                sizes="(max-width:700px) 90vw,45vw"
              />
              <span>0{i + 1} / VELAR EXPERIENCES</span>
            </div>
            <div className="service-content">
              <small>CONCEPT · DA CONFERMARE</small>
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <ul>
                {service.features.map((feature) => (
                  <li key={feature}>{feature}</li>
                ))}
              </ul>
              <Link
                href={"/booking?service=" + encodeURIComponent(service.title)}
                className="text-link"
              >
                RICHIEDI INFORMAZIONI DEMO <ArrowUpRight size={15} />
              </Link>
            </div>
          </article>
        ))}
      </section>
      <div className="section service-disclaimer">
        Le fotografie identificano vetture della collezione e sono illustrative
        dei concept. Non costituiscono prova di servizi, autisti o sedi
        operative. Nessuna richiesta viene inviata dall’attuale demo.
      </div>
    </main>
  );
}
