export const dynamic = "force-static";
import type { MetadataRoute } from "next";
import site from "@/data/site.json";
import { cars } from "@/data/cars";
export default function sitemap(): MetadataRoute.Sitemap {
  return [
    "",
    "/collection",
    "/services",
    "/about",
    "/contact",
    "/booking",
    ...cars.map((c) => "/collection/" + c.slug),
  ].map((path) => ({
    url: site.origin + path + "/",
    changeFrequency: "monthly" as const,
    priority: path === "" ? 1 : path.startsWith("/collection/") ? 0.8 : 0.6,
  }));
}
