import Link from "next/link";
import { ArrowRight } from "lucide-react";
export default function NotFound() {
  return (
    <main className="section not-found">
      <div className="eyebrow">VELAR / 404</div>
      <span className="error-number" aria-hidden="true">
        404
      </span>
      <h1>A different road.</h1>
      <p>
        Questa pagina non è nella collezione.
        <br />
        Scegli una nuova direzione.
      </p>
      <div className="summary-actions">
        <Link className="button" href="/collection">
          ESPLORA LA COLLEZIONE <ArrowRight size={15} />
        </Link>
        <Link href="/" className="text-link">
          TORNA ALLA HOME →
        </Link>
      </div>
    </main>
  );
}
