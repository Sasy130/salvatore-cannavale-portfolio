export const dynamic = "force-static";
import type { MetadataRoute } from "next";
import site from "@/data/site.json";
export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/privacy/", "/cookies/"] },
    sitemap: site.origin + "/sitemap.xml",
  };
}
