import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { PageIntro } from "@/components/PageIntro";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Contact — VELAR",
  description:
    "Informazioni e richiesta dimostrativa VELAR. Contatti aziendali e canali di invio non ancora configurati.",
};
export default function ContactPage() {
  return (
    <main>
      <PageIntro
        eyebrow="CONTACT"
        title="Let’s make it personal."
        description="Racconta l’esperienza che immagini. In questa demo puoi preparare un brief completo; i canali di contatto reali saranno aggiunti soltanto dopo la verifica dei dati aziendali."
      />
      <section className="section contact-layout">
        <div className="contact-panel">
          <div className="eyebrow">YOUR NEXT EXPERIENCE</div>
          <h2>
            Il primo passo
            <br />è una scelta.
          </h2>
          <p>
            Seleziona una vettura, indica date e località e prepara il
            riepilogo. Il modulo lavora nel tuo browser: nessun messaggio sarà
            inviato.
          </p>
          <Link className="button" href="/booking">
            PREPARA UNA RICHIESTA DEMO <ArrowUpRight size={15} />
          </Link>
          <dl className="rental-terms">
            <div>
              <dt>Email e telefono</dt>
              <dd>Recapiti aziendali non configurati.</dd>
            </div>
            <div>
              <dt>WhatsApp</dt>
              <dd>Canale non attivo in questa demo.</dd>
            </div>
            <div>
              <dt>Sede e orari</dt>
              <dd>Dati da verificare prima dell’apertura commerciale.</dd>
            </div>
          </dl>
        </div>
        <div className="faq">
          <div className="eyebrow">GOOD TO KNOW</div>
          <h2>
            Ogni dettaglio,
            <br />
            più chiaro.
          </h2>
          {[
            [
              "Posso confermare un noleggio?",
              "No. Questa demo prepara un riepilogo locale, senza invio, pagamento o verifica della disponibilità.",
            ],
            [
              "Le tariffe sono definitive?",
              "No. Sono esempi giornalieri dimostrativi. Totale, deposito, chilometraggio e coperture richiedono condizioni commerciali reali.",
            ],
            [
              "Dove posso ritirare la vettura?",
              "Puoi indicare una località preferita nel modulo. Non sono ancora dichiarate sedi o aree operative disponibili.",
            ],
            [
              "Sono disponibili autisti o transfer?",
              "Le pagine Services presentano concept. Disponibilità, abilitazioni e organizzazione devono essere confermate da un’azienda reale.",
            ],
            [
              "Dove vanno i dati del modulo?",
              "Restano nella memoria della pagina. Puoi scaricare un riepilogo sul tuo dispositivo. Non vengono inviati a un server da questo progetto.",
            ],
          ].map(([question, answer]) => (
            <details key={question}>
              <summary>{question}</summary>
              <p>{answer}</p>
            </details>
          ))}
        </div>
      </section>
    </main>
  );
}
