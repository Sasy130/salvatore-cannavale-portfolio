export type Car = {
  slug: string;
  brand: string;
  model: string;
  category: string;
  group: string;
  power: string;
  acceleration: string;
  speed: string;
  engine: string;
  price: number;
  description: string;
  image?: string;
  color: string;
  shape: number;
  source: string;
};
export const cars: Car[] = [
  {
    slug: "revuelto",
    brand: "Lamborghini",
    model: "Revuelto",
    category: "HYBRID SUPERCAR",
    group: "Supercars",
    power: "1,015 CV",
    acceleration: "2.5 s",
    speed: ">350 km/h",
    engine: "6.5L V12 · PHEV",
    price: 1800,
    description:
      "Un V12 aspirato, tre motori elettrici e un carattere inconfondibile. La nuova espressione del coraggio Lamborghini, per un’esperienza che resta.",
    image: "/demos/velar/cars/revuelto.webp",
    color: "#b9c497",
    shape: 0,
    source: "https://www.lamborghini.com/en-en/models/revuelto",
  },
  {
    slug: "296-gtb",
    brand: "Ferrari",
    model: "296 GTB",
    category: "HYBRID BERLINETTA",
    group: "Supercars",
    power: "830 CV",
    acceleration: "2.9 s",
    speed: ">330 km/h",
    engine: "3.0L V6 · PHEV",
    price: 1400,
    description:
      "Compatta, essenziale, straordinariamente reattiva. La 296 GTB unisce il suono del V6 alla risposta elettrica, nell’interpretazione più contemporanea del piacere di guida Ferrari.",
    image: "/demos/velar/cars/296-gtb.webp",
    color: "#a72c2d",
    shape: 1,
    source: "https://www.ferrari.com/en-EN/auto/296-gtb",
  },
  {
    slug: "cullinan",
    brand: "Rolls-Royce",
    model: "Cullinan",
    category: "ULTRA-LUXURY SUV",
    group: "Luxury SUVs",
    power: "571 CV",
    acceleration: "5.2 s",
    speed: "250 km/h",
    engine: "6.75L V12",
    price: 1600,
    description:
      "Il viaggio diventa uno spazio personale. Un abitacolo silenzioso, una presenza autorevole e il comfort distintivo Rolls-Royce.",
    image: "/demos/velar/cars/cullinan.webp",
    color: "#a5a8aa",
    shape: 2,
    source: "https://www.rolls-roycemotorcars.com/en_GB/showroom/cullinan.html",
  },
  {
    slug: "750s",
    brand: "McLaren",
    model: "750S",
    category: "LIGHTWEIGHT SUPERCAR",
    group: "Supercars",
    power: "750 CV",
    acceleration: "2.8 s",
    speed: "332 km/h",
    engine: "4.0L V8 twin-turbo",
    price: 1500,
    description:
      "Leggerezza, precisione e una connessione immediata con la strada. Una supercar costruita intorno alle sensazioni del guidatore.",
    image: "/demos/velar/cars/750s.webp",
    color: "#dba061",
    shape: 3,
    source: "https://cars.mclaren.com/en/750s",
  },
  {
    slug: "911-gt3-rs",
    brand: "Porsche",
    model: "911 GT3 RS",
    category: "TRACK-INSPIRED SPORTS CAR",
    group: "Sports cars",
    power: "525 CV",
    acceleration: "3.2 s",
    speed: "296 km/h",
    engine: "4.0L flat-six",
    price: 1100,
    description:
      "Aerodinamica attiva e un sei cilindri aspirato da 9.000 giri. La precisione Porsche nella sua forma più intensa. Utilizzo in pista escluso dalla richiesta dimostrativa.",
    image: "/demos/velar/cars/911-gt3-rs.webp",
    color: "#c9cdca",
    shape: 4,
    source: "https://www.porsche.com/international/models/911/911-gt3-rs/",
  },
  {
    slug: "g63",
    brand: "Mercedes-AMG",
    model: "G 63",
    category: "PERFORMANCE SUV",
    group: "Luxury SUVs",
    power: "585 CV",
    acceleration: "4.5 s",
    speed: "220 km/h",
    engine: "4.0L V8 · modello 2018",
    price: 900,
    description:
      "Una silhouette senza tempo, interpretata da AMG. Presenza, spazio e prestazioni per un viaggio fuori dall’ordinario. Dati riferiti alla versione 2018.",
    image: "/demos/velar/cars/g63.webp",
    color: "#7d8381",
    shape: 5,
    source: "https://media.mercedes-benz.com/",
  },
];
