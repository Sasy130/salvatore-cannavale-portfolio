export const services = [
  {
    slug: "luxury-rental",
    title: "Luxury Car Rental",
    image: "/demos/velar/cars/revuelto.webp",
    alt: "Lamborghini Revuelto",
    description:
      "Il piacere di scegliere un’icona e immaginare un viaggio diverso. La collezione riunisce sei interpretazioni del lusso e della performance.",
    features: [
      "Selezione della vettura",
      "Date e località personalizzate",
      "Preferenze per l’itinerario",
    ],
  },
  {
    slug: "chauffeur",
    title: "Chauffeur Service",
    image: "/demos/velar/cars/cullinan-cabin-access.webp",
    alt: "Accesso ai sedili posteriori di una Rolls-Royce Cullinan",
    description:
      "Un concept dedicato a chi desidera vivere il viaggio dal sedile posteriore. Autista, abilitazioni e coperture saranno da verificare prima di offrire il servizio.",
    features: [
      "Preferenze a bordo",
      "Itinerario da concordare",
      "Autista e disponibilità da confermare",
    ],
  },
  {
    slug: "airport-transfer",
    title: "Airport Transfer",
    image: "/demos/velar/cars/g63.webp",
    alt: "Mercedes-AMG G 63",
    description:
      "Arrivi e partenze pensati come parte dell’esperienza. Indica aeroporto, orari, passeggeri e bagagli per preparare un brief dimostrativo.",
    features: [
      "Aeroporto e volo nel brief",
      "Esigenze di bagaglio",
      "Orari e punto d’incontro da definire",
    ],
  },
  {
    slug: "wedding",
    title: "Wedding Experience",
    image: "/demos/velar/cars/296-gtb.webp",
    alt: "Ferrari 296 GTB",
    description:
      "Una presenza speciale per un giorno personale. Un’idea di esperienza da comporre intorno allo stile dell’evento, senza pacchetti o disponibilità presunti.",
    features: [
      "Vettura preferita",
      "Luoghi e programma",
      "Allestimenti da concordare",
    ],
  },
  {
    slug: "private-events",
    title: "Private Events",
    image: "/demos/velar/cars/750s.webp",
    alt: "McLaren 750S esposta a un evento automotive",
    description:
      "Un’occasione privata, un incontro o una presentazione. Il concept raccoglie esigenze organizzative e riferimenti estetici per una proposta futura.",
    features: [
      "Brief dell’evento",
      "Vetture e logistica da verificare",
      "Esigenze fotografiche",
    ],
  },
  {
    slug: "corporate",
    title: "Corporate Rental",
    image: "/demos/velar/cars/cullinan.webp",
    alt: "Rolls-Royce Cullinan",
    description:
      "Una proposta dimostrativa per trasferte, ospitalità e appuntamenti professionali. Contratti, fatturazione e condizioni aziendali non sono ancora configurati.",
    features: [
      "Esigenze di rappresentanza",
      "Durata e località",
      "Condizioni corporate da definire",
    ],
  },
] as const;
