import { cars } from "./cars";
export type GalleryPhoto = {
  src: string;
  alt: string;
  caption: string;
  creditSlug: string;
};
export type CarGallery = { exterior: GalleryPhoto[]; interior: GalleryPhoto[] };
export const galleries: Record<string, CarGallery> = Object.fromEntries(
  cars.map((car) => [
    car.slug,
    {
      exterior: [
        {
          src: car.image!,
          alt: car.brand + " " + car.model + " — vista esterna",
          caption: car.brand + " " + car.model + " · fotografia del modello",
          creditSlug: car.slug,
        },
      ],
      interior: [],
    },
  ]),
) as Record<string, CarGallery>;
galleries.revuelto.exterior.push({
  src: "/demos/velar/cars/revuelto-rear.webp",
  alt: "Lamborghini Revuelto — vista posteriore",
  caption: "Revuelto · vista posteriore",
  creditSlug: "revuelto-rear",
});
galleries.revuelto.interior.push({
  src: "/demos/velar/cars/hero.webp",
  alt: "Lamborghini Revuelto — volante e consolle",
  caption: "Revuelto · posto guida e consolle centrale",
  creditSlug: "hero",
});
galleries["296-gtb"].exterior.push({
  src: "/demos/velar/cars/296-gtb-rear.webp",
  alt: "Ferrari 296 GTB Assetto Fiorano — vista posteriore",
  caption: "296 GTB con pacchetto Assetto Fiorano · allestimento illustrativo",
  creditSlug: "296-gtb-rear",
});
galleries.cullinan.interior.push({
  src: "/demos/velar/cars/cullinan-cabin-access.webp",
  alt: "Rolls-Royce Cullinan 2018 — accesso ai sedili posteriori",
  caption: "Cullinan 2018 · accesso abitacolo posteriore, vista parziale",
  creditSlug: "cullinan-cabin-access",
});
galleries.g63.exterior.push({
  src: "/demos/velar/cars/g63-rear.webp",
  alt: "Mercedes-AMG G 63 2018 — vista posteriore",
  caption: "G 63 · versione 2018, vista posteriore",
  creditSlug: "g63-rear",
});
export const highlights: Record<string, string[]> = {
  revuelto: ["V12 aspirato", "Sistema ibrido plug-in", "Tre motori elettrici"],
  "296-gtb": ["V6 biturbo", "Sistema ibrido plug-in", "Berlinetta a due posti"],
  cullinan: [
    "V12 biturbo",
    "SUV ultra-luxury",
    "Abitacolo posteriore raffinato",
  ],
  "750s": ["V8 biturbo", "Coupé ad alte prestazioni", "Architettura leggera"],
  "911-gt3-rs": [
    "Sei cilindri aspirato",
    "Aerodinamica attiva",
    "Ispirazione motorsport",
  ],
  g63: [
    "V8 biturbo AMG",
    "SUV ad alte prestazioni",
    "Versione di riferimento 2018",
  ],
};

galleries.cullinan.interior.push({
  src: "/demos/velar/cars/cullinan-interior-2.webp",
  alt: "Rolls-Royce Cullinan 2018 — sedili e tavolino posteriori",
  caption: "Cullinan 2018 · dettagli dell’abitacolo posteriore",
  creditSlug: "cullinan-interior-2",
});
