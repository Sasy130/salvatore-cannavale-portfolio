/** Per-car photographic framing and direction; all six share the same motion grammar. */
export type CinematicPreset = {
  id: string;
  keyPosition: number;
  target: [number, number];
  mobileTarget: [number, number];
  truck: number;
  pedestal: number;
  dolly: number;
  light: string;
  connection: number;
};
export const cinematics: Record<string, CinematicPreset> = {
  revuelto: {
    id: "revuelto",
    keyPosition: 0,
    target: [59, 55],
    mobileTarget: [57, 52],
    truck: 24,
    pedestal: -8,
    dolly: 1.045,
    light: "#d8decd",
    connection: 1.1,
  },
  "296-gtb": {
    id: "296-gtb",
    keyPosition: 1,
    target: [57, 54],
    mobileTarget: [56, 52],
    truck: 14,
    pedestal: -6,
    dolly: 1.04,
    light: "#dcd5cd",
    connection: 1.04,
  },
  cullinan: {
    id: "cullinan",
    keyPosition: 2,
    target: [61, 53],
    mobileTarget: [57, 51],
    truck: 5,
    pedestal: -5,
    dolly: 1.028,
    light: "#d9dce1",
    connection: 1.25,
  },
  "750s": {
    id: "750s",
    keyPosition: 3,
    target: [57, 55],
    mobileTarget: [58, 51],
    truck: -6,
    pedestal: -8,
    dolly: 1.045,
    light: "#e0d8c9",
    connection: 1.03,
  },
  "911-gt3-rs": {
    id: "911-gt3-rs",
    keyPosition: 4,
    target: [59, 52],
    mobileTarget: [56, 52],
    truck: -16,
    pedestal: -7,
    dolly: 1.036,
    light: "#dadfd6",
    connection: 1.08,
  },
  g63: {
    id: "g63",
    keyPosition: 5,
    target: [59, 51],
    mobileTarget: [58, 51],
    truck: -24,
    pedestal: -5,
    dolly: 1.028,
    light: "#d6dbe0",
    connection: 1.18,
  },
};
